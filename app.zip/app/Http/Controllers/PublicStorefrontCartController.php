<?php

namespace App\Http\Controllers;

use App\Models\Customers;
use App\Models\ClothColor;
use App\Models\Storefront;
use App\Models\StorefrontCart;
use App\Models\StorefrontClothingListing;
use App\Rules\PakistanMobileNumber;
use App\Rules\SecureCustomerPin;
use App\Rules\UniqueCustomerPhone;
use App\Services\StorefrontCartService;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class PublicStorefrontCartController extends Controller
{
    public function show(Request $request, Storefront $storefront, StorefrontCartService $cartService)
    {
        $this->ensureVisible($storefront);
        $cart = $cartService->find($storefront, $request->session()->get($this->sessionKey($storefront)));
        $cart?->load([
            'customer', 'items.listing.cloth.brand', 'items.listing.cloth.type', 'items.color',
            'tailoringItems.service', 'tailoringItems.measurementTemplate',
            'tailoringItems.clothingItem.listing.cloth.brand', 'tailoringItems.clothingItem.listing.cloth.type',
        ]);

        return view('storefront.public.cart', compact('storefront', 'cart'));
    }

    public function store(
        Request $request,
        Storefront $storefront,
        StorefrontClothingListing $listing,
        StorefrontCartService $cartService
    ) {
        $this->ensureVisible($storefront);
        abort_unless($storefront->show_clothing && $storefront->clothingOrderingEnabled()
            && $storefront->business->clothing_enabled, 404);
        abort_unless(
            $listing->storefront_id === $storefront->id
            && $listing->is_published
            && $listing->acceptsOnlineOrders()
            && (int) $listing->cloth?->user_id === (int) $storefront->business->owner_user_id,
            404
        );
        $validated = $request->validate([
            'cloth_color_id' => ['required', 'integer'],
            'selected_color' => ['nullable', 'string', 'max:100'],
            'quantity' => ['required', 'numeric', 'min:0.01', 'max:1000'],
            'purchase_mode' => ['nullable', Rule::in(['fabric_only', 'fabric_and_stitching'])],
        ]);
        $this->ensureValidQuantity($listing, (float) $validated['quantity']);
        $color = $listing->cloth->colors()->findOrFail($validated['cloth_color_id']);
        $selectedColor = $this->selectedColor($listing, $color, $validated['selected_color'] ?? null);
        [$cart, $plainToken] = $cartService->getOrCreate(
            $storefront,
            $request->session()->get($this->sessionKey($storefront))
        );
        $cartItem = $cartService->reserve($cart, $listing, $color, round((float) $validated['quantity'], 2), $selectedColor);
        $request->session()->put($this->sessionKey($storefront), $plainToken);

        if (($validated['purchase_mode'] ?? 'fabric_only') === 'fabric_and_stitching'
            && $storefront->show_tailoring
            && $storefront->tailoringInquiriesEnabled()
            && $storefront->business->tailoring_enabled
            && $storefront->tailoringServices()->where('is_published', true)->where('is_available', true)
                ->where('accepts_inquiries', true)->whereNotNull('price_from')->exists()) {
            return redirect()->route('storefront.tailoring.index', [
                $storefront,
                'cloth_item' => $cartItem->id,
            ])->with('success', __('storefront.messages.fabric_reserved_choose_stitching'));
        }

        return redirect()->route('storefront.cart.show', $storefront)
            ->with('success', __('storefront.messages.cart_reserved'));
    }

    public function update(
        Request $request,
        Storefront $storefront,
        int $item,
        StorefrontCartService $cartService
    ) {
        $this->ensureVisible($storefront);
        $cart = $this->cartOrFail($request, $storefront, $cartService);
        $cartItem = $cart->items()->with(['listing.cloth', 'color'])->findOrFail($item);
        $validated = $request->validate([
            'quantity' => ['required', 'numeric', 'min:0.01', 'max:1000'],
        ]);
        abort_unless($cartItem->listing?->acceptsOnlineOrders(), 404);
        $this->ensureValidQuantity($cartItem->listing, (float) $validated['quantity']);
        $cartService->reserve(
            $cart,
            $cartItem->listing,
            $cartItem->color,
            round((float) $validated['quantity'], 2),
            $cartItem->selected_color,
        );

        return redirect()->route('storefront.cart.show', $storefront)
            ->with('success', __('storefront.messages.cart_updated'));
    }

    private function ensureValidQuantity(StorefrontClothingListing $listing, float $quantity): void
    {
        if (! $listing->acceptsQuantity($quantity)) {
            throw ValidationException::withMessages([
                'quantity' => __('storefront.messages.invalid_product_quantity', [
                    'min' => number_format($listing->minimumOrderQuantity(), 2),
                    'max' => number_format($listing->maximumOrderQuantity(), 2),
                    'step' => number_format($listing->orderIncrement(), 2),
                ]),
            ]);
        }
    }

    private function selectedColor(StorefrontClothingListing $listing, ClothColor $stock, ?string $requested): string
    {
        $cloth = $listing->cloth;
        if ($cloth->tracksColors()) {
            return $stock->color;
        }
        if (! $cloth->usesDisplayOnlyColors()) {
            return '';
        }

        $requested = trim((string) $requested);
        if ($requested === '' || ! in_array($requested, $cloth->selectableColorNames(), true)) {
            throw ValidationException::withMessages([
                'selected_color' => __('storefront.messages.select_valid_color'),
            ]);
        }

        abort_unless((int) $stock->id === (int) $cloth->colors()->value('id'), 422);

        return $requested;
    }

    public function destroy(
        Request $request,
        Storefront $storefront,
        int $item,
        StorefrontCartService $cartService
    ) {
        $this->ensureVisible($storefront);
        $cart = $this->cartOrFail($request, $storefront, $cartService);
        abort_unless($cart->items()->whereKey($item)->exists(), 404);
        $cartService->remove($cart, $item);

        return redirect()->route('storefront.cart.show', $storefront)
            ->with('success', __('storefront.messages.cart_removed'));
    }

    public function linkCustomer(
        Request $request,
        Storefront $storefront,
        StorefrontCartService $cartService
    ) {
        $this->ensureVisible($storefront);
        $validated = $request->validate([
            'phone' => ['required', 'string', 'max:50'],
            'pin' => ['required', 'digits:6'],
        ]);
        $cart = $this->cartOrFail($request, $storefront, $cartService);
        $result = DB::transaction(function () use ($validated, $storefront, $cart) {
            $matched = Customers::findByPhoneForOwner(
                $storefront->business->owner_user_id,
                $validated['phone']
            );
            $customer = $matched
                ? Customers::query()->whereKey($matched->id)->lockForUpdate()->first()
                : null;
            if ($customer?->pin_locked_until?->isFuture()) {
                return 'locked';
            }
            if (! $customer || ! $customer->mobile_pin || ! Hash::check($validated['pin'], $customer->mobile_pin)) {
                if ($customer) {
                    $attempts = min(255, (int) $customer->pin_failed_attempts + 1);
                    $customer->forceFill([
                        'pin_failed_attempts' => $attempts,
                        'pin_locked_until' => $attempts >= 5 ? now()->addMinutes(15) : null,
                    ])->save();
                }

                return 'invalid';
            }
            $customer->forceFill(['pin_failed_attempts' => 0, 'pin_locked_until' => null])->save();
            $cart->update(['customer_id' => $customer->id, 'last_activity_at' => now()]);

            return 'linked';
        });
        if ($result !== 'linked') {
            throw ValidationException::withMessages([
                'phone' => $result === 'locked'
                    ? __('storefront.messages.identity_locked')
                    : __('storefront.messages.identity_invalid'),
            ]);
        }

        return redirect()->route('storefront.cart.show', $storefront)
            ->with('success', __('storefront.messages.identity_linked'));
    }

    public function unlinkCustomer(
        Request $request,
        Storefront $storefront,
        StorefrontCartService $cartService
    ) {
        $this->ensureVisible($storefront);
        $cart = $this->cartOrFail($request, $storefront, $cartService);
        $cart->update(['customer_id' => null, 'last_activity_at' => now()]);

        return redirect()->route('storefront.cart.show', $storefront);
    }

    public function registerCustomer(
        Request $request,
        Storefront $storefront,
        StorefrontCartService $cartService
    ) {
        $this->ensureVisible($storefront);
        $ownerId = (int) $storefront->business->owner_user_id;
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'phone' => [
                'required',
                'string',
                'max:50',
                new PakistanMobileNumber,
                new UniqueCustomerPhone(
                    $ownerId,
                    message: __('storefront.messages.phone_exists')
                ),
            ],
            'pin' => ['required', 'digits:6', 'confirmed', new SecureCustomerPin],
        ]);
        $cart = $this->cartOrFail($request, $storefront, $cartService);

        try {
            DB::transaction(function () use ($validated, $ownerId, $storefront, $cart) {
                $lockedCart = StorefrontCart::query()
                    ->whereKey($cart->id)
                    ->where('storefront_id', $storefront->id)
                    ->whereNull('checked_out_at')
                    ->where('expires_at', '>', now())
                    ->lockForUpdate()
                    ->first();

                if (! $lockedCart || ! $lockedCart->hasOrderableItems()) {
                    throw ValidationException::withMessages([
                        'registration' => __('storefront.messages.cart_unavailable'),
                    ]);
                }

                $customer = new Customers([
                    'user_id' => $ownerId,
                    'name' => trim($validated['name']),
                    'phone_number1' => trim($validated['phone']),
                ]);
                $customer->forceFill([
                    'mobile_pin' => Hash::make($validated['pin']),
                    'pin_changed_at' => now(),
                    'self_registered_at' => now(),
                    'phone_verified_at' => null,
                ])->save();

                $lockedCart->update([
                    'customer_id' => $customer->id,
                    'last_activity_at' => now(),
                ]);
            });
        } catch (QueryException $exception) {
            if (! in_array((string) $exception->getCode(), ['23000', '23505'], true)) {
                throw $exception;
            }

            throw ValidationException::withMessages([
                'phone' => __('storefront.messages.phone_exists'),
            ]);
        }

        return redirect()->route('storefront.cart.show', $storefront)
            ->with('success', __('storefront.messages.registration_linked'));
    }

    private function cartOrFail(Request $request, Storefront $storefront, StorefrontCartService $cartService): StorefrontCart
    {
        $cart = $cartService->find($storefront, $request->session()->get($this->sessionKey($storefront)));
        abort_unless($cart, 404);

        return $cart;
    }

    private function ensureVisible(Storefront $storefront): void
    {
        abort_unless(
            $storefront->is_published
            && $storefront->isModerationActive()
            && $storefront->business?->isActive()
            && (($storefront->show_clothing && $storefront->clothingOrderingEnabled() && $storefront->business->clothing_enabled)
                || ($storefront->show_tailoring && $storefront->tailoringInquiriesEnabled() && $storefront->business->tailoring_enabled)),
            404
        );
    }

    private function sessionKey(Storefront $storefront): string
    {
        return 'storefront_cart_token_'.$storefront->id;
    }
}
