<?php

namespace App\Http\Controllers;

use App\Models\rack;
use App\Models\Business;
use App\Models\BusinessRole;
use App\Models\CounterOrderItem;
use App\Models\Order;
use App\Models\OrderStatusHistory;
use PhpOption\Option;
use App\Models\Design;
use App\Models\Tailor;
use App\Models\Options;
use App\Models\Setting;
use App\Models\Customers;
use App\Models\OptionType;
use App\Models\Transaction;
use App\Models\Tailorsalary;
use App\Models\MeasurementTemplate;
use App\Models\ProductionWorker;
use Illuminate\Http\Request;
use App\Events\NotificationEvent;
use App\Events\CompleteOrderEvent;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use App\Notifications\NewOrderNotification;
use Illuminate\Support\Facades\Notification;
use App\Notifications\OrderCompleteNotification;
use App\Services\MeasurementService;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use App\Services\ProductionWorkforceService;
use App\Services\CustomerLedgerService;
use App\Support\PaymentMethods;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;


class OrderController extends Controller
{
    public function __construct(
        private MeasurementService $measurements,
        private CustomerLedgerService $customerLedger
    ) {}

    public function edit($id)
    {

        $data = $this->ownedOrder($id)->load('measurementValues');
        $sub_customer = Customers::where('user_id', Auth::user()->businessOwnerId())->find($data->sub_customer);
        $customer = Customers::where('user_id', Auth::user()->businessOwnerId())->findOrFail($data->customerId);
        $tailors = Tailor::where('user_id', Auth::user()->businessOwnerId())->get();
        $currentTailor = $this->findOwnedTailor($data->tailorId);
        $missingTailor = ! empty($data->tailorId) && ! $currentTailor;
        $customerBalance = Auth::user()->hasBusinessPermission(\App\Models\BusinessRole::CUSTOMER_BALANCES)
            ? Transaction::where('userId', Auth::user()->businessOwnerId())->where("customerId", $data->customerId)->sum('remainingBalance')
            : null;
        $orderTransaction = Transaction::where('userId', Auth::user()->businessOwnerId())
            ->where('customerId', $data->customerId)->where('orderId', $data->id)->first();
        $recivedPayment = $orderTransaction?->recivedPayment ?? 0;
        $orderBalance = $orderTransaction?->remainingBalance ?? max(0, (float) $data->totalPayment - (float) $recivedPayment);
        $tailorRates = $currentTailor
            ? Tailorsalary::with('options')->where('tailor_id', $currentTailor->id)->get()
            : collect();
        $measurementCustomer = $sub_customer ?: $customer;
        $canChangeMeasurementProfile = $data->status === 'unassigned' && ! $data->tailorId;
        $measurementFields = $this->measurements->fieldsForTemplate(
            $this->measurements->activeFields(Auth::user()->businessOwnerId()),
            $data->measurementTemplate,
        );
        $measurementSystemKeys = $data->measurementTemplate
            ? collect($data->measurementTemplate->system_fields ?? [])
            ->filter(fn($key) => array_key_exists($key, MeasurementService::SYSTEM_FIELDS))
            ->values()
            : collect(array_keys(MeasurementService::SYSTEM_FIELDS));
        $useLatestMeasurements = request()->boolean('latest_measurements');
        $savedMeasurementValues = $useLatestMeasurements
            ? collect()
            : $data->measurementValues->keyBy('source_key');
        $customerCustomValues = $measurementCustomer->measurementValues()
            ->whereIn('measurement_field_id', $measurementFields->pluck('id'))
            ->pluck('value', 'measurement_field_id');
        $preferenceOptions = OptionType::query()
            ->whereIn('type', ['necktype', 'sleeve', 'daaman', 'jeab', 'swingtype', 'button', 'plate_type'])
            ->with(['options' => fn($query) => $query
                ->where('user_id', Auth::user()->businessOwnerId())
                ->where('measurement_template_id', $data->measurement_template_id)
                ->orderBy('Name')])
            ->get()
            ->mapWithKeys(fn(OptionType $type) => [
                $type->type === 'daaman' ? 'Daaman' : $type->type => $type->options,
            ]);
        $data['design'] = Options::where('option_id', 1)->get();
        // $currentTailorRate = 1220;
        return view('order.edit', compact(
            'data',
            'tailors',
            'tailorRates',
            'customerBalance',
            'orderBalance',
            'recivedPayment',
            'sub_customer',
            'customer',
            'measurementCustomer',
            'measurementFields',
            'savedMeasurementValues',
            'customerCustomValues',
            'preferenceOptions',
            'useLatestMeasurements',
            'measurementSystemKeys',
            'canChangeMeasurementProfile',
            'missingTailor'
        ));
    }

    public function update(Request $request, $id)
    {
        $order = $this->ownedOrder($id);
        $canChangeMeasurementProfile = $order->status === 'unassigned' && ! $order->tailorId;
        $measurementFields = $this->measurements->fieldsForTemplate(
            $this->measurements->activeFields(Auth::user()->businessOwnerId()),
            $order->measurementTemplate,
        );
        $measurementSystemKeys = $order->measurementTemplate
            ? collect($order->measurementTemplate->system_fields ?? [])
            ->filter(fn($key) => array_key_exists($key, MeasurementService::SYSTEM_FIELDS))
            ->values()
            : collect(array_keys(MeasurementService::SYSTEM_FIELDS));
        $measurementRules = [
            'system_measurements' => ['nullable', 'array'],
            'custom_measurements' => ['nullable', 'array'],
        ];
        foreach ($measurementSystemKeys as $key) {
            $meta = MeasurementService::SYSTEM_FIELDS[$key];
            $measurementRules['system_measurements.' . $key] = $meta['unit'] === 'inch'
                ? ['nullable', 'numeric', 'min:0']
                : ['nullable', 'string', 'max:500'];
        }
        foreach ($measurementFields as $field) {
            $fieldRules = ['nullable'];
            if ($field->field_type === 'number') {
                array_push($fieldRules, 'numeric', 'min:0');
            } elseif ($field->field_type === 'select') {
                $fieldRules[] = Rule::in($field->options ?? []);
            } else {
                array_push($fieldRules, 'string', 'max:500');
            }
            $measurementRules['custom_measurements.' . $field->id] = $fieldRules;
        }

        $validated = $request->validate(array_merge([
            'sub_id' => ['nullable', 'integer'],
            'customerId' => ['required', 'integer'],
            'suitQuantity' => ['required', 'integer', 'min:1'],
            'totalPayment' => ['required', 'numeric', 'min:0'],
            'recivedPayment' => ['required', 'numeric', 'min:0', 'lte:totalPayment'],
            'payment_method' => ['nullable', Rule::in(array_keys(PaymentMethods::LABELS))],
            'payment_reference' => [
                Rule::requiredIf(fn() => PaymentMethods::requiresReference($request->input('payment_method'))),
                'nullable',
                'string',
                'max:255',
            ],
            'paid_on' => ['nullable', 'date'],
            'tailorId' => [Rule::requiredIf((bool) $order->tailorId), 'nullable', 'integer'],
            'tailor_price' => [Rule::requiredIf(fn() => $request->filled('tailorId')), 'nullable', 'regex:/^\d+-.+$/', 'max:255'],
            'returnDate' => ['required', 'date'],
            'remarks' => ['nullable', 'string', 'max:1000'],
            'return_to_statement' => ['nullable', 'boolean'],
            'return_customer' => ['nullable', 'integer'],
            'return_search' => ['nullable', 'string', 'max:200'],
            'return_to_orders' => ['nullable', 'integer'],
            'save_measurements_to_profile' => ['nullable', 'boolean'],
        ], $measurementRules), [
            'recivedPayment.lte' => 'وصول رقم کل قیمت سے زیادہ نہیں ہو سکتی۔',
        ], $this->measurements->attributes($measurementFields));

        $customer = $this->ownedCustomer($validated['customerId']);
        $tailor = ! empty($validated['tailorId']) ? $this->ownedTailor($validated['tailorId']) : null;
        if (!empty($validated['sub_id'])) {
            $this->ownedCustomer($validated['sub_id']);
        }

        if (
            ! $canChangeMeasurementProfile
            && (int) ($validated['sub_id'] ?? $order->sub_customer) !== (int) $order->sub_customer
        ) {
            throw ValidationException::withMessages([
                'sub_id' => 'درزی مقرر ہونے کے بعد آرڈر کا ناپ والا فرد تبدیل نہیں کیا جا سکتا۔',
            ]);
        }

        //new change
        $rateId = null;
        $tailorPrice = 0;
        if ($tailor) {
            [$rateId] = explode('-', $validated['tailor_price'], 2);
            $tailorRate = Tailorsalary::where('tailor_id', $tailor->id)->findOrFail($rateId);
            $tailorPrice = $tailorRate->price;
        }
        $remainingBalance = max(0, $validated['totalPayment'] - $validated['recivedPayment']);

        $measurementCustomerId = $canChangeMeasurementProfile
            ? ($validated['sub_id'] ?? $validated['customerId'])
            : $order->sub_customer;
        $measurementChanged = (int) $order->sub_customer !== (int) $measurementCustomerId;
        $measurementCustomer = $this->ownedCustomer($measurementCustomerId);
        if ($measurementChanged) {
            $this->ensureRequiredMeasurements($measurementCustomer, $order->measurementTemplate);
        }

        DB::transaction(function () use ($validated, $order, $tailor, $rateId, $tailorPrice, $remainingBalance, $measurementChanged, $measurementCustomer, $measurementFields, $measurementSystemKeys, $canChangeMeasurementProfile) {
            $wasUnassigned = $order->status === 'unassigned' && ! $order->tailorId;
            $order->update([
                "sub_customer" => $canChangeMeasurementProfile
                    ? ($validated['sub_id'] ?? $validated['customerId'])
                    : $order->sub_customer,
                "customerId" => $validated['customerId'],
                "suitQuantity" => $validated['suitQuantity'],
                "totalPayment" => $validated['totalPayment'],
                "tailorId" => $tailor?->id,
                "rateId" => $rateId,
                "tailor_price" => $tailorPrice,
                "userId" => Auth::user()->businessOwnerId(),
                "returnDate" => $validated['returnDate'],
                "remarks" => $validated['remarks'] ?? null,
                "suitNum" => $measurementChanged
                    ? (string) ($measurementCustomer->serial_number ?? $measurementCustomer->id)
                    : $order->suitNum,
                "status" => $order->status === 'unassigned' && $tailor ? 'assigned' : $order->status,
                "status_changed_at" => $wasUnassigned && $tailor ? now() : $order->status_changed_at,
            ]);

            if ($wasUnassigned && $tailor) {
                OrderStatusHistory::create([
                    'order_id' => $order->id,
                    'user_id' => Auth::id(),
                    'tailor_id' => $tailor->id,
                    'from_status' => 'unassigned',
                    'to_status' => 'assigned',
                    'changed_by_type' => 'shop_owner',
                    'note' => 'آرڈر میں ترمیم کے دوران درزی مقرر کیا گیا۔',
                ]);
            }

            Transaction::updateOrCreate(
                ['orderId' => $order->id, 'userId' => Auth::user()->businessOwnerId()],
                [
                    "recivedPayment" => $validated['recivedPayment'],
                    "remainingBalance" => $remainingBalance,
                    "Order_type" => 'Tailor',
                    "customerId" => $validated['customerId'],
                ]
            );

            if ($measurementChanged) {
                $this->measurements->snapshotOrder($order, $measurementCustomer);
            } else {
                foreach ($measurementSystemKeys as $key) {
                    $meta = MeasurementService::SYSTEM_FIELDS[$key];
                    $value = $validated['system_measurements'][$key] ?? null;
                    $sourceKey = 'system.' . $key;
                    if ($value === null || $value === '') {
                        $order->measurementValues()->where('source_key', $sourceKey)->delete();
                        continue;
                    }
                    $order->measurementValues()->updateOrCreate(
                        ['source_key' => $sourceKey],
                        [
                            'measurement_field_id' => null,
                            'label' => $meta['label'],
                            'value' => (string) $value,
                            'unit' => $meta['unit'],
                            'sort_order' => array_search($key, array_keys(MeasurementService::SYSTEM_FIELDS), true),
                        ]
                    );
                }
                foreach ($measurementFields as $field) {
                    $value = $validated['custom_measurements'][$field->id] ?? null;
                    $sourceKey = 'custom.' . $field->id;
                    if ($value === null || $value === '') {
                        $order->measurementValues()->where('source_key', $sourceKey)->delete();
                        continue;
                    }
                    $order->measurementValues()->updateOrCreate(
                        ['source_key' => $sourceKey],
                        [
                            'measurement_field_id' => $field->id,
                            'label' => $field->label,
                            'value' => (string) $value,
                            'unit' => $field->unit,
                            'sort_order' => 1000 + (int) $field->sort_order,
                        ]
                    );
                }

                $preferenceSourceKeys = collect(['necktype', 'sleeve', 'Daaman', 'jeab', 'swingtype', 'button', 'plate_type'])
                    ->map(fn($key) => 'system.' . $key);
                $order->measurementValues()
                    ->whereIn('source_key', $preferenceSourceKeys)
                    ->where('value', '0')
                    ->delete();

                if (! empty($validated['save_measurements_to_profile'])) {
                    $this->measurements->syncCustomerFromOrder(
                        $measurementCustomer,
                        Auth::user()->businessOwnerId(),
                        $measurementFields,
                        $validated['system_measurements'] ?? [],
                        $validated['custom_measurements'] ?? [],
                        $order->measurementTemplate,
                        Auth::id(),
                    );
                }
            }
            app(ProductionWorkforceService::class)->syncOrder($order->fresh());
        });

        $returnToStatement = (bool) ($validated['return_to_statement'] ?? false);
        $returnToOrders = (int) ($validated['return_to_orders'] ?? 0);
        $returnToDirectory = (int) ($validated['return_customer'] ?? 0) === (int) $validated['customerId'];
        $returnSearch = trim((string) ($validated['return_search'] ?? ''));
        if ($returnToStatement) {
            $response = redirect()->route('admin.customers.statement', [
                'id' => $validated['customerId'],
                'tab' => 'tailoring',
            ]);
        } elseif ($returnToOrders > 0) {
            $returnCustomer = $this->ownedCustomer($returnToOrders);
            $response = redirect()->route('admin.customer.orders', $returnCustomer);
        } elseif ($returnToDirectory) {
            $response = redirect(url('admin/Customers') . '?' . http_build_query([
                'customer' => $validated['customerId'],
                'search' => $returnSearch !== '' ? $returnSearch : $customer->phone_number1,
            ]) . '#orderDetail');
        } else {
            $response = redirect('admin/Customers');
        }

        return $response->with('insert', 'آرڈر کامیابی سے اپ ڈیٹ کر دیا گیا ہے۔');
    }

    public function createOrder($id)
    {
        $customer = Customers::where('user_id', auth()->user()->businessOwnerId())
            ->findOrFail($id);
        $data = [];
        $data['customer'] = $customer;
        $data['remainingBalance'] = Auth::user()->hasBusinessPermission(\App\Models\BusinessRole::CUSTOMER_BALANCES)
            ? Transaction::where('userId', Auth::user()->businessOwnerId())->where('customerId', $id)->sum('remainingBalance')
            : null;
        $data['tailors'] = Tailor::with('tailorsalary')
            ->where('user_id', Auth::user()->businessOwnerId())->get();
        $data['hasReadyTailor'] = $data['tailors']->contains(
            fn(Tailor $tailor) => $tailor->tailorsalary->isNotEmpty()
        );
        $data['childData'] = Customers::where('parent_id', $id)->get();
        $data['design'] = Options::where('option_id', 1)->where('user_id', auth()->user()->businessOwnerId())->get();
        $data['measurementTemplates'] = MeasurementTemplate::where('user_id', auth()->user()->businessOwnerId())
            ->where('is_active', true)->orderByDesc('is_default')->orderBy('name')->get();
        $data['measurementTemplateId'] = $customer->measurement_template_id
            ?: $data['measurementTemplates']->firstWhere('is_default', true)?->id;

        $requestedProfileId = (int) old('sub_id', request('profile', $customer->id));
        $data['selectedMeasurementProfile'] = Customers::where('user_id', auth()->user()->businessOwnerId())
            ->whereKey($requestedProfileId)
            ->where(function ($query) use ($customer) {
                $query->whereKey($customer->id)->orWhere('parent_id', $customer->id);
            })
            ->first() ?: $customer;

        $data['measurementTemplateRequirements'] = $data['measurementTemplates']->mapWithKeys(
            fn(MeasurementTemplate $template) => [
                $template->id => $this->measurements->missingRequiredMeasurements(
                    $data['selectedMeasurementProfile'],
                    auth()->user()->businessOwnerId(),
                    $template,
                )->all(),
            ]
        );

        // Display the shop-scoped customer serial while keeping IDs for relationships.
        $data['serialNumber'] = $data['selectedMeasurementProfile']->serial_number
            ?? $data['selectedMeasurementProfile']->id;
        return view('order.create', compact('data'));
    }

    public function insert(Request $req)
    {
        $validated = $req->validate([
            'customerId' => ['required', 'integer'],
            'sub_id' => ['nullable', 'integer'],
            'suitQuantity' => ['required', 'integer', 'min:1'],
            'totalPayment' => ['required', 'numeric', 'min:0'],
            'recivedPayment' => ['required', 'numeric', 'min:0', 'lte:totalPayment'],
            'balance' => ['nullable', 'numeric', 'min:0'],
            'returnDate' => ['required', 'date'],
            'design' => ['nullable', 'string', 'max:255'],
            'designPrice' => ['nullable', 'numeric', 'min:0'],
            'tailorId' => ['nullable', 'integer'],
            'tailor_price' => [Rule::requiredIf(fn() => $req->filled('tailorId')), 'nullable', 'regex:/^\d+-.+$/', 'max:255'],
            'remarks' => ['nullable', 'string', 'max:1000'],
            'measurement_template_id' => ['nullable', 'integer', Rule::exists('measurement_templates', 'id')
                ->where('user_id', Auth::user()->businessOwnerId())->where('is_active', true)],
        ], [
            'recivedPayment.lte' => 'وصول رقم کل قیمت سے زیادہ نہیں ہو سکتی۔',
        ]);

        $this->ownedCustomer($validated['customerId']);
        $tailor = ! empty($validated['tailorId']) ? $this->ownedTailor($validated['tailorId']) : null;
        if (!empty($validated['sub_id'])) {
            $this->ownedCustomer($validated['sub_id']);
        }

        $rateId = null;
        $tailorPrice = 0;
        if ($tailor) {
            [$rateId] = explode('-', $validated['tailor_price'], 2);
            $tailorRate = Tailorsalary::where('tailor_id', $tailor->id)->findOrFail($rateId);
            $tailorPrice = $tailorRate->price;
        }
        $remainingBalance = round((float) $validated['totalPayment'] - (float) $validated['recivedPayment'], 2);
        $designParts = explode('-', $validated['design'] ?? '', 2);
        $subCustomerId = $validated['sub_id'] ?? $validated['customerId'];

        $measurementCustomer = $this->ownedCustomer($subCustomerId);
        $measurementTemplate = ! empty($validated['measurement_template_id'])
            ? MeasurementTemplate::where('user_id', Auth::user()->businessOwnerId())->findOrFail($validated['measurement_template_id'])
            : ($measurementCustomer->measurementTemplate
                ?: MeasurementTemplate::where('user_id', Auth::user()->businessOwnerId())
                ->where('is_active', true)
                ->where('is_default', true)
                ->first());
        $this->ensureRequiredMeasurements($measurementCustomer, $measurementTemplate);
        [$obj, $transaction] = DB::transaction(function () use ($validated, $tailor, $rateId, $tailorPrice, $remainingBalance, $designParts, $subCustomerId, $measurementCustomer, $measurementTemplate) {
            $obj = Order::create([
                'customerId' => $validated['customerId'],
                'sub_customer' => $subCustomerId,
                'measurement_template_id' => $measurementTemplate?->id,
                'suitQuantity' => $validated['suitQuantity'],
                'totalPayment' => $validated['totalPayment'],
                'returnDate' => $validated['returnDate'],
                'design' => $designParts[0] ?: 0,
                'tailorId' => $tailor?->id,
                'rateId' => $rateId,
                'userId' => Auth::user()->businessOwnerId(),
                'remarks' => $validated['remarks'] ?? null,
                'tailor_price' => $tailorPrice,
                'suitNum' => (string) ($measurementCustomer->serial_number ?? $measurementCustomer->id),
                'designPrice' => $validated['designPrice'] ?? 0,
                'status' => $tailor ? 'assigned' : 'unassigned',
                'status_changed_at' => now(),
                'tailor_paid_amount' => 0,
                'tailor_payment_status' => 'unpaid',
            ]);

            $transaction = Transaction::create([
                'recivedPayment' => $validated['recivedPayment'],
                'remainingBalance' => $remainingBalance,
                'orderId' => $obj->id,
                'customerId' => $validated['customerId'],
                'userId' => Auth::user()->businessOwnerId(),
                'Order_type' => 'Tailor',
                'payment_method' => $validated['payment_method'] ?? 'cash',
                'payment_reference' => $validated['payment_reference'] ?? null,
                'paid_on' => $validated['paid_on'] ?? now()->toDateString(),
            ]);

            $this->measurements->snapshotOrder($obj, $measurementCustomer, $measurementTemplate);
            app(ProductionWorkforceService::class)->syncOrder($obj);

            return [$obj, $transaction];
        });

        $Id = $obj->id;

        // find shop
        $setting = Setting::where('user_id', $obj->userId)->first();

        // Create the notification
        $notification = new NewOrderNotification($obj, $transaction, $setting);

        $customer = $this->ownedCustomer($validated['customerId']);
        // dd($customer);

        // Notify the user (adjust the 'user' to the correct user model)
        try {
            Notification::send($customer, $notification);
        } catch (\Throwable $exception) {
            Log::warning('Order created but customer notification failed.', [
                'order_id' => $obj->id,
                'error' => $exception->getMessage(),
            ]);
        }

        // event(new NotificationEvent("You have notification from {$setting->name}"));

        return redirect(url('/admin/order/print/' . $Id));
    }

    public function getCustomer(Request $req)
    {
        try {
            $validated = $req->validate([
                'id' => ['required', 'integer'],
                'profile_id' => ['nullable', 'integer'],
            ]);
            $accountCustomer = $this->ownedCustomer((int) $validated['id']);
            if ($accountCustomer->parent_id !== null) {
                $accountCustomer = $this->ownedCustomer((int) $accountCustomer->parent_id);
            }
            $id = $accountCustomer->id;
            $profileId = null;
            if (! empty($validated['profile_id'])) {
                $profile = $this->ownedCustomer((int) $validated['profile_id']);
                abort_unless(
                    (int) $profile->id === (int) $accountCustomer->id
                        || (int) $profile->parent_id === (int) $accountCustomer->id,
                    404
                );
                $profileId = $profile->id;
            }
            $Orders = DB::table('orders')
                ->leftJoin('tailors', 'orders.tailorId', '=', 'tailors.id')
                ->select('orders.*', 'tailors.name as tailor_name')
                ->where('orders.customerId', $id)
                ->where('orders.userId', Auth::user()->businessOwnerId())
                ->when($profileId, function ($query) use ($profileId, $accountCustomer) {
                    if ($profileId === $accountCustomer->id) {
                        $query->where(function ($rootOrders) use ($profileId) {
                            $rootOrders->where('orders.sub_customer', $profileId)
                                ->orWhereNull('orders.sub_customer')
                                ->orWhere('orders.sub_customer', 0);
                        });
                    } else {
                        $query->where('orders.sub_customer', $profileId);
                    }
                })
                ->get();
            $racks = rack::where('user_id', auth()->user()->businessOwnerId())->get();
            $detailedWorkflow = Business::tailoringStatusModeForOwner(Auth::user()->businessOwnerId())
                === Business::TAILORING_STATUS_DETAILED;
            $canViewBalances = Auth::user()->hasBusinessPermission(\App\Models\BusinessRole::CUSTOMER_BALANCES);
            $canAssignTailor = Auth::user()->hasBusinessPermission(BusinessRole::TAILORING_WORKSHOP);
            $tailorOptions = $canAssignTailor
                ? Tailor::query()
                ->with(['tailorsalary.options'])
                ->where('user_id', Auth::user()->businessOwnerId())
                ->orderBy('name')
                ->get()
                ->flatMap(fn(Tailor $tailor) => $tailor->tailorsalary->map(fn(Tailorsalary $rate) => [
                    'tailorId' => (int) $tailor->id,
                    'tailorName' => $tailor->name,
                    'rateId' => (int) $rate->id,
                    'rateValue' => $rate->id . '-' . $rate->price,
                    'rateName' => $rate->options?->Name ?: ($rate->type ?: 'عام سلائی'),
                    'price' => (float) $rate->price,
                ]))
                ->values()
                ->all()
                : [];
            $orderBalances = $canViewBalances
                ? $this->customerLedger->orderBalances(Auth::user()->businessOwnerId(), (int) $id)
                : collect();

            $data = [];
            $i = 1;
            foreach ($Orders as $order) {
                $remaining = $canViewBalances
                    ? max(0, (float) $orderBalances->get((int) $order->id, (float) $order->totalPayment))
                    : null;
                $paid = $canViewBalances ? max(0, (float) $order->totalPayment - $remaining) : null;
                $paymentStatus = ! $canViewBalances ? null : match (true) {
                    $remaining <= 0 => ['key' => 'paid', 'label' => 'ادا شدہ'],
                    $paid > 0 => ['key' => 'partial', 'label' => 'جزوی ادا شدہ'],
                    default => ['key' => 'unpaid', 'label' => 'غیر ادا شدہ'],
                };
                $currentStatus = (string) ($order->status ?: 'assigned');
                $button = $detailedWorkflow
                    ? (Order::STATUS_LABELS[$currentStatus] ?? ucfirst($currentStatus))
                    : match ($currentStatus) {
                        'unassigned' => 'درزی مقرر ہونا باقی',
                        'ready' => 'تیار ہے',
                        'delivered' => 'تیار ہے',
                        default => 'کارخانے میں ہے',
                    };
                $btn = match ($currentStatus) {
                    'unassigned' => 'order-stage-unassigned',
                    'assigned', 'cutting', 'stitching', 'trial' => 'order-stage-workshop',
                    'ready' => 'order-stage-ready',
                    'delivered' => $detailedWorkflow ? 'order-stage-delivered' : 'order-stage-ready',
                    default => 'order-stage-workshop',
                };
                $data[] = [
                    'number' => $i++,
                    'totalPayment' => $order->totalPayment,
                    'paidAmount' => $paid,
                    'remainingAmount' => $remaining,
                    'paymentStatus' => $paymentStatus,
                    'canReceivePayment' => $canViewBalances && $remaining > 0,
                    'customerId' => (int) $id,
                    'created_at' => date('d-m-Y', strtotime($order->created_at)),
                    'returnDate' => date('d-m-Y', strtotime($order->returnDate)),
                    'suitQuantity' => $order->suitQuantity,
                    'tailorName' => $order->tailor_name ?: 'ابھی مقرر نہیں',
                    'canAssignTailor' => $canAssignTailor && $currentStatus === 'unassigned' && ! $order->tailorId,
                    'tailorOptions' => $canAssignTailor && $currentStatus === 'unassigned' && ! $order->tailorId
                        ? $tailorOptions
                        : [],
                    'tailorAssignmentUrl' => route('admin.tailor-jobs.assign', ['order' => $order->id]),
                    'button' => $button,
                    'btnClass' => $btn,
                    'orderId' => $order->id,
                    'rack_no' => $order->rack_no,
                    'racks' => $racks,
                    'canMarkDelivered' => ! $detailedWorkflow && $currentStatus === 'ready',
                    'isDelivered' => ! $detailedWorkflow && $currentStatus === 'delivered',
                    'nextStatuses' => $detailedWorkflow
                        ? Order::nextStatusOptionsFor($currentStatus)
                        : match ($currentStatus) {
                            'unassigned' => [],
                            'delivered' => [],
                            default => [
                                ['value' => 'start', 'label' => 'کارخانے میں ہے'],
                                ['value' => 'complete', 'label' => 'تیار ہے'],
                            ],
                        },
                ];
            }

            return response()->json($data);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function customerOrders($id)
    {
        $selectedCustomer = $this->ownedCustomer($id);
        $customer = $selectedCustomer->primaryCustomer ?? $selectedCustomer;
        $customer = $this->ownedCustomer($customer->id);
        $detailedWorkflow = Business::tailoringStatusModeForOwner(Auth::user()->businessOwnerId())
            === Business::TAILORING_STATUS_DETAILED;
        $canViewBalances = Auth::user()->hasBusinessPermission(\App\Models\BusinessRole::CUSTOMER_BALANCES);

        return view('order.orders', compact(
            'customer',
            'selectedCustomer',
            'detailedWorkflow',
            'canViewBalances'
        ));
    }



    public function print($id)
    {
        $order = $this->ownedOrder($id);
        $tailor = $this->findOwnedTailor($order->tailorId);


        $customerId = $order->customerId;

        // Find the latest order for the customer
        $orderDetail = $order->load([
            'customers',
            'measurementValues',
            'measurementTemplate:id,name,field_layout,layout_columns',
        ]);
        $printMeasurements = $this->measurements->displayValuesForOrder($orderDetail);

        // dd($orderDetail);

        [$latestBalance, $previousBalance, $orderBalance] = $this->printBalanceSummary($order);

        $setting = Setting::ensureDefaultFor(Auth::user());
        $status = "default";
        $printDocumentService = app(\App\Services\PrintDocumentService::class);
        $printConfig = $printDocumentService->make($setting, request(), 'tailor-order', $order->id);
        $trackingUrl = \Illuminate\Support\Facades\URL::signedRoute('orders.track', ['order' => $order->id]);
        $trackingQrSvg = $printDocumentService->qrSvg($trackingUrl, 180);
        $counterOrderItem = CounterOrderItem::query()
            ->where('source_record_type', 'tailoring_order')
            ->where('source_record_id', $order->id)
            ->whereHas('counterOrder', fn($query) => $query->where('user_id', Auth::user()->businessOwnerId()))
            ->first();
        $receiptSerial = $counterOrderItem?->item_serial;

        return view('order.print', compact('order', 'orderDetail', 'printMeasurements', 'setting', 'status', 'latestBalance', 'previousBalance', 'orderBalance', 'tailor', 'printConfig', 'trackingUrl', 'trackingQrSvg', 'receiptSerial'));
    }




    // public function print($id)
    // {
    //     $balance=0;

    //     $orderDetail = Order::with('transactions','tailor','customers')->find($id);

    //     $customerId=$orderDetail->customerId;

    //     $balance=Transaction::where("customerId",$customerId)->sum('remainingBalance');

    //     $setting = Setting::where('user_id',Auth::user()->businessOwnerId())->where('status',1)->first();
    //     if(!$setting)
    //     {
    //         dd("Please Activate Your Setting");
    //     }else{
    //         $status= "default";
    //         return view('order.print',compact('orderDetail','setting','status','balance'));
    //     }

    // }
    public function two_prints($id)
    {
        $order = $this->ownedOrder($id);
        $tailor = $this->findOwnedTailor($order->tailorId);


        $customerId = $order->customerId;

        // Find the latest order for the customer
        $orderDetail = $order->load([
            'customers',
            'measurementValues',
            'measurementTemplate:id,name,field_layout,layout_columns',
        ]);
        $printMeasurements = $this->measurements->displayValuesForOrder($orderDetail);

        [$latestBalance, $previousBalance, $orderBalance] = $this->printBalanceSummary($order);

        $setting = Setting::ensureDefaultFor(Auth::user());
        $status = "default";
        $printDocumentService = app(\App\Services\PrintDocumentService::class);
        $printConfig = $printDocumentService->make($setting, request(), 'tailor-order-copy', $order->id);
        $trackingUrl = \Illuminate\Support\Facades\URL::signedRoute('orders.track', ['order' => $order->id]);
        $trackingQrSvg = $printDocumentService->qrSvg($trackingUrl, 180);
        $counterOrderItem = CounterOrderItem::query()
            ->where('source_record_type', 'tailoring_order')
            ->where('source_record_id', $order->id)
            ->whereHas('counterOrder', fn($query) => $query->where('user_id', Auth::user()->businessOwnerId()))
            ->first();
        $receiptSerial = $counterOrderItem?->item_serial;
        if (request()->boolean('serial_only')) {
            $displaySerial = $receiptSerial ?? $orderDetail->customers?->serial_number
                ?? ($orderDetail->suitNum ?: $orderDetail->sub_customer);

            return view('order.serial-label', compact('displaySerial'));
        }


        return view('order.prints', compact('order', 'orderDetail', 'printMeasurements', 'setting', 'status', 'latestBalance', 'previousBalance', 'orderBalance', 'tailor', 'printConfig', 'trackingUrl', 'trackingQrSvg', 'receiptSerial'));
    }

    private function printBalanceSummary(Order $order): array
    {
        [$previousBalance, $orderBalance] = $this->customerLedger->trackingSummary($order);
        $receivedForOrder = (float) $order->transactions()->sum('recivedPayment');
        $currentOrderDue = max(0, round((float) $order->totalPayment - $receivedForOrder, 2));

        // Legacy transactions may contain the customer's previous balance inside
        // this order's balance. Limit this figure to the order's own unpaid amount
        // because older dues are displayed separately on the receipt.
        $orderBalance = min($orderBalance, $currentOrderDue);
        $latestBalance = round($previousBalance + $orderBalance, 2);

        return [
            $latestBalance,
            $previousBalance,
            $orderBalance,
        ];
    }

    public function search(Request $req)
    {
        $validated = $req->validate([
            'sub_search' => ['nullable', 'string', 'max:255'],
            'customer_id' => ['nullable', 'integer'],
        ]);
        $search = $validated['sub_search'] ?? '';
        $primaryCustomer = null;
        if (! empty($validated['customer_id'])) {
            $primaryCustomer = $this->ownedCustomer((int) $validated['customer_id']);
            if ($primaryCustomer->parent_id !== null) {
                $primaryCustomer = $this->ownedCustomer((int) $primaryCustomer->parent_id);
            }
        }
        $data = Customers::where('user_id', Auth::user()->businessOwnerId())
            ->when($primaryCustomer, fn($query) => $query->where(function ($family) use ($primaryCustomer) {
                $family->whereKey($primaryCustomer->id)
                    ->orWhere('parent_id', $primaryCustomer->id);
            }))
            ->where(function ($query) use ($search) {
                $query->where('name', 'like', '%' . $search . '%')
                    ->orWhere('phone_number1', 'like', '%' . $search . '%')
                    ->orWhere('id', 'like', '%' . $search . '%');
            })
            ->orderByRaw('parent_id is not null')
            ->orderBy('name')
            ->limit(25)
            ->get();

        return view('order.partials.measurement-profile-select', compact('data'));
    }

    public function order_status(Request $req)
    {
        $validated = $req->validate([
            'order_id' => ['required', 'integer'],
            'order_status' => ['required', 'in:new,start,complete'],
        ]);
        $obj = $this->ownedOrder($validated['order_id']);
        $obj->status = $validated['order_status'];
        $obj->save();
        return back();
    }

    public function totalOrder(Request $request)
    {
        $ownerId = Auth::user()->businessOwnerId();
        $detailedWorkflow = Business::tailoringStatusModeForOwner($ownerId) === Business::TAILORING_STATUS_DETAILED;
        $validated = $request->validate([
            'week' => ['nullable', 'date'],
            'filter' => ['nullable', Rule::in(['upcoming', 'overdue', 'ready'])],
            'search' => ['nullable', 'string', 'max:100'],
        ]);

        $filter = $validated['filter'] ?? null;
        $search = trim($validated['search'] ?? '');

        $weekStart = Carbon::parse($validated['week'] ?? now())
            ->startOfWeek(Carbon::MONDAY)
            ->startOfDay();
        $weekEnd = $weekStart->copy()->endOfWeek(Carbon::SUNDAY)->endOfDay();

        $today = today()->toDateString();

        // 1) Base query: ownership + the active filter. No eager loads here.
        $base = Order::where('userId', $ownerId)
            ->whereHas('customers', fn($query) => $query->where('user_id', $ownerId));

        if ($filter === 'upcoming') {
            $base->where('returnDate', '>=', $today)
                ->whereNotIn('status', ['ready', 'delivered']);
        } elseif ($filter === 'overdue') {
            $base->where('returnDate', '<', $today)
                ->whereNotIn('status', ['ready', 'delivered']);
        } elseif ($filter === 'ready') {
            $base->where('status', 'ready');
        } else {
            $base->whereBetween('returnDate', [$weekStart->toDateString(), $weekEnd->toDateString()]);
        }

        // 2) Apply server-side search BEFORE summary totals and pagination.
        if ($search !== '') {
            $base->where(function ($query) use ($search, $ownerId) {
                // Search by order ID when the input is numeric.
                if (ctype_digit($search)) {
                    $query->orWhere('id', (int) $search);
                }

                // Search by order number / suit number.
                $query->orWhere('suitNum', 'like', "%{$search}%");

                // Search by customer name, phone number, or serial number.
                $query->orWhereHas('customers', function ($customerQuery) use ($search, $ownerId) {
                    $customerQuery
                        ->where('user_id', $ownerId)
                        ->where(function ($customerFields) use ($search) {
                            $customerFields
                                ->where('name', 'like', "%{$search}%")
                                ->orWhere('phone_number1', 'like', "%{$search}%")
                                ->orWhere('serial_number', 'like', "%{$search}%");
                        });
                });

                // Search by tailor name.
                $query->orWhereHas('tailor', function ($tailorQuery) use ($search, $ownerId) {
                    $tailorQuery
                        ->where('user_id', $ownerId)
                        ->where('name', 'like', "%{$search}%");
                });

                // Search by measurement template / garment name.
                $query->orWhereHas('measurementTemplate', function ($templateQuery) use ($search) {
                    $templateQuery->where('name', 'like', "%{$search}%");
                });
            });
        }

        // 2) Summary cards: ONE aggregate query, no models loaded.
        $totals = (clone $base)->toBase()->selectRaw("
            count(*) as orders,
            coalesce(sum(suitQuantity), 0) as suits,
            coalesce(sum(case when status not in ('ready','delivered') then 1 else 0 end), 0) as in_workshop,
            coalesce(sum(case when status in ('ready','delivered') then 1 else 0 end), 0) as ready,
            coalesce(sum(case when status not in ('ready','delivered') and returnDate < ? then 1 else 0 end), 0) as overdue
        ", [$today])->first();

        $summary = [
            'orders'      => (int) $totals->orders,
            'suits'       => (int) $totals->suits,
            'in_workshop' => (int) $totals->in_workshop,
            'ready'       => (int) $totals->ready,
            'overdue'     => (int) $totals->overdue,
        ];

        // 3) The rows: only the relations the table actually shows.
        $rowQuery = (clone $base)
            ->with([
                'customers' => fn($query) => $query->where('user_id', $ownerId)
                    ->select('id', 'name', 'phone_number1', 'serial_number'),
                'tailor' => fn($query) => $query->where('user_id', $ownerId)
                    ->select('id', 'name'),
                'measurementTemplate:id,name',
                'workAssignments' => fn($query) => $query->whereNull('legacy_key')
                    ->select('id', 'order_id', 'production_worker_id', 'legacy_key'),
            ]);

        if ($filter === 'upcoming') {
            // soonest due date first, newest id first within the same day
            $rowQuery->orderBy('returnDate')->orderByDesc('id');
        } else {
            // overdue, ready and week view: latest first
            $rowQuery->orderByDesc('returnDate')->orderByDesc('id');
        }

        if ($filter) {
            $paginator = $rowQuery->paginate(100)->withQueryString();
            $orders = $paginator->getCollection();
        } else {
            $paginator = null;
            $orders = $rowQuery->get();
        }

        $ordersByDate = $orders->groupBy(
            fn(Order $order) => Carbon::parse($order->returnDate)->toDateString()
        );
        $weekDays = $filter
            ? $ordersByDate->map(fn($dateOrders, string $date) => [
                'date' => Carbon::parse($date),
                'orders' => $dateOrders,
            ])->values()
            : collect(range(0, 6))->map(function (int $offset) use ($weekStart, $ordersByDate) {
                $date = $weekStart->copy()->addDays($offset);

                return [
                    'date' => $date,
                    'orders' => $ordersByDate->get($date->toDateString(), collect()),
                ];
            });

        $tailors = Cache::remember(
            "wo:tailors:{$ownerId}",
            120,
            fn() =>
            Tailor::with(['tailorsalary.options'])
                ->where('user_id', $ownerId)
                ->orderBy('name')
                ->get()
        );

        $tailorWorkloads = Order::where('userId', $ownerId)
            ->whereNotNull('tailorId')
            ->whereNotIn('status', ['ready', 'delivered'])
            ->selectRaw('tailorId, count(*) as active_jobs')
            ->groupBy('tailorId')
            ->pluck('active_jobs', 'tailorId');

        $workers = ProductionWorker::where('user_id', $ownerId)
            ->where('active', true)
            ->select('id', 'name')
            ->orderBy('name')
            ->get();

        return view('All_Total.order', compact(
            'weekStart',
            'weekEnd',
            'weekDays',
            'summary',
            'detailedWorkflow',
            'filter',
            'tailors',
            'tailorWorkloads',
            'workers',
            'paginator'
        ));
    }

    private function statusLabels(bool $detailed): array
    {
        return $detailed ? Order::STATUS_LABELS : [
            'unassigned' => 'درزی مقرر ہونا باقی',
            'assigned'   => 'کارخانے میں ہے',
            'cutting'    => 'کارخانے میں ہے',
            'stitching'  => 'کارخانے میں ہے',
            'trial'      => 'کارخانے میں ہے',
            'ready'      => 'تیار ہے',
            'delivered'  => 'حوالہ شدہ',
        ];
    }

    public function productionPanel(Order $order)
    {
        $user = Auth::user();
        $ownerId = $user->businessOwnerId();

        abort_unless((int) $order->userId === (int) $ownerId, 403);
        abort_unless($user->hasBusinessPermission('tailoring.workshop'), 403);

        $order->load([
            'customers:id,name',
            'tailor:id,name',
            'measurementTemplate:id,name',
            'statusHistory' => fn($q) => $q->latest()->limit(20),
            'workAssignments' => fn($q) => $q->whereNull('legacy_key'),
            'workAssignments.worker:id,name',
            'workAssignments.workType:id,name',
        ]);

        $workers = ProductionWorker::where('user_id', $ownerId)
            ->where('active', true)
            ->with([
                'skills:id,name',
                'compensationPlans' => fn($q) => $q->where('active', true),
            ])
            ->orderBy('name')
            ->get();

        $detailed = Business::tailoringStatusModeForOwner($ownerId) === Business::TAILORING_STATUS_DETAILED;

        return view('All_Total.partials.production-panel', [
            'order' => $order,
            'workers' => $workers,
            'statusLabels' => $this->statusLabels($detailed),
            'workerStatusLabels' => [
                'assigned' => 'تفویض',
                'in_progress' => 'جاری',
                'completed' => 'مکمل',
                'cancelled' => 'منسوخ',
            ],
            'canManageOrders' => $user->hasBusinessPermission('tailoring.orders'),
        ]);
    }

    public function updateRackNo(Request $request, $orderId)
    {
        $order = $this->ownedOrder($orderId);
        abort_unless(in_array($order->status, ['ready', 'delivered'], true), 422, 'ریک نمبر صرف تیار لباس کے لیے مقرر کیا جا سکتا ہے۔');
        $ownerId = Auth::user()->businessOwnerId();
        $validated = $request->validate([
            'rack_no' => [
                'nullable',
                'string',
                'max:100',
                Rule::exists('racks', 'rack_no')->where('user_id', $ownerId),
            ],
        ]);

        $order->rack_no = $validated['rack_no'] ?? null;
        $order->save();

        return response()->json(['message' => 'ریک نمبر محفوظ ہو گیا ہے۔'], 200);
    }

    public function orderCompleteNotify(Request $request)
    {
        Log::info('Order ID:', ['id' => $request->order_id]);

        $validated = $request->validate(['order_id' => ['required', 'integer']]);
        $order = Order::with('transactions')->where('userId', Auth::user()->businessOwnerId())->where('id', $validated['order_id'])->first();
        if ($order) {
            Log::info('Order found:', ['order' => $order]);
            $setting = Setting::where('user_id', $order->userId)->first();

            $customer = $order->customers; // Ensure this returns a valid notifiable entity
            if ($customer) {
                Log::info('Customer found:', ['customer' => $customer]);

                $notification = new OrderCompleteNotification($order, $setting);
                Notification::send($customer, $notification);
                Log::info('Notification sent.');

                // Add entry to server_notifications table
                DB::table('server_notifications')->insert([
                    'user_id' => $order->userId,
                    'customer_id' => $customer->id,
                    'message' => 'Your order has been completed.',
                    'is_send' => 0,  // Mark as unsent for SSE
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                // find shop
                $setting = Setting::where('user_id', $order->userId)->first();

                // event(new CompleteOrderEvent("You have notification from {$setting->name}"));

                return response()->json(['message' => 'Notification sent successfully.']);
            } else {
                return response()->json(['message' => 'Customer not found.'], 404);
            }
        } else {
            return response()->json(['message' => 'Order not found.'], 404);
        }
    }

    private function ownedOrder($id): Order
    {
        if (Auth::check()) {
            return Order::where('userId', Auth::user()->businessOwnerId())->findOrFail($id);
        }

        abort_unless(session('tailor') === 'tailor' && session()->has('tailor_id'), 403);

        return Order::where('tailorId', session('tailor_id'))->findOrFail($id);
    }

    private function ownedCustomer($id): Customers
    {
        return Customers::where('user_id', Auth::user()->businessOwnerId())->findOrFail($id);
    }

    private function ownedTailor($id): Tailor
    {
        return Tailor::where('user_id', Auth::user()->businessOwnerId())->findOrFail($id);
    }

    private function findOwnedTailor($id): ?Tailor
    {
        if (empty($id)) {
            return null;
        }

        return Tailor::where('user_id', Auth::user()->businessOwnerId())->find($id);
    }

    private function ensureRequiredMeasurements(
        Customers $customer,
        ?MeasurementTemplate $template,
    ): void {
        $missing = $this->measurements->missingRequiredMeasurements(
            $customer,
            Auth::user()->businessOwnerId(),
            $template,
        );
        if ($missing->isEmpty()) {
            return;
        }

        throw ValidationException::withMessages([
            'measurement_template_id' => 'آرڈر بنانے سے پہلے یہ ضروری پیمائش مکمل کریں: ' . $missing->implode('، '),
        ]);
    }
}
