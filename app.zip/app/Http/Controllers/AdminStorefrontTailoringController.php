<?php

namespace App\Http\Controllers;

use App\Models\StorefrontInquiry;
use App\Models\StorefrontTailoringService;
use App\Models\MeasurementTemplate;
use App\Services\StorefrontPaymentEvidenceService;
use App\Services\StorefrontTailoringBookingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class AdminStorefrontTailoringController extends Controller
{
    public function inquiryPaymentEvidence(
        StorefrontInquiry $inquiry,
        StorefrontPaymentEvidenceService $evidenceService
    ) {
        $storefront = $this->storefront(false);
        abort_unless(
            $inquiry->storefront_id === $storefront->id
            && $inquiry->payment_evidence_path,
            404
        );

        return $evidenceService->response(
            $inquiry->payment_evidence_path,
            $inquiry->payment_evidence_original_name,
            $inquiry->payment_evidence_mime_type,
        );
    }

    public function services()
    {
        $storefront = $this->storefront();
        $services = $storefront->tailoringServices()
            ->with('measurementTemplate:id,name')
            ->orderBy('sort_order')
            ->latest('id')
            ->get();

        $measurementTemplates = $this->measurementTemplates();

        return view('storefront.admin.tailoring-services', compact('storefront', 'services', 'measurementTemplates'));
    }

    public function storeService(Request $request)
    {
        $storefront = $this->storefront();
        $validated = $this->validateService($request);
        $validated = $this->withLegacyLocalizedServiceContent($validated, $storefront->default_locale);

        $storefront->tailoringServices()->create([
            ...$validated,
            'is_featured' => $request->boolean('is_featured'),
            'is_published' => $request->boolean('is_published'),
            'is_available' => $request->boolean('service_controls_present')
                ? $request->boolean('is_available') : true,
            'accepts_inquiries' => $request->boolean('service_controls_present')
                ? $request->boolean('accepts_inquiries') : true,
            'measurement_methods' => $request->boolean('service_controls_present')
                ? ($validated['measurement_methods'] ?? []) : null,
        ]);

        return redirect()->route('admin.storefront.tailoring.services')
            ->with('success', 'ٹیلرنگ خدمت شامل ہو گئی ہے۔');
    }

    public function updateService(Request $request, StorefrontTailoringService $service)
    {
        $storefront = $this->storefront();
        abort_unless($service->storefront_id === $storefront->id, 404);
        $validated = $this->validateService($request);
        $validated = $this->withLegacyLocalizedServiceContent($validated, $storefront->default_locale);
        $service->update([
            ...$validated,
            'is_featured' => $request->boolean('is_featured'),
            'is_published' => $request->boolean('is_published'),
            'is_available' => $request->boolean('service_controls_present')
                ? $request->boolean('is_available') : $service->is_available,
            'accepts_inquiries' => $request->boolean('service_controls_present')
                ? $request->boolean('accepts_inquiries') : $service->accepts_inquiries,
            'measurement_methods' => $request->boolean('service_controls_present')
                ? ($validated['measurement_methods'] ?? []) : $service->measurement_methods,
        ]);

        return redirect()->route('admin.storefront.tailoring.services')
            ->with('success', 'ٹیلرنگ خدمت محفوظ ہو گئی ہے۔');
    }

    public function inquiries(Request $request)
    {
        $storefront = $this->storefront(false);
        $filters = $request->validate([
            'status' => ['nullable', Rule::in(array_keys(StorefrontInquiry::statuses()))],
            'q' => ['nullable', 'string', 'max:100'],
        ]);
        $inquiries = $storefront->inquiries()
            ->with([
                'service:id,name,price_from,estimated_days,measurement_template_id',
                'service.measurementTemplate:id,name',
                'measurementTemplate:id,name',
                'paymentVerifier:id,name,username',
                'customer:id,name,phone_number1,measurement_template_id',
                'order:id,customerId,status,returnDate,totalPayment,measurement_template_id',
                'order.measurementTemplate:id,name',
                'confirmedBy:id,name,username',
                'rejectedBy:id,name,username',
            ])
            ->when($filters['status'] ?? null, fn ($query, $status) => $query->where('status', $status))
            ->when($filters['q'] ?? null, function ($query, $term) {
                $query->where(function ($query) use ($term) {
                    $query->where('customer_name', 'like', '%'.$term.'%')
                        ->orWhere('phone', 'like', '%'.$term.'%')
                        ->orWhere('email', 'like', '%'.$term.'%');
                });
            })
            ->latest()
            ->paginate(20)
            ->withQueryString();

        return view('storefront.admin.inquiries', [
            'storefront' => $storefront,
            'inquiries' => $inquiries,
            'filters' => $filters,
            'statuses' => StorefrontInquiry::statuses(),
            'measurementTemplates' => $this->measurementTemplates(),
        ]);
    }

    public function updateInquiry(Request $request, StorefrontInquiry $inquiry)
    {
        $storefront = $this->storefront(false);
        abort_unless($inquiry->storefront_id === $storefront->id, 404);
        if ($inquiry->isBooking()) {
            throw ValidationException::withMessages([
                'status' => 'آن لائن بکنگ کے لیے تصدیق یا مسترد کرنے کے بٹن استعمال کریں۔',
            ]);
        }
        $validated = $request->validate([
            'status' => ['required', Rule::in(array_keys(StorefrontInquiry::statuses()))],
            'admin_notes' => ['nullable', 'string', 'max:3000'],
        ]);
        $inquiry->update([
            ...$validated,
            'contacted_at' => $validated['status'] === StorefrontInquiry::STATUS_CONTACTED
                ? ($inquiry->contacted_at ?? now()) : $inquiry->contacted_at,
            'closed_at' => $validated['status'] === StorefrontInquiry::STATUS_CLOSED
                ? ($inquiry->closed_at ?? now()) : null,
        ]);

        return redirect()->route('admin.storefront.inquiries.index')
            ->with('success', 'درخواست کی حالت محفوظ ہو گئی ہے۔');
    }

    public function verifyInquiryPayment(Request $request, StorefrontInquiry $inquiry)
    {
        $storefront = $this->storefront(false);
        abort_unless($inquiry->storefront_id === $storefront->id, 404);
        if (in_array($inquiry->status, [StorefrontInquiry::STATUS_CONFIRMED, StorefrontInquiry::STATUS_REJECTED], true)) {
            throw ValidationException::withMessages([
                'payment_verification' => 'مکمل ہو چکی بکنگ کی ادائیگی کی تصدیق تبدیل نہیں کی جا سکتی۔',
            ]);
        }
        $validated = $request->validate([
            'decision' => ['required', Rule::in([
                StorefrontInquiry::VERIFICATION_VERIFIED,
                StorefrontInquiry::VERIFICATION_REJECTED,
            ])],
            'payment_verification_notes' => [
                Rule::requiredIf($request->input('decision') === StorefrontInquiry::VERIFICATION_REJECTED),
                'nullable',
                'string',
                'max:1000',
            ],
        ]);

        DB::transaction(function () use ($inquiry, $validated) {
            $lockedInquiry = StorefrontInquiry::query()->lockForUpdate()->findOrFail($inquiry->id);
            if (! StorefrontInquiry::requiresManualVerification($lockedInquiry->payment_method)) {
                throw ValidationException::withMessages([
                    'payment_verification' => 'اس ادائیگی کے طریقے کے لیے دستی تصدیق درکار نہیں۔',
                ]);
            }
            if ($lockedInquiry->payment_verification_status === StorefrontInquiry::VERIFICATION_VERIFIED) {
                throw ValidationException::withMessages([
                    'payment_verification' => 'یہ ادائیگی پہلے ہی تصدیق ہو چکی ہے۔',
                ]);
            }

            $verified = $validated['decision'] === StorefrontInquiry::VERIFICATION_VERIFIED;
            $lockedInquiry->update([
                'payment_verification_status' => $validated['decision'],
                'payment_verification_notes' => $validated['payment_verification_notes'] ?? null,
                'payment_verified_by_user_id' => Auth::id(),
                'payment_verified_at' => $verified ? now() : null,
                'payment_rejected_at' => $verified ? null : now(),
            ]);
        }, 3);

        return redirect()->route('admin.storefront.inquiries.index')
            ->with('success', $validated['decision'] === StorefrontInquiry::VERIFICATION_VERIFIED
                ? 'دستی ادائیگی کا حوالہ تصدیق کر دیا گیا ہے۔'
                : 'دستی ادائیگی کا حوالہ مسترد کر دیا گیا ہے۔');
    }

    public function confirmBooking(
        Request $request,
        StorefrontInquiry $inquiry,
        StorefrontTailoringBookingService $bookings,
    ) {
        $storefront = $this->storefront(false);
        abort_unless($inquiry->storefront_id === $storefront->id && $inquiry->isBooking(), 404);
        $validated = $request->validate([
            'final_price' => ['required', 'numeric', 'min:0', 'max:9999999999'],
            'suit_quantity' => ['required', 'integer', 'min:1', 'max:20'],
            'promised_date' => ['required', 'date', 'after_or_equal:today'],
            'measurement_template_id' => [
                'nullable',
                'integer',
                Rule::exists('measurement_templates', 'id')
                    ->where('user_id', Auth::user()->businessOwnerId())
                    ->where('is_active', true),
            ],
            'admin_notes' => ['nullable', 'string', 'max:3000'],
        ]);
        $bookings->confirm(
            $inquiry,
            (int) Auth::id(),
            (float) $validated['final_price'],
            (int) $validated['suit_quantity'],
            $validated['promised_date'],
            isset($validated['measurement_template_id']) ? (int) $validated['measurement_template_id'] : null,
            $validated['admin_notes'] ?? null,
        );

        return redirect()->route('admin.storefront.inquiries.index')
            ->with('success', 'بکنگ منظور ہو گئی، ٹیلرنگ آرڈر اور مالی ریکارڈ بنا دیے گئے ہیں۔');
    }

    public function rejectBooking(
        Request $request,
        StorefrontInquiry $inquiry,
        StorefrontTailoringBookingService $bookings,
    ) {
        $storefront = $this->storefront(false);
        abort_unless($inquiry->storefront_id === $storefront->id && $inquiry->isBooking(), 404);
        $validated = $request->validate([
            'rejection_reason' => ['required', 'string', 'max:1000'],
        ]);
        $bookings->reject($inquiry, (int) Auth::id(), $validated['rejection_reason']);

        return redirect()->route('admin.storefront.inquiries.index')
            ->with('success', 'بکنگ مسترد کر دی گئی ہے۔');
    }

    public function bookingJobSheet(StorefrontInquiry $inquiry)
    {
        $storefront = $this->storefront(false);
        abort_unless(
            $inquiry->storefront_id === $storefront->id
            && $inquiry->isBooking()
            && $inquiry->status === StorefrontInquiry::STATUS_CONFIRMED
            && $inquiry->order_id,
            404
        );
        $inquiry->load(['service', 'customer', 'order.measurementValues.field', 'confirmedBy']);

        return view('storefront.admin.tailoring-job-sheet', [
            'storefront' => $storefront,
            'booking' => $inquiry,
        ]);
    }

    private function storefront(bool $requireTailoring = true)
    {
        $business = Auth::user()->business;
        abort_unless($business && (! $requireTailoring || $business->tailoring_enabled), 404);
        $storefront = $business->storefront()->first();
        abort_unless($storefront, 404, 'پہلے آن لائن دکان کی بنیادی معلومات محفوظ کریں۔');

        return $storefront;
    }

    private function validateService(Request $request): array
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:180'],
            'name_ur' => ['nullable', 'string', 'max:180'],
            'name_en' => ['nullable', 'string', 'max:180'],
            'description' => ['nullable', 'string', 'max:2000'],
            'description_ur' => ['nullable', 'string', 'max:2000'],
            'description_en' => ['nullable', 'string', 'max:2000'],
            'price_from' => ['nullable', 'numeric', 'min:0', 'max:9999999999'],
            'price_unit' => ['required', Rule::in(['فی سوٹ', 'فی لباس', 'فی کام'])],
            'estimated_days' => ['nullable', 'integer', 'min:1', 'max:365'],
            'measurement_template_id' => [
                'nullable',
                'integer',
                Rule::exists('measurement_templates', 'id')
                    ->where('user_id', Auth::user()->businessOwnerId())
                    ->where('is_active', true),
            ],
            'deposit_type' => ['nullable', Rule::in(array_keys(StorefrontTailoringService::depositTypes()))],
            'deposit_value' => ['nullable', 'numeric', 'min:0', 'max:9999999999'],
            'measurement_methods' => ['nullable', 'array'],
            'measurement_methods.*' => [Rule::in(array_keys(StorefrontTailoringService::measurementMethodLabels()))],
            'weekly_booking_limit' => ['nullable', 'integer', 'min:1', 'max:999'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'is_featured' => ['nullable', 'boolean'],
            'is_published' => ['nullable', 'boolean'],
            'is_available' => ['nullable', 'boolean'],
            'accepts_inquiries' => ['nullable', 'boolean'],
            'service_controls_present' => ['nullable', 'boolean'],
        ]);
        $depositType = $validated['deposit_type'] ?? StorefrontTailoringService::DEPOSIT_NONE;
        if ($depositType !== StorefrontTailoringService::DEPOSIT_NONE
            && blank($validated['deposit_value'] ?? null)) {
            throw ValidationException::withMessages([
                'deposit_value' => 'پیشگی رقم یا فیصد درج کریں۔',
            ]);
        }
        if ($depositType === StorefrontTailoringService::DEPOSIT_PERCENTAGE
            && (float) ($validated['deposit_value'] ?? 0) > 100) {
            throw ValidationException::withMessages([
                'deposit_value' => 'پیشگی فیصد 100 سے زیادہ نہیں ہو سکتا۔',
            ]);
        }
        if ($depositType === StorefrontTailoringService::DEPOSIT_PERCENTAGE
            && blank($validated['price_from'] ?? null)) {
            throw ValidationException::withMessages([
                'price_from' => 'فیصدی پیشگی رقم کے لیے ابتدائی قیمت درج کریں۔',
            ]);
        }
        if ($depositType !== StorefrontTailoringService::DEPOSIT_NONE
            && collect(array_keys(Auth::user()->business->storefront->acceptedInquiryPaymentMethods()))
                ->every(fn ($method) => $method === StorefrontInquiry::PAYMENT_UNPAID)) {
            throw ValidationException::withMessages([
                'deposit_type' => 'پیشگی رقم مقرر کرنے سے پہلے ٹیلرنگ کی بنیادی ترتیب میں کم از کم ایک ادائیگی کا طریقہ فعال کریں۔',
            ]);
        }
        if ($request->boolean('service_controls_present')
            && $request->boolean('accepts_inquiries')
            && empty($validated['measurement_methods'] ?? [])) {
            throw ValidationException::withMessages([
                'measurement_methods' => 'درخواست قبول کرنے کے لیے کم از کم ایک پیمائش کا طریقہ منتخب کریں۔',
            ]);
        }
        $templateMethods = [
            StorefrontTailoringService::MEASUREMENT_STANDARD_SIZE,
            StorefrontTailoringService::MEASUREMENT_CUSTOM,
        ];
        if (array_intersect($templateMethods, $validated['measurement_methods'] ?? [])
            && empty($validated['measurement_template_id'])) {
            throw ValidationException::withMessages([
                'measurement_template_id' => 'معیاری یا اپنی پیمائش کے لیے اس خدمت کا پیمائش ٹیمپلیٹ منتخب کریں۔',
            ]);
        }
        if ($request->boolean('is_published') && ! Auth::user()->business->storefront->show_tailoring) {
            throw ValidationException::withMessages([
                'is_published' => 'پہلے آن لائن دکان کی ترتیب میں ٹیلرنگ شعبہ فعال کریں۔',
            ]);
        }

        return $validated;
    }

    private function withLegacyLocalizedServiceContent(array $validated, ?string $defaultLocale): array
    {
        $locale = $defaultLocale === 'en' ? 'en' : 'ur';
        foreach (['name', 'description'] as $field) {
            if (filled($validated[$field.'_'.$locale] ?? null)) {
                $validated[$field] = $validated[$field.'_'.$locale];
            }
        }

        return $validated;
    }

    private function measurementTemplates()
    {
        return MeasurementTemplate::query()
            ->where('user_id', Auth::user()->businessOwnerId())
            ->where('is_active', true)
            ->orderByDesc('is_default')
            ->orderBy('name')
            ->get(['id', 'name', 'is_default']);
    }
}
