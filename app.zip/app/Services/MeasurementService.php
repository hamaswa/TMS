<?php

namespace App\Services;

use App\Models\Customers;
use App\Models\CustomerMeasurementHistory;
use App\Models\MeasurementField;
use App\Models\MeasurementTemplate;
use App\Models\Order;
use App\Models\OrderMeasurementValue;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class MeasurementService
{
    private const PREFERENCE_SYSTEM_KEYS = [
        'necktype', 'sleeve', 'Daaman', 'jeab', 'swingtype', 'button', 'plate_type',
    ];

    public const SYSTEM_FIELDS = [
    'length' => ['label' => 'لمبائی', 'unit' => 'inch'],
    'necktype' => ['label' => 'گلہ', 'unit' => ''],
    'arms' => ['label' => 'بازو', 'unit' => 'inch'],
    'sleeve' => ['label' => 'کف', 'unit' => ''],
    'teraa' => ['label' => 'تیرا', 'unit' => 'inch'],
    'Daaman' => ['label' => 'دامن', 'unit' => ''],
    'jeab' => ['label' => 'جیب', 'unit' => ''],
    'senaChorai' => ['label' => 'سینہ چوڑائی', 'unit' => 'inch'],
    'swingtype' => ['label' => 'سلائی', 'unit' => ''],
    'damanchorai' => ['label' => 'دامن چوڑائی', 'unit' => 'inch'],
    'button' => ['label' => 'بٹن', 'unit' => ''],
    'shalwar' => ['label' => 'شلوار', 'unit' => 'inch'],
    'plate_type' => ['label' => 'پلیٹ', 'unit' => ''],
    'pancha' => ['label' => 'پائنچہ', 'unit' => 'inch'],
    'shalwarGheer' => ['label' => 'شلوار گھیر', 'unit' => 'inch'],
    'shoulder' => ['label' => 'مونڈھا', 'unit' => 'inch'],
    'chuta' => ['label' => 'چوتا', 'unit' => 'inch'],
];

    public function activeFields(int $ownerId): Collection
    {
        return MeasurementField::where('user_id', $ownerId)->where('is_active', true)
            ->orderBy('sort_order')->orderBy('label')->get();
    }

    public function fieldsForTemplate(Collection $fields, ?MeasurementTemplate $template): Collection
    {
        if (! $template) {
            return $fields;
        }

        $selected = array_map('intval', $template->custom_field_ids ?? []);

        return $fields->filter(fn ($field) => in_array((int) $field->id, $selected, true))->values();
    }

    /**
     * Return the historical order snapshot plus newer customer fields that did
     * not exist when the order was created. Existing snapshot values always win.
     */
    public function displayValuesForOrder(Order $order): Collection
    {
        $values = $order->measurementValues->keyBy('source_key');
        $customer = $order->customers;

        if (! $customer) {
            return $values->sortBy('sort_order')->values();
        }

        foreach (self::PREFERENCE_SYSTEM_KEYS as $key) {
            $sourceKey = 'system.'.$key;
            $snapshotValue = trim((string) optional($values->get($sourceKey))->value);
            $currentValue = trim((string) $customer->{$key});
            if (($snapshotValue === '' || $snapshotValue === '0') && $currentValue !== '' && $currentValue !== '0') {
                $values->put($sourceKey, new OrderMeasurementValue([
                    'order_id' => $order->id,
                    'measurement_field_id' => null,
                    'source_key' => $sourceKey,
                    'label' => self::SYSTEM_FIELDS[$key]['label'],
                    'value' => $currentValue,
                    'unit' => '',
                    'sort_order' => array_search($key, array_keys(self::SYSTEM_FIELDS), true),
                ]));
            }
        }

        $fields = $this->fieldsForTemplate(
            $this->activeFields((int) $order->userId),
            $order->measurementTemplate,
        )->reject(fn ($field) => $values->has('custom.'.$field->id));

        if ($fields->isEmpty()) {
            return $values->sortBy('sort_order')->values();
        }

        $customer->measurementValues()
            ->with('field')
            ->whereIn('measurement_field_id', $fields->pluck('id'))
            ->whereNotNull('value')
            ->where('value', '!=', '')
            ->get()
            ->each(function ($customerValue) use ($values): void {
                $field = $customerValue->field;
                if (! $field) {
                    return;
                }

                $sourceKey = 'custom.'.$field->id;
                $values->put($sourceKey, new OrderMeasurementValue([
                    'order_id' => null,
                    'measurement_field_id' => $field->id,
                    'source_key' => $sourceKey,
                    'label' => $field->label,
                    'value' => (string) $customerValue->value,
                    'unit' => $field->unit,
                    'sort_order' => 1000 + (int) $field->sort_order,
                ]));
            });

        return $values->sortBy('sort_order')->values();
    }

    public function rules(Collection $fields): array
    {
        $rules = ['custom_measurements' => ['nullable', 'array']];
        foreach ($fields as $field) {
            $fieldRules = [$field->is_required ? 'required' : 'nullable'];
            if ($field->field_type === 'number') {
                array_push($fieldRules, 'numeric', 'min:0');
            } elseif ($field->field_type === 'select') {
                $fieldRules[] = Rule::in($field->options ?? []);
            } else {
                array_push($fieldRules, 'string', 'max:500');
            }
            $rules['custom_measurements.'.$field->id] = $fieldRules;
        }

        return $rules;
    }

    public function attributes(Collection $fields): array
    {
        return $fields->mapWithKeys(fn ($field) => [
            'custom_measurements.'.$field->id => $field->label,
        ])->all();
    }

    public function syncCustomer(Customers $customer, Collection $fields, array $values): void
    {
        foreach ($fields as $field) {
            $value = $values[$field->id] ?? null;
            if ($value === null || $value === '') {
                $customer->measurementValues()->where('measurement_field_id', $field->id)->delete();
                continue;
            }
            $customer->measurementValues()->updateOrCreate(
                ['measurement_field_id' => $field->id],
                ['value' => (string) $value]
            );
        }
    }

    public function syncCustomerFromOrder(
        Customers $customer,
        int $ownerId,
        Collection $fields,
        array $systemValues,
        array $customValues,
        ?MeasurementTemplate $template,
        ?int $recordedByUserId,
    ): bool {
        $previousTemplate = $customer->measurementTemplate;
        $targetTemplate = $template ?: $previousTemplate;
        $previousRows = $this->measurementRows($customer, $ownerId, $previousTemplate);
        $previousFingerprint = $this->measurementFingerprint($previousRows, $previousTemplate);

        foreach (self::SYSTEM_FIELDS as $key => $meta) {
            if (! array_key_exists($key, $systemValues)) {
                continue;
            }

            $value = $systemValues[$key];
            $customer->{$key} = $value === null || $value === '' ? null : $value;
        }

        if ($template) {
            $customer->measurement_template_id = $template->id;
        }
        $customer->save();
        $this->syncCustomer($customer, $fields, $customValues);

        $currentRows = $this->measurementRows($customer, $ownerId, $targetTemplate);
        $currentFingerprint = $this->measurementFingerprint($currentRows, $targetTemplate);
        if (hash_equals($previousFingerprint, $currentFingerprint)) {
            return false;
        }

        if (! $customer->measurementHistories()->exists()) {
            $this->recordHistoryRows(
                $customer,
                $previousRows,
                $previousTemplate,
                $recordedByUserId,
                'baseline',
            );
        }
        $this->recordHistoryRows(
            $customer,
            $currentRows,
            $targetTemplate,
            $recordedByUserId,
            'order_update',
        );

        return true;
    }

    public function snapshotOrder(Order $order, Customers $customer, ?MeasurementTemplate $template = null): void
    {
        $template ??= $order->measurementTemplate;
        $rows = $this->savedMeasurementRows($customer, (int) $order->userId, $template);

        if ($rows->isEmpty()) {
            $rows = $this->measurementRows($customer, (int) $order->userId, $template);
        }

        $order->measurementValues()->delete();
        $order->measurementValues()->createMany($rows->all());
    }

    public function savedMeasurementRows(
        Customers $customer,
        int $ownerId,
        ?MeasurementTemplate $template,
    ): Collection {
        if (! $template) {
            return $this->measurementRows($customer, $ownerId);
        }

        $history = CustomerMeasurementHistory::query()
            ->where('user_id', $ownerId)
            ->where('customer_id', $customer->id)
            ->where('measurement_template_id', $template->id)
            ->with('values')
            ->latest('id')
            ->first();

        if ($history) {
            return $history->values->map(fn ($value) => [
                'measurement_field_id' => $value->measurement_field_id,
                'source_key' => $value->source_key,
                'label' => $value->label,
                'value' => $value->value,
                'unit' => $value->unit,
                'sort_order' => $value->sort_order,
            ])->sortBy('sort_order')->values();
        }

        if ((int) $customer->measurement_template_id === (int) $template->id) {
            return $this->measurementRows($customer, $ownerId, $template);
        }

        return collect();
    }

    public function measurementRows(Customers $customer, int $ownerId, ?MeasurementTemplate $template = null): Collection
    {
        $rows = collect();
        $sortOrder = 0;
        foreach (self::SYSTEM_FIELDS as $key => $meta) {
            if ($template && ! in_array($key, $template->system_fields ?? [], true)) {
                continue;
            }
            $value = $customer->{$key};
            if ($value !== null && $value !== '') {
                $rows->push([
                    'measurement_field_id' => null,
                    'source_key' => 'system.'.$key,
                    'label' => $meta['label'],
                    'value' => (string) $value,
                    'unit' => $meta['unit'],
                    'sort_order' => $sortOrder++,
                ]);
            }
        }

        $customValues = $customer->measurementValues()->with('field')
            ->whereHas('field', fn ($query) => $query
                ->where('user_id', $ownerId)->where('is_active', true))
            ->when($template, fn ($query) => $query->whereIn('measurement_field_id', $template->custom_field_ids ?? []))
            ->get()->sortBy(fn ($value) => [$value->field->sort_order, $value->field->label]);

        foreach ($customValues as $customValue) {
            $rows->push([
                'measurement_field_id' => $customValue->measurement_field_id,
                'source_key' => 'custom.'.$customValue->measurement_field_id,
                'label' => $customValue->field->label,
                'value' => $customValue->value,
                'unit' => $customValue->field->unit,
                'sort_order' => 1000 + $customValue->field->sort_order,
            ]);
        }

        return $rows;
    }

    public function missingRequiredMeasurements(
        Customers $customer,
        int $ownerId,
        ?MeasurementTemplate $template,
    ): Collection {
        if (! $template) {
            return collect();
        }

        return $this->missingRequiredMeasurementsFromRows(
            $this->savedMeasurementRows($customer, $ownerId, $template),
            $ownerId,
            $template,
        );
    }

    public function missingRequiredMeasurementsFromRows(
        Collection $rows,
        int $ownerId,
        MeasurementTemplate $template,
    ): Collection {
        $savedValues = $rows->pluck('value', 'source_key');

        $missing = collect($template->system_fields ?? [])
            ->filter(fn (string $key) => array_key_exists($key, self::SYSTEM_FIELDS))
            ->filter(fn (string $key) => blank($savedValues->get('system.'.$key)))
            ->map(fn (string $key) => self::SYSTEM_FIELDS[$key]['label']);

        $requiredCustomFields = MeasurementField::query()
            ->where('user_id', $ownerId)
            ->where('is_active', true)
            ->where('is_required', true)
            ->whereIn('id', array_map('intval', $template->custom_field_ids ?? []))
            ->orderBy('sort_order')
            ->get(['id', 'label']);
        $availableCustomIds = $savedValues->keys()
            ->filter(fn ($key) => str_starts_with((string) $key, 'custom.'))
            ->map(fn ($key) => (int) Str::after((string) $key, 'custom.'));

        return $missing->concat(
            $requiredCustomFields
                ->reject(fn ($field) => $availableCustomIds->contains((int) $field->id))
                ->pluck('label')
        )->values();
    }

    public function measurementFingerprint(Collection $rows, ?MeasurementTemplate $template = null): string
    {
        return hash('sha256', json_encode([
            'template_id' => $template?->id,
            'values' => $rows->map(fn (array $row) => [
                'source_key' => $row['source_key'],
                'value' => (string) $row['value'],
                'unit' => $row['unit'],
            ])->values()->all(),
        ], JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION));
    }

    public function recordHistory(
        Customers $customer,
        int $ownerId,
        ?MeasurementTemplate $template,
        ?int $recordedByUserId,
        string $source = 'customer_update',
    ): ?CustomerMeasurementHistory {
        return $this->recordHistoryRows(
            $customer,
            $this->measurementRows($customer, $ownerId, $template),
            $template,
            $recordedByUserId,
            $source,
        );
    }

    public function recordHistoryRows(
        Customers $customer,
        Collection $rows,
        ?MeasurementTemplate $template,
        ?int $recordedByUserId,
        string $source,
    ): ?CustomerMeasurementHistory {
        if ($rows->isEmpty()) {
            return null;
        }

        $history = $customer->measurementHistories()->create([
            'user_id' => $customer->user_id,
            'measurement_template_id' => $template?->id,
            'recorded_by_user_id' => $recordedByUserId,
            'source' => $source,
        ]);
        $history->values()->createMany($rows->all());

        return $history;
    }
}
