<?php

namespace App\Services;

use App\Models\ClothCategory;
use App\Models\ClothColor;
use App\Models\CounterOrderItem;
use App\Models\Customers;
use App\Models\OnlineOrder;
use App\Models\Order;
use App\Models\SaleStock;
use App\Models\StorefrontOrder;
use App\Models\Tailor;
use App\Models\TailorRecord;
use App\Models\Transaction;
use App\Models\Workers;
use App\Support\PaymentMethods;
use Carbon\CarbonInterface;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Data for the reports page, split into a cloth sales view and a tailoring view.
 */
class ReportDashboardService
{
    public const SALE_TYPES = ['Sale', 'Sale Cancellation', 'Sale Return'];
    public const TAILOR_TYPES = ['Tailor', 'Tailor_Advance_Cut'];
    private const BILL_KEY = 'COALESCE(sale_stocks.counter_sale_receipt_id, -sale_stocks.id)';
    private const KEPT_QUANTITY = 'sale_stocks.length - COALESCE(line_returns.returned_quantity, 0)';
    private const KEPT_AMOUNT = 'sale_stocks.selling_price * sale_stocks.length - COALESCE(line_returns.returned_amount, 0)';

    public function __construct(
        private FinancialReportService $finance,
        private CustomerLedgerService $ledger,
    ) {
    }

    /** Daily cloth sales and stitching income for the trend chart, counted like the finance report. */
    public function dailySeries(int $userId, CarbonInterface $start, CarbonInterface $end, array $modules): array
    {
        $from = $start->copy()->startOfDay();
        $to = $end->copy()->endOfDay();
        $daily = [];
        for ($day = $from->copy(); $day->lte($to) && count($daily) < 400; $day->addDay()) {
            $daily[$day->toDateString()] = ['cloth' => 0.0, 'tailoring' => 0.0];
        }
        $add = function ($query, string $column, string $amount, string $key) use (&$daily) {
            $query->selectRaw("DATE({$column}) AS day, SUM({$amount}) AS amount")
                ->groupBy(DB::raw("DATE({$column})"))->get()
                ->each(function ($row) use (&$daily, $key) {
                    if (isset($daily[$row->day])) {
                        $daily[$row->day][$key] += (float) $row->amount;
                    }
                });
        };

        if (in_array('clothing', $modules, true)) {
            // A returned item is taken off the day it was sold, so the chart only shows what customers kept.
            $add($this->keptSales($userId, $to)->whereBetween('sale_stocks.sellDate', [$from, $to]), 'sale_stocks.sellDate', self::KEPT_AMOUNT, 'cloth');
            $add(DB::table('saledetails')->join('sales', 'saledetails.sale_id', '=', 'sales.id')
                ->where('sales.user_id', $userId)->where('sales.status', '!=', 'cancelled')
                ->whereBetween('sales.created_at', [$from, $to]), 'sales.created_at', 'saledetails.quantity * saledetails.price', 'cloth');
            $add(OnlineOrder::where('admin_user_id', $userId)->whereBetween('created_at', [$from, $to])
                ->whereRaw('LOWER(status) != ?', ['cancelled']), 'created_at', 'price * length', 'cloth');
            $add(StorefrontOrder::whereHas('storefront.business', fn ($query) => $query->where('owner_user_id', $userId))
                ->whereBetween('placed_at', [$from, $to])->where('status', '!=', StorefrontOrder::STATUS_CANCELLED), 'placed_at', 'subtotal', 'cloth');
        }
        if (in_array('tailoring', $modules, true)) {
            $add($this->activeOrders($userId)->whereBetween('created_at', [$from, $to]), 'created_at', 'totalPayment', 'tailoring');
        }

        return $daily;
    }

    // ---------------------------------------------------------------- Sales

    /** Headline numbers for cloth sales in a period; also used for the previous period's comparison. */
    public function salesMetrics(int $userId, CarbonInterface $start, CarbonInterface $end, array $modules): array
    {
        $revenue = $this->finance->build($userId, $start, $end, false, $modules)['revenue'];
        unset($revenue['ٹیلرنگ آرڈرز']);
        $categories = $this->finance->salesByCategory($userId, $start, $end, $modules);
        $from = $start->copy()->startOfDay();
        $to = $end->copy()->endOfDay();
        // A bill whose every item came back is no longer a sale.
        $bills = $this->keptSales($userId, $to)->whereBetween('sale_stocks.sellDate', [$from, $to])
            ->selectRaw('COUNT(DISTINCT CASE WHEN '.self::KEPT_QUANTITY.' > 0.0001 THEN '.self::BILL_KEY.' END) AS bills')->value('bills');

        return [
            'revenue' => array_sum($revenue),
            'meters' => $categories['totals'][ClothCategory::UNIT_METER]['net'] ?? 0,
            'suits' => $categories['totals'][ClothCategory::UNIT_SUIT]['net'] ?? 0,
            'pieces' => $categories['totals'][ClothCategory::UNIT_PIECE]['net'] ?? 0,
            'received' => $this->received($userId, $start, $end, 'sales'),
            'bills' => (int) $bills,
            'revenue_sources' => $revenue,
            'categories' => $categories,
        ];
    }

    /** Each walk-in sale keeps its own "Walk-in #9" record; reports just call them "Walk-in". */
    public static function customerLabel(?string $name): string
    {
        $name = trim((string) $name);
        if ($name === '') {
            return 'عام گاہک';
        }

        return preg_match('/^Walk-in #\d+$/', $name) ? 'Walk-in' : $name;
    }

    /** The latest sale bills: one row per counter receipt (or per sale without one). */
    public function recentSales(int $userId, CarbonInterface $start, CarbonInterface $end, int $limit = 5): Collection
    {
        $bills = $this->keptSales($userId, $end)
            ->whereBetween('sale_stocks.sellDate', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->groupBy(DB::raw(self::BILL_KEY))
            ->selectRaw('MAX(sale_stocks.counter_sale_receipt_id) AS receipt_id, MAX(sale_stocks.sellDate) AS sold_at, MAX(sale_stocks.c_name) AS customer')
            ->selectRaw('COUNT(*) AS items, SUM('.self::KEPT_AMOUNT.') AS amount, SUM(COALESCE(line_returns.returned_amount, 0)) AS returned')
            ->orderByDesc('sold_at')->limit($limit)->get();
        $methods = Transaction::where('userId', (string) $userId)->whereIn('counter_sale_receipt_id', $bills->pluck('receipt_id')->filter())
            ->where('Order_type', 'Sale')->pluck('payment_method', 'counter_sale_receipt_id');

        return $bills->map(fn ($bill) => [
            'date' => $bill->sold_at,
            'customer' => self::customerLabel($bill->customer),
            'items' => (int) $bill->items,
            'amount' => (float) $bill->amount,
            'returned' => (float) $bill->returned,
            'method' => PaymentMethods::label($methods[$bill->receipt_id] ?? 'cash'),
        ]);
    }

    /**
     * Cloth sales in the period, one entry per bill (a counter receipt, or a sale without one), newest first,
     * each with the items sold on it. Optionally only items of one category (and its sub categories) or
     * matching a search. Paged by bill, so a bill is never split across pages.
     */
    public function salesLines(int $userId, CarbonInterface $start, CarbonInterface $end, ?int $categoryId, int $perPage = 15, ?string $search = null): LengthAwarePaginator
    {
        $categories = ClothCategory::with('parent')->where('user_id', $userId)->get()->keyBy('id');
        $search = trim((string) $search);
        $lines = fn () => $this->keptSales($userId, $end)
            ->leftJoin('cloths', 'cloths.id', '=', 'sale_stocks.cloth_id')
            ->whereBetween('sale_stocks.sellDate', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->when($categoryId, fn ($query) => $query->whereIn('cloths.cloth_category_id',
                $categories->filter(fn ($category) => $category->id === $categoryId || $category->parent_id === $categoryId)->keys()))
            ->when($search !== '', fn ($query) => $query->where(function ($match) use ($search, $userId) {
                $like = '%'.addcslashes($search, '%_\\').'%';
                $match->where('sale_stocks.c_name', 'like', $like)->orWhere('sale_stocks.phone', 'like', $like)
                    ->orWhere('sale_stocks.color', 'like', $like)->orWhere('cloths.name', 'like', $like)
                    // The order number (ORD-000094) or receipt number of the bill.
                    ->orWhereIn('sale_stocks.counter_sale_receipt_id', DB::table('counter_order_items')
                        ->join('counter_orders', 'counter_orders.id', '=', 'counter_order_items.counter_order_id')
                        ->where('counter_orders.user_id', $userId)
                        ->where('counter_order_items.source_record_type', 'counter_sale_receipt')
                        ->where(fn ($number) => $number->where('counter_orders.serial_number', 'like', $like)
                            ->orWhere('counter_orders.reference', 'like', $like))
                        ->select('counter_order_items.source_record_id'))
                    ->orWhereIn('sale_stocks.counter_sale_receipt_id', DB::table('counter_sale_receipts')
                        ->where('user_id', $userId)->where('receipt_number', 'like', $like)->select('id'));
            }));

        $bills = $lines()
            ->groupBy(DB::raw(self::BILL_KEY))
            ->selectRaw(self::BILL_KEY.' AS bill_key, MAX(sale_stocks.sellDate) AS sold_at, MAX(sale_stocks.id) AS last_id')
            ->orderByDesc('sold_at')->orderByDesc('last_id')
            ->paginate($perPage, ['*'], 'sales_page')->withQueryString();

        $items = $bills->isEmpty() ? collect() : $lines()
            ->whereIn(DB::raw(self::BILL_KEY), $bills->getCollection()->pluck('bill_key'))
            ->orderBy('sale_stocks.id')
            ->select(['sale_stocks.id', 'sale_stocks.sellDate', 'sale_stocks.c_name', 'sale_stocks.c_id', 'sale_stocks.phone', 'sale_stocks.counter_sale_receipt_id', 'sale_stocks.color', 'sale_stocks.length', 'sale_stocks.selling_price'])
            ->selectRaw(self::BILL_KEY.' AS bill_key')
            ->addSelect(['cloths.name AS cloth_name', 'cloths.stock_unit', 'cloths.cloth_category_id'])
            ->selectRaw('COALESCE(line_returns.returned_quantity, 0) AS returned_quantity, COALESCE(line_returns.returned_amount, 0) AS returned_amount')
            ->get()->groupBy('bill_key');
        // The counter order each bill was confirmed from, for its order number.
        $orders = CounterOrderItem::query()
            ->where('source_record_type', 'counter_sale_receipt')
            ->whereIn('source_record_id', $items->flatten(1)->pluck('counter_sale_receipt_id')->filter()->unique())
            ->whereHas('counterOrder', fn ($query) => $query->where('user_id', $userId))
            ->with('counterOrder:id,reference,serial_number')
            ->get()->keyBy('source_record_id');

        return $bills->through(function ($bill) use ($items, $categories, $orders) {
            $lines = $items->get($bill->bill_key, collect());
            $first = $lines->first();
            $order = $first?->counter_sale_receipt_id ? $orders->get($first->counter_sale_receipt_id)?->counterOrder : null;

            return [
                // The first item's sale line; the old one-receipt-per-line print page takes it.
                'id' => (int) $first?->id,
                'customer_id' => $first?->c_id ? (int) $first->c_id : null,
                'receipt_id' => $first?->counter_sale_receipt_id ? (int) $first->counter_sale_receipt_id : null,
                'counter_order_id' => $order?->id,
                'order_number' => $order?->displayNumber(),
                'phone' => $first?->phone,
                'date' => $bill->sold_at,
                'customer' => self::customerLabel($first?->c_name),
                'amount' => $lines->sum(fn ($line) => (float) $line->selling_price * (float) $line->length - (float) $line->returned_amount),
                'items' => $lines->map(fn ($line) => [
                    'id' => (int) $line->id,
                    'name' => $line->cloth_name ?: 'سیٹ',
                    'color' => $line->color,
                    'category' => $categories->get($line->cloth_category_id)?->fullName() ?? '—',
                    'quantity' => (float) $line->length,
                    'unit' => $line->stock_unit ?: ClothCategory::UNIT_METER,
                    'amount' => (float) $line->selling_price * (float) $line->length - (float) $line->returned_amount,
                    'returned' => (float) $line->returned_quantity,
                ])->values()->all(),
            ];
        });
    }

    /** Biggest cloth customer in the period. */
    public function topSalesCustomer(int $userId, CarbonInterface $start, CarbonInterface $end): ?array
    {
        $row = $this->keptSales($userId, $end)->whereNotNull('sale_stocks.c_name')->where('sale_stocks.c_name', '!=', '')
            ->whereBetween('sale_stocks.sellDate', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->groupBy('sale_stocks.c_name')->selectRaw('sale_stocks.c_name, SUM('.self::KEPT_AMOUNT.') AS amount')
            ->selectRaw('COUNT(DISTINCT CASE WHEN '.self::KEPT_QUANTITY.' > 0.0001 THEN '.self::BILL_KEY.' END) AS bills')
            ->havingRaw('SUM('.self::KEPT_AMOUNT.') > 0.009')
            ->orderByDesc('amount')->first();

        return $row ? ['name' => self::customerLabel($row->c_name), 'amount' => (float) $row->amount, 'count' => (int) $row->bills] : null;
    }

    /** Stock on hand per category, in each category's unit. */
    public function stockByCategory(int $userId): Collection
    {
        $categories = ClothCategory::with('parent')->where('user_id', $userId)->get()->keyBy('id');

        return ClothColor::query()->join('cloths', 'cloths.id', '=', 'cloth_colors.cloth_id')
            ->where('cloths.user_id', $userId)->whereNull('cloths.deleted_at')
            ->groupBy('cloths.cloth_category_id', 'cloths.stock_unit')
            ->selectRaw('cloths.cloth_category_id AS category_id, cloths.stock_unit AS unit, COUNT(DISTINCT cloths.id) AS sets')
            ->selectRaw('SUM(cloth_colors.length) AS quantity, SUM(cloth_colors.length * COALESCE(cloth_colors.average_unit_cost, 0)) AS value')
            ->get()
            ->map(fn ($row) => [
                'category' => $categories->get($row->category_id)?->fullName() ?? 'بغیر کیٹیگری',
                'unit' => $row->unit ?: ClothCategory::UNIT_METER,
                'sets' => (int) $row->sets,
                'quantity' => (float) $row->quantity,
                'value' => (float) $row->value,
            ])->sortBy('category')->values();
    }

    // ------------------------------------------------------------- Tailoring

    public function tailoringMetrics(int $userId, CarbonInterface $start, CarbonInterface $end): array
    {
        $orders = $this->activeOrders($userId)->whereBetween('created_at', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->selectRaw('COUNT(*) AS orders, SUM(CASE WHEN suitQuantity >= 1 THEN suitQuantity ELSE 1 END) AS suits, SUM(totalPayment) AS revenue')
            ->first();

        return [
            'revenue' => (float) ($orders->revenue ?? 0),
            'orders' => (int) ($orders->orders ?? 0),
            'suits' => (int) ($orders->suits ?? 0),
            'received' => $this->received($userId, $start, $end, 'tailoring'),
        ];
    }

    /**
     * Orders placed in the period per status, labelled the way the shop chose under its work statuses
     * (simple mode joins the workshop steps into one). Cancelled orders are included so nothing goes missing.
     */
    public function ordersByStatus(int $userId, CarbonInterface $start, CarbonInterface $end, bool $detailed): Collection
    {
        $counts = Order::where('userId', (string) $userId)->whereBetween('created_at', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->selectRaw('status, COUNT(*) AS total')->groupBy('status')->pluck('total', 'status');
        $labels = Order::statusLabelsFor($detailed);

        return collect(Order::STATUSES)
            ->groupBy(fn ($status) => $labels[$status] ?? $status)
            ->map(fn ($statuses, $label) => [
                'label' => $label,
                'status' => $statuses->first(),
                'count' => (int) $statuses->sum(fn ($status) => $counts[$status] ?? 0),
            ])
            ->filter(fn ($item) => $item['count'] > 0)->values();
    }

    public function orders(int $userId, CarbonInterface $start, CarbonInterface $end, ?string $status, int $perPage = 15, string $pageName = 'orders_page'): LengthAwarePaginator
    {
        return Order::query()
            ->leftJoin('customers', 'customers.id', '=', 'orders.customerId')
            ->leftJoin('tailors', 'tailors.id', '=', 'orders.tailorId')
            ->where('orders.userId', (string) $userId)
            ->whereBetween('orders.created_at', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->when($status === 'workshop', fn ($query) => $query->whereIn('orders.status', Order::SIMPLE_WORKSHOP_STATUSES))
            ->when($status && $status !== 'workshop', fn ($query) => $query->where('orders.status', $status))
            ->orderByDesc('orders.created_at')->orderByDesc('orders.id')
            ->select(['orders.id', 'orders.suitNum', 'orders.suitQuantity', 'orders.totalPayment', 'orders.status', 'orders.returnDate', 'orders.created_at'])
            ->addSelect(['customers.name AS customer_name', 'tailors.name AS tailor_name'])
            ->paginate($perPage, ['*'], $pageName)->withQueryString();
    }

    /**
     * Each tailor's work: suits and charges in the period, plus everything still owed up to the end date
     * (stitching charges on their orders minus what has been paid against those orders).
     */
    public function tailors(int $userId, CarbonInterface $start, CarbonInterface $end): Collection
    {
        $suits = 'CASE WHEN orders.suitQuantity >= 1 THEN orders.suitQuantity ELSE 1 END';
        $from = $start->copy()->startOfDay();
        $to = $end->copy()->endOfDay();

        return Tailor::withTrashed()
            ->joinSub(DB::table('orders')
                ->selectRaw('orders.tailorId AS tailor_id')
                ->selectRaw("SUM(CASE WHEN orders.created_at >= ? THEN 1 ELSE 0 END) AS period_jobs", [$from])
                ->selectRaw("SUM(CASE WHEN orders.created_at >= ? THEN {$suits} ELSE 0 END) AS period_suits", [$from])
                ->selectRaw("SUM(CASE WHEN orders.created_at >= ? THEN COALESCE(orders.tailor_price, 0) * {$suits} ELSE 0 END) AS period_earned", [$from])
                ->selectRaw("SUM(COALESCE(orders.tailor_price, 0) * {$suits}) AS earned, SUM(COALESCE(orders.tailor_paid_amount, 0)) AS paid")
                ->where('orders.userId', (string) $userId)->whereNotNull('orders.tailorId')
                ->where(fn ($query) => $query->whereNull('orders.status')->orWhere('orders.status', '!=', 'cancelled'))
                ->where('orders.created_at', '<=', $to)
                ->groupBy('orders.tailorId'), 'tailor_work', 'tailor_work.tailor_id', '=', 'tailors.id')
            ->where('tailors.user_id', $userId)
            ->select(['tailors.id', 'tailors.name', 'tailors.phone_number1'])
            ->selectRaw('tailor_work.period_jobs, tailor_work.period_suits, tailor_work.period_earned, tailor_work.earned, tailor_work.paid, (tailor_work.earned - tailor_work.paid) AS balance')
            ->get()
            ->filter(fn ($tailor) => $tailor->period_jobs > 0 || $tailor->balance > 0.009)
            ->sortByDesc(fn ($tailor) => [(int) $tailor->period_suits, (float) $tailor->balance])
            ->values();
    }

    /** Money given to tailors and workers in the period: tailor payments, worker payments and salaries. */
    public function payouts(int $userId, CarbonInterface $start, CarbonInterface $end): Collection
    {
        $from = $start->copy()->startOfDay();
        $to = $end->copy()->endOfDay();
        $rows = collect();
        TailorRecord::with('tailor:id,name')->whereHas('tailor', fn ($query) => $query->withTrashed()->where('user_id', $userId))
            ->whereBetween('created_at', [$from, $to])->latest()->limit(200)->get()
            ->each(fn ($row) => $rows->push(['date' => $row->created_at->toDateString(), 'name' => $row->tailor?->name ?? 'درزی', 'kind' => 'درزی کو ادائیگی', 'note' => $row->comment, 'amount' => (float) $row->amount]));
        DB::table('worker_ledger_entries')->join('production_workers', 'production_workers.id', '=', 'worker_ledger_entries.production_worker_id')
            ->where('worker_ledger_entries.user_id', $userId)->whereNull('production_workers.legacy_tailor_id')
            ->where('worker_ledger_entries.entry_type', 'payment')
            ->whereBetween('worker_ledger_entries.entry_date', [$start->toDateString(), $end->toDateString()])
            ->orderByDesc('worker_ledger_entries.entry_date')->limit(200)
            ->get(['worker_ledger_entries.entry_date', 'worker_ledger_entries.amount', 'production_workers.name'])
            ->each(fn ($row) => $rows->push(['date' => $row->entry_date, 'name' => $row->name, 'kind' => 'ورکر کو ادائیگی', 'note' => null, 'amount' => abs((float) $row->amount)]));
        Workers::where('user_id', $userId)->whereBetween('dateentered', [$start->toDateString(), $end->toDateString()])
            ->orderByDesc('dateentered')->limit(200)->get()
            ->each(fn ($row) => $rows->push(['date' => $row->dateentered, 'name' => $row->Worker_Name, 'kind' => 'تنخواہ', 'note' => null, 'amount' => (float) $row->Worker_salary]));

        return $rows->sortByDesc(fn ($row) => (string) $row['date'])->values();
    }

    /** Biggest stitching customer in the period. */
    public function topTailoringCustomer(int $userId, CarbonInterface $start, CarbonInterface $end): ?array
    {
        $row = $this->activeOrders($userId)->join('customers', 'customers.id', '=', 'orders.customerId')
            ->whereBetween('orders.created_at', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->groupBy('customers.id', 'customers.name')
            ->selectRaw('customers.name, SUM(orders.totalPayment) AS amount, COUNT(*) AS orders')
            ->orderByDesc('amount')->first();

        return $row ? ['name' => $row->name, 'amount' => (float) $row->amount, 'count' => (int) $row->orders] : null;
    }

    // ---------------------------------------------------------------- Shared

    /**
     * Customers who still owe for one side (cloth "sales" or "tailoring"), using the customer ledger's
     * allocation so a customer's payments are never counted on both sides.
     */
    public function customerBalances(int $userId, CarbonInterface $end, string $side, ?string $search, int $perPage = 15, string $pageName = 'customers_page'): array
    {
        $balances = $this->ledger->sideBalances($userId, $end)->filter(fn ($balance) => $balance[$side] > 0.009);
        $customers = Customers::where('user_id', $userId)->whereIn('id', $balances->keys())
            ->when($search, fn ($query) => $query->where(fn ($nested) => $nested
                ->where('name', 'like', "%{$search}%")->orWhere('phone_number1', 'like', "%{$search}%")))
            ->get(['id', 'name', 'phone_number1'])
            ->map(fn ($customer) => [
                'name' => $customer->name,
                'phone' => $customer->phone_number1,
                'balance' => $balances[$customer->id][$side],
                'total' => $balances[$customer->id]['total'],
            ])->sortByDesc('balance')->values();
        $page = LengthAwarePaginator::resolveCurrentPage($pageName);
        $paginator = new LengthAwarePaginator($customers->forPage($page, $perPage)->values(), $customers->count(), $perPage, $page, [
            'path' => LengthAwarePaginator::resolveCurrentPath(),
            'pageName' => $pageName,
        ]);

        return [
            'list' => $paginator->withQueryString(),
            'total' => $balances->sum($side),
            'count' => $balances->count(),
        ];
    }

    /** Money customers paid in the period towards cloth sales or stitching. */
    private function received(int $userId, CarbonInterface $start, CarbonInterface $end, string $side): float
    {
        return (float) Transaction::where('userId', (string) $userId)
            ->whereBetween('created_at', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->where(fn ($query) => $side === 'sales'
                ? $query->whereIn('Order_type', self::SALE_TYPES)
                    ->orWhere(fn ($payment) => $payment->where('Order_type', 'Payment')->whereNotNull('counter_sale_receipt_id'))
                : $query->whereIn('Order_type', self::TAILOR_TYPES)
                    ->orWhere(fn ($payment) => $payment->where('Order_type', 'Payment')->whereNotNull('orderId')))
            ->sum('recivedPayment');
    }

    /** Counter sale lines with what has come back from each one (line_returns), so totals count only what the customer kept. */
    private function keptSales(int $userId, CarbonInterface $end)
    {
        return SaleStock::financiallyActive()
            ->leftJoinSub($this->finance->returnedPerSaleLine($userId, $end), 'line_returns', 'line_returns.sale_stock_id', '=', 'sale_stocks.id')
            ->where('sale_stocks.user_id', $userId);
    }

    private function activeOrders(int $userId)
    {
        return Order::where('orders.userId', (string) $userId)
            ->where(fn ($query) => $query->whereNull('orders.status')->orWhere('orders.status', '!=', 'cancelled'));
    }
}
