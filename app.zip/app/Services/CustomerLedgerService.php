<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Transaction;
use Carbon\CarbonInterface;
use Illuminate\Support\Collection;

class CustomerLedgerService
{
    public function orderBalances(int $ownerId, int $customerId): Collection
    {
        $allocation = $this->allocate($ownerId, $customerId);

        return collect($allocation['order_balances'])
            ->map(fn (int $cents) => round($cents / 100, 2));
    }

    /**
     * What each cloth sale receipt still owes after the customer's payments and credits are
     * allocated: a credit linked to a receipt pays that receipt first, unlinked ones pay the oldest dues.
     */
    public function receiptBalances(int $ownerId, int $customerId): Collection
    {
        $balances = [];
        foreach ($this->allocate($ownerId, $customerId)['charges'] as $charge) {
            if ($charge['receipt_id']) {
                $balances[$charge['receipt_id']] = ($balances[$charge['receipt_id']] ?? 0) + $charge['remaining'];
            }
        }

        return collect($balances)->map(fn (int $cents) => round(max(0, $cents) / 100, 2));
    }

    public function orderBalance(Order $order): float
    {
        $balances = $this->orderBalances((int) $order->userId, (int) $order->customerId);

        if ($balances->has((int) $order->id)) {
            return max(0, (float) $balances->get((int) $order->id));
        }

        return max(0, round(
            (float) $order->totalPayment - (float) $order->transactions()->sum('recivedPayment'),
            2
        ));
    }

    public function receiptSummary(Order $order): array
    {
        $allocation = $this->allocate((int) $order->userId, (int) $order->customerId);
        $orderId = (int) $order->id;

        if (! array_key_exists($orderId, $allocation['order_first_transaction_ids'])) {
            $orderBalance = $this->orderBalance($order);

            return [$orderBalance, 0.0, $orderBalance];
        }

        $firstOrderTransactionId = $allocation['order_first_transaction_ids'][$orderId];
        $previousCents = 0;

        foreach ($allocation['charges'] as $charge) {
            if ($charge['transaction_id'] < $firstOrderTransactionId) {
                $previousCents += $charge['remaining'];
            }
        }

        $previousBalance = max(0, round($previousCents / 100, 2));
        $orderBalance = max(0, round(($allocation['order_balances'][$orderId] ?? 0) / 100, 2));

        return [
            round($previousBalance + $orderBalance, 2),
            $previousBalance,
            $orderBalance,
        ];
    }

    public function trackingSummary(Order $order): array
    {
        $allocation = $this->allocate((int) $order->userId, (int) $order->customerId);
        $orderId = (int) $order->id;
        $customerBalance = max(0, round($allocation['ledger_balance'] / 100, 2));

        if (! array_key_exists($orderId, $allocation['order_first_transaction_ids'])) {
            return [$customerBalance, $this->orderBalance($order)];
        }

        $orderBalance = max(0, round(($allocation['order_balances'][$orderId] ?? 0) / 100, 2));

        return [
            max(0, round($customerBalance - $orderBalance, 2)),
            $orderBalance,
        ];
    }

    /**
     * What every customer of the shop still owes, split into cloth sales and stitching, using the same
     * allocation as the customer ledger: each remaining charge belongs to its order (stitching) or its
     * receipt (cloth); a charge with neither is placed by its transaction type.
     *
     * @return Collection<int, array{sales: float, tailoring: float, total: float}>
     */
    public function sideBalances(int $ownerId, ?CarbonInterface $end = null): Collection
    {
        // Plain rows (not models) for every transaction of the shop; userId is a text column, so it is
        // compared as text to keep its index usable.
        return Transaction::where('userId', (string) $ownerId)
            ->whereNotNull('customerId')
            ->when($end, fn ($query) => $query->where('created_at', '<=', $end->copy()->endOfDay()))
            ->orderBy('id')
            ->toBase()
            ->get(['id', 'customerId', 'orderId', 'counter_sale_receipt_id', 'Order_type', 'remainingBalance'])
            ->groupBy('customerId')
            ->map(function (Collection $transactions) {
                $allocation = $this->allocateTransactions($transactions);
                $sides = ['sales' => 0, 'tailoring' => 0];
                foreach ($allocation['charges'] as $charge) {
                    $side = $charge['order_id'] || str_starts_with((string) $charge['type'], 'Tailor') ? 'tailoring' : 'sales';
                    $sides[$side] += $charge['remaining'];
                }

                return [
                    'sales' => round(max(0, $sides['sales']) / 100, 2),
                    'tailoring' => round(max(0, $sides['tailoring']) / 100, 2),
                    'total' => round(max(0, $allocation['ledger_balance']) / 100, 2),
                ];
            });
    }

    private function allocate(int $ownerId, int $customerId): array
    {
        return $this->allocateTransactions(Transaction::where('userId', (string) $ownerId)
            ->where('customerId', (string) $customerId)
            ->orderBy('id')
            ->get(['id', 'orderId', 'counter_sale_receipt_id', 'Order_type', 'remainingBalance']));
    }

    private function allocateTransactions(Collection $transactions): array
    {
        $charges = [];
        $sharedCredit = 0;
        $orderCredits = [];
        $orderFirstTransactionIds = [];
        $ledgerBalance = 0;

        foreach ($transactions as $transaction) {
            $orderId = filled($transaction->orderId) ? (int) $transaction->orderId : null;
            $receiptId = filled($transaction->counter_sale_receipt_id) ? (int) $transaction->counter_sale_receipt_id : null;
            $amount = (int) round((float) $transaction->remainingBalance * 100);
            $ledgerBalance += $amount;

            if ($orderId && $transaction->Order_type === 'Tailor') {
                $orderFirstTransactionIds[$orderId] ??= (int) $transaction->id;
            }

            if ($amount > 0) {
                if ($orderId && ($orderCredits[$orderId] ?? 0) > 0) {
                    $applied = min($amount, $orderCredits[$orderId]);
                    $amount -= $applied;
                    $orderCredits[$orderId] -= $applied;
                }

                if ($sharedCredit > 0) {
                    $applied = min($amount, $sharedCredit);
                    $amount -= $applied;
                    $sharedCredit -= $applied;
                }

                $charges[] = [
                    'transaction_id' => (int) $transaction->id,
                    'order_id' => $orderId,
                    'receipt_id' => $receiptId,
                    'type' => $transaction->Order_type,
                    'remaining' => $amount,
                ];

                continue;
            }

            if ($amount >= 0) {
                continue;
            }

            $credit = abs($amount);
            if (! $orderId && $receiptId) {
                // A receipt payment / return / cancellation settles that receipt first; any excess is shared.
                $credit = $this->applyCredit($charges, $credit, null, $receiptId);
            }
            $credit = $this->applyCredit($charges, $credit, $orderId);

            if ($credit > 0) {
                if ($orderId) {
                    $orderCredits[$orderId] = ($orderCredits[$orderId] ?? 0) + $credit;
                } else {
                    $sharedCredit += $credit;
                }
            }
        }

        $orderBalances = array_fill_keys(array_keys($orderFirstTransactionIds), 0);
        foreach ($charges as $charge) {
            if ($charge['order_id'] && array_key_exists($charge['order_id'], $orderBalances)) {
                $orderBalances[$charge['order_id']] += $charge['remaining'];
            }
        }

        return [
            'charges' => $charges,
            'ledger_balance' => $ledgerBalance,
            'order_balances' => $orderBalances,
            'order_first_transaction_ids' => $orderFirstTransactionIds,
        ];
    }

    private function applyCredit(array &$charges, int $credit, ?int $orderId, ?int $receiptId = null): int
    {
        foreach ($charges as &$charge) {
            if ($credit <= 0) {
                break;
            }

            if ($orderId && $charge['order_id'] !== $orderId) {
                continue;
            }

            if ($receiptId && $charge['receipt_id'] !== $receiptId) {
                continue;
            }

            if ($charge['remaining'] <= 0) {
                continue;
            }

            $applied = min($credit, $charge['remaining']);
            $charge['remaining'] -= $applied;
            $credit -= $applied;
        }
        unset($charge);

        return $credit;
    }
}
