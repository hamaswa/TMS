<?php

namespace App\Services;

use App\Models\Business;
use App\Models\MeasurementTemplate;
use App\Models\Options;
use App\Models\OptionType;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class TailoringOptionDefaultsService
{
    public const SEWING_TYPE_SLUG = 'add_sewing_type';

    public const DEFAULT_MEASUREMENT_TEMPLATE_NAME = 'مردانہ شلوار قمیض';

    public const SEWING_TYPE_CHOICES = [
        'چمک تین سیلائی مکمل',
        'چمک تین سیلائی ہاف',
        'چمک سادہ مکمل ٹچ',
        'چمک سلای اوپر والی سنگل',
        'چمک سیلائی',
        'دبل چمک سیلائی مکمل',
        'ڈبل چمک سیلائی ہاف',
        'سادہ',
        'سادہ چمک ھاف',
        'سنگل چمک سیلائی',
        'سنگل چمک سیلائی پھرکی والی',
        'کر تہ کلی والا',
        'کنکر سیلا ئی',
        'گوم سیلائی',
    ];

    public const NECK_TYPE_CHOICES = [
        '2 انچ کالر 5۔16',
        'collar',
        'افغانی گلہ',
        'افغانی گلہ پیچھے بین',
        'افغانی گلہ شانے پربٹن',
        'بین انچ سے 2 سطر کم 11',
        'بین انچ سے 2 سطر کم 13.5',
        'بین 11',
        'بین 11۔5',
        'بین 13',
        'بین 13۔5',
        'بین 14',
        'بین 14۔5',
        'بین 15',
        'بین 16',
        'بین 17',
        'بین 18',
        'بین 19',
        'بین 20',
        'بین 21',
        'بین 3 یس 16',
        'بین 3 یس 17',
        'بین 3 یس 5۔16',
        'بین 5۔ 16',
        'بین 5۔15',
        'بین 5۔17',
        'بین 5۔18',
        'بین 5۔19',
        'بین آدہ انچ 15',
        'بین آدہ انچ 16',
        'بین آدہ انچ 17',
        'بین آدہ انچ 5۔15',
        'بین آدہ انچ 5۔16',
        'بین آدہ انچ 5۔17',
        'بین آدہ انچ گول 15',
        'بین انچ سے 2 سطر کم 15',
        'بین انچ سے 2 سطر کم 16',
        'بین انچ سے 2 سطر کم 17',
        'بین انچ سے 2 سطر کم 18',
        'بین انچ سے 2 سطر کم 19',
        'بین انچ سے 2 سطر کم 5۔15',
        'بین انچ سے 2 سطر کم 5۔16',
        'بین انچ سے 2 سطر کم 5۔17',
        'بین انچ سے 2 سطر کم 5۔18',
        'بین انچ سے 2 سطر کم 5۔19',
        'بین انچ سے 2 سطر کم 12.5',
        'بین انچ سے 2 سطر کم گول 16،5',
        'بین انچ سے 2 سطر کم 12',
        'بین انچ سے 2 سطر کم 13',
        'بین انچ سے 2 سطر کم 14',
        'بین انچ سے 2 سطر کم 14.5',
        'بین انچ سے 2 سطر کم گول 14',
        'بین انچ سے 2 سطر کم گول 17',
        'بین انچ سے 2 سطر کم گول 14۔5',
        'بین انچ سے 2 سطر کم گول 15',
        'بین انچ سے 2 سطر کم گول 15۔5',
        'بین انچ سے 2 سطر کم گول 19۔5',
        'بین انچ سے 2 سطر کم گول 20',
        'بین انچ سے 2 سطر کم گول 16',
        'بین انچ سے 2 سطر کم گول 18',
        'بین انچ سے 2 سطر کم گول 17۔5',
        'بین انچ سے 2 سطر کم گول 19',
        'بین سوا 19',
        'بین سوا 18',
        'بین سوا 21',
        'بین سوا انچ 15',
        'بین سوا انچ 16',
        'بین سوا انچ 17',
        'بین سوا انچ 18',
        'بین سوا انچ 19',
        'بین سوا انچ 5۔15',
        'بین سوا انچ 5۔17',
        'بین سوا انچ 5۔18',
        'بین سوا انچ 5۔19',
        'بین سوا انچ 6۔16',
        'بین گول 14',
        'بین گول 15',
        'بین گول 15.50',
        'بین گول 16',
        'بین گول 16.50',
        'بین گول 17',
        'بین گول 17.50',
        'بین گول 18',
        'بین گول 18.50',
        'بین گول 19',
        'بین گول 20',
        'بین گول . 19.50',
        'بینا انچ سے 2 سطر کم 11.5',
        'پونے 2 انچ 16 کالر',
        'پونے 2 انچ15 کالر',
        'دبل بین 13',
        'دبل بین 14',
        'دبل بین 15',
        'دبل بین 16',
        'دبل بین 17',
        'دبل بین 18',
        'دبل بین 5۔13',
        'دبل بین 5۔14',
        'دبل بین 5۔15',
        'دبل بین 5۔16',
        'دبل بین 5۔17',
        'دبل بین 5۔18',
        'سادہ 14',
        'سادہ 15',
        'سادہ 16',
        'سادہ 17',
        'سادہ 18',
        'سادہ گلہ پیچھے بین',
        'کالر ڈیڈ 2-1 انچ نوک',
        'کالر 12',
        'کالر 13',
        'کالر 14',
        'کالر 15',
        'کالر 15 2انچ',
        'کالر 16',
        'کالر 16 2 انچ',
        'کالر 17',
        'کالر 18',
        'کالر 2 انچ نوک 15',
        'کالر 2 انچ نوک',
        'کالر 2 انچ نوک 14',
        'کالر 5۔12',
        'کالر 5۔13',
        'کالر 5۔14',
        'کالر 5۔15',
        'کالر 5۔16',
        'کالر 5۔16 2 انچ',
        'کالر 5۔17',
        'کالر 5۔18',
        'کالر سوا 2 نوک 14',
        'کالر سوا 2 انچ نوک',
        'کالر سوا 2 انچ نوک 14.50',
        'کالر سوا 2 نوک 14.5',
        'کالر سوا 2 نوک 15',
        'کالر سوا 2 نوک 15.5',
        'کالر سوا 2 نوک 16',
        'کالر سوا 2 نوک 16.5',
        'کالر سوا 2 نوک 17',
        'کالر سوا 2 نوک 17.5',
        'کالر سوا 2 نوک 18',
        'کالر سوا 2 نوک 18.5',
        'کالر سوا 2 نوک 19',
        'کالر18',
        'کالرسوا 2 انچ نوک 14',
        'کالرسوا 2 انچ نوک 15',
        'کالرسوا 2 انچ نوک 16',
        'کالرسوا 2 انچ نوک 17',
    ];

    public const SLEEVE_TYPE_CHOICES = [
        'بازو گول 4',
        'بازو گول 5',
        'بازو گول 5۔5',
        'بازو گول 5۔6',
        'بازو گول 6',
        'بازو گول 6.25',
        'بازو گول 7',
        'بازو گول چکپٹی',
        'بازو گول چکپٹی 4،5',
        'بازو گول کنی 6',
        'بازو گول کنی 5',
        'بازو گول کنی 5۔4',
        'بازو گول کنی 5۔5',
        'بازو گول کنی 7',
        'بازو گول کنی 8',
        'بازو گول کنی5۔6',
        'رینگ بٹن',
        'کف 7/2.5',
        'کف 2.5 / 9',
        'کف گول 2.5 /9',
        'کف 10.5',
        'کف 10/2.5',
        'کف 2.5 /سوا 8',
        'کف 2.5/ 9.5',
        'کف 2/ 5۔7',
        'کف 5۔2 / 5۔8',
        'کف 5۔2 / 5۔9',
        'کف 5۔2 / 9',
        'کف 5۔2 /5۔9سنگل سٹڈ',
        'کف 5۔2 /8',
        'کف 5۔2 /9سنگل سٹڈ',
        'کف 5۔2/سوا9',
        'کف بازو گول کنی 4',
        'کف چورس 10/2.5اوپرنیچےبٹن',
        'کف چورس 2.5 /8',
        'کف چورس 5۔2 /10',
        'کف چورس 5۔2 /5۔9',
        'کف چورس 5۔2 /9',
        'کف چورس 9.5/2.5اوپرنیچےبٹن',
        'کف چورس 9.75 ڈاٹ',
        'کف چورس 9/2.5اوپرنیچےبٹن',
        'کف ڈاٹ ہو 5۔9/ 5۔2',
        'کف ڈاٹ ہو 9/5۔2',
        'کف ڈبل سٹڈ 2.5 /8',
        'کف ڈبل سٹڈ 2.5 /8.5',
        'کف ڈبل سٹڈ 2.5 /9',
        'کف ڈبل سٹڈ 2.5 /9.5',
        'کف سٹڈ 2.5 / 9.5',
        'کف سٹڈ 9 /2.5',
        'کف سٹیڈ 3',
        'کف سنگل سٹڈ 2.5/ 10',
        'کف سنگل سٹڈ 2.5 / 10.5',
        'کف سنگل سٹڈ 2.5/ 8.5',
        'کف سنگل سٹڈ 2.5 / 9.5',
        'کف سوا 9/2.5 گول',
        'کف سیڈ 2.5 /9',
        'کف سیڈ 2.5 /9،5',
        'کف کٹ 9/2.5',
        'کف کٹ 2.5 / 9.5',
        'کف کٹ 2.5/ 8.5',
        'کف کٹ 5۔2 / 10',
        'کف کٹ 5۔9/ 5۔2',
        'کف گول 10/2.5',
        'کف گول 2.5 / 9.5',
    ];

    public const POCKET_TYPE_CHOICES = [
        '1سامنے 2سائیڈ',
        '1سامنے 2سائیڈشلوارجیب نہ ٰ ھو',
        '2 سائیڈ 2 شلور جیب پجامہ ٹائپ',
        '2 سائیڈ شلور جیب نہ ہو',
        '2 سامنے تاش جیب',
        '2سائیڈ شلوارجیب نہ ٰ ھو',
    ];

    public const BUTTON_TYPE_CHOICES = [
        'بٹن سادہ',
        'ڈیزائن',
        'رینگ',
        'رینگ ڈیزائن',
        'رینگ ڈیزائن کراچی والی',
        'رینگ ڈیزائن نگ',
        'لکڑی',
        'میٹل',
    ];

    public const PLATE_TYPE_CHOICES = [
        '10',
        '11',
        '12',
        '13',
        '14',
        '15',
        '16',
        '16.5',
        '17',
        '17.5',
        'ادھا انچ 10',
        'انچ سے 2 سطر کم 12',
        'پلیٹ ایک انچ نوک 13',
        'پلیٹ ایک انچ نوک 14',
        'پلیٹ سوا ایک انچ 13',
        'پلیٹ سوا ایک انچ 14',
        'پلیٹ سوا ایک انچ 5۔13',
        'پلیٹ سوا ایک انچ نوک 13',
        'پلیٹ سوا ایک انچ نوک 14',
        'پلیٹ نوک 12',
        'پلیٹ نوک 13',
        'پلیٹ نوک 14',
        'پلیٹ نوک 11',
        'پلیٹ نوک ایک انچ 13',
        'پلیٹ نوک ایک انچ 14',
        'پلیٹ نوک ایک انچ 5۔13',
        'ڈبل پلیٹ 10',
        'ڈبل پلیٹ 11',
        'ڈبل پلیٹ 12',
        'ڈبل پلیٹ 13',
        'ڈبل پلیٹ 14',
        'ڈبل پلیٹ 15',
    ];

    public const DAAMAN_TYPE_CHOICES = [
        'دامن چورس',
        'دامن گول',
        'دامن گول ڈبل سیلائی',
    ];

    public function seedForOwner(int $ownerId): void
    {
        DB::transaction(function () use ($ownerId) {
            foreach ($this->defaultOptionTypes() as $typeSlug => $defaults) {
                $optionType = OptionType::query()
                    ->whereNull('user_id')
                    ->where('slug', $typeSlug)
                    ->first();

                if (! $optionType) {
                    $optionType = OptionType::create([
                        'user_id' => null,
                        'slug' => $typeSlug,
                        'Name' => $defaults['name'],
                        'type' => $defaults['type'],
                    ]);
                }

                foreach (array_unique($defaults['choices']) as $choice) {
                    Options::firstOrCreate(
                        [
                            'user_id' => $ownerId,
                            'measurement_template_id' => null,
                            'option_id' => $optionType->id,
                            'Name' => $choice,
                        ],
                        [
                            'slug' => 'default-'.$ownerId.'-'.substr(sha1($typeSlug.'|'.$choice), 0, 16),
                        ]
                    );
                }
            }

            $this->seedMeasurementTemplateForOwner($ownerId);
        });
    }

    public function seedMeasurementTemplateForOwner(int $ownerId): MeasurementTemplate
    {
        $template = MeasurementTemplate::firstOrNew([
            'user_id' => $ownerId,
            'name' => self::DEFAULT_MEASUREMENT_TEMPLATE_NAME,
        ]);

        if (! $template->exists) {
            $template->description = 'قمیض، شلوار اور متعلقہ سلائی کی پسند کے لیے مکمل بنیادی ٹیمپلیٹ';
            $template->custom_field_ids = [];
            $template->layout_columns = 2;
        }

        $template->forceFill([
            'system_fields' => array_keys(MeasurementService::SYSTEM_FIELDS),
            'is_builtin' => true,
            'is_default' => true,
            'is_active' => true,
        ])->save();

        MeasurementTemplate::where('user_id', $ownerId)
            ->where('id', '!=', $template->id)
            ->update(['is_default' => false, 'is_builtin' => false]);

        Options::where('user_id', $ownerId)->whereNull('measurement_template_id')->get()
            ->each(function (Options $option) use ($template): void {
                Options::firstOrCreate([
                    'user_id' => $option->user_id,
                    'measurement_template_id' => $template->id,
                    'option_id' => $option->option_id,
                    'Name' => $option->Name,
                ], [
                    'slug' => $option->slug.'-template-'.$template->id,
                ]);
            });

        return $template;
    }

    public function defaultOptionTypes(): array
    {
        return [
            self::SEWING_TYPE_SLUG => [
                'name' => 'سلائی',
                'type' => 'swingtype',
                'choices' => self::SEWING_TYPE_CHOICES,
            ],
            'add_neck_type' => [
                'name' => 'گلہ',
                'type' => 'necktype',
                'choices' => self::NECK_TYPE_CHOICES,
            ],
            'add_sleeve_opening_type' => [
                'name' => 'کف',
                'type' => 'sleeve',
                'choices' => self::SLEEVE_TYPE_CHOICES,
            ],
            'add_pocket_type' => [
                'name' => 'جیب',
                'type' => 'jeab',
                'choices' => self::POCKET_TYPE_CHOICES,
            ],
            'add_button_type' => [
                'name' => 'بٹن',
                'type' => 'button',
                'choices' => self::BUTTON_TYPE_CHOICES,
            ],
            'plate_type' => [
                'name' => 'پلیٹ',
                'type' => 'plate_type',
                'choices' => self::PLATE_TYPE_CHOICES,
            ],
            'add_daaman_type' => [
                'name' => 'دامن',
                'type' => 'daaman',
                'choices' => self::DAAMAN_TYPE_CHOICES,
            ],
        ];
    }

    public function seedForAllTailoringOwners(): void
    {
        $ownerIds = User::query()
            ->where('tailoring_access', true)
            ->where(function ($query) {
                $query->where('is_business_owner', true)
                    ->orWhereHas('roles', fn ($roles) => $roles->where('name', 'shop_owner'));
            })
            ->pluck('id')
            ->merge(Business::query()->where('tailoring_enabled', true)->pluck('owner_user_id'))
            ->filter()
            ->unique();

        foreach ($ownerIds as $ownerId) {
            $this->seedForOwner((int) $ownerId);
        }
    }
}
