<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StorefrontOrder extends Model
{
    use HasFactory;

    public const STATUS_PENDING = 'pending';

    public const STATUS_CONFIRMED = 'confirmed';

    public const STATUS_COMPLETE = 'complete';

    public const STATUS_CANCELLED = 'cancelled';

    public const PAYMENT_UNPAID = 'unpaid';

    public const PAYMENT_COD = 'cod';

    public const PAYMENT_EASYPAISA = 'easypaisa';

    public const PAYMENT_JAZZCASH = 'jazzcash';

    public const PAYMENT_BANK_TRANSFER = 'bank_transfer';

    public const PAYMENT_RAAST = 'raast';

    public const VERIFICATION_NOT_REQUIRED = 'not_required';

    public const VERIFICATION_PENDING = 'pending';

    public const VERIFICATION_VERIFIED = 'verified';

    public const VERIFICATION_REJECTED = 'rejected';

    protected $fillable = [
        'storefront_id',
        'storefront_cart_id',
        'customer_id',
        'transaction_id',
        'reference',
        'tracking_token_hash',
        'status',
        'fulfillment_method',
        'delivery_address',
        'customer_note',
        'payment_method',
        'payment_sender_phone',
        'payment_reference',
        'payment_evidence_path',
        'payment_evidence_original_name',
        'payment_evidence_mime_type',
        'payment_evidence_size',
        'payment_evidence_submitted_at',
        'payment_verification_status',
        'payment_verification_notes',
        'payment_verified_by_user_id',
        'payment_verified_at',
        'payment_rejected_at',
        'payment_collected_at',
        'payment_collected_by_user_id',
        'payment_collection_reference',
        'payment_collection_notes',
        'subtotal',
        'paid_amount',
        'balance_amount',
        'placed_at',
        'confirmed_by_user_id',
        'confirmed_at',
        'completed_at',
        'cancelled_at',
    ];

    public static function paymentMethods(): array
    {
        return [
            self::PAYMENT_UNPAID => 'ابھی ادائیگی نہیں',
            self::PAYMENT_COD => 'کیش آن ڈیلیوری',
            self::PAYMENT_EASYPAISA => 'ایزی پیسہ',
            self::PAYMENT_JAZZCASH => 'جاز کیش',
            self::PAYMENT_BANK_TRANSFER => 'بینک ٹرانسفر',
            self::PAYMENT_RAAST => 'راست',
        ];
    }

    public static function publicPaymentMethods(): array
    {
        return [
            self::PAYMENT_UNPAID => __('storefront.payment.methods.unpaid'),
            self::PAYMENT_COD => __('storefront.payment.methods.cod'),
            self::PAYMENT_EASYPAISA => __('storefront.payment.methods.easypaisa'),
            self::PAYMENT_JAZZCASH => __('storefront.payment.methods.jazzcash'),
            self::PAYMENT_BANK_TRANSFER => __('storefront.payment.methods.bank_transfer'),
            self::PAYMENT_RAAST => __('storefront.payment.methods.raast'),
        ];
    }

    public static function manualPaymentMethods(): array
    {
        return [
            self::PAYMENT_EASYPAISA,
            self::PAYMENT_JAZZCASH,
            self::PAYMENT_BANK_TRANSFER,
            self::PAYMENT_RAAST,
        ];
    }

    public static function requiresManualVerification(?string $method): bool
    {
        return in_array($method, self::manualPaymentMethods(), true);
    }

    protected $hidden = ['tracking_token_hash'];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'paid_amount' => 'decimal:2',
        'balance_amount' => 'decimal:2',
        'placed_at' => 'datetime',
        'confirmed_at' => 'datetime',
        'completed_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'payment_verified_at' => 'datetime',
        'payment_rejected_at' => 'datetime',
        'payment_collected_at' => 'datetime',
        'payment_evidence_size' => 'integer',
        'payment_evidence_submitted_at' => 'datetime',
    ];

    public function storefront()
    {
        return $this->belongsTo(Storefront::class);
    }

    public function cart()
    {
        return $this->belongsTo(StorefrontCart::class, 'storefront_cart_id');
    }

    public function customer()
    {
        return $this->belongsTo(Customers::class, 'customer_id');
    }

    public function transaction()
    {
        return $this->belongsTo(Transaction::class);
    }

    public function items()
    {
        return $this->hasMany(StorefrontOrderItem::class);
    }

    public function tailoringItems()
    {
        return $this->hasMany(StorefrontOrderTailoringItem::class);
    }

    public function paymentVerifier()
    {
        return $this->belongsTo(User::class, 'payment_verified_by_user_id');
    }

    public function confirmedBy()
    {
        return $this->belongsTo(User::class, 'confirmed_by_user_id');
    }

    public function paymentCollectedBy()
    {
        return $this->belongsTo(User::class, 'payment_collected_by_user_id');
    }

    public function refunds()
    {
        return $this->hasMany(StorefrontOrderRefund::class);
    }

    public function returns()
    {
        return $this->hasMany(StorefrontOrderReturn::class);
    }

    public static function verificationStatuses(): array
    {
        return [
            self::VERIFICATION_NOT_REQUIRED => 'تصدیق درکار نہیں',
            self::VERIFICATION_PENDING => 'تصدیق زیرِ انتظار',
            self::VERIFICATION_VERIFIED => 'ادائیگی تصدیق شدہ',
            self::VERIFICATION_REJECTED => 'ادائیگی مسترد',
        ];
    }
}
