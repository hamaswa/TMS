<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StorefrontInquiry extends Model
{
    use HasFactory;

    public const STATUS_NEW = 'new';

    public const STATUS_CONTACTED = 'contacted';

    public const STATUS_CLOSED = 'closed';

    public const STATUS_CONFIRMED = 'confirmed';

    public const STATUS_REJECTED = 'rejected';

    public const PAYMENT_UNPAID = 'unpaid';

    public const PAYMENT_COD = 'cod';

    public const PAYMENT_EASYPAISA = 'easypaisa';

    public const PAYMENT_JAZZCASH = 'jazzcash';

    public const PAYMENT_BANK_TRANSFER = 'bank_transfer';

    public const PAYMENT_RAAST = 'raast';

    public const VERIFICATION_NOT_REQUIRED = 'not_required';

    public const VERIFICATION_PENDING = 'pending';

    public const VERIFICATION_VERIFIED = 'verified';

    public const VERIFICATION_REJECTED = 'rejected';

    protected $fillable = [
        'storefront_id',
        'tailoring_service_id',
        'measurement_template_id',
        'customer_id',
        'order_id',
        'customer_name',
        'phone',
        'booking_pin_hash',
        'email',
        'city',
        'preferred_date',
        'measurement_method',
        'suit_quantity',
        'estimated_price',
        'service_deposit_type',
        'service_deposit_value',
        'service_deposit_amount',
        'final_price',
        'promised_date',
        'message',
        'payment_method',
        'payment_sender_phone',
        'payment_reference',
        'payment_claimed_amount',
        'payment_evidence_path',
        'payment_evidence_original_name',
        'payment_evidence_mime_type',
        'payment_evidence_size',
        'payment_evidence_submitted_at',
        'payment_verification_status',
        'payment_verification_notes',
        'payment_verified_by_user_id',
        'payment_verified_at',
        'payment_rejected_at',
        'status',
        'admin_notes',
        'confirmed_by_user_id',
        'rejected_by_user_id',
        'rejection_reason',
        'contacted_at',
        'confirmed_at',
        'rejected_at',
        'closed_at',
    ];

    protected $hidden = ['booking_pin_hash'];

    public static function paymentMethods(): array
    {
        return [
            self::PAYMENT_UNPAID => 'ابھی ادائیگی نہیں',
            self::PAYMENT_COD => 'کیش آن ڈیلیوری',
            self::PAYMENT_EASYPAISA => 'ایزی پیسہ',
            self::PAYMENT_JAZZCASH => 'جاز کیش',
            self::PAYMENT_BANK_TRANSFER => 'بینک ٹرانسفر',
            self::PAYMENT_RAAST => 'راست',
        ];
    }

    public static function publicPaymentMethods(): array
    {
        return [
            self::PAYMENT_UNPAID => __('storefront.payment.methods.unpaid'),
            self::PAYMENT_COD => __('storefront.payment.methods.cod'),
            self::PAYMENT_EASYPAISA => __('storefront.payment.methods.easypaisa'),
            self::PAYMENT_JAZZCASH => __('storefront.payment.methods.jazzcash'),
            self::PAYMENT_BANK_TRANSFER => __('storefront.payment.methods.bank_transfer'),
            self::PAYMENT_RAAST => __('storefront.payment.methods.raast'),
        ];
    }

    public static function manualPaymentMethods(): array
    {
        return StorefrontOrder::manualPaymentMethods();
    }

    public static function requiresManualVerification(?string $method): bool
    {
        return in_array($method, self::manualPaymentMethods(), true);
    }

    protected $casts = [
        'preferred_date' => 'date',
        'promised_date' => 'date',
        'contacted_at' => 'datetime',
        'confirmed_at' => 'datetime',
        'rejected_at' => 'datetime',
        'closed_at' => 'datetime',
        'payment_verified_at' => 'datetime',
        'payment_rejected_at' => 'datetime',
        'payment_evidence_size' => 'integer',
        'payment_evidence_submitted_at' => 'datetime',
        'service_deposit_value' => 'decimal:2',
        'service_deposit_amount' => 'decimal:2',
        'estimated_price' => 'decimal:2',
        'payment_claimed_amount' => 'decimal:2',
        'final_price' => 'decimal:2',
        'suit_quantity' => 'integer',
    ];

    public static function statuses(): array
    {
        return [
            self::STATUS_NEW => 'نئی درخواست',
            self::STATUS_CONTACTED => 'رابطہ ہو گیا',
            self::STATUS_CLOSED => 'بند',
            self::STATUS_CONFIRMED => 'تصدیق شدہ بکنگ',
            self::STATUS_REJECTED => 'مسترد',
        ];
    }

    public function storefront()
    {
        return $this->belongsTo(Storefront::class);
    }

    public function service()
    {
        return $this->belongsTo(StorefrontTailoringService::class, 'tailoring_service_id');
    }

    public function measurementTemplate()
    {
        return $this->belongsTo(MeasurementTemplate::class);
    }

    public function paymentVerifier()
    {
        return $this->belongsTo(User::class, 'payment_verified_by_user_id');
    }

    public function customer()
    {
        return $this->belongsTo(Customers::class);
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function confirmedBy()
    {
        return $this->belongsTo(User::class, 'confirmed_by_user_id');
    }

    public function rejectedBy()
    {
        return $this->belongsTo(User::class, 'rejected_by_user_id');
    }

    public static function verificationStatuses(): array
    {
        return [
            self::VERIFICATION_NOT_REQUIRED => 'تصدیق درکار نہیں',
            self::VERIFICATION_PENDING => 'تصدیق زیرِ انتظار',
            self::VERIFICATION_VERIFIED => 'ادائیگی تصدیق شدہ',
            self::VERIFICATION_REJECTED => 'ادائیگی مسترد',
        ];
    }

    public function getReferenceAttribute(): string
    {
        return ($this->booking_pin_hash ? 'BOOK-' : 'INQ-').str_pad((string) $this->id, 6, '0', STR_PAD_LEFT);
    }

    public function isBooking(): bool
    {
        return filled($this->booking_pin_hash) && filled($this->tailoring_service_id);
    }
}
