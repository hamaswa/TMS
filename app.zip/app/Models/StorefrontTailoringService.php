<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StorefrontTailoringService extends Model
{
    use HasFactory;

    public const DEPOSIT_NONE = 'none';
    public const DEPOSIT_PERCENTAGE = 'percentage';
    public const DEPOSIT_FIXED = 'fixed';

    public const MEASUREMENT_SHOP_VISIT = 'shop_visit';
    public const MEASUREMENT_EXISTING_PROFILE = 'existing_profile';
    public const MEASUREMENT_HOME_VISIT = 'home_visit';
    public const MEASUREMENT_STANDARD_SIZE = 'standard_size';
    public const MEASUREMENT_CUSTOM = 'custom_measurements';

    protected $fillable = [
        'storefront_id',
        'measurement_template_id',
        'name',
        'name_ur',
        'name_en',
        'description',
        'description_ur',
        'description_en',
        'price_from',
        'price_unit',
        'estimated_days',
        'deposit_type',
        'deposit_value',
        'measurement_methods',
        'standard_sizes',
        'weekly_booking_limit',
        'is_featured',
        'is_published',
        'is_available',
        'accepts_inquiries',
        'sort_order',
    ];

    protected $casts = [
        'price_from' => 'decimal:2',
        'estimated_days' => 'integer',
        'deposit_value' => 'decimal:2',
        'measurement_methods' => 'array',
        'standard_sizes' => 'array',
        'weekly_booking_limit' => 'integer',
        'is_featured' => 'boolean',
        'is_published' => 'boolean',
        'is_available' => 'boolean',
        'accepts_inquiries' => 'boolean',
        'sort_order' => 'integer',
    ];

    public function storefront()
    {
        return $this->belongsTo(Storefront::class);
    }

    public function localizedName(?string $locale = null): string
    {
        $locale = in_array($locale ?: app()->getLocale(), ['ur', 'en'], true) ? ($locale ?: app()->getLocale()) : 'ur';

        return $this->getAttribute('name_'.$locale) ?: $this->name;
    }

    public function localizedDescription(?string $locale = null): ?string
    {
        $locale = in_array($locale ?: app()->getLocale(), ['ur', 'en'], true) ? ($locale ?: app()->getLocale()) : 'ur';

        return $this->getAttribute('description_'.$locale) ?: $this->description;
    }

    public function localizedPriceUnit(?string $locale = null): string
    {
        $locale = $locale ?: app()->getLocale();
        if ($locale !== 'en') {
            return $this->price_unit;
        }

        return [
            'فی سوٹ' => 'per suit',
            'فی لباس' => 'per garment',
            'فی کام' => 'per job',
        ][$this->price_unit] ?? $this->price_unit;
    }

    public function inquiries()
    {
        return $this->hasMany(StorefrontInquiry::class, 'tailoring_service_id');
    }

    public function measurementTemplate()
    {
        return $this->belongsTo(MeasurementTemplate::class);
    }

    public static function depositTypes(): array
    {
        return [
            self::DEPOSIT_NONE => 'پیشگی رقم ضروری نہیں',
            self::DEPOSIT_PERCENTAGE => 'قیمت کا فیصد',
            self::DEPOSIT_FIXED => 'مقررہ رقم',
        ];
    }

    public static function measurementMethodLabels(): array
    {
        return [
            self::MEASUREMENT_STANDARD_SIZE => 'معیاری سائز منتخب کریں',
            self::MEASUREMENT_CUSTOM => 'اپنی مکمل پیمائش درج کریں',
            self::MEASUREMENT_SHOP_VISIT => 'دکان پر نئی پیمائش',
            self::MEASUREMENT_EXISTING_PROFILE => 'محفوظ شدہ پیمائش',
            self::MEASUREMENT_HOME_VISIT => 'گھر پر پیمائش',
        ];
    }

    public function availableMeasurementMethods(): array
    {
        return $this->measurement_methods ?: [
            self::MEASUREMENT_SHOP_VISIT,
            self::MEASUREMENT_EXISTING_PROFILE,
        ];
    }

    public function availableStandardSizes(): array
    {
        $profiles = $this->availableStandardProfiles();
        if ($profiles->isNotEmpty()) {
            return $profiles->pluck('name')->all();
        }

        return collect($this->standard_sizes ?: [])
            ->map(fn ($size) => trim((string) $size))->filter()->unique()->values()->all();
    }

    public function availableStandardProfiles()
    {
        if (! $this->measurementTemplate) {
            return collect();
        }

        if ($this->measurementTemplate->relationLoaded('standardProfiles')) {
            return $this->measurementTemplate->standardProfiles->where('is_active', true)->values();
        }

        return $this->measurementTemplate->standardProfiles()->where('is_active', true)->get();
    }

    public function depositAmount(): ?float
    {
        if ($this->deposit_type === self::DEPOSIT_FIXED) {
            return round((float) $this->deposit_value, 2);
        }
        if ($this->deposit_type === self::DEPOSIT_PERCENTAGE
            && $this->price_from !== null && $this->deposit_value !== null) {
            return round((float) $this->price_from * (float) $this->deposit_value / 100, 2);
        }

        return null;
    }
}
