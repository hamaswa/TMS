<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // middlewares that run on every request in your application
        $middleware->use([
            // \App\Http\Middleware\TrustHosts::class,
            \App\Http\Middleware\TrustProxies::class,
            \Illuminate\Http\Middleware\HandleCors::class,
            // \Fruitcake\Cors\HandleCors::class,
            \App\Http\Middleware\PreventRequestsDuringMaintenance::class,
            \Illuminate\Foundation\Http\Middleware\ValidatePostSize::class,
            \App\Http\Middleware\TrimStrings::class,
            \Illuminate\Foundation\Http\Middleware\ConvertEmptyStringsToNull::class,
        ]);

        // default web and api middleware group
        $middleware->group('web', [
            \App\Http\Middleware\EncryptCookies::class,
            \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
            \Illuminate\Session\Middleware\StartSession::class,
            // \Illuminate\Session\Middleware\AuthenticateSession::class,
            \Illuminate\View\Middleware\ShareErrorsFromSession::class,
            \App\Http\Middleware\VerifyCsrfToken::class,
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
            \App\Http\Middleware\ProtectDemoAccount::class,
            \App\Http\Middleware\ApplyUiLocale::class,
        ]);

        $middleware->group('api', [
            // \Laravel\Sanctum\Http\Middleware\EnsureFrontendRequestsAreStateful::class,
            'throttle:api',
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
        ]);

        // used within groups or with individually route
        $middleware->alias([
            'auth' => \App\Http\Middleware\Authenticate::class,
            'Tailor' => \App\Http\Middleware\Tailor::class,
            'auth.basic' => \Illuminate\Auth\Middleware\AuthenticateWithBasicAuth::class,
            'cache.headers' => \Illuminate\Http\Middleware\SetCacheHeaders::class,
            'can' => \Illuminate\Auth\Middleware\Authorize::class,
            'guest' => \App\Http\Middleware\RedirectIfAuthenticated::class,
            'password.confirm' => \Illuminate\Auth\Middleware\RequirePassword::class,
            'signed' => \Illuminate\Routing\Middleware\ValidateSignature::class,
            'throttle' => \Illuminate\Routing\Middleware\ThrottleRequests::class,
            'verified' => \Illuminate\Auth\Middleware\EnsureEmailIsVerified::class,
            'shop_owner' => \App\Http\Middleware\ShopOwnerMiddleware::class,
            'stock_seller' => \App\Http\Middleware\StockSellerMiddleware::class,
            'role' => \App\Http\Middleware\AdministratorMiddleware::class,
            'user' => \App\Http\Middleware\UserMiddleware::class,
            'module' => \App\Http\Middleware\EnsureModuleAccess::class,
            'business.permission' => \App\Http\Middleware\EnsureBusinessPermission::class,
            'business.activity' => \App\Http\Middleware\RecordBusinessActivity::class,
            'business.status' => \App\Http\Middleware\EnsureBusinessActive::class,
            'subscription.active' => \App\Http\Middleware\EnsureSubscriptionActive::class,
            'password.changed' => \App\Http\Middleware\EnsureEmployeePasswordChanged::class,
            'public.locale' => \App\Http\Middleware\SetPublicLocale::class,
            'abilities' => \Laravel\Sanctum\Http\Middleware\CheckAbilities::class,
            'ability' => \Laravel\Sanctum\Http\Middleware\CheckForAnyAbility::class,
            'sales.agent' => \App\Http\Middleware\EnsureSalesAgentAccess::class,
            'shop.hub.relay' => \App\Http\Middleware\VerifyShopHubRelay::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
