@extends('main')

@section('content')
    @php
        $draftItems = $counterOrder->items->where('status', 'draft');
        $confirmedItems = $counterOrder->items->where('status', 'confirmed');
        $draftTotal = (float) $draftItems->sum('line_total');
        $statusLabels = [
            'draft' => 'مسودہ',
            'forwarded' => 'ایجنٹ سے موصول',
            'claimed' => 'ایڈمن کے پاس',
            'confirmed' => 'تصدیق شدہ',
            'closed' => 'بند',
        ];
        $orderScopeText =
            $canAddCloth && $canAddTailoring
                ? 'آئٹمز اور سلائی ایک ہی آرڈر میں'
                : ($canAddCloth
                    ? 'آئٹمز کی فروخت کا آرڈر'
                    : 'سلائی کا آرڈر');
        // Stitching needs a known customer, so a walk-in order only offers items until one is picked.
        $isWalkInOrder = (bool) $counterOrder->customer?->is_walk_in;
        $canOfferTailoring = $canAddTailoring && !$isWalkInOrder;
        // The customer can be changed (or cleared back to walk-in) until something is confirmed.
        // Drafted stitching carries the customer's measurements, so it locks the choice.
        $hasDraftTailoring = $draftItems->contains('type', 'tailoring');
        $canPickCustomer = !$counterOrder->isClosed() && $confirmedItems->isEmpty() && !$hasDraftTailoring;
        $currentCustomerLabel = $isWalkInOrder ? 'واک اِن (بغیر شناخت)' : $counterOrder->customer?->name;
        // Texts for both states, so picking a customer can switch them without a reload.
        $emptyHints = [
            'customer' => $canAddCloth && $canAddTailoring
                ? 'اوپر سے آئٹم یا سلائی شامل کریں۔'
                : ($canAddCloth ? 'اوپر سے فروخت ہونے والا آئٹم شامل کریں۔' : 'اوپر سے سلائی شامل کریں۔'),
            'walk_in' => $canAddCloth
                ? ($canAddTailoring ? 'اوپر سے آئٹم شامل کریں؛ سلائی کے لیے پہلے گاہک منتخب کریں۔' : 'اوپر سے فروخت ہونے والا آئٹم شامل کریں۔')
                : 'سلائی کے لیے پہلے گاہک منتخب کریں۔',
        ];
        $itemsHints = [
            'customer' => $canAddCloth
                ? ($canAddTailoring ? 'آئٹم اسی فہرست میں شامل یا تبدیل کریں؛ سلائی کی تفصیل الگ فارم میں کھلے گی۔' : 'آئٹم اسی فہرست میں شامل یا تبدیل کریں۔')
                : 'سلائی کی تفصیل شامل یا تبدیل کرنے کے لیے فارم کھولیں۔',
            'walk_in' => $canAddCloth
                ? 'آئٹم اسی فہرست میں شامل یا تبدیل کریں۔'
                : 'سلائی کی تفصیل شامل یا تبدیل کرنے کے لیے فارم کھولیں۔',
        ];
        $customerState = $isWalkInOrder ? 'walk_in' : 'customer';
        $emptyOrderHint = $emptyHints[$customerState];
        $confirmationHint =
            $canAddCloth && $canAddTailoring
                ? 'تصدیق پر آئٹم اسٹاک سے کم ہوگا اور سلائی ورکشاپ آرڈر بنے گا۔'
                : ($canAddCloth
                    ? 'تصدیق پر آئٹم اسٹاک سے کم ہوگا۔'
                    : 'تصدیق پر سلائی ورکشاپ آرڈر بنے گا۔');
        $moreItemsHint =
            $canAddCloth && $canAddTailoring
                ? 'مزید آئٹم یا سلائی بعد میں بھی شامل ہو سکتی ہے۔'
                : ($canAddCloth
                    ? 'مزید آئٹم بعد میں بھی شامل ہو سکتا ہے۔'
                    : 'مزید سلائی بعد میں بھی شامل ہو سکتی ہے۔');
    @endphp
    <style>
        .co-page {
            --blue: #1769e0;
            --navy: #122d4f;
            --muted: #718096;
            --line: #e0e7f0;
            direction: rtl;
            padding: 24px 16px 60px;
            color: var(--navy)
        }

        .co-shell {
            max-width: 1420px;
            margin: auto
        }

        .co-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 17px
        }

        .co-title h1 {
            margin: 0 0 5px;
            font-size: 1.65rem;
            font-weight: 850
        }

        .co-title p {
            margin: 0;
            color: var(--muted)
        }

        .co-status {
            padding: 7px 11px;
            border-radius: 999px;
            color: #185e3e;
            background: #e8f8ef;
            font-size: .8rem;
            font-weight: 800
        }

        .co-summary {
            display: grid;
            grid-template-columns: 1.3fr repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 16px
        }

        .co-summary>div {
            padding: 15px 17px;
            border: 1px solid var(--line);
            border-radius: 13px;
            background: #fff
        }

        .co-summary small {
            display: block;
            margin-bottom: 5px;
            color: var(--muted)
        }

        .co-summary strong {
            font-size: 1.02rem
        }

        .co-adds [hidden],
        .co-closed-actions[hidden] {
            display: none !important
        }

        .co-cust-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            margin-bottom: 5px
        }

        .co-cust-head small {
            margin-bottom: 0 !important
        }

        .co-cust-new-link {
            padding: 0;
            border: 0;
            background: transparent;
            color: #1769e0;
            font-size: .82rem;
            font-weight: 700;
            cursor: pointer
        }

        .co-cust-picker {
            position: relative
        }

        .co-cust-toggle {
            display: flex;
            width: 100%;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            min-height: 40px;
            padding: 7px 11px;
            border: 1px solid #d4deeb;
            border-radius: 9px;
            background: #fff;
            color: inherit;
            font-weight: 700;
            text-align: right;
            cursor: pointer
        }

        .co-cust-toggle i {
            color: #7a8ba0;
            font-size: .8rem
        }

        .co-cust-panel {
            position: absolute;
            z-index: 40;
            top: 100%;
            right: 0;
            left: 0;
            min-width: 260px;
            margin-top: 5px;
            padding: 8px;
            border: 1px solid #d4deeb;
            border-radius: 11px;
            background: #fff;
            box-shadow: 0 15px 35px rgba(20, 50, 85, .14)
        }

        .co-cust-panel[hidden] {
            display: none
        }

        .co-cust-list {
            max-height: 240px;
            margin-top: 6px;
            overflow: auto
        }

        .co-cust-option {
            display: flex;
            width: 100%;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding: 9px 10px;
            border: 0;
            border-radius: 8px;
            background: #fff;
            text-align: right;
            cursor: pointer
        }

        .co-cust-option:hover,
        .co-cust-option:focus {
            background: #f4f8ff
        }

        .co-cust-option.is-selected {
            background: #ecfdf3;
            color: #14532d
        }

        .co-cust-option small {
            direction: ltr;
            margin: 0 !important;
            color: #64748b
        }

        .co-cust-empty {
            padding: 10px;
            color: #718096;
            text-align: center;
            font-size: .85rem
        }

        .co-main {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 330px;
            gap: 16px;
            align-items: start
        }

        .co-panel {
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: 15px;
            background: #fff;
            box-shadow: 0 8px 26px rgba(23, 52, 86, .05)
        }

        .co-panel-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 17px 19px;
            border-bottom: 1px solid var(--line)
        }

        .co-panel-head h2 {
            margin: 0;
            font-size: 1.08rem;
            font-weight: 850
        }

        .co-adds {
            display: flex;
            gap: 8px
        }

        .co-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-height: 39px;
            padding: 7px 12px;
            border: 1px solid #ccdaeb;
            border-radius: 9px;
            color: #35506e !important;
            background: #fff;
            font-weight: 750;
            text-decoration: none !important
        }

        .co-btn.is-primary {
            border-color: var(--blue);
            color: #fff !important;
            background: var(--blue)
        }

        .co-btn.is-tailor {
            border-color: #188657;
            color: #fff !important;
            background: #188657
        }

        .co-btn:disabled {
            opacity: .55
        }

        .co-list {
            padding: 6px 18px
        }

        .co-item {
            display: grid;
            grid-template-columns: 44px minmax(0, 1fr) auto auto;
            gap: 12px;
            align-items: center;
            padding: 15px 2px;
            border-bottom: 1px solid #edf1f6
        }

        .co-item:last-child {
            border: 0
        }

        .co-icon {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            border-radius: 11px;
            color: #1769e0;
            background: #edf5ff
        }

        .co-item.is-tailoring .co-icon {
            color: #12804e;
            background: #eaf8f1
        }

        .co-item h3 {
            margin: 0 0 4px;
            font-size: .98rem;
            font-weight: 850
        }

        .co-item p {
            margin: 0;
            color: var(--muted);
            font-size: .8rem
        }

        .co-price {
            text-align: left;
            white-space: nowrap
        }

        .co-price strong {
            display: block
        }

        .co-price small {
            color: var(--muted)
        }

        .co-state {
            display: inline-flex;
            padding: 4px 8px;
            border-radius: 999px;
            color: #9a6500;
            background: #fff3d8;
            font-size: .72rem;
            font-weight: 800
        }

        .co-state.is-confirmed {
            color: #147348;
            background: #e8f7ef
        }

        .co-empty {
            padding: 55px 20px;
            text-align: center;
            color: var(--muted)
        }

        .co-empty i {
            display: block;
            margin-bottom: 11px;
            color: #c4d0de;
            font-size: 34px
        }

        .co-side {
            display: grid;
            gap: 16px
        }

        .co-left {
            display: grid;
            gap: 16px;
            min-width: 0
        }

        .co-total {
            padding: 20px
        }

        .co-total-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            padding: 9px 0;
            color: #607187
        }

        .co-total-row.is-main {
            margin-top: 7px;
            padding-top: 15px;
            border-top: 1px solid var(--line);
            color: var(--navy);
            font-size: 1.05rem;
            font-weight: 850
        }

        .co-confirm {
            padding: 18px;
            border-top: 1px solid var(--line);
            background: #fbfdff
        }

        .co-confirm .form-control {
            min-height: 43px;
            border-radius: 8px
        }

        .co-help {
            margin: 0 0 13px;
            color: var(--muted);
            font-size: .78rem
        }

        .co-source {
            display: inline-flex;
            margin-top: 6px;
            color: #1769e0;
            font-size: .76rem;
            font-weight: 700
        }

        .co-close {
            padding: 18px
        }

        .modal-content {
            direction: rtl;
            text-align: right;
            border: 0;
            border-radius: 15px
        }

        .modal-header .close {
            margin: -1rem auto -1rem -1rem
        }

        .modal-title {
            font-weight: 850
        }

        .modal-body .form-control {
            min-height: 44px;
            border-radius: 8px
        }

        .co-modal-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 13px
        }

        .co-modal-grid .is-wide {
            grid-column: 1/-1
        }

        .co-modal-grid label {
            display: block;
            margin-bottom: 6px;
            font-weight: 750
        }

        .co-remove {
            border: 0;
            color: #c03c48;
            background: transparent
        }

        .co-alert {
            margin-bottom: 15px
        }

        .co-mobile-source {
            margin-bottom: 16px;
            padding: 13px 16px;
            border: 1px solid #cfe1fa;
            border-radius: 12px;
            color: #315f92;
            background: #f1f7ff
        }

        .modal-content {
            max-height: calc(100vh - 32px);
            overflow: hidden
        }

        .co-modal-form {
            display: flex;
            min-height: 0;
            max-height: calc(100vh - 32px);
            flex: 1 1 auto;
            flex-direction: column
        }

        .co-modal-form .modal-header,
        .co-modal-form .modal-footer {
            flex: 0 0 auto
        }

        .co-modal-form .modal-body {
            min-height: 0;
            overflow-y: auto;
            overscroll-behavior: contain
        }

        #orderRecoveryModal .modal-dialog {
            height: calc(100vh - 32px);
            margin-top: 16px;
            margin-bottom: 16px
        }

        #orderRecoveryModal .modal-content {
            display: flex;
            height: 100%;
            max-height: 100%;
            flex-direction: column
        }

        #orderRecoveryModal .modal-header {
            flex: 0 0 auto
        }

        #orderRecoveryModal .modal-body {
            min-height: 0;
            flex: 1 1 auto;
            overflow-y: auto;
            overscroll-behavior: contain;
            -webkit-overflow-scrolling: touch
        }

        .co-field-label {
            display: flex !important;
            align-items: center;
            justify-content: space-between;
            gap: 10px
        }

        .co-measurement-link {
            padding: 0;
            border: 0;
            color: #1769e0;
            background: transparent;
            font-size: .78rem;
            font-weight: 750;
            cursor: pointer
        }

        .co-calculated {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 12px 14px;
            border: 1px solid #cfe3f4;
            border-radius: 10px;
            background: #f5faff
        }

        .co-calculated span {
            color: #52677f;
            font-weight: 750
        }

        .co-calculated strong {
            font-size: 1.05rem
        }

        .co-actions {
            display: flex;
            align-items: center;
            gap: 3px
        }

        .co-edit {
            border: 0;
            color: #1769e0;
            background: transparent
        }

        .co-readonly {
            padding: 11px 13px;
            border: 1px solid #e0e7f0;
            border-radius: 8px;
            color: #52677f;
            background: #f7f9fc;
            font-weight: 700
        }

        .co-suit-only[hidden] {
            display: none !important
        }

        .co-measurement-modal .modal-dialog {
            max-width: 980px
        }

        .co-measurement-modal .modal-body {
            min-height: 0;
            max-height: calc(100vh - 115px);
            overflow-y: auto;
            overscroll-behavior: contain
        }

        .co-measurement-loading {
            padding: 54px 20px;
            color: var(--muted);
            text-align: center
        }

        .co-measurement-context {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 15px
        }

        .co-measurement-context>div {
            padding: 10px 12px;
            border: 1px solid #dce6f1;
            border-radius: 10px;
            background: #f8fbfe
        }

        .co-measurement-context span {
            display: block;
            color: var(--muted);
            font-size: .72rem
        }

        .co-measurement-context strong {
            display: block;
            margin-top: 3px
        }

        .co-measurement-columns {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            align-items: start
        }

        .co-measurement-column {
            padding: 14px;
            border: 1px solid #dde7f0;
            border-radius: 12px;
            background: #fbfdff
        }

        .co-measurement-stack {
            display: grid;
            grid-template-columns: minmax(0, 1fr);
            gap: 13px
        }

        .co-measurement-field label {
            display: block;
            margin-bottom: 5px;
            color: #29435f;
            font-weight: 800
        }

        .co-measurement-field label small {
            color: #718096
        }

        .co-measurement-field .form-control {
            min-height: 44px;
            border-color: #cbd9e7;
            border-radius: 8px;
            background: #fff
        }

        .co-measurement-empty {
            padding: 18px;
            color: var(--muted);
            text-align: center
        }

        .co-grid-head,
        .co-grid-row {
            display: grid;
            grid-template-columns: minmax(230px, 2fr) minmax(105px, .8fr) minmax(95px, .65fr) minmax(115px, .8fr) minmax(150px, 1fr) 112px;
            gap: 8px;
            align-items: center
        }

        .co-grid-head {
            padding: 9px 10px;
            border-bottom: 1px solid #dbe5f0;
            color: #64748b;
            background: #f6f9fc;
            font-size: .72rem;
            font-weight: 850
        }

        .co-grid-row {
            padding: 9px 10px;
            border-bottom: 1px solid #edf1f6
        }

        .co-grid-row:last-child {
            border-bottom: 0
        }

        .co-grid-row[hidden] {
            display: none !important
        }

        .co-grid-row .form-control {
            height: 40px;
            min-height: 40px;
            padding: 6px 9px;
            border-radius: 7px;
            font-size: .82rem
        }

        .co-grid-row .co-suit-only:not([hidden]) {
            margin-top: 4px
        }

        .co-grid-row .co-cell-main {
            min-width: 0
        }

        .co-grid-row .co-cell-main strong {
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: .87rem
        }

        .co-grid-row .co-cell-main small {
            display: block;
            color: var(--muted);
            font-size: .7rem
        }

        .co-grid-row .co-cell-money {
            direction: ltr;
            text-align: right;
            font-weight: 800;
            white-space: nowrap
        }

        .co-grid-row .co-cell-note {
            overflow: hidden;
            color: var(--muted);
            font-size: .75rem;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .co-grid-actions {
            display: flex;
            flex-wrap: wrap;
            min-width: 0;
            align-items: center;
            justify-content: flex-start;
            gap: 6px
        }

        .co-grid-actions .co-print-action {
            max-width: 100%;
            white-space: normal;
            text-align: center;
            overflow-wrap: anywhere
        }

        .co-grid-actions .co-print-action i {
            flex-shrink: 0
        }

        @media(min-width:1101px) {
            .co-grid-actions .co-print-action {
                width: 100%
            }
        }

        .co-print-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            min-height: 34px;
            padding: 5px 8px;
            border: 1px solid #b9d1ef;
            border-radius: 7px;
            color: #1769e0 !important;
            background: #f5f9ff;
            font-size: .72rem;
            font-weight: 850;
            text-decoration: none !important;
            white-space: nowrap
        }

        .co-grid-save,
        .co-grid-cancel {
            width: 34px;
            height: 34px;
            display: grid;
            place-items: center;
            border: 1px solid #bdd3eb;
            border-radius: 7px;
            background: #fff
        }

        .co-grid-save {
            border-color: var(--blue);
            color: #fff;
            background: var(--blue)
        }

        .co-grid-cancel {
            color: #52677f
        }

        .co-grid-row.is-new {
            border: 1px solid #9fc5f3;
            border-radius: 10px;
            background: #f7fbff
        }

        .co-grid-row.is-new .form-control {
            border-color: #b9cee5
        }

        .co-grid-row.is-tailoring {
            background: #fcfefd
        }

        .co-closed-actions {
            display: flex;
            justify-content: flex-end;
            align-items: stretch;
            flex-wrap: wrap;
            gap: 12px;
            margin: 0 0 24px;
            direction: rtl;
        }

        .co-closed-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            min-width: 165px;
            min-height: 54px;
            padding: 12px 18px;

            border: 1px solid #e2e8f0;
            border-radius: 12px;
            background: #fff;
            color: #26364b !important;

            font-size: 14px;
            font-weight: 700;
            text-decoration: none !important;

            box-shadow: 0 2px 5px rgba(15, 23, 42, 0.04);
            transition: all 0.2s ease;
        }

        .co-closed-btn i {
            font-size: 17px;
            color: #4775b8;
        }

        .co-closed-btn:hover {
            transform: translateY(-2px);
            border-color: #b9cfee;
            background: #f7faff;
            box-shadow: 0 5px 14px rgba(15, 23, 42, 0.08);
        }

        .co-closed-btn-primary {
            color: #fff !important;
            background: var(--blue);
            border-color: var(--blue);
            box-shadow: 0 3px 8px rgba(37, 99, 235, 0.18);
        }

        .co-closed-btn-primary i {
            color: #fff;
        }

        .co-closed-btn-primary:hover {
            color: #fff !important;
            background: #1256bd;
            border-color: #1256bd;
        }

        .co-row-status {
            display: inline-flex;
            margin-top: 3px;

            padding:2px 6px;border-radius:999px;color:#9a6500;background:#fff3d8;font-size:.65rem;font-weight:800}.co-row-status.is-confirmed{color:#147348;background:#e8f7ef}.co-add-row-button[aria-expanded="true"] {
                border-color: #9dbce3;
                color: #315f92 !important;
                background: #edf5ff
            }

            @media(max-width:1000px) {
                .co-main {
                    grid-template-columns: 1fr
                }

                .co-summary {
                    grid-template-columns: 1fr 1fr
                }

                .co-side {
                    grid-row: 1
                }
            }

            @media(max-width:1100px) {
                .co-grid-head {
                    display: none
                }

                .co-grid-row {
                    grid-template-columns: repeat(2, minmax(0, 1fr));
                    padding: 13px
                }

                .co-grid-row>*:before {
                    content: attr(data-label);
                    display: block;
                    margin-bottom: 3px;
                    color: #718096;
                    font-size: .67rem;
                    font-weight: 800
                }

                .co-grid-row .co-cell-main {
                    grid-column: 1/-1
                }

                .co-grid-actions {
                    grid-column: 1/-1
                }

                .co-grid-actions:before {
                    display: none
                }
            }

            @media(max-width:700px) {

                .co-head,
                .co-panel-head {
                    align-items: stretch;
                    flex-direction: column
                }

                .co-summary {
                    grid-template-columns: 1fr
                }

                .co-adds {
                    display: grid;
                    grid-template-columns: 1fr 1fr
                }

                .co-modal-grid,
                .co-measurement-context,
                .co-measurement-columns {
                    grid-template-columns: 1fr
                }

                .co-modal-grid .is-wide {
                    grid-column: auto
                }

                .co-grid-row {
                    grid-template-columns: 1fr
                }

                .co-grid-row .co-cell-main,
                .co-grid-actions {
                    grid-column: 1
                }
            }

            @media (max-width: 600px) {
                .co-closed-actions {
                    display: grid;
                    grid-template-columns: 1fr;
                    gap: 10px;
                }

                .co-closed-btn {
                    width: 100%;
                    min-width: 0;
                }
            }

        /* Searchable cloth picker that sits on top of the native #co-cloth-select. */
        .co-picker-native {
            position: absolute !important;
            width: 1px !important;
            height: 1px !important;
            opacity: 0;
            pointer-events: none
        }

        .co-picker {
            position: relative
        }

        .co-picker-trigger {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            min-height: 40px;
            padding: 5px 11px;
            border: 1px solid #cfdbe9;
            border-radius: 9px;
            background: #fff;
            color: var(--navy);
            text-align: right;
            transition: border-color .15s ease, box-shadow .15s ease
        }

        .co-picker-trigger:hover {
            border-color: #9fbde6
        }

        .co-picker-trigger:focus,
        .co-picker.is-open .co-picker-trigger {
            border-color: var(--blue);
            outline: 0;
            box-shadow: 0 0 0 3px rgba(23, 105, 224, .14)
        }

        .co-picker-trigger-text {
            flex: 1;
            min-width: 0
        }

        .co-picker-trigger-text strong,
        .co-picker-trigger-text small {
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .co-picker-trigger-text strong {
            font-size: .84rem;
            font-weight: 800
        }

        .co-picker-trigger-text small {
            color: var(--muted);
            font-size: .7rem
        }

        .co-picker-placeholder {
            color: #8a99ad;
            font-size: .84rem
        }

        .co-picker-caret {
            color: #8a99ad;
            font-size: .75rem;
            transition: transform .15s ease
        }

        .co-picker.is-open .co-picker-caret {
            transform: rotate(180deg)
        }

        .co-picker-panel {
            position: fixed;
            z-index: 1060;
            display: flex;
            flex-direction: column;
            max-height: 420px;
            overflow: hidden;
            border: 1px solid #d6e2f0;
            border-radius: 14px;
            background: #fff;
            box-shadow: 0 22px 48px rgba(18, 45, 79, .2);
            direction: rtl
        }

        .co-picker-panel[hidden] {
            display: none
        }

        .co-picker-search {
            position: relative;
            padding: 10px 10px 8px;
            border-bottom: 1px solid #edf1f6
        }

        .co-picker-search i {
            position: absolute;
            top: 50%;
            left: 22px;
            color: #94a3b8;
            transform: translateY(-50%);
            pointer-events: none
        }

        .co-picker-search input {
            width: 100%;
            height: 38px;
            padding: 6px 12px 6px 34px;
            border: 1px solid #dbe5f0;
            border-radius: 9px;
            background: #f8fafd;
            font-size: .83rem
        }

        .co-picker-search input:focus {
            border-color: var(--blue);
            outline: 0;
            background: #fff
        }

        .co-picker-search,
        .co-picker-tabs,
        .co-picker-subtabs {
            flex: 0 0 auto
        }

        .co-picker-tabs {
            display: flex;
            gap: 4px;
            margin: 8px 10px 0;
            padding: 4px;
            overflow-x: auto;
            border-radius: 11px;
            background: #f1f5f9;
            scrollbar-width: none
        }

        .co-picker-tabs[hidden],
        .co-picker-subtabs[hidden] {
            display: none
        }

        .co-picker-tab {
            flex: 1 0 auto;
            min-height: 34px;
            padding: 6px 14px;
            border: 0;
            border-radius: 8px;
            background: transparent;
            color: #475569;
            font-size: .8rem;
            font-weight: 800;
            line-height: 1.4;
            white-space: nowrap
        }

        .co-picker-tab:hover {
            color: var(--navy)
        }

        .co-picker-tab.is-active {
            background: #fff;
            color: var(--blue);
            box-shadow: 0 2px 6px rgba(18, 45, 79, .12)
        }

        .co-picker-subtabs {
            display: flex;
            gap: 6px;
            padding: 8px 10px 2px;
            overflow-x: auto;
            scrollbar-width: none
        }

        .co-picker-chip {
            flex: 0 0 auto;
            min-height: 28px;
            padding: 4px 12px;
            border: 1px solid #dbe5f0;
            border-radius: 999px;
            background: #fff;
            color: #4a5f7a;
            font-size: .74rem;
            font-weight: 800;
            line-height: 1.4;
            white-space: nowrap
        }

        .co-picker-chip.is-active {
            border-color: var(--blue);
            background: #eaf2ff;
            color: var(--blue)
        }

        .co-picker-list {
            min-height: 0;
            border-top: 1px solid #edf1f6;
            margin-top: 8px
        }

        .co-picker-list {
            flex: 1;
            padding: 4px 6px 8px;
            overflow-y: auto
        }

        .co-picker-group {
            position: sticky;
            top: -4px;
            z-index: 1;
            padding: 9px 8px 5px;
            background: #fff;
            color: #64748b;
            font-size: .7rem;
            font-weight: 850;
            letter-spacing: .02em
        }

        .co-picker-option {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            padding: 8px 9px;
            border: 0;
            border-radius: 10px;
            background: transparent;
            color: var(--navy);
            text-align: right
        }

        .co-picker-option:hover,
        .co-picker-option.is-active {
            background: #eef5ff
        }

        .co-picker-option.is-selected {
            background: #e3efff;
            box-shadow: inset 0 0 0 1px #b9d3f7
        }

        .co-picker-avatar {
            display: inline-flex;
            flex: 0 0 34px;
            align-items: center;
            justify-content: center;
            height: 34px;
            border-radius: 9px;
            background: #eaf2ff;
            color: var(--blue);
            font-size: .85rem;
            font-weight: 900
        }

        .co-picker-option[data-unit="suit"] .co-picker-avatar {
            background: #f3edff;
            color: #6d3fd1
        }

        .co-picker-option-text {
            flex: 1;
            min-width: 0
        }

        .co-picker-option-text strong,
        .co-picker-option-text small {
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .co-picker-option-text strong {
            font-size: .84rem;
            font-weight: 800
        }

        .co-picker-option-text small {
            color: var(--muted);
            font-size: .72rem
        }

        .co-picker-price {
            flex: 0 0 auto;
            padding: 3px 9px;
            border-radius: 999px;
            background: #f1f5f9;
            color: #334155;
            font-size: .72rem;
            font-weight: 800;
            white-space: nowrap
        }

        .co-picker-empty {
            padding: 26px 12px;
            color: var(--muted);
            font-size: .82rem;
            text-align: center
        }
    </style>
    <section class="main-content co-page">
        <div class="co-shell">
            <header class="co-head">
                <div class="co-title">
                    <h1>آرڈر {{ $counterOrder->displayNumber() }}</h1>
                    <p><span id="co-head-customer">{{ $counterOrder->customer?->name }}</span> · {{ $orderScopeText }}@if ($counterOrder->serial_number)
                            · حوالہ {{ $counterOrder->reference }}
                        @endif
                    </p>
                </div><span class="co-status">{{ $statusLabels[$counterOrder->status] ?? $counterOrder->status }}</span>
            </header>
            <div class="co-closed-actions" id="co-customer-actions" @if ($isWalkInOrder) hidden @endif>
                @if (!$isWalkInOrder)
                    @include('customer.partials.action-menu', [
                        'customer' => $counterOrder->customer,
                        'selectedCustomer' => $counterOrder->customer,
                    ])
                @endif
            </div>
            <div id="co-live-alert" class="alert co-alert" role="status" hidden></div>
            @if (session('success'))
                <div class="alert alert-success co-alert">{{ session('success') }}</div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger co-alert"><strong>تبدیلی محفوظ نہیں ہوئی:</strong> {{ $errors->first() }}
                </div>
            @endif
            @if ($counterOrder->saleSession)
                <div class="co-mobile-source"><i class="fas fa-mobile-alt ml-1"></i> یہ آرڈر سیلز ایجنٹ
                    {{ $counterOrder->saleSession->agent?->name }} نے موبائل سے بھیجا تھا۔ قیمت، ادائیگی اور حتمی تصدیق
                    ایڈمن ڈیسک کے پاس ہے۔</div>
            @endif
            <div class="co-summary">
                @if ($canPickCustomer)
                    <div>
                        <div class="co-cust-head"><small>گاہک</small><button type="button" class="co-cust-new-link"
                                data-toggle="modal" data-target="#newCustomerModal"><i class="fas fa-user-plus"></i> نیا گاہک</button></div>
                        <div class="co-cust-picker" id="co-customer-picker" data-walk-in="{{ $isWalkInOrder ? '1' : '0' }}"
                            data-current-id="{{ $isWalkInOrder ? '' : $counterOrder->customer_id }}">
                            <button type="button" class="co-cust-toggle" id="co-customer-toggle" aria-haspopup="listbox"
                                aria-expanded="false" aria-controls="co-customer-panel"><span>{{ $currentCustomerLabel }}</span><i
                                    class="fas fa-chevron-down"></i></button>
                            <div class="co-cust-panel" id="co-customer-panel" hidden>
                                <input type="search" class="form-control" id="co-customer-search" autocomplete="off"
                                    placeholder="نام، فون یا گاہک نمبر سے تلاش کریں">
                                <div class="co-cust-list" id="co-customer-list" role="listbox"></div>
                            </div>
                            <form method="POST" id="co-customer-choose-form"
                                action="{{ route('admin.counter-orders.customer.identify', $counterOrder) }}" hidden>@csrf
                                <input type="hidden" name="existing_customer_id" id="co-customer-choose-id">
                            </form>
                        </div>
                    </div>
                @else
                    <div><small>گاہک</small><strong>{{ $currentCustomerLabel }}</strong>
                        @if ($hasDraftTailoring && $confirmedItems->isEmpty() && !$counterOrder->isClosed())
                            <small class="d-block mt-1">گاہک بدلنے کے لیے پہلے سلائی کا آئٹم ہٹائیں۔</small>
                        @endif
                    </div>
                @endif
                <div><small>کل آرڈر</small><strong id="co-summary-subtotal" dir="ltr">Rs.
                        {{ number_format((float) $counterOrder->subtotal, 2) }}</strong></div>
                <div><small>وصول شدہ</small><strong id="co-summary-paid" dir="ltr">Rs.
                        {{ number_format((float) $counterOrder->paid_amount, 2) }}</strong></div>
                <div><small>بقایا</small><strong id="co-summary-balance" dir="ltr">Rs.
                        {{ number_format((float) $counterOrder->balance_amount, 2) }}</strong></div>
            </div>
            @php
                $hasConfirmedTailoring = $counterOrder->items->contains(
                    fn ($item) => $item->type === 'tailoring' && $item->status === 'confirmed'
                );
                $activeReceipts = $receiptLinks->where('status', '!=', 'cancelled');
            @endphp
            <div class="co-main {{ $itemBoxes ? 'has-item-boxes' : '' }}">
                <div class="co-left">
                @if ($itemBoxes)
                    @include('counter-orders.partials.item-boxes')
                @endif
                <section class="co-panel">
                    <div class="co-panel-head">
                        <div>
                            <h2>آرڈر کے آئٹمز</h2><small
                                class="text-muted" id="co-items-hint" data-walk-in="{{ $itemsHints['walk_in'] }}"
                                data-customer="{{ $itemsHints['customer'] }}">{{ $itemsHints[$customerState] }}</small>
                        </div>
                        <div class="co-adds">
                            @if ($confirmedItems->isNotEmpty())
                                <a class="co-btn" target="_blank"
                                    href="{{ route('admin.counter-orders.print', $counterOrder) }}"><i
                                        class="fas fa-print"></i>
                                    {{ $canAddCloth && $canAddTailoring ? 'مشترکہ رسید' : 'آرڈر رسید' }}</a>
                                @endif @if (!$counterOrder->isClosed())
                                    @if ($canAddCloth && !$itemBoxes)
                                        <button id="co-add-cloth-button" class="co-btn is-primary co-add-row-button"
                                            type="button" aria-expanded="{{ old('cloth_id') ? 'true' : 'false' }}"
                                            aria-controls="co-new-cloth-row"><i class="fas fa-plus"></i> آئٹم شامل کریں</button>
                                        @endif @if ($canAddTailoring)
                                            <button class="co-btn is-tailor" id="co-add-tailoring-button" data-toggle="modal"
                                                data-target="#tailoringItemModal" {{ $canOfferTailoring ? '' : 'hidden' }}><i class="fas fa-plus"></i> سلائی شامل کریں</button>
                                        @endif
                                    @endif
                        </div>
                    </div>
                    <div class="co-list">
                        <div class="co-grid-head" aria-hidden="true"><span>آئٹم</span><span>رنگ / تفصیل</span><span>میٹر / تعداد</span><span>کل قیمت</span><span>نوٹ</span><span>رسید / عمل</span></div>
                        @if ($canAddCloth && !$counterOrder->isClosed())
                            <form id="co-new-cloth-row" class="co-grid-row co-cloth-form co-ajax-row-form is-new"
                                method="POST"
                                action="{{ route('admin.counter-orders.cloth-items.store', $counterOrder) }}"
                                data-old-color="{{ old('color') }}" @if (!old('cloth_id')) hidden @endif>@csrf
                                <div class="co-cell-main" data-label="آئٹم"><select id="co-cloth-select"
                                        class="form-control" name="cloth_id" aria-label="آئٹم" required>
                                        <option value="">آئٹم منتخب کریں</option>
                                        {{-- Grouped by category so women's suits and men's cloth are easy to tell apart. --}}
                                        @foreach ($cloths->groupBy(fn ($cloth) => $cloth->category?->fullName() ?? 'دیگر') as $categoryName => $categoryCloths)
                                        <optgroup label="{{ $categoryName }}">
                                        @foreach ($categoryCloths as $cloth)
                                            @php
                                                // Same stock row the sale uses: per color, or the cloth's first row.
                                                $colorStock = $cloth->tracksColors()
                                                    ? $cloth->colors->mapWithKeys(fn ($c) => [$c->color => round((float) $c->length, 2)])
                                                    : collect();
                                                $clothStock = $cloth->tracksColors()
                                                    ? (float) $colorStock->sum()
                                                    : round((float) ($cloth->colors->sortBy('id')->first()?->length ?? 0), 2);
                                            @endphp
                                            {{-- Out-of-stock cloths are not offered (unless re-shown after a failed submit). --}}
                                            @continue($clothStock <= 0 && (int) old('cloth_id') !== $cloth->id)
                                            <option value="{{ $cloth->id }}"
                                                data-name="{{ $cloth->name }}"
                                                data-main="{{ $cloth->category?->parent?->localizedName() ?? $cloth->category?->localizedName() }}"
                                                data-sub="{{ $cloth->category?->parent ? $cloth->category->localizedName() : '' }}"
                                                data-meta="{{ collect([$cloth->brand?->name, $cloth->type?->name])->filter()->implode(' · ') }}"
                                                data-price="{{ $cloth->sellsPerSuit() ? $cloth->suit_sale_price : $cloth->sale_price }}"
                                                data-length="{{ $cloth->default_sale_length ?: 4.5 }}"
                                                data-basis="{{ $cloth->sale_price_basis }}"
                                                data-unit="{{ $cloth->stock_unit }}"
                                                data-stock="{{ $clothStock }}"
                                                data-color-stock='@json($colorStock)'
                                                data-colors='@json($cloth->selectableColorNames())' @selected((int) old('cloth_id') === $cloth->id)>
                                                {{ collect([$cloth->name, $cloth->brand?->name, $cloth->type?->name])->filter()->implode(' · ') }}</option>
                                        @endforeach
                                        </optgroup>
                                        @endforeach
                                    </select>
                                </div>
                                <div data-label="رنگ"><select id="co-cloth-color" class="form-control" name="color"
                                        aria-label="رنگ">
                                        <option value="">رنگ لاگو نہیں</option>
                                    </select></div>
                                <div data-label="میٹر / تعداد"><input id="co-cloth-length"
                                        class="form-control co-cloth-length" type="number" name="length"
                                        value="{{ old('length') }}" min="0.01" step="0.01" aria-label="لمبائی میٹر"
                                        placeholder="میٹر" required><input id="co-cloth-quantity"
                                        class="form-control co-cloth-quantity co-suit-only" type="number" name="quantity"
                                        value="{{ old('quantity', 1) }}" min="1" step="1"
                                        aria-label="سوٹ کی تعداد" hidden></div>
                                <div data-label="کل قیمت"><input id="co-cloth-price" class="form-control co-cloth-total"
                                        type="number" name="total_price" value="{{ old('total_price') }}" min="0"
                                        step="0.01" aria-label="کل قیمت" placeholder="کل قیمت" required></div>
                                <div data-label="نوٹ"><input id="co-cloth-note" class="form-control" name="note"
                                        value="{{ old('note') }}" maxlength="1000" aria-label="نوٹ"
                                        placeholder="اختیاری نوٹ"></div>
                                <div class="co-grid-actions"><button class="co-grid-save" type="submit"
                                        title="شامل کریں" aria-label="شامل کریں"><i
                                            class="fas fa-check"></i></button><button class="co-grid-cancel"
                                        type="button" data-inline-cancel="co-new-cloth-row" title="منسوخ"
                                        aria-label="منسوخ"><i class="fas fa-times"></i></button></div>
                            </form>
                        @endif
                        <div id="co-items-rows" style="display:contents">
                            @forelse($counterOrder->items as $item)
                                @include('counter-orders.partials.item-row', ['item' => $item])
                            @empty<div class="co-empty"><i class="fas fa-receipt"></i><strong>آرڈر ابھی خالی
                                        ہے</strong>
                                    <div id="co-empty-hint" data-walk-in="{{ $emptyHints['walk_in'] }}"
                                        data-customer="{{ $emptyHints['customer'] }}">{{ $emptyOrderHint }}</div>
                                </div>
                            @endforelse
                        </div>
                    </div>
                </section>
                </div>
                <aside class="co-side">
                    @if ($itemBoxes)
                        @include('counter-orders.partials.item-cart')
                    @endif
                    <section class="co-panel">
                        <div class="co-total">
                            <h2 class="h6 font-weight-bold mb-3">موجودہ خلاصہ</h2>
                            <div class="co-total-row"><span>تصدیق شدہ آئٹمز</span><strong
                                    id="co-confirmed-count">{{ $confirmedItems->count() }}</strong></div>
                            <div class="co-total-row"><span>نئے آئٹمز</span><strong
                                    id="co-draft-count">{{ $draftItems->count() }}</strong></div>
                            <div class="co-total-row"><span>نئی رقم</span><strong id="co-draft-total"
                                    dir="ltr">Rs. {{ number_format($draftTotal, 2) }}</strong></div>
                            <div class="co-total-row" id="co-previous-due-row" @if ($previousDue <= 0) hidden @endif>
                                <span>پچھلا بقایا</span><strong id="co-previous-due" class="text-danger"
                                    dir="ltr">Rs. {{ number_format($previousDue, 2) }}</strong></div>
                            <div class="co-total-row is-main"><span>کل قابلِ وصول</span><strong id="co-payable-total"
                                    dir="ltr">Rs. {{ number_format($draftTotal + $previousDue, 2) }}</strong></div>
                        </div>
                        @if (!$counterOrder->isClosed() && $canManageAllDrafts)
                            <form id="co-confirm-form" class="co-confirm" method="POST"
                                action="{{ route('admin.counter-orders.confirm', $counterOrder) }}"
                                @if ($draftItems->isEmpty()) hidden @endif>@csrf<p class="co-help">
                                    {{ $confirmationHint }}</p>
                                <div class="form-group"><label class="d-flex justify-content-between align-items-center">
                                        <span>ابھی وصول رقم</span>
                                        <button type="button" class="btn btn-link btn-sm p-0" id="co-pay-full">پوری رقم</button>
                                    </label><input class="form-control"
                                        type="number" name="payment" min="0" max="{{ $draftTotal + $previousDue }}"
                                        step="0.01" value="{{ old('payment', 0) }}" required
                                        data-max-message="وصول رقم کل قابلِ وصول رقم سے زیادہ نہیں ہو سکتی۔">
                                    <small class="text-muted d-block mt-1" id="co-payment-hint"
                                        @if ($previousDue <= 0) hidden @endif>پہلے نئے آئٹمز ادا ہوں گے، اضافی رقم پچھلے بقایا میں جائے گی۔</small>
                                </div>
                                <div class="form-group"><label>ادائیگی کا طریقہ</label><select class="form-control"
                                        name="payment_method" required>
                                        @foreach ($paymentMethods as $value => $label)
                                            <option value="{{ $value }}" @selected(old('payment_method', 'cash') === $value)>
                                                {{ $label }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group"><label>حوالہ نمبر <small class="text-muted">(اگر لاگو
                                            ہو)</small></label><input class="form-control" name="payment_reference"
                                        value="{{ old('payment_reference') }}"></div><button
                                    class="co-btn is-primary w-100" type="submit">نئے آئٹمز کی تصدیق کریں</button>
                            </form>
                        @endif
                    </section>
                    @if (!$counterOrder->isClosed() && $draftItems->isEmpty() && $confirmedItems->isNotEmpty() && $canManageAllItems)
                        <section class="co-panel co-close">
                            <p class="co-help">{{ $moreItemsHint }} صرف معاملہ مکمل ہونے پر آرڈر بند کریں۔</p>
                            <form method="POST" action="{{ route('admin.counter-orders.close', $counterOrder) }}">
                                @csrf<button class="co-btn w-100" type="submit">آرڈر بند کریں</button></form>
                        </section>
                    @endif
                </aside>
            </div>
        </div>
    </section>

    @if ($canPickCustomer)
        <div class="modal fade" id="newCustomerModal" tabindex="-1" role="dialog" aria-hidden="true"
            data-auto-open="{{ $errors->hasAny(['name', 'phone']) ? '1' : '0' }}">
            <div class="modal-dialog modal-dialog-centered"><div class="modal-content" dir="rtl">
                <div class="modal-header"><h2 class="modal-title h5">نیا گاہک شامل کریں</h2><button class="close" type="button" data-dismiss="modal">&times;</button></div>
                <form method="POST" action="{{ route('admin.counter-orders.customer.identify', $counterOrder) }}" id="co-new-customer-form">@csrf
                    <div class="modal-body">
                        <div class="alert alert-danger" id="co-new-customer-error" role="alert" hidden></div>
                        <div class="form-group"><label for="new-customer-name">نام</label><input class="form-control" id="new-customer-name" name="name" maxlength="255" value="{{ old('name') }}" required></div>
                        <div class="form-group mb-0"><label for="new-customer-phone">موبائل نمبر</label><input class="form-control" id="new-customer-phone" name="phone" maxlength="50" inputmode="tel" placeholder="03001234567" value="{{ old('phone') }}" required></div>
                    </div><div class="modal-footer"><button class="co-btn" type="button" data-dismiss="modal">منسوخ</button><button class="co-btn is-primary" type="submit">محفوظ اور منتخب کریں</button></div>
                </form>
            </div></div>
        </div>
    @endif

    @if ($canAddTailoring && !$counterOrder->isClosed())
        <div class="modal fade" id="tailoringItemModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <form class="co-modal-form co-tailoring-form" method="POST"
                        action="{{ route('admin.counter-orders.tailoring-items.store', $counterOrder) }}">@csrf
                        <div class="modal-header">
                            <h2 class="modal-title h5">سلائی شامل کریں</h2><button class="close" type="button"
                                data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="co-modal-grid">
                                <div><label class="co-field-label" for="co-profile"><span>ناپ کس کا ہے؟</span><button
                                            id="co-measurement-link" class="co-measurement-link" type="button"><i
                                                class="fas fa-ruler-combined ml-1"></i> ناپ دیکھیں / تبدیل کریں</button></label><select id="co-profile" class="form-control"
                                        name="measurement_profile_id" required>
                                        @include('counter-orders.partials.profile-options')
                                    </select>
                                </div>
                                <div><label for="co-template">لباس / محفوظ پیمائش</label><select id="co-template"
                                        class="form-control" name="measurement_template_id" required>
                                        @foreach ($templates as $template)
                                            <option value="{{ $template->id }}" data-template-id="{{ $template->id }}">
                                                {{ $template->name }}</option>
                                        @endforeach
                                    </select>
                                    <small class="co-template-hint form-text text-muted"></small>
                                </div>
                                <div><label for="co-suit-quantity">کتنے سوٹ سلنے ہیں؟</label><input id="co-suit-quantity"
                                        class="form-control" type="number" name="quantity" value="1"
                                        min="1" required></div>
                                <div><label for="co-tailoring-price">گاہک سے فی سوٹ سلائی رقم</label><input
                                        id="co-tailoring-price" class="form-control" type="number" name="unit_price"
                                        min="0" step="0.01" required></div>
                                <div class="is-wide co-calculated"><span>کل سلائی رقم</span><strong
                                        id="co-tailoring-total" dir="ltr">Rs. 0.00</strong></div>

                                <div>
                                    <label for="co-tailor">درزی منتخب کریں</label>
                                    <select id="co-tailor" class="form-control" name="tailor_id">
                                        <option value="">درزی منتخب کریں</option>
                                        @foreach ($tailors as $tailor)
                                            <option value="{{ $tailor->id }}">
                                                {{ $tailor->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div>
                                    <label for="co-tailor-rate">سلائی کی شرح منتخب کریں</label>
                                    <select id="co-tailor-rate" class="form-control" name="tailor_price"
                                        data-rate-url="{{ route('admin.counter-orders.tailors.rates', ['tailorId' => '__ID__']) }}"
                                        disabled>
                                        <option value="">پہلے درزی منتخب کریں</option>
                                    </select>
                                </div>
                                <div class="is-wide"><label for="co-due-date">مکمل کرنے کی تاریخ</label><input
                                        id="co-due-date" class="form-control" type="date" name="due_date"
                                        min="{{ now()->toDateString() }}" required></div>
                                <div class="is-wide"><label for="co-tailoring-note">خصوصی سلائی ہدایات <small
                                            class="text-muted">(اختیاری)</small></label>
                                    <textarea id="co-tailoring-note" class="form-control" name="note" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer"><button class="co-btn" type="button"
                                data-dismiss="modal">منسوخ</button><button class="co-btn is-tailor" type="submit">آرڈر
                                میں شامل کریں</button></div>
                    </form>
                </div>
            </div>
        </div>
    @endif

    @if ($canAddTailoring && !$counterOrder->isClosed())
        <div class="modal fade co-measurement-modal" id="measurementProfileModal" tabindex="-1" role="dialog"
            aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title h5">منتخب فرد کی پیمائش</h2><button class="close" type="button"
                            data-dismiss="modal">&times;</button>
                    </div>
                    <div id="co-measurement-modal-body" class="modal-body">
                        <div class="co-measurement-loading"><i class="fas fa-circle-notch fa-spin ml-1"></i> پیمائش لوڈ ہو
                            رہی ہے…</div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @foreach ($draftItems as $item)
        @if ($item->type === 'tailoring' && $canAddTailoring)
            <div class="modal fade" id="editItemModal{{ $item->id }}" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <form class="co-modal-form co-tailoring-form" method="POST"
                            action="{{ route('admin.counter-orders.items.update', [$counterOrder, $item]) }}">@csrf
                            @method('PATCH')
                            <div class="modal-header">
                                <h2 class="modal-title h5">سلائی تبدیل کریں</h2><button class="close" type="button"
                                    data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div class="co-modal-grid">
                                    <div><label class="co-field-label" for="edit-profile-{{ $item->id }}"><span>ناپ
                                                کس کا ہے؟</span><button class="co-measurement-link" type="button"><i
                                                    class="fas fa-ruler-combined ml-1"></i> ناپ دیکھیں / تبدیل کریں</button></label><select id="edit-profile-{{ $item->id }}"
                                            class="form-control co-profile" name="measurement_profile_id" required>
                                            @foreach ($profiles as $profile)
                                                <option value="{{ $profile->id }}" data-measurement-url="{{ route('admin.counter-orders.measurements.edit', [$counterOrder, $profile]) }}"
                                                    data-template-ids="{{ implode(',', $profileTemplateIds->get($profile->id, [])) }}"
                                                    @selected($item->measurement_profile_id === $profile->id)>{{ $profile->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div><label for="edit-template-{{ $item->id }}">لباس / محفوظ پیمائش</label><select
                                            id="edit-template-{{ $item->id }}" class="form-control co-template"
                                            name="measurement_template_id"
                                            data-existing-template-id="{{ $item->measurement_template_id }}" required>
                                            @foreach ($templates as $template)
                                                <option value="{{ $template->id }}"
                                                    data-template-id="{{ $template->id }}" @selected($item->measurement_template_id === $template->id)>
                                                    {{ $template->name }}</option>
                                            @endforeach
                                        </select><small class="co-template-hint form-text text-muted"></small></div>
                                    <div><label for="edit-tailor-quantity-{{ $item->id }}">کتنے سوٹ سلنے
                                            ہیں؟</label><input id="edit-tailor-quantity-{{ $item->id }}"
                                            class="form-control co-tailoring-quantity" type="number" name="quantity"
                                            value="{{ (int) $item->quantity }}" min="1" required></div>
                                    <div><label for="edit-tailor-price-{{ $item->id }}">گاہک سے فی سوٹ سلائی
                                            رقم</label><input id="edit-tailor-price-{{ $item->id }}"
                                            class="form-control co-tailoring-price" type="number" name="unit_price"
                                            value="{{ $item->unit_price }}" min="0" step="0.01" required>
                                    </div>
                                    <div class="is-wide co-calculated"><span>کل سلائی رقم</span><strong
                                            class="co-tailoring-total" dir="ltr">Rs.
                                            {{ number_format((float) $item->line_total, 2) }}</strong></div>
                                    <div class="is-wide"><label for="edit-due-{{ $item->id }}">مکمل کرنے کی
                                            تاریخ</label><input id="edit-due-{{ $item->id }}" class="form-control"
                                            type="date" name="due_date"
                                            value="{{ $item->due_date?->toDateString() }}"
                                            min="{{ now()->toDateString() }}" required></div>
                                    <div class="is-wide"><label for="edit-tailor-note-{{ $item->id }}">خصوصی سلائی
                                            ہدایات <small class="text-muted">(اختیاری)</small></label>
                                        <textarea id="edit-tailor-note-{{ $item->id }}" class="form-control" name="note" rows="2">{{ $item->note }}</textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer"><button class="co-btn" type="button"
                                    data-dismiss="modal">منسوخ</button><button class="co-btn is-tailor"
                                    type="submit">تبدیلی محفوظ کریں</button></div>
                        </form>
                    </div>
                </div>
            </div>
        @endif
    @endforeach

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                (function() {
                    var picker = document.getElementById('co-customer-picker');
                    if (!picker) return;
                    var toggle = document.getElementById('co-customer-toggle'),
                        panel = document.getElementById('co-customer-panel'),
                        search = document.getElementById('co-customer-search'),
                        list = document.getElementById('co-customer-list'),
                        form = document.getElementById('co-customer-choose-form'),
                        chosenId = document.getElementById('co-customer-choose-id'),
                        searchUrl = @json(route('admin.counter-orders.customers.search')),
                        isWalkIn = picker.dataset.walkIn === '1',
                        currentId = picker.dataset.currentId,
                        timer = null,
                        requestNo = 0;

                    function close() {
                        panel.hidden = true;
                        toggle.setAttribute('aria-expanded', 'false');
                        search.value = '';
                    }

                    function option(label, meta, selected, onPick) {
                        var button = document.createElement('button');
                        button.type = 'button';
                        button.className = 'co-cust-option' + (selected ? ' is-selected' : '');
                        button.setAttribute('role', 'option');
                        button.setAttribute('aria-selected', selected ? 'true' : 'false');
                        var name = document.createElement('strong');
                        name.textContent = label;
                        button.appendChild(name);
                        if (meta) {
                            var small = document.createElement('small');
                            small.textContent = meta;
                            button.appendChild(small);
                        }
                        button.addEventListener('click', onPick);
                        return button;
                    }

                    var toggleLabel = toggle.querySelector('span');

                    function liveMessage(message, isError) {
                        var alert = document.getElementById('co-live-alert');
                        alert.hidden = false;
                        alert.className = 'alert co-alert ' + (isError ? 'alert-danger' : 'alert-success');
                        alert.textContent = message;
                    }

                    // Save the customer in the background and update the parts of the page that depend on it.
                    function saveCustomer(targetForm, body) {
                        return fetch(targetForm.action, {
                            method: 'POST',
                            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                            body: body
                        }).then(function(response) {
                            return response.json().catch(function() { return {}; }).then(function(data) {
                                if (!response.ok) {
                                    var errors = data.errors ? Object.values(data.errors).flat() : [];
                                    throw new Error(errors[0] || data.message || 'گاہک محفوظ نہیں ہو سکا۔ دوبارہ کوشش کریں۔');
                                }
                                return data;
                            });
                        }).then(function(data) {
                            applyCustomer(data);
                            return data;
                        });
                    }

                    function applyCustomer(data) {
                        var customer = data.customer || {},
                            state = customer.is_walk_in ? 'walk_in' : 'customer';
                        isWalkIn = Boolean(customer.is_walk_in);
                        currentId = isWalkIn ? '' : String(customer.id);
                        picker.dataset.walkIn = isWalkIn ? '1' : '0';
                        picker.dataset.currentId = currentId;
                        toggleLabel.textContent = customer.label;
                        var head = document.getElementById('co-head-customer');
                        if (head) head.textContent = customer.name;
                        var actions = document.getElementById('co-customer-actions');
                        if (actions) {
                            actions.innerHTML = data.customer_actions || '';
                            actions.hidden = isWalkIn;
                        }
                        var tailorButton = document.getElementById('co-add-tailoring-button');
                        if (tailorButton) tailorButton.hidden = isWalkIn;
                        ['co-items-hint', 'co-empty-hint'].forEach(function(id) {
                            var hint = document.getElementById(id);
                            if (hint) hint.textContent = state === 'walk_in' ? hint.dataset.walkIn : hint.dataset.customer;
                        });
                        var profileSelect = document.getElementById('co-profile');
                        if (profileSelect && typeof data.profile_options === 'string') {
                            profileSelect.innerHTML = data.profile_options;
                            profileSelect.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                        if (window.history && window.history.replaceState) {
                            var url = new URL(window.location.href);
                            isWalkIn ? url.searchParams.delete('profile') : url.searchParams.set('profile', customer.id);
                            window.history.replaceState(null, '', url.toString());
                        }
                        liveMessage(data.message, false);
                    }

                    function choose(id, label) {
                        var previous = toggleLabel.textContent;
                        chosenId.value = id;
                        toggleLabel.textContent = label;
                        toggle.disabled = true;
                        close();
                        saveCustomer(form, new FormData(form)).catch(function(error) {
                            toggleLabel.textContent = previous;
                            liveMessage(error.message, true);
                        }).finally(function() {
                            toggle.disabled = false;
                        });
                    }

                    function render(customers, loading) {
                        list.innerHTML = '';
                        // Walk-in is always first, so a wrong pick can be undone.
                        list.appendChild(option('واک اِن (بغیر شناخت)', '', isWalkIn, isWalkIn ? close : function() {
                            choose('walk_in', 'واک اِن (بغیر شناخت)');
                        }));
                        if (!customers.length && !loading) {
                            var empty = document.createElement('div');
                            empty.className = 'co-cust-empty';
                            empty.textContent = 'کوئی گاہک نہیں ملا۔ اوپر سے نیا گاہک شامل کریں۔';
                            list.appendChild(empty);
                            return;
                        }
                        customers.forEach(function(customer) {
                            var meta = (customer.phone_number1 || 'فون موجود نہیں') +
                                (customer.serial_number ? ' · #' + customer.serial_number : '');
                            var isCurrent = String(customer.id) === currentId;
                            list.appendChild(option(customer.name, meta, isCurrent, isCurrent ? close : function() {
                                choose(customer.id, customer.name);
                            }));
                        });
                    }

                    function load() {
                        var mine = ++requestNo;
                        fetch(searchUrl + '?q=' + encodeURIComponent(search.value.trim()), {
                            headers: { 'Accept': 'application/json' }
                        }).then(function(response) {
                            return response.ok ? response.json() : { customers: [] };
                        }).then(function(payload) {
                            if (mine === requestNo) render(payload.customers || [], false);
                        });
                    }

                    toggle.addEventListener('click', function() {
                        if (!panel.hidden) return close();
                        panel.hidden = false;
                        toggle.setAttribute('aria-expanded', 'true');
                        render([], true);
                        load();
                        search.focus();
                    });
                    search.addEventListener('input', function() {
                        clearTimeout(timer);
                        timer = setTimeout(load, 250);
                    });
                    search.addEventListener('keydown', function(event) {
                        if (event.key === 'Escape') close();
                    });
                    document.addEventListener('click', function(event) {
                        if (!picker.contains(event.target)) close();
                    });

                    var newModal = document.getElementById('newCustomerModal'),
                        newForm = document.getElementById('co-new-customer-form'),
                        newError = document.getElementById('co-new-customer-error');
                    if (newModal && newModal.dataset.autoOpen === '1' && window.jQuery) {
                        window.jQuery(newModal).modal('show');
                    }
                    if (newForm) {
                        newForm.addEventListener('submit', function(event) {
                            event.preventDefault();
                            var submit = newForm.querySelector('[type="submit"]');
                            submit.disabled = true;
                            newError.hidden = true;
                            saveCustomer(newForm, new FormData(newForm)).then(function() {
                                newForm.reset();
                                if (window.jQuery) window.jQuery(newModal).modal('hide');
                            }).catch(function(error) {
                                newError.textContent = error.message;
                                newError.hidden = false;
                            }).finally(function() {
                                submit.disabled = false;
                            });
                        });
                    }
                })();

                var cloth = document.getElementById('co-cloth-select'),
                    color = document.getElementById('co-cloth-color'),
                    price = document.getElementById('co-cloth-price'),
                    length = document.getElementById('co-cloth-length');

                function closeInlineEditors(exceptId) {
                    document.querySelectorAll('.co-grid-row.is-new').forEach(function(editor) {
                        if (editor.id !== exceptId) {
                            editor.hidden = true;
                            var article = editor.closest('[data-order-item]');
                            if (article) {
                                var display = article.querySelector('[data-display-row]');
                                if (display) display.hidden = false;
                            }
                        }
                    });
                    document.querySelectorAll('[data-inline-edit]').forEach(function(button) {
                        button.setAttribute('aria-expanded', button.dataset.inlineEdit === exceptId ? 'true' :
                            'false')
                    });
                    var add = document.getElementById('co-add-cloth-button');
                    if (add) add.setAttribute('aria-expanded', exceptId === 'co-new-cloth-row' ? 'true' : 'false');
                }
                var addButton = document.getElementById('co-add-cloth-button');
                if (addButton) {
                    addButton.addEventListener('click', function() {
                        var row = document.getElementById('co-new-cloth-row');
                        closeInlineEditors(row.id);
                        row.hidden = false;
                        this.setAttribute('aria-expanded', 'true');
                        var picker = row.querySelector('.co-picker-trigger'),
                            select = row.querySelector('select[name="cloth_id"]');
                        if (picker) picker.focus();
                        else if (select) select.focus();
                    });
                }
                document.addEventListener('click', function(event) {
                    var editButton = event.target.closest('[data-inline-edit]');
                    if (editButton) {
                        var editor = document.getElementById(editButton.dataset.inlineEdit);
                        closeInlineEditors(editor.id);
                        var article = editor.closest('[data-order-item]'),
                            display = article && article.querySelector('[data-display-row]');
                        if (display) display.hidden = true;
                        editor.hidden = false;
                        editButton.setAttribute('aria-expanded', 'true');
                        var field = editor.querySelector('select,input');
                        if (field) field.focus();
                        return;
                    }
                    var cancelButton = event.target.closest('[data-inline-cancel]');
                    if (cancelButton) {
                        closeInlineEditors(null);
                    }
                });
                if (cloth) {
                    var updateClothFields = function(preserveValues) {
                        var o = cloth.options[cloth.selectedIndex],
                            form = cloth.closest('.co-cloth-form'),
                            colors = [],
                            unitPrice = Number(o.dataset.price || 0),
                            defaultLength = Number(o.dataset.length || 4.5),
                            quantity = form.querySelector('.co-cloth-quantity'),
                            suitOnly = form.querySelector('.co-suit-only'),
                            oldColor = preserveValues ? (form.dataset.oldColor || '') : '',
                            // Packed suits and pieces (perfume, cap) are sold by count only; there is no length to cut.
                            suitStock = o.dataset.unit === 'suit' || o.dataset.unit === 'piece',
                            wholeLabel = o.dataset.unit === 'piece' ? ' عدد' : ' سوٹ';
                        try {
                            colors = JSON.parse(o.dataset.colors || '[]')
                        } catch (e) {}
                        var colorStock = {};
                        try {
                            colorStock = JSON.parse(o.dataset.colorStock || '{}') || {}
                        } catch (e) {}
                        color.innerHTML = '';
                        if (colors.length) {
                            // Per-color stock: show meters and leave out colors with no stock.
                            colors = colors.filter(function(c) {
                                return !(c in colorStock) || Number(colorStock[c]) > 0 || oldColor === c;
                            });
                            colors.forEach(function(c, index) {
                                var x = document.createElement('option'),
                                    tracked = c in colorStock;
                                x.value = c;
                                x.textContent = tracked ? c + ' — ' + (suitStock ? Number(colorStock[c]).toFixed(0) + wholeLabel :
                                    Number(colorStock[c]).toFixed(2) + ' میٹر') : c;
                                x.selected = oldColor ? oldColor === c : index === 0;
                                color.appendChild(x)
                            });
                        } else {
                            var placeholder = document.createElement('option');
                            placeholder.value = '';
                            placeholder.textContent = 'رنگ لاگو نہیں';
                            color.appendChild(placeholder);
                        }
                        color.required = false;
                        color.disabled = !cloth.value;
                        suitOnly.hidden = o.dataset.basis !== 'per_suit';
                        length.hidden = suitStock;
                        form.dataset.basis = o.dataset.basis || 'per_meter';
                        form.dataset.unitPrice = unitPrice;
                        if (!preserveValues) {
                            length.value = cloth.value ? (suitStock ? '1' : defaultLength.toFixed(2)) : '';
                            if (quantity) quantity.value = 1;
                            price.value = cloth.value && unitPrice ? (o.dataset.basis === 'per_suit' ? unitPrice :
                                unitPrice * defaultLength).toFixed(2) : '';
                        }
                    };
                    cloth.addEventListener('change', function() {
                        updateClothFields(false);
                    });
                    if (cloth.value) updateClothFields(true);
                    else color.disabled = true;
                }


                // Searchable, grouped picker drawn over the native cloth select. The select stays the
                // source of truth: picking a card sets its value and fires "change" for the code above.
                (function initClothPicker(select) {
                    if (!select) return;
                    var form = select.closest('form'),
                        wrap = document.createElement('div'),
                        trigger = document.createElement('button'),
                        panel = document.createElement('div'),
                        search, list, tabs, subtabs,
                        activeMain = '',
                        activeSub = '',
                        activeIndex = -1;

                    wrap.className = 'co-picker';
                    trigger.type = 'button';
                    trigger.className = 'co-picker-trigger';
                    trigger.setAttribute('aria-haspopup', 'listbox');
                    trigger.setAttribute('aria-expanded', 'false');
                    trigger.setAttribute('aria-label', 'آئٹم منتخب کریں');
                    panel.className = 'co-picker-panel';
                    panel.hidden = true;
                    panel.innerHTML =
                        '<div class="co-picker-search"><input type="search" autocomplete="off" placeholder="نام، برانڈ یا قسم سے تلاش کریں" aria-label="آئٹم تلاش کریں"><i class="fas fa-search"></i></div>' +
                        '<div class="co-picker-tabs" role="tablist" aria-label="مین کیٹیگری"></div>' +
                        '<div class="co-picker-subtabs" role="tablist" aria-label="سب کیٹیگری"></div>' +
                        '<div class="co-picker-list" role="listbox"></div>';
                    search = panel.querySelector('input');
                    tabs = panel.querySelector('.co-picker-tabs');
                    subtabs = panel.querySelector('.co-picker-subtabs');
                    list = panel.querySelector('.co-picker-list');

                    select.classList.add('co-picker-native');
                    select.tabIndex = -1;
                    select.setAttribute('aria-hidden', 'true');
                    select.parentNode.insertBefore(wrap, select);
                    wrap.appendChild(trigger);
                    wrap.appendChild(select);
                    document.body.appendChild(panel);

                    function escapeHtml(value) {
                        return String(value || '').replace(/[&<>"']/g, function(c) {
                            return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c];
                        });
                    }

                    function items() {
                        return Array.from(select.options).filter(function(o) { return o.value; }).map(function(o) {
                            var suit = o.dataset.basis === 'per_suit';
                            return {
                                value: o.value,
                                name: o.dataset.name || o.textContent.trim(),
                                meta: o.dataset.meta || '',
                                group: o.parentNode.tagName === 'OPTGROUP' ? o.parentNode.label : '',
                                main: o.dataset.main || '',
                                sub: o.dataset.sub || '',
                                unit: o.dataset.unit || 'meter',
                                price: Number(o.dataset.price || 0),
                                priceUnit: o.dataset.unit === 'piece' ? 'عدد' : (suit ? 'سوٹ' : 'میٹر')
                            };
                        });
                    }

                    function money(value) {
                        return 'Rs ' + Number(value || 0).toLocaleString('en-PK', {maximumFractionDigits: 0});
                    }

                    function renderTrigger() {
                        var o = select.options[select.selectedIndex];
                        trigger.innerHTML = (o && o.value
                            ? '<span class="co-picker-trigger-text"><strong>' + escapeHtml(o.dataset.name || o.textContent) +
                                '</strong><small>' + escapeHtml(o.dataset.meta || '') + '</small></span>'
                            : '<span class="co-picker-trigger-text co-picker-placeholder">آئٹم منتخب کریں</span>') +
                            '<i class="fas fa-chevron-down co-picker-caret" aria-hidden="true"></i>';
                    }

                    function unique(values) {
                        return values.filter(function(value, index) { return value && values.indexOf(value) === index; });
                    }

                    // Main categories (Men, Women…) as tabs; the selected one's sub categories as chips below.
                    function renderTabs(all) {
                        var mains = unique(all.map(function(item) { return item.main; })),
                            subs = activeMain ? unique(all.filter(function(item) { return item.main === activeMain; })
                                .map(function(item) { return item.sub; })) : [];
                        tabs.hidden = mains.length < 2;
                        tabs.innerHTML = [''].concat(mains).map(function(main) {
                            return '<button type="button" role="tab" class="co-picker-tab' + (main === activeMain ? ' is-active' : '') +
                                '" aria-selected="' + (main === activeMain) + '" data-main="' + escapeHtml(main) + '">' +
                                (main ? escapeHtml(main) : 'سب') + '</button>';
                        }).join('');
                        subtabs.hidden = subs.length < 2;
                        subtabs.innerHTML = [''].concat(subs).map(function(sub) {
                            return '<button type="button" role="tab" class="co-picker-chip' + (sub === activeSub ? ' is-active' : '') +
                                '" aria-selected="' + (sub === activeSub) + '" data-sub="' + escapeHtml(sub) + '">' +
                                (sub ? escapeHtml(sub) : 'سب ' + escapeHtml(activeMain)) + '</button>';
                        }).join('');
                    }

                    function renderList() {
                        var all = items(),
                            term = search.value.trim().toLowerCase(),
                            html = '',
                            lastGroup = null,
                            shown = all.filter(function(item) {
                                return (!activeMain || item.main === activeMain) &&
                                    (!activeSub || item.sub === activeSub) &&
                                    (!term || (item.name + ' ' + item.meta + ' ' + item.group).toLowerCase().indexOf(term) !== -1);
                            });
                        renderTabs(all);
                        shown.forEach(function(item, index) {
                            if (item.group !== lastGroup) {
                                html += '<div class="co-picker-group">' + escapeHtml(item.group || 'دیگر') + '</div>';
                                lastGroup = item.group;
                            }
                            html += '<button type="button" role="option" class="co-picker-option' +
                                (item.value === select.value ? ' is-selected' : '') + '" data-value="' + item.value +
                                '" data-unit="' + item.unit + '" data-index="' + index + '">' +
                                '<span class="co-picker-avatar">' + escapeHtml(item.name.trim().charAt(0).toUpperCase() || '؟') + '</span>' +
                                '<span class="co-picker-option-text"><strong>' + escapeHtml(item.name) + '</strong><small>' +
                                escapeHtml(item.meta) + '</small></span>' +
                                (item.price ? '<span class="co-picker-price">' + money(item.price) + ' / ' + item.priceUnit + '</span>' : '') +
                                '</button>';
                        });
                        list.innerHTML = html || '<div class="co-picker-empty"><i class="fas fa-box-open ml-1"></i> کوئی دستیاب آئٹم نہیں ملا</div>';
                        activeIndex = -1;
                    }

                    function place() {
                        var rect = trigger.getBoundingClientRect(),
                            width = Math.max(rect.width, Math.min(420, window.innerWidth - 24)),
                            right = Math.max(12, window.innerWidth - rect.right),
                            below = window.innerHeight - rect.bottom - 12,
                            above = rect.top - 12;
                        panel.style.width = width + 'px';
                        panel.style.right = Math.min(right, window.innerWidth - width - 12) + 'px';
                        if (below >= 260 || below >= above) {
                            panel.style.top = (rect.bottom + 6) + 'px';
                            panel.style.bottom = '';
                            panel.style.maxHeight = Math.min(420, below) + 'px';
                        } else {
                            panel.style.top = '';
                            panel.style.bottom = (window.innerHeight - rect.top + 6) + 'px';
                            panel.style.maxHeight = Math.min(420, above) + 'px';
                        }
                    }

                    function open() {
                        if (select.disabled) return;
                        search.value = '';
                        renderList();
                        panel.hidden = false;
                        wrap.classList.add('is-open');
                        trigger.setAttribute('aria-expanded', 'true');
                        place();
                        var selected = list.querySelector('.is-selected');
                        if (selected) selected.scrollIntoView({block: 'nearest'});
                        search.focus();
                    }

                    function close(focusTrigger) {
                        if (panel.hidden) return;
                        panel.hidden = true;
                        wrap.classList.remove('is-open');
                        trigger.setAttribute('aria-expanded', 'false');
                        if (focusTrigger) trigger.focus();
                    }

                    function choose(value) {
                        select.value = value;
                        select.dispatchEvent(new Event('change', {bubbles: true}));
                        renderTrigger();
                        close(true);
                    }

                    function highlight(step) {
                        var options = list.querySelectorAll('.co-picker-option');
                        if (!options.length) return;
                        activeIndex = (activeIndex + step + options.length) % options.length;
                        options.forEach(function(option, index) { option.classList.toggle('is-active', index === activeIndex); });
                        options[activeIndex].scrollIntoView({block: 'nearest'});
                    }

                    trigger.addEventListener('click', function() { panel.hidden ? open() : close(false); });
                    trigger.addEventListener('keydown', function(event) {
                        if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
                            event.preventDefault();
                            open();
                        }
                    });
                    search.addEventListener('input', renderList);
                    search.addEventListener('keydown', function(event) {
                        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                            event.preventDefault();
                            highlight(event.key === 'ArrowDown' ? 1 : -1);
                        } else if (event.key === 'Enter') {
                            event.preventDefault();
                            var options = list.querySelectorAll('.co-picker-option'),
                                target = options[activeIndex >= 0 ? activeIndex : 0];
                            if (target) choose(target.dataset.value);
                        } else if (event.key === 'Escape') {
                            close(true);
                        }
                    });
                    tabs.addEventListener('click', function(event) {
                        var tab = event.target.closest('.co-picker-tab');
                        if (!tab) return;
                        activeMain = tab.dataset.main;
                        activeSub = '';
                        renderList();
                        search.focus();
                    });
                    subtabs.addEventListener('click', function(event) {
                        var chip = event.target.closest('.co-picker-chip');
                        if (!chip) return;
                        activeSub = chip.dataset.sub;
                        renderList();
                        search.focus();
                    });
                    list.addEventListener('click', function(event) {
                        var option = event.target.closest('.co-picker-option');
                        if (option) choose(option.dataset.value);
                    });
                    document.addEventListener('mousedown', function(event) {
                        if (!panel.hidden && !panel.contains(event.target) && !wrap.contains(event.target)) close(false);
                    });
                    window.addEventListener('resize', function() { if (!panel.hidden) place(); });
                    window.addEventListener('scroll', function() { if (!panel.hidden) place(); }, true);
                    select.addEventListener('change', renderTrigger);
                    // The row form is reset after an item is added; show the empty picker again.
                    if (form) form.addEventListener('reset', function() { setTimeout(renderTrigger, 0); });
                    renderTrigger();
                })(cloth);

                $(document).on('change', '#co-tailor', function() {
                    var tailorId = $(this).val();
                    var rateSelect = $('#co-tailor-rate');

                    rateSelect
                        .empty()
                        .append($('<option>', {
                            value: '',
                            text: tailorId ?
                                'شرح لوڈ ہو رہی ہے...' : 'پہلے درزی منتخب کریں'
                        }))
                        .prop('disabled', true);

                    if (!tailorId) {
                        return;
                    }

                    var url = rateSelect
                        .data('rate-url')
                        .replace('__ID__', encodeURIComponent(tailorId));

                    $.ajax({
                        url: url,
                        method: 'GET',
                        dataType: 'json',

                        success: function(rates) {
                            rateSelect.empty();

                            rateSelect.append($('<option>', {
                                value: '',
                                text: 'سلائی کی شرح منتخب کریں'
                            }));

                            $.each(rates, function(_, rate) {
                                rateSelect.append($('<option>', {
                                    value: rate.rateValue,
                                    text: rate.rateName + ' — Rs. ' +
                                        Number(rate.price).toFixed(2)
                                }));
                            });

                            if (rates.length === 0) {
                                rateSelect.empty().append($('<option>', {
                                    value: '',
                                    text: 'اس درزی کے لیے کوئی شرح موجود نہیں'
                                }));
                            }

                            rateSelect.prop('disabled', rates.length === 0);

                            // console.log('Fetched tailor rates:', rates);
                        },

                        error: function(xhr) {
                            console.error('Failed to fetch tailor rates:', xhr.status, xhr
                                .responseText);

                            rateSelect
                                .empty()
                                .append($('<option>', {
                                    value: '',
                                    text: 'شرح لوڈ نہیں ہو سکی'
                                }))
                                .prop('disabled', true);
                        }
                    });
                });

                function bindClothForm(form) {
                    if (form.dataset.bound === 'true') return;
                    form.dataset.bound = 'true';
                    var quantity = form.querySelector('.co-cloth-quantity'),
                        clothLength = form.querySelector('.co-cloth-length'),
                        total = form.querySelector('.co-cloth-total');

                    function recalculate() {
                        var unit = Number(form.dataset.unitPrice || 0);
                        if (!unit || !total) return;
                        total.value = (unit * (form.dataset.basis === 'per_suit' ? Math.max(1, Number(quantity &&
                            quantity.value || 1)) : Math.max(0, Number(clothLength && clothLength.value ||
                            0)))).toFixed(2);
                    }
                    if (quantity) quantity.addEventListener('input', recalculate);
                    if (clothLength) clothLength.addEventListener('input', recalculate);
                }
                document.querySelectorAll('.co-cloth-form').forEach(bindClothForm);

                function money(value) {
                    return 'Rs. ' + Number(value || 0).toLocaleString('en-PK', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    });
                }

                function updateSummary(summary) {
                    document.getElementById('co-summary-subtotal').textContent = money(summary.subtotal);
                    document.getElementById('co-summary-paid').textContent = money(summary.paid);
                    document.getElementById('co-summary-balance').textContent = money(summary.balance);
                    document.getElementById('co-confirmed-count').textContent = summary.confirmed_count;
                    document.getElementById('co-draft-count').textContent = summary.draft_count;
                    document.getElementById('co-draft-total').textContent = money(summary.draft_total);
                    var previousDue = Number(summary.previous_due || 0),
                        payable = Number(summary.draft_total) + previousDue;
                    document.getElementById('co-previous-due').textContent = money(previousDue);
                    document.getElementById('co-previous-due-row').hidden = previousDue <= 0;
                    document.getElementById('co-payable-total').textContent = money(payable);
                    var confirmForm = document.getElementById('co-confirm-form');
                    if (confirmForm) {
                        confirmForm.hidden = summary.draft_count < 1;
                        var payment = confirmForm.querySelector('[name="payment"]');
                        if (payment) payment.max = payable.toFixed(2);
                        var hint = document.getElementById('co-payment-hint');
                        if (hint) hint.hidden = previousDue <= 0;
                    }
                }

                // Payment: "pay full" fills the whole payable amount; over-limit shows an Urdu message.
                (function() {
                    var payment = document.querySelector('#co-confirm-form [name="payment"]');
                    if (!payment) return;
                    var check = function() {
                        payment.setCustomValidity(
                            payment.max !== '' && Number(payment.value) > Number(payment.max) + 0.001
                                ? payment.dataset.maxMessage + ' (Rs. ' + Number(payment.max).toFixed(2) + ')'
                                : ''
                        );
                    };
                    payment.addEventListener('input', check);
                    document.getElementById('co-pay-full').addEventListener('click', function() {
                        payment.value = Number(payment.max || 0).toFixed(2);
                        check();
                    });
                })();

                function showLiveMessage(message, isError) {
                    var alert = document.getElementById('co-live-alert');
                    alert.hidden = false;
                    alert.className = 'alert co-alert ' + (isError ? 'alert-danger' : 'alert-success');
                    alert.textContent = message;
                }
                document.addEventListener('submit', async function(event) {
                    var form = event.target.closest('.co-ajax-row-form');
                    if (!form) return;
                    event.preventDefault();
                    var submit = form.querySelector('[type="submit"]');
                    if (submit) submit.disabled = true;
                    try {
                        var response = await fetch(form.action, {
                            method: 'POST',
                            body: new FormData(form),
                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        var data = await response.json();
                        if (!response.ok) {
                            var errors = data.errors || {},
                                first = Object.keys(errors).length ? errors[Object.keys(errors)[0]][0] : (
                                    data.message || 'تبدیلی محفوظ نہیں ہوئی۔');
                            showLiveMessage(first, true);
                            return;
                        }
                        var holder = document.createElement('div');
                        holder.innerHTML = data.row_html.trim();
                        var article = holder.firstElementChild,
                            existing = document.querySelector('[data-order-item="' + data.item_id + '"]'),
                            rows = document.getElementById('co-items-rows');
                        if (existing) existing.replaceWith(article);
                        else rows.appendChild(article);
                        var empty = rows.querySelector('.co-empty');
                        if (empty) empty.remove();
                        bindClothForm(article.querySelector('.co-cloth-form'));
                        updateSummary(data.summary);
                        if (form.id === 'co-new-cloth-row') {
                            form.reset();
                            color.innerHTML = '<option value="">رنگ لاگو نہیں</option>';
                            color.disabled = true;
                            length.value = '';
                            price.value = '';
                        }
                        closeInlineEditors(null);
                        showLiveMessage(data.message, false);
                    } catch (error) {
                        showLiveMessage('تبدیلی محفوظ نہیں ہوئی۔ دوبارہ کوشش کریں۔', true);
                    } finally {
                        if (submit) submit.disabled = false;
                    }
                });
                document.querySelectorAll('.co-tailoring-form').forEach(function(form) {
                    var profile = form.querySelector('.co-profile') || document.getElementById('co-profile'),
                        template = form.querySelector('.co-template') || document.getElementById('co-template'),
                        measurementLink = form.querySelector('.co-measurement-link'),
                        templateHint = form.querySelector('.co-template-hint'),
                        suitQuantity = form.querySelector('.co-tailoring-quantity') || document.getElementById(
                            'co-suit-quantity'),
                        tailoringPrice = form.querySelector('.co-tailoring-price') || document.getElementById(
                            'co-tailoring-price'),
                        tailoringTotal = form.querySelector('.co-tailoring-total') || document.getElementById(
                            'co-tailoring-total');

                    function filterTemplates() {
                        if (!profile || !template) return;
                        var selectedProfile = profile.options[profile.selectedIndex],
                            ids = (selectedProfile.dataset.templateIds || '').split(',').filter(Boolean),
                            existing = template.dataset.existingTemplateId || '',
                            firstAvailable = null;
                        Array.from(template.options).forEach(function(option) {
                            var allowed = ids.indexOf(String(option.value)) !== -1 || String(option
                                .value) === String(existing);
                            option.hidden = !allowed;
                            option.disabled = !allowed;
                            if (allowed && !firstAvailable) firstAvailable = option;
                        });
                        if (!template.selectedOptions.length || template.selectedOptions[0].disabled) {
                            template.value = firstAvailable ? firstAvailable.value : '';
                        }
                        var hasTemplate = Boolean(template.value) && template.selectedOptions.length && !
                            template.selectedOptions[0].disabled;
                        template.disabled = !hasTemplate;
                        if (measurementLink) measurementLink.disabled = !hasTemplate;
                        if (templateHint) templateHint.textContent = hasTemplate ?
                            'صرف اس فرد کی محفوظ پیمائش دکھائی گئی ہے۔' :
                            'اس فرد کی کوئی محفوظ پیمائش موجود نہیں۔ پہلے گاہک کے پروفائل میں پیمائش شامل کریں۔';
                        updateMeasurementLink();
                    }

                    function updateMeasurementLink() {
                        if (!profile || !template || !measurementLink) return;
                        var o = profile.options[profile.selectedIndex],
                            base = o.dataset.measurementUrl || '#';
                        measurementLink.dataset.url = template.disabled ? '#' : base + (base.indexOf('?') === -
                            1 ? '?' : '&') + 'measurement_template_id=' + encodeURIComponent(template.value);
                    }

                    function updateTailoringTotal() {
                        if (!suitQuantity || !tailoringPrice || !tailoringTotal) return;
                        var total = Math.max(0, Number(suitQuantity.value || 0)) * Math.max(0, Number(
                            tailoringPrice.value || 0));
                        tailoringTotal.textContent = 'Rs. ' + total.toLocaleString('en-PK', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        });
                    }
                    if (profile && template) {
                        profile.addEventListener('change', filterTemplates);
                        template.addEventListener('change', updateMeasurementLink);
                        filterTemplates();
                    }
                    if (suitQuantity && tailoringPrice) {
                        suitQuantity.addEventListener('input', updateTailoringTotal);
                        tailoringPrice.addEventListener('input', updateTailoringTotal);
                        updateTailoringTotal();
                    }
                });

                var measurementModal = document.getElementById('measurementProfileModal'),
                    measurementBody = document.getElementById('co-measurement-modal-body'),
                    returnTailoringModal = null;
                async function loadMeasurementEditor(button) {
                    if (!measurementModal || !measurementBody) return;
                    var url = button.dataset.url;
                    if (!url || url === '#') {
                        showLiveMessage('پہلے فرد اور لباس منتخب کریں۔', true);
                        return;
                    }
                    returnTailoringModal = button.closest('.modal');
                    measurementBody.innerHTML =
                        '<div class="co-measurement-loading"><i class="fas fa-circle-notch fa-spin ml-1"></i> پیمائش لوڈ ہو رہی ہے…</div>';
                    var openEditor = function() {
                        window.jQuery(measurementModal).modal('show');
                    };
                    if (returnTailoringModal) {
                        window.jQuery(returnTailoringModal).one('hidden.bs.modal', openEditor).modal('hide');
                    } else {
                        openEditor();
                    }
                    try {
                        var response = await fetch(url, {
                            headers: {
                                'Accept': 'text/html',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        if (!response.ok) throw new Error('load');
                        measurementBody.innerHTML = await response.text();
                    } catch (error) {
                        measurementBody.innerHTML =
                            '<div class="alert alert-danger mb-0">پیمائش لوڈ نہیں ہو سکی۔ دوبارہ کوشش کریں۔</div>';
                    }
                }
                document.addEventListener('click', function(event) {
                    var measurementButton = event.target.closest('.co-measurement-link');
                    if (measurementButton) {
                        event.preventDefault();
                        loadMeasurementEditor(measurementButton);
                    }
                });
                if (measurementModal) {
                    window.jQuery(measurementModal).on('hidden.bs.modal', function() {
                        if (returnTailoringModal) {
                            var target = returnTailoringModal;
                            returnTailoringModal = null;
                            window.jQuery(target).modal('show');
                        }
                    });
                }
                document.addEventListener('focusin', function(event) {
                    var select = event.target.closest('#co-measurement-editor-form select[data-inline-option-type]');
                    if (select) select.dataset.previousValue = select.value;
                });
                document.addEventListener('change', async function(event) {
                    var select = event.target.closest('#co-measurement-editor-form select[data-inline-option-type]');
                    if (!select) return;
                    if (select.value !== '__add_new__') {
                        select.dataset.previousValue = select.value;
                        return;
                    }
                    select.value = select.dataset.previousValue || '';
                    var label = select.dataset.inlineOptionLabel || (select.closest('.form-group')?.querySelector('label')?.textContent || '').trim();
                    var result = await window.TMSQuickAdd.open({
                        title: (label ? label + ' — ' : '') + 'نیا انتخاب شامل کریں',
                        url: select.dataset.inlineOptionUrl,
                        fields: [{ name: 'Name', label: 'انتخاب کا نام', urdu: true }],
                        extra: { OptionTypeId: select.dataset.inlineOptionType, measurement_template_id: select.dataset.inlineOptionTemplate }
                    });
                    if (!result) return;
                    select.add(new Option(result.name, result.name, true, true));
                    select.dataset.previousValue = result.name;
                    select.dispatchEvent(new Event('change', { bubbles: true }));
                });
                document.addEventListener('submit', async function(event) {
                    var form = event.target.closest('#co-measurement-editor-form');
                    if (!form) return;
                    event.preventDefault();
                    var submit = form.querySelector('[type="submit"]'),
                        errors = document.getElementById('co-measurement-errors');
                    if (submit) submit.disabled = true;
                    if (errors) {
                        errors.hidden = true;
                        errors.innerHTML = '';
                    }
                    try {
                        var response = await fetch(form.action, {
                            method: 'POST',
                            body: new FormData(form),
                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        var data = await response.json();
                        if (!response.ok) {
                            var messages = [];
                            Object.keys(data.errors || {}).forEach(function(key) {
                                messages = messages.concat(data.errors[key]);
                            });
                            if (!messages.length) messages.push(data.message || 'پیمائش محفوظ نہیں ہوئی۔');
                            if (errors) {
                                errors.innerHTML =
                                    '<strong>پیمائش محفوظ نہیں ہوئی:</strong><ul class="mb-0 mt-2">' +
                                    messages.map(function(message) {
                                        return '<li>' + String(message).replace(/[&<>"']/g, function(
                                            char) {
                                            return {
                                                '&': '&amp;',
                                                '<': '&lt;',
                                                '>': '&gt;',
                                                '"': '&quot;',
                                                "'": '&#039;'
                                            } [char];
                                        }) + '</li>';
                                    }).join('') + '</ul>';
                                errors.hidden = false;
                            }
                            return;
                        }
                        showLiveMessage(data.message, false);
                        window.jQuery(measurementModal).modal('hide');
                    } catch (error) {
                        if (errors) {
                            errors.textContent = 'پیمائش محفوظ نہیں ہوئی۔ دوبارہ کوشش کریں۔';
                            errors.hidden = false;
                        }
                    } finally {
                        if (submit) submit.disabled = false;
                    }
                });
            });
        </script>
        @include('partials.quick-add-modal')
    @endpush
@endsection
