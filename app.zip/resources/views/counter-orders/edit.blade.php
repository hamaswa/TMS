@extends('main')

@section('content')
    @php
        $draftItems = $counterOrder->items->where('status', 'draft');
        $confirmedItems = $counterOrder->items->where('status', 'confirmed');
        $draftTotal = (float) $draftItems->sum('line_total');
        $statusLabels = [
            'draft' => 'مسودہ',
            'forwarded' => 'ایجنٹ سے موصول',
            'claimed' => 'ایڈمن کے پاس',
            'confirmed' => 'تصدیق شدہ',
            'closed' => 'بند',
        ];
        $orderScopeText =
            $canAddCloth && $canAddTailoring
                ? 'کپڑا اور سلائی ایک ہی آرڈر میں'
                : ($canAddCloth
                    ? 'کپڑے کی فروخت کا آرڈر'
                    : 'سلائی کا آرڈر');
        $emptyOrderHint =
            $canAddCloth && $canAddTailoring
                ? 'اوپر سے کپڑا یا سلائی شامل کریں۔'
                : ($canAddCloth
                    ? 'اوپر سے فروخت ہونے والا کپڑا شامل کریں۔'
                    : 'اوپر سے سلائی شامل کریں۔');
        $confirmationHint =
            $canAddCloth && $canAddTailoring
                ? 'تصدیق پر کپڑا اسٹاک سے کم ہوگا اور سلائی ورکشاپ آرڈر بنے گا۔'
                : ($canAddCloth
                    ? 'تصدیق پر کپڑا اسٹاک سے کم ہوگا۔'
                    : 'تصدیق پر سلائی ورکشاپ آرڈر بنے گا۔');
        $moreItemsHint =
            $canAddCloth && $canAddTailoring
                ? 'مزید کپڑا یا سلائی بعد میں بھی شامل ہو سکتی ہے۔'
                : ($canAddCloth
                    ? 'مزید کپڑا بعد میں بھی شامل ہو سکتا ہے۔'
                    : 'مزید سلائی بعد میں بھی شامل ہو سکتی ہے۔');
    @endphp
    <style>
        .co-page {
            --blue: #1769e0;
            --navy: #122d4f;
            --muted: #718096;
            --line: #e0e7f0;
            direction: rtl;
            padding: 24px 16px 60px;
            color: var(--navy)
        }

        .co-shell {
            max-width: 1420px;
            margin: auto
        }

        .co-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 17px
        }

        .co-title h1 {
            margin: 0 0 5px;
            font-size: 1.65rem;
            font-weight: 850
        }

        .co-title p {
            margin: 0;
            color: var(--muted)
        }

        .co-status {
            padding: 7px 11px;
            border-radius: 999px;
            color: #185e3e;
            background: #e8f8ef;
            font-size: .8rem;
            font-weight: 800
        }

        .co-summary {
            display: grid;
            grid-template-columns: 1.3fr repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 16px
        }

        .co-summary>div {
            padding: 15px 17px;
            border: 1px solid var(--line);
            border-radius: 13px;
            background: #fff
        }

        .co-summary small {
            display: block;
            margin-bottom: 5px;
            color: var(--muted)
        }

        .co-summary strong {
            font-size: 1.02rem
        }

        .co-main {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 330px;
            gap: 16px;
            align-items: start
        }

        .co-panel {
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: 15px;
            background: #fff;
            box-shadow: 0 8px 26px rgba(23, 52, 86, .05)
        }

        .co-panel-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 17px 19px;
            border-bottom: 1px solid var(--line)
        }

        .co-panel-head h2 {
            margin: 0;
            font-size: 1.08rem;
            font-weight: 850
        }

        .co-adds {
            display: flex;
            gap: 8px
        }

        .co-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-height: 39px;
            padding: 7px 12px;
            border: 1px solid #ccdaeb;
            border-radius: 9px;
            color: #35506e !important;
            background: #fff;
            font-weight: 750;
            text-decoration: none !important
        }

        .co-btn.is-primary {
            border-color: var(--blue);
            color: #fff !important;
            background: var(--blue)
        }

        .co-btn.is-tailor {
            border-color: #188657;
            color: #fff !important;
            background: #188657
        }

        .co-btn:disabled {
            opacity: .55
        }

        .co-list {
            padding: 6px 18px
        }

        .co-item {
            display: grid;
            grid-template-columns: 44px minmax(0, 1fr) auto auto;
            gap: 12px;
            align-items: center;
            padding: 15px 2px;
            border-bottom: 1px solid #edf1f6
        }

        .co-item:last-child {
            border: 0
        }

        .co-icon {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            border-radius: 11px;
            color: #1769e0;
            background: #edf5ff
        }

        .co-item.is-tailoring .co-icon {
            color: #12804e;
            background: #eaf8f1
        }

        .co-item h3 {
            margin: 0 0 4px;
            font-size: .98rem;
            font-weight: 850
        }

        .co-item p {
            margin: 0;
            color: var(--muted);
            font-size: .8rem
        }

        .co-price {
            text-align: left;
            white-space: nowrap
        }

        .co-price strong {
            display: block
        }

        .co-price small {
            color: var(--muted)
        }

        .co-state {
            display: inline-flex;
            padding: 4px 8px;
            border-radius: 999px;
            color: #9a6500;
            background: #fff3d8;
            font-size: .72rem;
            font-weight: 800
        }

        .co-state.is-confirmed {
            color: #147348;
            background: #e8f7ef
        }

        .co-empty {
            padding: 55px 20px;
            text-align: center;
            color: var(--muted)
        }

        .co-empty i {
            display: block;
            margin-bottom: 11px;
            color: #c4d0de;
            font-size: 34px
        }

        .co-side {
            display: grid;
            gap: 16px
        }

        .co-total {
            padding: 20px
        }

        .co-total-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            padding: 9px 0;
            color: #607187
        }

        .co-total-row.is-main {
            margin-top: 7px;
            padding-top: 15px;
            border-top: 1px solid var(--line);
            color: var(--navy);
            font-size: 1.05rem;
            font-weight: 850
        }

        .co-confirm {
            padding: 18px;
            border-top: 1px solid var(--line);
            background: #fbfdff
        }

        .co-confirm .form-control {
            min-height: 43px;
            border-radius: 8px
        }

        .co-help {
            margin: 0 0 13px;
            color: var(--muted);
            font-size: .78rem
        }

        .co-source {
            display: inline-flex;
            margin-top: 6px;
            color: #1769e0;
            font-size: .76rem;
            font-weight: 700
        }

        .co-close {
            padding: 18px
        }

        .modal-content {
            direction: rtl;
            text-align: right;
            border: 0;
            border-radius: 15px
        }

        .modal-header .close {
            margin: -1rem auto -1rem -1rem
        }

        .modal-title {
            font-weight: 850
        }

        .modal-body .form-control {
            min-height: 44px;
            border-radius: 8px
        }

        .co-modal-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 13px
        }

        .co-modal-grid .is-wide {
            grid-column: 1/-1
        }

        .co-modal-grid label {
            display: block;
            margin-bottom: 6px;
            font-weight: 750
        }

        .co-remove {
            border: 0;
            color: #c03c48;
            background: transparent
        }

        .co-alert {
            margin-bottom: 15px
        }

        .co-mobile-source {
            margin-bottom: 16px;
            padding: 13px 16px;
            border: 1px solid #cfe1fa;
            border-radius: 12px;
            color: #315f92;
            background: #f1f7ff
        }

        .modal-content {
            max-height: calc(100vh - 32px);
            overflow: hidden
        }

        .co-modal-form {
            display: flex;
            min-height: 0;
            max-height: calc(100vh - 32px);
            flex: 1 1 auto;
            flex-direction: column
        }

        .co-modal-form .modal-header,
        .co-modal-form .modal-footer {
            flex: 0 0 auto
        }

        .co-modal-form .modal-body {
            min-height: 0;
            overflow-y: auto;
            overscroll-behavior: contain
        }

        .co-field-label {
            display: flex !important;
            align-items: center;
            justify-content: space-between;
            gap: 10px
        }

        .co-measurement-link {
            padding: 0;
            border: 0;
            color: #1769e0;
            background: transparent;
            font-size: .78rem;
            font-weight: 750;
            cursor: pointer
        }

        .co-calculated {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 12px 14px;
            border: 1px solid #cfe3f4;
            border-radius: 10px;
            background: #f5faff
        }

        .co-calculated span {
            color: #52677f;
            font-weight: 750
        }

        .co-calculated strong {
            font-size: 1.05rem
        }

        .co-actions {
            display: flex;
            align-items: center;
            gap: 3px
        }

        .co-edit {
            border: 0;
            color: #1769e0;
            background: transparent
        }

        .co-readonly {
            padding: 11px 13px;
            border: 1px solid #e0e7f0;
            border-radius: 8px;
            color: #52677f;
            background: #f7f9fc;
            font-weight: 700
        }

        .co-suit-only[hidden] {
            display: none !important
        }

        .co-measurement-modal .modal-dialog {
            max-width: 980px
        }

        .co-measurement-modal .modal-body {
            min-height: 0;
            max-height: calc(100vh - 115px);
            overflow-y: auto;
            overscroll-behavior: contain
        }

        .co-measurement-loading {
            padding: 54px 20px;
            color: var(--muted);
            text-align: center
        }

        .co-measurement-context {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 15px
        }

        .co-measurement-context>div {
            padding: 10px 12px;
            border: 1px solid #dce6f1;
            border-radius: 10px;
            background: #f8fbfe
        }

        .co-measurement-context span {
            display: block;
            color: var(--muted);
            font-size: .72rem
        }

        .co-measurement-context strong {
            display: block;
            margin-top: 3px
        }

        .co-measurement-columns {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            align-items: start
        }

        .co-measurement-column {
            padding: 14px;
            border: 1px solid #dde7f0;
            border-radius: 12px;
            background: #fbfdff
        }

        .co-measurement-stack {
            display: grid;
            grid-template-columns: minmax(0, 1fr);
            gap: 13px
        }

        .co-measurement-field label {
            display: block;
            margin-bottom: 5px;
            color: #29435f;
            font-weight: 800
        }

        .co-measurement-field label small {
            color: #718096
        }

        .co-measurement-field .form-control {
            min-height: 44px;
            border-color: #cbd9e7;
            border-radius: 8px;
            background: #fff
        }

        .co-measurement-empty {
            padding: 18px;
            color: var(--muted);
            text-align: center
        }

        .co-grid-head,
        .co-grid-row {
            display: grid;
            grid-template-columns: minmax(230px, 2fr) minmax(105px, .8fr) minmax(95px, .65fr) minmax(115px, .8fr) minmax(150px, 1fr) 112px;
            gap: 8px;
            align-items: center
        }

        .co-grid-head {
            padding: 9px 10px;
            border-bottom: 1px solid #dbe5f0;
            color: #64748b;
            background: #f6f9fc;
            font-size: .72rem;
            font-weight: 850
        }

        .co-grid-row {
            padding: 9px 10px;
            border-bottom: 1px solid #edf1f6
        }

        .co-grid-row:last-child {
            border-bottom: 0
        }

        .co-grid-row[hidden] {
            display: none !important
        }

        .co-grid-row .form-control {
            height: 40px;
            min-height: 40px;
            padding: 6px 9px;
            border-radius: 7px;
            font-size: .82rem
        }

        .co-grid-row .co-suit-only:not([hidden]) {
            margin-top: 4px
        }

        .co-grid-row .co-cell-main {
            min-width: 0
        }

        .co-grid-row .co-cell-main strong {
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: .87rem
        }

        .co-grid-row .co-cell-main small {
            display: block;
            color: var(--muted);
            font-size: .7rem
        }

        .co-grid-row .co-cell-money {
            direction: ltr;
            text-align: right;
            font-weight: 800;
            white-space: nowrap
        }

        .co-grid-row .co-cell-note {
            overflow: hidden;
            color: var(--muted);
            font-size: .75rem;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .co-grid-actions {
            display: flex;
            flex-wrap: wrap;
            min-width: 0;
            align-items: center;
            justify-content: flex-start;
            gap: 6px
        }

        .co-grid-actions .co-print-action {
            max-width: 100%;
            white-space: normal;
            text-align: center;
            overflow-wrap: anywhere
        }

        .co-grid-actions .co-print-action i {
            flex-shrink: 0
        }

        @media(min-width:1101px) {
            .co-grid-actions .co-print-action {
                width: 100%
            }
        }

        .co-print-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            min-height: 34px;
            padding: 5px 8px;
            border: 1px solid #b9d1ef;
            border-radius: 7px;
            color: #1769e0 !important;
            background: #f5f9ff;
            font-size: .72rem;
            font-weight: 850;
            text-decoration: none !important;
            white-space: nowrap
        }

        .co-grid-save,
        .co-grid-cancel {
            width: 34px;
            height: 34px;
            display: grid;
            place-items: center;
            border: 1px solid #bdd3eb;
            border-radius: 7px;
            background: #fff
        }

        .co-grid-save {
            border-color: var(--blue);
            color: #fff;
            background: var(--blue)
        }

        .co-grid-cancel {
            color: #52677f
        }

        .co-grid-row.is-new {
            border: 1px solid #9fc5f3;
            border-radius: 10px;
            background: #f7fbff
        }

        .co-grid-row.is-new .form-control {
            border-color: #b9cee5
        }

        .co-grid-row.is-tailoring {
            background: #fcfefd
        }

        .co-row-status {
            display: inline-flex;
            margin-top: 3px;

            padding:2px 6px;border-radius:999px;color:#9a6500;background:#fff3d8;font-size:.65rem;font-weight:800}.co-row-status.is-confirmed{color:#147348;background:#e8f7ef}.co-add-row-button[aria-expanded="true"] {
                border-color: #9dbce3;
                color: #315f92 !important;
                background: #edf5ff
            }

            @media(max-width:1000px) {
                .co-main {
                    grid-template-columns: 1fr
                }

                .co-summary {
                    grid-template-columns: 1fr 1fr
                }

                .co-side {
                    grid-row: 1
                }
            }

            @media(max-width:1100px) {
                .co-grid-head {
                    display: none
                }

                .co-grid-row {
                    grid-template-columns: repeat(2, minmax(0, 1fr));
                    padding: 13px
                }

                .co-grid-row>*:before {
                    content: attr(data-label);
                    display: block;
                    margin-bottom: 3px;
                    color: #718096;
                    font-size: .67rem;
                    font-weight: 800
                }

                .co-grid-row .co-cell-main {
                    grid-column: 1/-1
                }

                .co-grid-actions {
                    grid-column: 1/-1
                }

                .co-grid-actions:before {
                    display: none
                }
            }

            @media(max-width:700px) {

                .co-head,
                .co-panel-head {
                    align-items: stretch;
                    flex-direction: column
                }

                .co-summary {
                    grid-template-columns: 1fr
                }

                .co-adds {
                    display: grid;
                    grid-template-columns: 1fr 1fr
                }

                .co-modal-grid,
                .co-measurement-context,
                .co-measurement-columns {
                    grid-template-columns: 1fr
                }

                .co-modal-grid .is-wide {
                    grid-column: auto
                }

                .co-grid-row {
                    grid-template-columns: 1fr
                }

                .co-grid-row .co-cell-main,
                .co-grid-actions {
                    grid-column: 1
                }
            }
    </style>
    <section class="main-content co-page">
        <div class="co-shell">
            <header class="co-head">
                <div class="co-title">
                    <h1>آرڈر {{ $counterOrder->displayNumber() }}</h1>
                    <p>{{ $counterOrder->customer?->name }} · {{ $orderScopeText }}@if ($counterOrder->serial_number)
                            · حوالہ {{ $counterOrder->reference }}
                        @endif
                    </p>
                </div><span class="co-status">{{ $statusLabels[$counterOrder->status] ?? $counterOrder->status }}</span>
            </header>
            <div id="co-live-alert" class="alert co-alert" role="status" hidden></div>
            @if (session('success'))
                <div class="alert alert-success co-alert">{{ session('success') }}</div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger co-alert"><strong>تبدیلی محفوظ نہیں ہوئی:</strong> {{ $errors->first() }}
                </div>
            @endif
            @if ($counterOrder->saleSession)
                <div class="co-mobile-source"><i class="fas fa-mobile-alt ml-1"></i> یہ آرڈر سیلز ایجنٹ
                    {{ $counterOrder->saleSession->agent?->name }} نے موبائل سے بھیجا تھا۔ قیمت، ادائیگی اور حتمی تصدیق
                    ایڈمن ڈیسک کے پاس ہے۔</div>
            @endif
            <div class="co-summary">
                <div><small>گاہک</small><strong>{{ $counterOrder->customer?->name }}</strong></div>
                <div><small>کل آرڈر</small><strong id="co-summary-subtotal" dir="ltr">Rs.
                        {{ number_format((float) $counterOrder->subtotal, 2) }}</strong></div>
                <div><small>وصول شدہ</small><strong id="co-summary-paid" dir="ltr">Rs.
                        {{ number_format((float) $counterOrder->paid_amount, 2) }}</strong></div>
                <div><small>بقایا</small><strong id="co-summary-balance" dir="ltr">Rs.
                        {{ number_format((float) $counterOrder->balance_amount, 2) }}</strong></div>
            </div>
            <div class="co-main">
                <section class="co-panel">
                    <div class="co-panel-head">
                        <div>
                            <h2>آرڈر کے آئٹمز</h2><small
                                class="text-muted">{{ $canAddCloth ? 'کپڑا اسی فہرست میں شامل یا تبدیل کریں؛ سلائی کی تفصیل الگ فارم میں کھلے گی۔' : 'سلائی کی تفصیل شامل یا تبدیل کرنے کے لیے فارم کھولیں۔' }}</small>
                        </div>
                        <div class="co-adds">
                            @if ($confirmedItems->isNotEmpty())
                                <a class="co-btn" target="_blank"
                                    href="{{ route('admin.counter-orders.print', $counterOrder) }}"><i
                                        class="fas fa-print"></i>
                                    {{ $canAddCloth && $canAddTailoring ? 'مشترکہ رسید' : 'آرڈر رسید' }}</a>
                                @endif @if (!$counterOrder->isClosed())
                                    @if ($canAddCloth)
                                        <button id="co-add-cloth-button" class="co-btn is-primary co-add-row-button"
                                            type="button" aria-expanded="{{ old('cloth_id') ? 'true' : 'false' }}"
                                            aria-controls="co-new-cloth-row"><i class="fas fa-plus"></i> کپڑا شامل
                                            کریں</button>
                                        @endif @if ($canAddTailoring)
                                            <button class="co-btn is-tailor" data-toggle="modal"
                                                data-target="#tailoringItemModal"><i class="fas fa-plus"></i> سلائی شامل
                                                کریں</button>
                                        @endif
                                    @endif
                        </div>
                    </div>
                    <div class="co-list">
                        <div class="co-grid-head" aria-hidden="true"><span>آئٹم</span><span>رنگ / تفصیل</span><span>میٹر /
                                تعداد</span><span>کل قیمت</span><span>نوٹ</span><span>رسید / عمل</span></div>
                        @if ($canAddCloth && !$counterOrder->isClosed())
                            <form id="co-new-cloth-row" class="co-grid-row co-cloth-form co-ajax-row-form is-new"
                                method="POST"
                                action="{{ route('admin.counter-orders.cloth-items.store', $counterOrder) }}"
                                data-old-color="{{ old('color') }}" @if (!old('cloth_id')) hidden @endif>@csrf
                                <div class="co-cell-main" data-label="آئٹم"><select id="co-cloth-select"
                                        class="form-control" name="cloth_id" aria-label="کپڑے کا سیٹ" required>
                                        <option value="">کپڑا منتخب کریں</option>
                                        @foreach ($cloths as $cloth)
                                            <option value="{{ $cloth->id }}"
                                                data-price="{{ $cloth->sellsPerSuit() ? $cloth->suit_sale_price : $cloth->sale_price }}"
                                                data-length="{{ $cloth->default_sale_length ?: 4.5 }}"
                                                data-basis="{{ $cloth->sale_price_basis }}"
                                                data-colors='@json($cloth->selectableColorNames())' @selected((int) old('cloth_id') === $cloth->id)>
                                                {{ $cloth->name }} · {{ $cloth->brand?->name }} ·
                                                {{ $cloth->type?->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div data-label="رنگ"><select id="co-cloth-color" class="form-control" name="color"
                                        aria-label="رنگ">
                                        <option value="">رنگ لاگو نہیں</option>
                                    </select></div>
                                <div data-label="میٹر / تعداد"><input id="co-cloth-length"
                                        class="form-control co-cloth-length" type="number" name="length"
                                        value="{{ old('length') }}" min="0.01" step="0.01" aria-label="لمبائی میٹر"
                                        placeholder="میٹر" required><input id="co-cloth-quantity"
                                        class="form-control co-cloth-quantity co-suit-only" type="number" name="quantity"
                                        value="{{ old('quantity', 1) }}" min="1" step="1"
                                        aria-label="سوٹ کی تعداد" hidden></div>
                                <div data-label="کل قیمت"><input id="co-cloth-price" class="form-control co-cloth-total"
                                        type="number" name="total_price" value="{{ old('total_price') }}" min="0"
                                        step="0.01" aria-label="کل قیمت" placeholder="کل قیمت" required></div>
                                <div data-label="نوٹ"><input id="co-cloth-note" class="form-control" name="note"
                                        value="{{ old('note') }}" maxlength="1000" aria-label="نوٹ"
                                        placeholder="اختیاری نوٹ"></div>
                                <div class="co-grid-actions"><button class="co-grid-save" type="submit"
                                        title="شامل کریں" aria-label="شامل کریں"><i
                                            class="fas fa-check"></i></button><button class="co-grid-cancel"
                                        type="button" data-inline-cancel="co-new-cloth-row" title="منسوخ"
                                        aria-label="منسوخ"><i class="fas fa-times"></i></button></div>
                            </form>
                        @endif
                        <div id="co-items-rows" style="display:contents">
                            @forelse($counterOrder->items as $item)
                                @include('counter-orders.partials.item-row', ['item' => $item])
                            @empty<div class="co-empty"><i class="fas fa-receipt"></i><strong>آرڈر ابھی خالی
                                        ہے</strong>
                                    <div>{{ $emptyOrderHint }}</div>
                                </div>
                            @endforelse
                        </div>
                    </div>
                </section>
                <aside class="co-side">
                    <section class="co-panel">
                        <div class="co-total">
                            <h2 class="h6 font-weight-bold mb-3">موجودہ خلاصہ</h2>
                            <div class="co-total-row"><span>تصدیق شدہ آئٹمز</span><strong
                                    id="co-confirmed-count">{{ $confirmedItems->count() }}</strong></div>
                            <div class="co-total-row"><span>نئے آئٹمز</span><strong
                                    id="co-draft-count">{{ $draftItems->count() }}</strong></div>
                            <div class="co-total-row is-main"><span>نئی رقم</span><strong id="co-draft-total"
                                    dir="ltr">Rs. {{ number_format($draftTotal, 2) }}</strong></div>
                        </div>
                        @if (!$counterOrder->isClosed() && $canManageAllDrafts)
                            <form id="co-confirm-form" class="co-confirm" method="POST"
                                action="{{ route('admin.counter-orders.confirm', $counterOrder) }}"
                                @if ($draftItems->isEmpty()) hidden @endif>@csrf<p class="co-help">
                                    {{ $confirmationHint }}</p>
                                <div class="form-group"><label>ابھی وصول رقم</label><input class="form-control"
                                        type="number" name="payment" min="0" max="{{ $draftTotal }}"
                                        step="0.01" value="{{ old('payment', 0) }}" required></div>
                                <div class="form-group"><label>ادائیگی کا طریقہ</label><select class="form-control"
                                        name="payment_method" required>
                                        @foreach ($paymentMethods as $value => $label)
                                            <option value="{{ $value }}" @selected(old('payment_method', 'cash') === $value)>
                                                {{ $label }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group"><label>حوالہ نمبر <small class="text-muted">(اگر لاگو
                                            ہو)</small></label><input class="form-control" name="payment_reference"
                                        value="{{ old('payment_reference') }}"></div><button
                                    class="co-btn is-primary w-100" type="submit">نئے آئٹمز کی تصدیق کریں</button>
                            </form>
                        @endif
                    </section>
                    @if (!$counterOrder->isClosed() && $draftItems->isEmpty() && $confirmedItems->isNotEmpty() && $canManageAllItems)
                        <section class="co-panel co-close">
                            <p class="co-help">{{ $moreItemsHint }} صرف معاملہ مکمل ہونے پر آرڈر بند کریں۔</p>
                            <form method="POST" action="{{ route('admin.counter-orders.close', $counterOrder) }}">
                                @csrf<button class="co-btn w-100" type="submit">آرڈر بند کریں</button></form>
                        </section>
                    @endif
                </aside>
            </div>
        </div>
    </section>

    @if ($canAddTailoring && !$counterOrder->isClosed())
        <div class="modal fade" id="tailoringItemModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <form class="co-modal-form co-tailoring-form" method="POST"
                        action="{{ route('admin.counter-orders.tailoring-items.store', $counterOrder) }}">@csrf
                        <div class="modal-header">
                            <h2 class="modal-title h5">سلائی شامل کریں</h2><button class="close" type="button"
                                data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="co-modal-grid">
                                <div><label class="co-field-label" for="co-profile"><span>ناپ کس کا ہے؟</span><button
                                            id="co-measurement-link" class="co-measurement-link" type="button"><i
                                                class="fas fa-ruler-combined ml-1"></i> ناپ دیکھیں / تبدیل
                                            کریں</button></label><select id="co-profile" class="form-control"
                                        name="measurement_profile_id" required>
                                        @foreach ($profiles as $profile)
                                            <option value="{{ $profile->id }}"
                                                data-measurement-url="{{ route('admin.counter-orders.measurements.edit', [$counterOrder, $profile]) }}"
                                                data-template-ids="{{ implode(',', $profileTemplateIds->get($profile->id, [])) }}"
                                                @selected((int) $selectedProfileId === $profile->id)>{{ $profile->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div><label for="co-template">لباس / محفوظ پیمائش</label><select id="co-template"
                                        class="form-control" name="measurement_template_id" required>
                                        @foreach ($templates as $template)
                                            <option value="{{ $template->id }}" data-template-id="{{ $template->id }}">
                                                {{ $template->name }}</option>
                                        @endforeach
                                    </select>
                                    <small class="co-template-hint form-text text-muted"></small>
                                </div>
                                <div><label for="co-suit-quantity">کتنے سوٹ سلنے ہیں؟</label><input id="co-suit-quantity"
                                        class="form-control" type="number" name="quantity" value="1"
                                        min="1" required></div>
                                <div><label for="co-tailoring-price">گاہک سے فی سوٹ سلائی رقم</label><input
                                        id="co-tailoring-price" class="form-control" type="number" name="unit_price"
                                        min="0" step="0.01" required></div>
                                <div class="is-wide co-calculated"><span>کل سلائی رقم</span><strong
                                        id="co-tailoring-total" dir="ltr">Rs. 0.00</strong></div>

                                <div>
                                    <label for="co-tailor">درزی منتخب کریں</label>
                                    <select id="co-tailor" class="form-control" name="tailor_id">
                                        <option value="">درزی منتخب کریں</option>
                                        @foreach ($tailors as $tailor)
                                            <option value="{{ $tailor->id }}">
                                                {{ $tailor->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div>
                                    <label for="co-tailor-rate">سلائی کی شرح منتخب کریں</label>
                                    <select
                                        id="co-tailor-rate"
                                        class="form-control"
                                        name="tailor_price"
                                        data-rate-url="{{ route('admin.counter-orders.tailors.rates', ['tailorId' => '__ID__']) }}"
                                        disabled
                                    >
                                        <option value="">پہلے درزی منتخب کریں</option>
                                    </select>
                                </div>
                                <div class="is-wide"><label for="co-due-date">مکمل کرنے کی تاریخ</label><input
                                        id="co-due-date" class="form-control" type="date" name="due_date"
                                        min="{{ now()->toDateString() }}" required></div>
                                <div class="is-wide"><label for="co-tailoring-note">خصوصی سلائی ہدایات <small
                                            class="text-muted">(اختیاری)</small></label>
                                    <textarea id="co-tailoring-note" class="form-control" name="note" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer"><button class="co-btn" type="button"
                                data-dismiss="modal">منسوخ</button><button class="co-btn is-tailor" type="submit">آرڈر
                                میں شامل کریں</button></div>
                    </form>
                </div>
            </div>
        </div>
    @endif

    @if ($canAddTailoring && !$counterOrder->isClosed())
        <div class="modal fade co-measurement-modal" id="measurementProfileModal" tabindex="-1" role="dialog"
            aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title h5">منتخب فرد کی پیمائش</h2><button class="close" type="button"
                            data-dismiss="modal">&times;</button>
                    </div>
                    <div id="co-measurement-modal-body" class="modal-body">
                        <div class="co-measurement-loading"><i class="fas fa-circle-notch fa-spin ml-1"></i> پیمائش لوڈ ہو
                            رہی ہے…</div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @foreach ($draftItems as $item)
        @if ($item->type === 'tailoring' && $canAddTailoring)
            <div class="modal fade" id="editItemModal{{ $item->id }}" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <form class="co-modal-form co-tailoring-form" method="POST"
                            action="{{ route('admin.counter-orders.items.update', [$counterOrder, $item]) }}">@csrf
                            @method('PATCH')
                            <div class="modal-header">
                                <h2 class="modal-title h5">سلائی تبدیل کریں</h2><button class="close" type="button"
                                    data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div class="co-modal-grid">
                                    <div><label class="co-field-label" for="edit-profile-{{ $item->id }}"><span>ناپ
                                                کس کا ہے؟</span><button class="co-measurement-link" type="button"><i
                                                    class="fas fa-ruler-combined ml-1"></i> ناپ دیکھیں / تبدیل
                                                کریں</button></label><select id="edit-profile-{{ $item->id }}"
                                            class="form-control co-profile" name="measurement_profile_id" required>
                                            @foreach ($profiles as $profile)
                                                <option value="{{ $profile->id }}"
                                                    data-measurement-url="{{ route('admin.counter-orders.measurements.edit', [$counterOrder, $profile]) }}"
                                                    data-template-ids="{{ implode(',', $profileTemplateIds->get($profile->id, [])) }}"
                                                    @selected($item->measurement_profile_id === $profile->id)>{{ $profile->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div><label for="edit-template-{{ $item->id }}">لباس / محفوظ پیمائش</label><select
                                            id="edit-template-{{ $item->id }}" class="form-control co-template"
                                            name="measurement_template_id"
                                            data-existing-template-id="{{ $item->measurement_template_id }}" required>
                                            @foreach ($templates as $template)
                                                <option value="{{ $template->id }}"
                                                    data-template-id="{{ $template->id }}" @selected($item->measurement_template_id === $template->id)>
                                                    {{ $template->name }}</option>
                                            @endforeach
                                        </select><small class="co-template-hint form-text text-muted"></small></div>
                                    <div><label for="edit-tailor-quantity-{{ $item->id }}">کتنے سوٹ سلنے
                                            ہیں؟</label><input id="edit-tailor-quantity-{{ $item->id }}"
                                            class="form-control co-tailoring-quantity" type="number" name="quantity"
                                            value="{{ (int) $item->quantity }}" min="1" required></div>
                                    <div><label for="edit-tailor-price-{{ $item->id }}">گاہک سے فی سوٹ سلائی
                                            رقم</label><input id="edit-tailor-price-{{ $item->id }}"
                                            class="form-control co-tailoring-price" type="number" name="unit_price"
                                            value="{{ $item->unit_price }}" min="0" step="0.01" required>
                                    </div>
                                    <div class="is-wide co-calculated"><span>کل سلائی رقم</span><strong
                                            class="co-tailoring-total" dir="ltr">Rs.
                                            {{ number_format((float) $item->line_total, 2) }}</strong></div>
                                    <div class="is-wide"><label for="edit-due-{{ $item->id }}">مکمل کرنے کی
                                            تاریخ</label><input id="edit-due-{{ $item->id }}" class="form-control"
                                            type="date" name="due_date"
                                            value="{{ $item->due_date?->toDateString() }}"
                                            min="{{ now()->toDateString() }}" required></div>
                                    <div class="is-wide"><label for="edit-tailor-note-{{ $item->id }}">خصوصی سلائی
                                            ہدایات <small class="text-muted">(اختیاری)</small></label>
                                        <textarea id="edit-tailor-note-{{ $item->id }}" class="form-control" name="note" rows="2">{{ $item->note }}</textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer"><button class="co-btn" type="button"
                                    data-dismiss="modal">منسوخ</button><button class="co-btn is-tailor"
                                    type="submit">تبدیلی محفوظ کریں</button></div>
                        </form>
                    </div>
                </div>
            </div>
        @endif
    @endforeach

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var cloth = document.getElementById('co-cloth-select'),
                    color = document.getElementById('co-cloth-color'),
                    price = document.getElementById('co-cloth-price'),
                    length = document.getElementById('co-cloth-length');

                function closeInlineEditors(exceptId) {
                    document.querySelectorAll('.co-grid-row.is-new').forEach(function(editor) {
                        if (editor.id !== exceptId) {
                            editor.hidden = true;
                            var article = editor.closest('[data-order-item]');
                            if (article) {
                                var display = article.querySelector('[data-display-row]');
                                if (display) display.hidden = false;
                            }
                        }
                    });
                    document.querySelectorAll('[data-inline-edit]').forEach(function(button) {
                        button.setAttribute('aria-expanded', button.dataset.inlineEdit === exceptId ? 'true' :
                            'false')
                    });
                    var add = document.getElementById('co-add-cloth-button');
                    if (add) add.setAttribute('aria-expanded', exceptId === 'co-new-cloth-row' ? 'true' : 'false');
                }
                var addButton = document.getElementById('co-add-cloth-button');
                if (addButton) {
                    addButton.addEventListener('click', function() {
                        var row = document.getElementById('co-new-cloth-row');
                        closeInlineEditors(row.id);
                        row.hidden = false;
                        this.setAttribute('aria-expanded', 'true');
                        var select = row.querySelector('select[name="cloth_id"]');
                        if (select) select.focus();
                    });
                }
                document.addEventListener('click', function(event) {
                    var editButton = event.target.closest('[data-inline-edit]');
                    if (editButton) {
                        var editor = document.getElementById(editButton.dataset.inlineEdit);
                        closeInlineEditors(editor.id);
                        var article = editor.closest('[data-order-item]'),
                            display = article && article.querySelector('[data-display-row]');
                        if (display) display.hidden = true;
                        editor.hidden = false;
                        editButton.setAttribute('aria-expanded', 'true');
                        var field = editor.querySelector('select,input');
                        if (field) field.focus();
                        return;
                    }
                    var cancelButton = event.target.closest('[data-inline-cancel]');
                    if (cancelButton) {
                        closeInlineEditors(null);
                    }
                });
                if (cloth) {
                    var updateClothFields = function(preserveValues) {
                        var o = cloth.options[cloth.selectedIndex],
                            form = cloth.closest('.co-cloth-form'),
                            colors = [],
                            unitPrice = Number(o.dataset.price || 0),
                            defaultLength = Number(o.dataset.length || 4.5),
                            quantity = form.querySelector('.co-cloth-quantity'),
                            suitOnly = form.querySelector('.co-suit-only'),
                            oldColor = preserveValues ? (form.dataset.oldColor || '') : '';
                        try {
                            colors = JSON.parse(o.dataset.colors || '[]')
                        } catch (e) {}
                        color.innerHTML = '';
                        if (colors.length) {
                            colors.forEach(function(c, index) {
                                var x = document.createElement('option');
                                x.value = c;
                                x.textContent = c;
                                x.selected = oldColor ? oldColor === c : index === 0;
                                color.appendChild(x)
                            });
                        } else {
                            var placeholder = document.createElement('option');
                            placeholder.value = '';
                            placeholder.textContent = 'رنگ لاگو نہیں';
                            color.appendChild(placeholder);
                        }
                        color.required = false;
                        color.disabled = !cloth.value;
                        suitOnly.hidden = o.dataset.basis !== 'per_suit';
                        form.dataset.basis = o.dataset.basis || 'per_meter';
                        form.dataset.unitPrice = unitPrice;
                        if (!preserveValues) {
                            length.value = cloth.value ? defaultLength.toFixed(2) : '';
                            if (quantity) quantity.value = 1;
                            price.value = cloth.value && unitPrice ? (o.dataset.basis === 'per_suit' ? unitPrice :
                                unitPrice * defaultLength).toFixed(2) : '';
                        }
                    };
                    cloth.addEventListener('change', function() {
                        updateClothFields(false);
                    });
                    if (cloth.value) updateClothFields(true);
                    else color.disabled = true;
                }

                $(document).on('change', '#co-tailor', function () {
                    var tailorId = $(this).val();
                    var rateSelect = $('#co-tailor-rate');

                    rateSelect
                        .empty()
                        .append($('<option>', {
                            value: '',
                            text: tailorId
                                ? 'شرح لوڈ ہو رہی ہے...'
                                : 'پہلے درزی منتخب کریں'
                        }))
                        .prop('disabled', true);

                    if (!tailorId) {
                        return;
                    }

                    var url = rateSelect
                        .data('rate-url')
                        .replace('__ID__', encodeURIComponent(tailorId));

                    $.ajax({
                        url: url,
                        method: 'GET',
                        dataType: 'json',

                        success: function (rates) {
                            rateSelect.empty();

                            rateSelect.append($('<option>', {
                                value: '',
                                text: 'سلائی کی شرح منتخب کریں'
                            }));

                            $.each(rates, function (_, rate) {
                                rateSelect.append($('<option>', {
                                    value: rate.rateValue,
                                    text: rate.rateName + ' — Rs. ' +
                                        Number(rate.price).toFixed(2)
                                }));
                            });

                            if (rates.length === 0) {
                                rateSelect.empty().append($('<option>', {
                                    value: '',
                                    text: 'اس درزی کے لیے کوئی شرح موجود نہیں'
                                }));
                            }

                            rateSelect.prop('disabled', rates.length === 0);

                            // console.log('Fetched tailor rates:', rates);
                        },

                        error: function (xhr) {
                            console.error('Failed to fetch tailor rates:', xhr.status, xhr.responseText);

                            rateSelect
                                .empty()
                                .append($('<option>', {
                                    value: '',
                                    text: 'شرح لوڈ نہیں ہو سکی'
                                }))
                                .prop('disabled', true);
                        }
                    });
                });

                function bindClothForm(form) {
                    if (form.dataset.bound === 'true') return;
                    form.dataset.bound = 'true';
                    var quantity = form.querySelector('.co-cloth-quantity'),
                        clothLength = form.querySelector('.co-cloth-length'),
                        total = form.querySelector('.co-cloth-total');

                    function recalculate() {
                        var unit = Number(form.dataset.unitPrice || 0);
                        if (!unit || !total) return;
                        total.value = (unit * (form.dataset.basis === 'per_suit' ? Math.max(1, Number(quantity &&
                            quantity.value || 1)) : Math.max(0, Number(clothLength && clothLength.value ||
                            0)))).toFixed(2);
                    }
                    if (quantity) quantity.addEventListener('input', recalculate);
                    if (clothLength) clothLength.addEventListener('input', recalculate);
                }
                document.querySelectorAll('.co-cloth-form').forEach(bindClothForm);

                function money(value) {
                    return 'Rs. ' + Number(value || 0).toLocaleString('en-PK', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    });
                }

                function updateSummary(summary) {
                    document.getElementById('co-summary-subtotal').textContent = money(summary.subtotal);
                    document.getElementById('co-summary-paid').textContent = money(summary.paid);
                    document.getElementById('co-summary-balance').textContent = money(summary.balance);
                    document.getElementById('co-confirmed-count').textContent = summary.confirmed_count;
                    document.getElementById('co-draft-count').textContent = summary.draft_count;
                    document.getElementById('co-draft-total').textContent = money(summary.draft_total);
                    var confirmForm = document.getElementById('co-confirm-form');
                    if (confirmForm) {
                        confirmForm.hidden = summary.draft_count < 1;
                        var payment = confirmForm.querySelector('[name="payment"]');
                        if (payment) payment.max = summary.draft_total;
                    }
                }

                function showLiveMessage(message, isError) {
                    var alert = document.getElementById('co-live-alert');
                    alert.hidden = false;
                    alert.className = 'alert co-alert ' + (isError ? 'alert-danger' : 'alert-success');
                    alert.textContent = message;
                }
                document.addEventListener('submit', async function(event) {
                    var form = event.target.closest('.co-ajax-row-form');
                    if (!form) return;
                    event.preventDefault();
                    var submit = form.querySelector('[type="submit"]');
                    if (submit) submit.disabled = true;
                    try {
                        var response = await fetch(form.action, {
                            method: 'POST',
                            body: new FormData(form),
                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        var data = await response.json();
                        if (!response.ok) {
                            var errors = data.errors || {},
                                first = Object.keys(errors).length ? errors[Object.keys(errors)[0]][0] : (
                                    data.message || 'تبدیلی محفوظ نہیں ہوئی۔');
                            showLiveMessage(first, true);
                            return;
                        }
                        var holder = document.createElement('div');
                        holder.innerHTML = data.row_html.trim();
                        var article = holder.firstElementChild,
                            existing = document.querySelector('[data-order-item="' + data.item_id + '"]'),
                            rows = document.getElementById('co-items-rows');
                        if (existing) existing.replaceWith(article);
                        else rows.appendChild(article);
                        var empty = rows.querySelector('.co-empty');
                        if (empty) empty.remove();
                        bindClothForm(article.querySelector('.co-cloth-form'));
                        updateSummary(data.summary);
                        if (form.id === 'co-new-cloth-row') {
                            form.reset();
                            color.innerHTML = '<option value="">رنگ لاگو نہیں</option>';
                            color.disabled = true;
                            length.value = '';
                            price.value = '';
                        }
                        closeInlineEditors(null);
                        showLiveMessage(data.message, false);
                    } catch (error) {
                        showLiveMessage('تبدیلی محفوظ نہیں ہوئی۔ دوبارہ کوشش کریں۔', true);
                    } finally {
                        if (submit) submit.disabled = false;
                    }
                });
                document.querySelectorAll('.co-tailoring-form').forEach(function(form) {
                    var profile = form.querySelector('.co-profile') || document.getElementById('co-profile'),
                        template = form.querySelector('.co-template') || document.getElementById('co-template'),
                        measurementLink = form.querySelector('.co-measurement-link'),
                        templateHint = form.querySelector('.co-template-hint'),
                        suitQuantity = form.querySelector('.co-tailoring-quantity') || document.getElementById(
                            'co-suit-quantity'),
                        tailoringPrice = form.querySelector('.co-tailoring-price') || document.getElementById(
                            'co-tailoring-price'),
                        tailoringTotal = form.querySelector('.co-tailoring-total') || document.getElementById(
                            'co-tailoring-total');

                    function filterTemplates() {
                        if (!profile || !template) return;
                        var selectedProfile = profile.options[profile.selectedIndex],
                            ids = (selectedProfile.dataset.templateIds || '').split(',').filter(Boolean),
                            existing = template.dataset.existingTemplateId || '',
                            firstAvailable = null;
                        Array.from(template.options).forEach(function(option) {
                            var allowed = ids.indexOf(String(option.value)) !== -1 || String(option
                                .value) === String(existing);
                            option.hidden = !allowed;
                            option.disabled = !allowed;
                            if (allowed && !firstAvailable) firstAvailable = option;
                        });
                        if (!template.selectedOptions.length || template.selectedOptions[0].disabled) {
                            template.value = firstAvailable ? firstAvailable.value : '';
                        }
                        var hasTemplate = Boolean(template.value) && template.selectedOptions.length && !
                            template.selectedOptions[0].disabled;
                        template.disabled = !hasTemplate;
                        if (measurementLink) measurementLink.disabled = !hasTemplate;
                        if (templateHint) templateHint.textContent = hasTemplate ?
                            'صرف اس فرد کی محفوظ پیمائش دکھائی گئی ہے۔' :
                            'اس فرد کی کوئی محفوظ پیمائش موجود نہیں۔ پہلے گاہک کے پروفائل میں پیمائش شامل کریں۔';
                        updateMeasurementLink();
                    }

                    function updateMeasurementLink() {
                        if (!profile || !template || !measurementLink) return;
                        var o = profile.options[profile.selectedIndex],
                            base = o.dataset.measurementUrl || '#';
                        measurementLink.dataset.url = template.disabled ? '#' : base + (base.indexOf('?') === -
                            1 ? '?' : '&') + 'measurement_template_id=' + encodeURIComponent(template.value);
                    }

                    function updateTailoringTotal() {
                        if (!suitQuantity || !tailoringPrice || !tailoringTotal) return;
                        var total = Math.max(0, Number(suitQuantity.value || 0)) * Math.max(0, Number(
                            tailoringPrice.value || 0));
                        tailoringTotal.textContent = 'Rs. ' + total.toLocaleString('en-PK', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        });
                    }
                    if (profile && template) {
                        profile.addEventListener('change', filterTemplates);
                        template.addEventListener('change', updateMeasurementLink);
                        filterTemplates();
                    }
                    if (suitQuantity && tailoringPrice) {
                        suitQuantity.addEventListener('input', updateTailoringTotal);
                        tailoringPrice.addEventListener('input', updateTailoringTotal);
                        updateTailoringTotal();
                    }
                });

                var measurementModal = document.getElementById('measurementProfileModal'),
                    measurementBody = document.getElementById('co-measurement-modal-body'),
                    returnTailoringModal = null;
                async function loadMeasurementEditor(button) {
                    if (!measurementModal || !measurementBody) return;
                    var url = button.dataset.url;
                    if (!url || url === '#') {
                        showLiveMessage('پہلے فرد اور لباس منتخب کریں۔', true);
                        return;
                    }
                    returnTailoringModal = button.closest('.modal');
                    measurementBody.innerHTML =
                        '<div class="co-measurement-loading"><i class="fas fa-circle-notch fa-spin ml-1"></i> پیمائش لوڈ ہو رہی ہے…</div>';
                    var openEditor = function() {
                        window.jQuery(measurementModal).modal('show');
                    };
                    if (returnTailoringModal) {
                        window.jQuery(returnTailoringModal).one('hidden.bs.modal', openEditor).modal('hide');
                    } else {
                        openEditor();
                    }
                    try {
                        var response = await fetch(url, {
                            headers: {
                                'Accept': 'text/html',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        if (!response.ok) throw new Error('load');
                        measurementBody.innerHTML = await response.text();
                    } catch (error) {
                        measurementBody.innerHTML =
                            '<div class="alert alert-danger mb-0">پیمائش لوڈ نہیں ہو سکی۔ دوبارہ کوشش کریں۔</div>';
                    }
                }
                document.addEventListener('click', function(event) {
                    var measurementButton = event.target.closest('.co-measurement-link');
                    if (measurementButton) {
                        event.preventDefault();
                        loadMeasurementEditor(measurementButton);
                    }
                });
                if (measurementModal) {
                    window.jQuery(measurementModal).on('hidden.bs.modal', function() {
                        if (returnTailoringModal) {
                            var target = returnTailoringModal;
                            returnTailoringModal = null;
                            window.jQuery(target).modal('show');
                        }
                    });
                }
                document.addEventListener('submit', async function(event) {
                    var form = event.target.closest('#co-measurement-editor-form');
                    if (!form) return;
                    event.preventDefault();
                    var submit = form.querySelector('[type="submit"]'),
                        errors = document.getElementById('co-measurement-errors');
                    if (submit) submit.disabled = true;
                    if (errors) {
                        errors.hidden = true;
                        errors.innerHTML = '';
                    }
                    try {
                        var response = await fetch(form.action, {
                            method: 'POST',
                            body: new FormData(form),
                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        var data = await response.json();
                        if (!response.ok) {
                            var messages = [];
                            Object.keys(data.errors || {}).forEach(function(key) {
                                messages = messages.concat(data.errors[key]);
                            });
                            if (!messages.length) messages.push(data.message || 'پیمائش محفوظ نہیں ہوئی۔');
                            if (errors) {
                                errors.innerHTML =
                                    '<strong>پیمائش محفوظ نہیں ہوئی:</strong><ul class="mb-0 mt-2">' +
                                    messages.map(function(message) {
                                        return '<li>' + String(message).replace(/[&<>"']/g, function(
                                            char) {
                                            return {
                                                '&': '&amp;',
                                                '<': '&lt;',
                                                '>': '&gt;',
                                                '"': '&quot;',
                                                "'": '&#039;'
                                            } [char];
                                        }) + '</li>';
                                    }).join('') + '</ul>';
                                errors.hidden = false;
                            }
                            return;
                        }
                        showLiveMessage(data.message, false);
                        window.jQuery(measurementModal).modal('hide');
                    } catch (error) {
                        if (errors) {
                            errors.textContent = 'پیمائش محفوظ نہیں ہوئی۔ دوبارہ کوشش کریں۔';
                            errors.hidden = false;
                        }
                    } finally {
                        if (submit) submit.disabled = false;
                    }
                });
            });
        </script>
    @endpush
@endsection
