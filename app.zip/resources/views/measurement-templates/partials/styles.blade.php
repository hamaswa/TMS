<style>
    .template-page{background:#f4f7fa;min-height:calc(100vh - 70px)}
    .template-hero{background:linear-gradient(135deg,#102a43,#1769aa);color:#fff;border-radius:22px;padding:1.7rem 2rem;box-shadow:0 14px 34px rgba(16,42,67,.16)}
    .template-hero h1{color:#fff!important}.template-hero p{color:rgba(255,255,255,.82)}.template-hero-actions{display:flex;gap:.65rem;flex-wrap:wrap}
    .template-card{border:0;border-radius:18px;box-shadow:0 9px 25px rgba(31,45,61,.08);overflow:hidden}.template-inactive{opacity:.62}
    .template-count{background:#edf5fb;color:#1769aa;border-radius:999px;padding:.35rem .65rem;font-weight:700;white-space:nowrap}
    .template-summary{display:grid;grid-template-columns:1fr 1fr;gap:.55rem}.template-summary span{display:flex;align-items:center;gap:.45rem;background:#f5f8fb;border-radius:10px;padding:.55rem;color:#526575}.template-summary i{color:#1769aa}.template-summary strong{color:#102a43}
    .empty-state{display:flex;flex-direction:column;align-items:center;text-align:center;color:#718096;padding:3rem}.empty-state>i{font-size:2.5rem;color:#8aadd0;margin-bottom:.8rem}.empty-state strong{color:#28445f}
    .builder-head{display:flex;align-items:center;justify-content:space-between;gap:1rem}.builder-back{font-weight:700}.builder-section-title{display:flex;align-items:flex-start;gap:.8rem;margin-bottom:1.25rem}.builder-section-title>span{display:grid;place-items:center;min-width:34px;height:34px;border-radius:10px;background:#e8f2ff;color:#1769aa;font-weight:800}.builder-section-title h2{font-size:1.12rem;font-weight:800;margin:0 0 .2rem}.builder-section-title p{color:#718096;margin:0}
    .field-options{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:.65rem}.field-choice{position:relative;display:flex;align-items:center;gap:.65rem;border:1px solid #dfe7f0;border-radius:13px;padding:.8rem;background:#fff;margin:0;cursor:pointer;transition:.18s ease}.field-choice:hover{border-color:#8dbaf0;transform:translateY(-1px)}.field-choice input{position:absolute;opacity:0}.field-choice:has(input:checked){border-color:#2d79da;background:#edf6ff;box-shadow:0 0 0 2px rgba(45,121,218,.08)}.field-choice-icon{display:grid;place-items:center;min-width:30px;height:30px;border-radius:9px;background:#edf2f7;color:#8a9bad}.field-choice:has(input:checked) .field-choice-icon{background:#2d79da;color:#fff}.field-choice strong,.field-choice small{display:block}.field-choice small{color:#718096;margin-top:.1rem}
    .template-default{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;border:1px solid #cfe0ed;background:#eef7fd;border-radius:12px;padding:.7rem .9rem;margin:0}.template-default span{color:#5f7386}.builder-empty{border:1px dashed #bdd0e0;border-radius:13px;padding:1rem;text-align:center;color:#718096}
    .template-system-field{position:relative}.template-system-field .field-choice{padding-left:2.8rem}.template-system-field .template-field-edit{z-index:2}.template-custom-field{position:relative}.template-custom-field .field-choice{padding-left:2.8rem;cursor:default}.template-field-edit{position:absolute;left:.55rem;top:50%;display:grid;place-items:center;width:30px;height:30px;padding:0;border:1px solid #cfe0ed;border-radius:8px;background:#fff;color:#1769aa;transform:translateY(-50%)}.template-field-modal .modal-content{border:0;border-radius:17px;overflow:hidden}.template-field-modal .modal-header{align-items:center;background:#f7faff}.template-field-modal label{font-weight:700;color:#334e68}.template-check{display:flex;align-items:center;gap:.55rem;padding:.7rem .85rem;border:1px solid #dbe5ef;border-radius:10px;background:#f9fbfd;cursor:pointer}.template-check input{width:18px;height:18px}.template-option-entry{display:flex;gap:.55rem}.template-option-entry .form-control{min-width:0}.template-option-add{white-space:nowrap}.template-option-list{display:flex;flex-wrap:wrap;align-items:flex-start;gap:.6rem;max-width:100%}.template-option-list .template-option-chip{flex:0 1 auto;max-width:100%;min-width:0;white-space:normal;overflow-wrap:anywhere;line-height:1.5;vertical-align:top}.template-option-list .template-option-chip .template-option-name{display:inline-block;width:auto;height:auto;min-width:0;max-width:100%;white-space:normal;overflow-wrap:anywhere;text-align:right;line-height:1.5;border:0;border-radius:0;padding:0;background:transparent;color:#28445f;font-weight:700;cursor:text}.template-option-list .template-option-chip>button:not(.template-option-name){flex:0 0 22px}.template-option-chip{display:inline-flex;align-items:center;gap:.45rem;padding:.42rem .65rem;border:1px solid #cfe0ed;border-radius:999px;background:#f3f8fd;color:#28445f;font-weight:700}.template-option-chip button{display:grid;place-items:center;width:22px;height:22px;padding:0;border:0;border-radius:50%;background:#fff;color:#b23b48}.template-option-empty{margin-top:.7rem;padding:.65rem;border:1px dashed #ccd9e5;border-radius:10px;color:#8292a2;text-align:center}.template-option-list:not(:empty)+.template-option-empty{display:none}
    .builder-preview{position:sticky;top:90px}.preview-label{display:inline-block;background:#e8f2ff;color:#1769aa;border-radius:999px;padding:.3rem .65rem;font-size:.8rem;font-weight:700}.column-mode{display:grid;grid-template-columns:1fr 1fr;gap:.45rem;margin-bottom:.85rem}.column-mode label{margin:0;cursor:pointer}.column-mode input{position:absolute;opacity:0}.column-mode span{display:flex;align-items:center;justify-content:center;gap:.4rem;border:1px solid #d6e1ec;border-radius:10px;padding:.55rem;background:#fff;color:#526575;font-weight:700}.column-mode input:checked+span{border-color:#2d79da;background:#edf6ff;color:#1769aa;box-shadow:0 0 0 2px rgba(45,121,218,.08)}.layout-preview{display:grid;grid-template-columns:1fr 1fr;gap:.65rem}.layout-preview.is-one-column{grid-template-columns:1fr}.layout-preview.is-one-column .layout-lane[data-column="left"]{display:none}.lane-title{display:block;margin-bottom:.45rem;color:#526575}.layout-preview.is-one-column .layout-lane[data-column="right"] .lane-title{font-size:0}.layout-preview.is-one-column .layout-lane[data-column="right"] .lane-title:after{content:'واحد کالم';font-size:.95rem}.preview-list{display:grid;gap:.5rem;min-height:54px;max-height:55vh;overflow:auto;border:1px dashed #d8e2ec;border-radius:11px;padding:.4rem}.preview-item{display:grid;grid-template-columns:28px minmax(0,1fr) 30px;gap:.35rem;align-items:center;padding:.5rem;border:1px solid #e2eaf2;border-radius:9px;background:#fff;color:#28445f;cursor:grab;box-shadow:0 2px 7px rgba(31,45,61,.05)}.preview-item.is-dragging{opacity:.45}.preview-item-label{font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.drag-handle,.move-column{display:grid;place-items:center;width:28px;height:28px;padding:0;border:0;border-radius:7px;background:#eef4fa;color:#66809a;cursor:grab}.move-column{background:#e8f2ff;color:#1769aa;cursor:pointer}.drag-handle i,.move-column i{color:inherit}.preview-empty{border:1px dashed #ccd9e5;border-radius:12px;padding:1rem;text-align:center;color:#8292a2}
    details summary{cursor:pointer;list-style:none}details summary::-webkit-details-marker{display:none}.saved-profile,.new-profile{border:1px solid #d7e4dc;background:#fff;border-radius:11px;overflow:hidden}.saved-profile>summary,.new-profile>summary{display:flex;justify-content:space-between;padding:.8rem 1rem;color:#17633c}.profile-measurement-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:.8rem}
    @media(max-width:1199px){.builder-preview{position:static;margin-bottom:1rem}}@media(max-width:767px){.template-hero{padding:1.3rem}.builder-head{align-items:flex-start;flex-direction:column}.template-summary,.layout-preview{grid-template-columns:1fr}.field-options{grid-template-columns:1fr}}
    
/* Modern Urdu keyboard */
.mf-urdu-wrap {
    position: relative;
    width: 100%;
}

.mf-urdu-keyboard {
    display: none;
    position: relative;
    width: 100%;
    margin-top: 12px;
    padding: 16px;
    background: #f8faff;
    border: 1px solid #dce5f5;
    border-radius: 16px;
    box-shadow: 0 8px 24px rgba(30, 64, 175, 0.09);
    direction: rtl;
    z-index: 20;
}

.mf-urdu-keyboard.is-open {
    display: block;
    animation: urduKeyboardIn 0.18s ease-out;
}

@keyframes urduKeyboardIn {
    from {
        opacity: 0;
        transform: translateY(-5px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.mf-urdu-keyboard-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding-bottom: 12px;
    margin-bottom: 14px;
    border-bottom: 1px solid #e3eaf5;
    color: #253b67;
    font-size: 15px;
    font-weight: 700;
}

.mf-urdu-close {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border: 0;
    border-radius: 9px;
    background: #e9eef8;
    color: #40516f;
    font-size: 23px;
    cursor: pointer;
}

.mf-urdu-close:hover {
    background: #fee2e2;
    color: #dc2626;
}

.mf-urdu-keys {
    display: grid;
    grid-template-columns: repeat(7, minmax(0, 1fr));
    gap: 8px;
}

.mf-urdu-key {
    min-width: 0;
    min-height: 43px;
    padding: 6px 2px;
    border: 1px solid #dbe4f2;
    border-radius: 10px;
    background: #fff;
    color: #243b66;
    font-family: inherit;
    font-size: 21px;
    font-weight: 500;
    line-height: 1.3;
    cursor: pointer;
    box-shadow: 0 2px 3px rgba(15, 23, 42, 0.035);
    transition: background 0.15s ease, border-color 0.15s ease,
                transform 0.15s ease, color 0.15s ease;
}

.mf-urdu-key:hover {
    background: #e8efff;
    border-color: #8eafff;
    color: #244fc5;
    transform: translateY(-1px);
}

.mf-urdu-key:active {
    transform: scale(0.96);
    background: #dbe7ff;
}

.mf-urdu-actions {
    display: grid;
    grid-template-columns: 1fr 1.2fr 1fr;
    gap: 8px;
    margin-top: 14px;
}

.mf-urdu-action {
    min-height: 40px;
    padding: 8px 10px;
    border: 1px solid #d7e1f0;
    border-radius: 10px;
    background: #fff;
    color: #344563;
    font-family: inherit;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s ease;
}

.mf-urdu-action:hover {
    background: #edf3ff;
    border-color: #9db7f5;
}

.mf-urdu-action.is-space {
    background: #e9efff;
    border-color: #d4e0ff;
    color: #284eb5;
}

.mf-urdu-action[data-action="clear"] {
    color: #c24141;
}

.mf-urdu-action[data-action="clear"]:hover {
    background: #fff0f0;
    border-color: #fecaca;
}

.mf-urdu-input {
    text-align: right;
    font-size: 16px;
}

@media (max-width: 480px) {
    .mf-urdu-keyboard {
        padding: 10px;
        border-radius: 12px;
    }

    .mf-urdu-keys {
        grid-template-columns: repeat(5, minmax(0, 1fr));
        gap: 6px;
    }

    .mf-urdu-key {
        min-height: 40px;
        font-size: 19px;
    }

    .mf-urdu-actions {
        grid-template-columns: 1fr;
    }
}
</style>
