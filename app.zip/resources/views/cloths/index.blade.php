@extends('main')

@push('styles')
    <style>
        .cloth-directory {
            --blue: #1769ef;
            --ink: #14213d;
            --muted: #718096;
            --line: #e1e8f2;
            min-height: calc(100vh - 65px);
            padding: 27px 0 48px;
            background: #f7f9fc;
            color: var(--ink)
        }

        .cloth-shell {
            max-width: 1560px;
            margin: auto;
            padding: 0 24px
        }

        .cloth-breadcrumb {
            margin-bottom: 12px;
            color: var(--muted);
            font-size: .84rem
        }

        .cloth-breadcrumb a {
            color: inherit
        }

        .cloth-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 20px
        }

        .cloth-heading {
            display: flex;
            align-items: center;
            gap: 14px
        }

        .cloth-heading-icon {
            display: grid;
            place-items: center;
            width: 52px;
            height: 52px;
            border: 1px solid var(--line);
            border-radius: 13px;
            background: #fff;
            color: var(--blue);
            font-size: 21px;
            box-shadow: 0 5px 18px rgba(25, 67, 120, .06)
        }

        .cloth-heading h1 {
            margin: 0 0 4px;
            font-size: 1.6rem;
            font-weight: 800
        }

        .cloth-heading p {
            margin: 0;
            color: var(--muted)
        }

        .cloth-header-actions {
            display: flex;
            align-items: center;
            gap: 9px
        }

        .cloth-header-actions .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            min-height: 44px;
            border-radius: 8px;
            font-weight: 700
        }

        .cloth-primary {
            border: 0;
            background: linear-gradient(135deg, #1769ef, #287fff);
            color: #fff !important;
            box-shadow: 0 8px 20px rgba(23, 105, 239, .2)
        }

        .cloth-more {
            min-width: 44px;
            justify-content: center
        }

        .cloth-header-actions .dropdown-menu {
            min-width: 220px;
            text-align: right
        }

        .cloth-header-actions .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 15px
        }

        .cloth-header-actions .dropdown-item i {
            width: 19px;
            color: #607089;
            text-align: center
        }

        .cloth-stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 15px;
            margin-bottom: 18px
        }

        .cloth-stat {
            display: flex;
            align-items: center;
            justify-content: space-between;
            min-height: 105px;
            padding: 18px 20px;
            border: 1px solid var(--line);
            border-radius: 13px;
            background: #fff;
            box-shadow: 0 5px 20px rgba(28, 63, 105, .045)
        }

        .cloth-stat small {
            display: block;
            color: var(--muted);
            font-weight: 700
        }

        .cloth-stat strong {
            display: block;
            margin-top: 7px;
            color: var(--ink);
            font: 800 1.18rem/1.3 Arial, sans-serif;
            direction: ltr
        }

        .cloth-stat-icon {
            display: grid;
            place-items: center;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            font-size: 19px
        }

        .cloth-stat:nth-child(1) .cloth-stat-icon {
            background: #eaf2ff;
            color: #1769ef
        }

        .cloth-stat:nth-child(2) .cloth-stat-icon {
            background: #f1eaff;
            color: #7e48df
        }

        .cloth-stat:nth-child(3) .cloth-stat-icon {
            background: #e8f9f0;
            color: #18a866
        }

        .cloth-stat:nth-child(4) .cloth-stat-icon {
            background: #fff3e8;
            color: #e77817
        }

        .cloth-panel {
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: 13px;
            background: #fff;
            box-shadow: 0 5px 20px rgba(28, 63, 105, .045)
        }

        .cloth-searchbar {
            display: grid;
            grid-template-columns: minmax(220px, 560px) auto;
            align-items: end;
            gap: 10px;
            padding: 14px 20px;
            border-bottom: 1px solid var(--line);
            background: #fbfcfe
        }

        .cloth-filter {
            position: relative
        }

        .cloth-filter label {
            display: block;
            margin: 0 2px 6px;
            color: #607089;
            font-size: .76rem;
            font-weight: 800
        }

        .cloth-filter .form-control {
            height: 43px;
            border-color: #d8e1ed;
            border-radius: 7px;
            background: #fff
        }

        .cloth-search i {
            position: absolute;
            z-index: 2;
            right: 14px;
            bottom: 14px;
            color: #8492a7
        }

        .cloth-search .form-control {
            padding-right: 41px
        }

        .cloth-filter-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            height: 43px;
            padding: 0 15px;
            border-radius: 8px;
            font-weight: 800
        }

        .cloth-filter-count {
            display: grid;
            place-items: center;
            min-width: 22px;
            height: 22px;
            padding: 0 6px;
            border-radius: 999px;
            background: #fff;
            color: #1769ef;
            font: 800 .72rem Arial, sans-serif
        }

        .cloth-active-filter {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-right: 8px;
            padding: 4px 8px;
            border-radius: 999px;
            background: #eaf2ff;
            color: #1769ef;
            font-size: .74rem;
            font-weight: 800
        }

        .cloth-filter-backdrop {
            position: fixed;
            z-index: 1199;
            inset: 0;
            background: rgba(15, 30, 49, .42);
            opacity: 0;
            visibility: hidden;
            transition: .2s ease
        }

        .cloth-filter-backdrop.is-open {
            opacity: 1;
            visibility: visible
        }

        .cloth-filter-drawer {
            position: fixed;
            z-index: 1200;
            top: 0;
            bottom: 0;
            left: 0;
            width: min(420px, 100vw);
            display: flex;
            flex-direction: column;
            background: #fff;
            box-shadow: 16px 0 45px rgba(15, 34, 58, .24);
            transform: translateX(-105%);
            transition: transform .24s ease
        }

        .cloth-filter-drawer.is-open {
            transform: translateX(0)
        }

        .cloth-filter-drawer-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 19px 20px;
            border-bottom: 1px solid var(--line)
        }

        .cloth-filter-drawer-head h3 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 800
        }

        .cloth-filter-close {
            display: grid;
            place-items: center;
            width: 38px;
            height: 38px;
            border: 1px solid var(--line);
            border-radius: 8px;
            background: #fff;
            color: #53657d
        }

        .cloth-filter-drawer-body {
            flex: 1;
            min-height: 0;
            overflow-y: auto;
            overscroll-behavior: contain;
            display: grid;
            grid-template-columns: 1fr;
            gap: 14px;
            padding: 18px 20px
        }

        .cloth-filter-drawer-actions {
            position: relative;
            z-index: 1;
            display: flex;
            flex: 0 0 auto;
            gap: 9px;
            padding: 15px 20px;
            border-top: 1px solid var(--line);
            background: #fff
        }

        .cloth-filter-drawer-actions .btn {
            flex: 1;
            min-height: 43px;
            border-radius: 8px;
            font-weight: 800
        }

        .cloth-table {
            margin: 0
        }

        .cloth-table thead th {
            padding: 13px 14px;
            border: 0;
            border-bottom: 1px solid var(--line);
            background: #f8fafd;
            color: #52627b;
            font-weight: 800;
            white-space: nowrap
        }

        .cloth-table td {
            padding: 14px;
            vertical-align: middle;
            border-color: #edf1f6
        }

        .cloth-index {
            color: #8794a7;
            font: 700 .84rem Arial, sans-serif
        }

        .cloth-identity {
            display: flex;
            align-items: center;
            gap: 11px;
            min-width: 220px
        }

        .cloth-thumb {
            display: grid;
            place-items: center;
            flex: 0 0 48px;
            height: 48px;
            overflow: hidden;
            border: 1px solid #e1e8f2;
            border-radius: 10px;
            background: #f2f5fa;
            color: #9cabbd
        }

        .cloth-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover
        }

        .cloth-identity strong {
            display: block;
            color: var(--ink)
        }

        .cloth-identity small {
            display: block;
            margin-top: 3px;
            color: var(--muted)
        }

        .cloth-code {
            font-family: Arial, sans-serif;
            direction: ltr
        }

        .cloth-number {
            display: inline-block;
            font: 800 .88rem Arial, sans-serif;
            direction: ltr
        }

        .cloth-price small {
            display: block;
            margin-top: 4px;
            color: var(--muted);
            font: 600 .75rem/1.4 inherit;
            direction: rtl
        }

        .cloth-stock-badge,
        .cloth-channel {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 9px;
            border-radius: 999px;
            background: #e9f9f0;
            color: #15844c;
            font-size: .75rem;
            font-weight: 800
        }

        .cloth-stock-badge {
            display: flex;
            margin-top: 5px
        }

        .cloth-stock-badge.is-low {
            background: #fff3e4;
            color: #c46b0b
        }

        .cloth-stock-badge.is-empty {
            background: #fff0f1;
            color: #c93643
        }

        .cloth-channel {
            background: #eaf2ff;
            color: #1769ef
        }

        .cloth-channel.is-pos {
            background: #f0f2f5;
            color: #59677a
        }

        .cloth-colors {
            min-width: 190px
        }

        .cloth-colors summary {
            cursor: pointer;
            list-style: none;
            color: #1769ef;
            font-weight: 800
        }

        .cloth-colors summary::-webkit-details-marker {
            display: none
        }

        .cloth-colors summary::before {
            content: '\f0d9';
            margin-left: 7px;
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            color: #8da0b8
        }

        .cloth-colors[open] summary::before {
            content: '\f0d7'
        }

        .cloth-color-list {
            min-width: 240px;
            margin-top: 9px;
            padding: 8px;
            border: 1px solid #e1e8f2;
            border-radius: 9px;
            background: #f8fafd
        }

        .cloth-color-row {
            display: grid;
            grid-template-columns: minmax(90px, 1fr) auto auto;
            align-items: center;
            gap: 10px;
            padding: 7px
        }

        .cloth-color-row+.cloth-color-row {
            border-top: 1px solid #e7edf5
        }

        .cloth-color-name {
            font-weight: 700
        }

        .cloth-color-cost {
            color: #748298;
            font-size: .75rem
        }

        .cloth-color-edit {
            display: grid;
            place-items: center;
            width: 29px;
            height: 29px;
            border: 1px solid #d7e1ee;
            border-radius: 7px;
            background: #fff;
            color: #415775 !important
        }

        .cloth-actions {
            white-space: nowrap
        }

        .cloth-edit {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            height: 37px;
            padding: 0 12px;
            border-radius: 8px;
            background: #1769ef;
            color: #fff !important;
            font-weight: 700
        }

        .cloth-row-more {
            width: 37px;
            height: 37px;
            margin-right: 5px;
            border: 1px solid #d7e1ee;
            border-radius: 8px;
            background: #fff;
            color: #415775
        }

        .cloth-actions .dropdown-menu {
            min-width: 190px;
            text-align: right
        }

        .cloth-actions .dropdown-item {
            display: flex;
            align-items: center;
            gap: 9px;
            padding: 9px 13px
        }

        .cloth-actions .dropdown-item i {
            width: 18px;
            color: #607089;
            text-align: center
        }

        .cloth-empty {
            padding: 55px 20px !important;
            text-align: center;
            color: #8b98aa
        }

        .cloth-empty i {
            display: block;
            margin-bottom: 10px;
            color: #c3cedb;
            font-size: 34px
        }

        .cloth-pagination {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            padding: 15px 20px;
            border-top: 1px solid var(--line);
            color: var(--muted);
            font-size: .85rem
        }

        .cloth-pagination nav {
            margin-right: auto
        }

        .cloth-import-drop {
            padding: 24px;
            border: 2px dashed #cdd8e7;
            border-radius: 11px;
            background: #f8fbff;
            text-align: center
        }

        .cloth-import-drop i {
            display: block;
            margin-bottom: 10px;
            color: #1769ef;
            font-size: 30px
        }

        .cloth-import-drop .form-control {
            height: auto;
            padding: 9px;
            background: #fff
        }

        .cloth-modal .modal-content {
            border: 0;
            border-radius: 13px;
            box-shadow: 0 18px 50px rgba(20, 45, 75, .22)
        }

        .cloth-modal .modal-header,
        .cloth-modal .modal-footer {
            border-color: var(--line)
        }

        @media(max-width:1180px) {
            .cloth-stats {
                grid-template-columns: repeat(2, 1fr)
            }
        }

        @media(max-width:767.98px) {
            .cloth-shell {
                padding: 0 12px
            }

            .cloth-header {
                align-items: stretch;
                flex-direction: column
            }

            .cloth-header-actions {
                justify-content: space-between
            }

            .cloth-header-actions>.btn:first-child {
                flex: 1;
                justify-content: center
            }

            .cloth-stats {
                grid-template-columns: 1fr
            }

            .cloth-stat {
                min-height: 92px
            }

            .cloth-searchbar {
                grid-template-columns: 1fr auto;
                padding: 12px
            }

            .cloth-filter label {
                display: none
            }

            .cloth-filter-button {
                width: 46px;
                padding: 0
            }

            .cloth-filter-button>span:not(.cloth-filter-count) {
                display: none
            }

            .cloth-table,
            .cloth-table tbody,
            .cloth-table tr,
            .cloth-table td {
                display: block;
                width: 100%
            }

            .cloth-table thead {
                display: none
            }

            .cloth-table tr {
                width: calc(100% - 20px);
                margin: 10px;
                border: 1px solid var(--line);
                border-radius: 10px;
                padding: 7px
            }

            .cloth-table td {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: 13px;
                padding: 10px;
                border-top: 1px solid #edf1f6
            }

            .cloth-table td:first-child {
                display: none
            }

            .cloth-table td::before {
                content: attr(data-label);
                flex: 0 0 31%;
                color: var(--muted);
                font-weight: 800
            }

            .cloth-table .cloth-main-cell::before,
            .cloth-table .cloth-actions::before {
                display: none
            }

            .cloth-table .cloth-main-cell {
                display: block;
                border-top: 0
            }

            .cloth-colors {
                min-width: 0;
                text-align: left
            }

            .cloth-color-list {
                min-width: 210px
            }

            .cloth-actions {
                display: block !important
            }

            .cloth-pagination {
                align-items: stretch;
                flex-direction: column
            }

            .cloth-pagination nav {
                margin: 0;
                overflow: auto
            }
        }
    </style>
@endpush

@section('content')
    @php $activeFilters = collect($filters)->except('per_page')->filter(fn ($value) => filled($value) && $value !== 'all' && $value !== 'newest')->count(); @endphp
    <section class="main-content cloth-directory" dir="rtl">
        <div class="cloth-shell">
            <div class="cloth-breadcrumb"><a href="{{ route('admin.home') }}">ڈیش بورڈ</a><span
                    class="mx-2">‹</span>انوینٹری<span class="mx-2">‹</span>کپڑوں کی فہرست</div>
            <header class="cloth-header">
                <div class="cloth-heading"><span class="cloth-heading-icon"><i class="fas fa-layer-group"></i></span>
                    <div>
                        <h1>کپڑوں کی فہرست</h1>
                        <p>ہر کپڑے کا سیٹ ایک ریکارڈ ہے؛ اس کے رنگ اور مقدار اسی کے اندر موجود ہیں۔</p>
                    </div>
                </div>
                <div class="cloth-header-actions"><a href="{{ route('admin.purchases.create') }}" class="btn cloth-primary"><i
                            class="fas fa-plus"></i> نیا کپڑا شامل کریں</a>
                    <div class="dropdown"><button class="btn btn-light border cloth-more" type="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="مزید اختیارات"><i
                                class="fas fa-ellipsis-v"></i></button>
                        <div class="dropdown-menu dropdown-menu-left"><a href="{{ route('admin.cloth.qr-labels') }}"
                                class="dropdown-item" target="_blank" rel="noopener"><i class="fas fa-qrcode"></i> تمام سیٹ
                                QR لیبل</a><button type="button" class="dropdown-item" data-toggle="modal"
                                data-target="#clothesCsvModal"><i class="fas fa-file-import"></i> ایکسل درآمد</button><a
                                href="{{ route('admin.clothscsv') }}" class="dropdown-item"><i
                                    class="fas fa-file-excel"></i> ایکسل برآمد</a></div>
                    </div>
                </div>
            </header>
            @include('inc.message')
            <div class="cloth-stats">
                <article class="cloth-stat">
                    <div><small>کپڑوں کے سیٹ</small><strong>{{ number_format($summary['sets']) }}</strong></div><span
                        class="cloth-stat-icon"><i class="fas fa-layer-group"></i></span>
                </article>
                <article class="cloth-stat">
                    <div><small>رنگ / اسٹاک ریکارڈز</small><strong>{{ number_format($summary['colors']) }}</strong></div>
                    <span class="cloth-stat-icon"><i class="fas fa-swatchbook"></i></span>
                </article>
                <article class="cloth-stat">
                    <div><small>کل دستیاب اسٹاک</small><strong>{{ number_format($summary['meters'], 2) }} m</strong></div>
                    <span class="cloth-stat-icon"><i class="fas fa-ruler-combined"></i></span>
                </article>
                <article class="cloth-stat">
                    <div><small>کم یا ختم سیٹ</small><strong>{{ number_format($summary['low_or_empty']) }}</strong></div>
                    <span class="cloth-stat-icon"><i class="fas fa-exclamation-triangle"></i></span>
                </article>
            </div>
            <section class="cloth-panel">
                <form method="GET" action="{{ route('admin.cloth.index') }}" id="clothFilterForm">
                    <div class="cloth-searchbar">
                        <div class="cloth-filter cloth-search"><label for="cloth-q">تلاش</label><i
                                class="fas fa-search"></i><input id="cloth-q" name="q" type="search"
                                class="form-control" value="{{ $filters['q'] ?? '' }}"
                                placeholder="سیٹ کوڈ، اسٹاک کوڈ، برانڈ، قسم یا رنگ"></div>
                        <button type="button" class="btn btn-outline-primary cloth-filter-button" id="clothFilterToggle"
                            aria-controls="clothFilterDrawer" aria-expanded="false"><i
                                class="fas fa-sliders-h"></i><span>فلٹر</span>
                            @if ($activeFilters)
                                <span class="cloth-filter-count">{{ $activeFilters }}</span>
                            @endif
                        </button>
                    </div>
                    <div class="cloth-filter-backdrop" id="clothFilterBackdrop" aria-hidden="true"></div>
                    <aside class="cloth-filter-drawer" id="clothFilterDrawer" role="dialog" aria-modal="true"
                        aria-labelledby="clothFilterDrawerTitle" aria-hidden="true">
                        <div class="cloth-filter-drawer-head">
                            <div>
                                <h3 id="clothFilterDrawerTitle">انوینٹری فلٹر</h3><small class="text-muted">فہرست کو ضرورت
                                    کے مطابق محدود کریں</small>
                            </div><button type="button" class="cloth-filter-close" id="clothFilterClose"
                                aria-label="فلٹر بند کریں"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="cloth-filter-drawer-body">
                            <div class="cloth-filter"><label for="cloth-brand">برانڈ</label><select id="cloth-brand"
                                    name="brand" class="form-control">
                                    <option value="">تمام برانڈز</option>
                                    @foreach ($brands as $brand)
                                        <option value="{{ $brand->id }}" @selected((string) ($filters['brand'] ?? '') === (string) $brand->id)>
                                            {{ $brand->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="cloth-filter"><label for="cloth-type">کپڑے کی قسم</label><select id="cloth-type"
                                    name="type" class="form-control">
                                    <option value="">تمام اقسام</option>
                                    @foreach ($types as $type)
                                        <option value="{{ $type->id }}" @selected((string) ($filters['type'] ?? '') === (string) $type->id)>
                                            {{ $type->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="cloth-filter"><label for="cloth-color">رنگ</label><select id="cloth-color"
                                    name="color" class="form-control">
                                    <option value="">تمام رنگ</option>
                                    @foreach ($colors as $color)
                                        <option value="{{ $color }}" @selected(($filters['color'] ?? '') === $color)>
                                            {{ $color }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="cloth-filter"><label for="cloth-stock">اسٹاک حالت</label><select id="cloth-stock"
                                    name="stock" class="form-control">
                                    <option value="all">تمام اسٹاک</option>
                                    <option value="available" @selected(($filters['stock'] ?? '') === 'available')>دستیاب (10 میٹر سے زیادہ)
                                    </option>
                                    <option value="low" @selected(($filters['stock'] ?? '') === 'low')>کم اسٹاک (10 میٹر یا کم)</option>
                                    <option value="empty" @selected(($filters['stock'] ?? '') === 'empty')>ختم / اسٹاک درج نہیں</option>
                                </select></div>
                            <div class="cloth-filter"><label for="cloth-basis">فروخت کی بنیاد</label><select
                                    id="cloth-basis" name="basis" class="form-control">
                                    <option value="all">تمام قیمتیں</option>
                                    <option value="per_meter" @selected(($filters['basis'] ?? '') === 'per_meter')>فی میٹر</option>
                                    <option value="per_suit" @selected(($filters['basis'] ?? '') === 'per_suit')>فی سوٹ</option>
                                </select></div>
                            <div class="cloth-filter"><label for="cloth-availability">فروخت کی جگہ</label><select
                                    id="cloth-availability" name="availability" class="form-control">
                                    <option value="all">POS اور آن لائن — تمام</option>
                                    <option value="pos_only" @selected(($filters['availability'] ?? '') === 'pos_only')>صرف POS / دکان</option>
                                    <option value="online_order" @selected(($filters['availability'] ?? '') === 'online_order')>آن لائن آرڈر فعال</option>
                                </select></div>
                            <div class="cloth-filter"><label for="cloth-sort">ترتیب</label><select id="cloth-sort"
                                    name="sort" class="form-control">
                                    <option value="newest">نئے پہلے</option>
                                    <option value="oldest" @selected(($filters['sort'] ?? '') === 'oldest')>پرانے پہلے</option>
                                    <option value="brand" @selected(($filters['sort'] ?? '') === 'brand')>برانڈ کے مطابق</option>
                                    <option value="type" @selected(($filters['sort'] ?? '') === 'type')>قسم کے مطابق</option>
                                    <option value="stock_high" @selected(($filters['sort'] ?? '') === 'stock_high')>زیادہ اسٹاک پہلے</option>
                                    <option value="stock_low" @selected(($filters['sort'] ?? '') === 'stock_low')>کم اسٹاک پہلے</option>
                                </select></div>
                            <div class="cloth-filter"><label for="cloth-page-size">فی صفحہ</label><select
                                    id="cloth-page-size" name="per_page" class="form-control">
                                    @foreach ([25, 50, 100] as $size)
                                        <option value="{{ $size }}" @selected((int) ($filters['per_page'] ?? 25) === $size)>
                                            {{ $size }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="cloth-filter-drawer-actions"><a class="btn btn-light border"
                                href="{{ route('admin.cloth.index') }}">صاف کریں</a><button class="btn btn-primary"
                                type="submit"><i class="fas fa-filter ml-1"></i> فلٹر لگائیں</button></div>
                    </aside>
                </form>
                <div class="table-responsive">
                    <table class="table table-hover cloth-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>کپڑے کا سیٹ</th>
                                <th>رنگ اور اسٹاک</th>
                                <th>کل مقدار</th>
                                <th>فروخت کی قیمت</th>
                                <th>فروخت کی جگہ</th>
                                <th>عمل</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($cloths as $cloth)
                                @php
                                    $totalStock = (float) $cloth->colors->sum('length');
                                    $stockStatus =
                                        $totalStock <= 0 ? 'empty' : ($totalStock <= 10 ? 'low' : 'available');
                                    $stockLabel =
                                        $stockStatus === 'empty'
                                            ? 'ختم / درج نہیں'
                                            : ($stockStatus === 'low'
                                                ? 'کم اسٹاک'
                                                : 'دستیاب');
                                    $firstColor = $cloth->colors->first();
                                    $image = $cloth->images->first();
                                    $online = $cloth->storefrontListings->contains(
                                        fn($listing) => $listing->is_published &&
                                            $listing->is_available &&
                                            $listing->online_order_enabled,
                                    );
                                    $colorNames = $cloth->usesDisplayOnlyColors()
                                        ? collect($cloth->selectableColorNames())
                                        : $cloth->colors->pluck('color');
                                    $colorSummary = $cloth->tracksColors()
                                        ? ($colorNames->filter()->count() ?: 'کوئی') . ' رنگ'
                                        : 'مشترکہ اسٹاک';
                                @endphp
                                <tr>
                                    <td data-label="#"><span
                                            class="cloth-index">{{ ($cloths->firstItem() ?? 1) + $loop->index }}</span>
                                    </td>
                                    <td data-label="کپڑے کا سیٹ" class="cloth-main-cell">
                                        <div class="cloth-identity"><span class="cloth-thumb">
                                                @if ($image)
                                                    <img src="{{ $image->image_url }}"
                                                    alt="{{ $cloth->name ?? 'کپڑا' }}">@else<i
                                                        class="fas fa-image"></i>
                                                @endif
                                            </span>
                                            <div><strong>{{ $cloth->name ?: 'نام درج نہیں' }}</strong><small>{{ $cloth->brand->name ?? 'برانڈ درج نہیں' }}
                                                    · {{ $cloth->type->name ?? 'قسم درج نہیں' }}</small></div>
                                        </div>
                                    </td>
                                    <td data-label="رنگ اور اسٹاک">
                                        <details class="cloth-colors">
                                            <summary>{{ $colorSummary }}</summary>
                                            <div class="cloth-color-list">
                                                @forelse($cloth->colors as $color)
                                                    @php $latestCost = $color->latestCostedStockAddition?->unit_cost ?? $color->average_unit_cost ?? $cloth->price; @endphp
                                                    <div class="cloth-color-row"><span
                                                            class="cloth-color-name">{{ $cloth->tracksColors() ? ($cloth->usesDisplayOnlyColors() ? collect($cloth->selectableColorNames())->join('، ') : $color->color) : 'تمام اسٹاک' }}</span><span><b
                                                                class="cloth-number">{{ number_format((float) $color->length, 2) }}
                                                                m</b><small class="cloth-color-cost d-block">لاگت Rs.
                                                                {{ number_format((float) $latestCost, 2) }}</small></span><a
                                                            class="cloth-color-edit"
                                                            href="{{ route('admin.edit-cloths', ['id' => $cloth->id, 'color' => $color->color]) }}"
                                                            title="اس اسٹاک ریکارڈ میں ترمیم کریں"><i
                                                            class="fas fa-pen"></i></a></div>@empty<div
                                                        class="p-2 text-muted">اس سیٹ کا اسٹاک ریکارڈ موجود نہیں۔</div>
                                                @endforelse
                                            </div>
                                        </details>
                                    </td>
                                    <td data-label="کل مقدار"><span
                                            class="cloth-number">{{ number_format($totalStock, 2) }} m</span><span
                                            class="cloth-stock-badge {{ $stockStatus === 'low' ? 'is-low' : ($stockStatus === 'empty' ? 'is-empty' : '') }}">{{ $stockLabel }}</span>
                                    </td>
                                    <td data-label="فروخت کی قیمت" class="cloth-price">
                                        @if ($cloth->sellsPerSuit())
                                            <span class="cloth-number">Rs.
                                                {{ number_format((float) $cloth->suit_sale_price, 2) }}</span><small>فی سوٹ
                                                · {{ number_format((float) $cloth->default_sale_length, 2) }}
                                            میٹر</small>@else<span class="cloth-number">Rs.
                                                {{ number_format((float) $cloth->sale_price, 2) }}</span><small>فی
                                                میٹر</small>
                                        @endif
                                    </td>
                                    <td data-label="فروخت کی جگہ"><span
                                            class="cloth-channel {{ $online ? '' : 'is-pos' }}"><i
                                                class="fas {{ $online ? 'fa-globe' : 'fa-store' }}"></i>{{ $online ? 'POS + آن لائن' : 'صرف POS' }}</span>
                                    </td>
                                    <td class="cloth-actions" data-label="عمل">
                                        @if ($firstColor)
                                            <a href="{{ route('admin.edit-cloths', ['id' => $cloth->id, 'color' => $firstColor->color]) }}"
                                            class="cloth-edit"><i class="fas fa-pen"></i> ترمیم</a>@else<span
                                                class="text-muted small">ترمیم کے لیے اسٹاک ریکارڈ درکار ہے</span>
                                        @endif
                                    </td>
                                </tr>
                            @empty<tr>
                                    <td colspan="7" class="cloth-empty"><i class="fas fa-layer-group"></i>
                                        @if ($activeFilters)
                                            فلٹر کے مطابق کوئی کپڑا نہیں ملا۔
                                            <a href="{{ route('admin.cloth.index') }}">تمام ریکارڈز دیکھیں</a>
                                        @else
                                            ابھی کوئی کپڑا شامل نہیں کیا گیا۔
                                        @endif
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                @if ($cloths->total())
                    <div class="cloth-pagination"><span>{{ $cloths->firstItem() }} سے {{ $cloths->lastItem() }} — کل {{ number_format($cloths->total()) }} سیٹ</span>
                        @if ($cloths->hasPages())
                            {{ $cloths->links() }}
                        @endif
                    </div>
                @endif
            </section>
        </div>
        <div class="modal fade cloth-modal" id="clothesCsvModal" tabindex="-1" role="dialog"
            aria-labelledby="clothesCsvModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form action="{{ route('admin.clothescsv') }}" method="post" enctype="multipart/form-data">@csrf
                        <div class="modal-header">
                            <h2 class="modal-title h5 mb-0" id="clothesCsvModalTitle">ایکسل فائل درآمد کریں</h2><button
                                type="button" class="close mx-0" data-dismiss="modal" aria-label="بند کریں"><span
                                    aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="cloth-import-drop"><i class="fas fa-file-excel"></i><strong
                                    class="d-block mb-2">کپڑوں کی ایکسل فائل منتخب کریں</strong><small
                                    class="text-muted d-block mb-3">درست ٹیمپلیٹ والی فائل استعمال کریں۔</small><input
                                    type="file" name="csvFile" class="form-control" accept=".csv,.xls,.xlsx"
                                    required></div>
                        </div>
                        <div class="modal-footer"><button type="button" class="btn btn-light border"
                                data-dismiss="modal">منسوخ</button><button type="submit" class="btn btn-primary"><i
                                    class="fas fa-upload ml-1"></i> فائل درآمد کریں</button></div>
                    </form>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const drawer = document.getElementById('clothFilterDrawer');
            const backdrop = document.getElementById('clothFilterBackdrop');
            const toggle = document.getElementById('clothFilterToggle');
            const close = document.getElementById('clothFilterClose');
            const setDrawer = function(open) {
                drawer.classList.toggle('is-open', open);
                backdrop.classList.toggle('is-open', open);
                drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
                backdrop.setAttribute('aria-hidden', open ? 'false' : 'true');
                toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
                document.body.style.overflow = open ? 'hidden' : '';
                if (open) drawer.querySelector('select, input, button')?.focus();
            };
            toggle.addEventListener('click', function() {
                setDrawer(true);
            });
            close.addEventListener('click', function() {
                setDrawer(false);
            });
            backdrop.addEventListener('click', function() {
                setDrawer(false);
            });
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape' && drawer.classList.contains('is-open')) setDrawer(false);
            });
        });
    </script>
@endpush
