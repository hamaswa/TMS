@extends('main')
@section('content')
<section class="main-content">
    <div class="container">

        <div class="card col-sm-10 mx-auto">
            <h2 class="mb-4 text-right"> کپڑے کی نئی قسم شامل کریں</h2>
        <form id="cc-form__addCustomerForm" action="{{ route('admin.clothtype.store')}}" class="add-customer-form"
            method="post">
            @csrf

            <div class="form-group row">
                <div class="col-md-8">
                    <div class="form-row m-0">
                        <label class="col-sm-3 col-form-label f"><span class="english">نام (اردو)</span> </label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="name_ur" value="{{ old('name_ur') }}" required>
                        </div>
                    </div>
                    <div class="form-row m-0 mt-3">
                        <label class="col-sm-3 col-form-label f"><span class="english">Name (English)</span></label>
                        <div class="col-sm-9"><input type="text" class="form-control" name="name_en" value="{{ old('name_en') }}" dir="ltr" required></div>
                    </div>
                </div>
                <div class="button-group">
                    <button type="submit" class="btn btn-blue mr-3">محفوظ کریں</button>
                </div>
            </div>
        </form>
        </div>
    </div>
</section>

@endsection
