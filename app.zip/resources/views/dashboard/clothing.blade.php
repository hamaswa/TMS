@extends('main')

@push('styles')
<style>
    .shop-dashboard{--dash-blue:#1769ef;--dash-ink:#14213d;--dash-muted:#718096;--dash-line:#e1e8f2;min-height:calc(100vh - 65px);padding:27px 0 48px;background:#f7f9fc;color:var(--dash-ink)}
    .shop-dashboard-shell{max-width:1560px;margin:auto;padding:0 24px}.shop-dashboard-hero{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:space-between;gap:24px;min-height:166px;margin-bottom:18px;padding:28px 32px;border-radius:18px;background:linear-gradient(125deg,#123f77 0%,#1769ef 60%,#2794f5 100%);color:#fff;box-shadow:0 15px 35px rgba(23,105,239,.18)}.shop-dashboard-hero::before,.shop-dashboard-hero::after{content:'';position:absolute;border-radius:50%;background:rgba(255,255,255,.08)}.shop-dashboard-hero::before{width:260px;height:260px;top:-155px;left:12%}.shop-dashboard-hero::after{width:190px;height:190px;bottom:-130px;right:38%}.shop-dashboard-hero-copy,.shop-dashboard-hero-actions{position:relative;z-index:1}.shop-dashboard-kicker{display:inline-flex;align-items:center;gap:7px;margin-bottom:8px;padding:5px 10px;border-radius:999px;background:rgba(255,255,255,.15);font-size:.76rem;font-weight:800}.shop-dashboard-hero h1{margin:0 0 7px;color:#fff;font-size:1.75rem;font-weight:800}.shop-dashboard-hero p{margin:0;color:rgba(255,255,255,.82)}.shop-dashboard-hero-actions{display:flex;gap:10px;flex-wrap:wrap}.shop-dashboard-hero-actions a{display:inline-flex;align-items:center;gap:8px;min-height:44px;padding:9px 16px;border-radius:8px;font-weight:800}.dash-hero-primary{background:#fff;color:#1769ef!important}.dash-hero-secondary{border:1px solid rgba(255,255,255,.45);background:rgba(255,255,255,.09);color:#fff!important}
    .dash-metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:15px;margin-bottom:18px}.dash-metric{display:flex;align-items:center;justify-content:space-between;min-height:111px;padding:18px;border:1px solid var(--dash-line);border-radius:13px;background:#fff;box-shadow:0 5px 20px rgba(28,63,105,.045)}.dash-metric small{display:block;color:var(--dash-muted);font-weight:700}.dash-metric strong{display:block;margin-top:7px;color:var(--dash-ink);font:800 1.1rem/1.3 Arial,sans-serif;direction:ltr}.dash-metric-meta{display:block;margin-top:4px;color:var(--dash-muted);font-size:.72rem}.dash-metric-icon{display:grid;place-items:center;flex:0 0 50px;height:50px;border-radius:50%;font-size:20px}.dash-metric:nth-child(1) .dash-metric-icon{background:#eaf2ff;color:#1769ef}.dash-metric:nth-child(2) .dash-metric-icon{background:#e8f9f0;color:#18a866}.dash-metric:nth-child(3) .dash-metric-icon{background:#fff3e8;color:#e77817}.dash-metric:nth-child(4) .dash-metric-icon{background:#f1eaff;color:#7e48df}.dash-metric:nth-child(5) .dash-metric-icon{background:#e7f8fa;color:#1696a8}
    .dash-layout{display:grid;grid-template-columns:minmax(0,1.45fr) minmax(340px,.7fr);gap:18px;margin-bottom:18px}.dash-panel{overflow:hidden;border:1px solid var(--dash-line);border-radius:13px;background:#fff;box-shadow:0 5px 20px rgba(28,63,105,.045)}.dash-panel-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:17px 20px;border-bottom:1px solid var(--dash-line)}.dash-panel-title{display:flex;align-items:center;gap:9px;margin:0;color:var(--dash-ink);font-size:1.05rem;font-weight:800}.dash-panel-title i{color:#1769ef}.dash-panel-link{color:#1769ef;font-size:.82rem;font-weight:800}.dash-chart{height:270px;padding:24px 22px 18px}.dash-chart-bars{display:flex;align-items:flex-end;justify-content:space-around;gap:12px;height:205px;border-bottom:1px solid #dfe6ef;background:repeating-linear-gradient(to top,transparent 0,transparent 50px,#eef2f7 51px)}.dash-chart-column{display:flex;flex:1;align-items:center;justify-content:flex-end;flex-direction:column;height:100%}.dash-chart-value{margin-bottom:7px;color:#60718a;font:700 .7rem Arial,sans-serif;direction:ltr}.dash-chart-bar{width:min(42px,70%);min-height:4px;border-radius:7px 7px 2px 2px;background:linear-gradient(180deg,#36a0fb,#1769ef);transition:.2s ease}.dash-chart-column:hover .dash-chart-bar{filter:brightness(.94)}.dash-chart-day{margin-top:9px;color:#718096;font-size:.74rem}.dash-chart-summary{display:flex;align-items:center;justify-content:space-between;margin-top:14px;color:var(--dash-muted);font-size:.82rem}.dash-chart-summary strong{color:#1769ef;font-family:Arial,sans-serif;direction:ltr}
    .dash-alert-list{padding:8px 18px}.dash-alert-item{display:flex;align-items:center;gap:11px;padding:12px 0;border-bottom:1px solid #edf1f6}.dash-alert-item:last-child{border-bottom:0}.dash-alert-icon{display:grid;place-items:center;flex:0 0 38px;height:38px;border-radius:9px;background:#fff3e8;color:#e77817}.dash-alert-copy{min-width:0;flex:1}.dash-alert-copy strong{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dash-alert-copy small{display:block;margin-top:2px;color:var(--dash-muted)}.dash-alert-qty{padding:5px 8px;border-radius:999px;background:#fff0f1;color:#c93643;font:800 .75rem Arial,sans-serif;direction:ltr}.dash-empty{padding:38px 20px;text-align:center;color:#8b98aa}.dash-empty i{display:block;margin-bottom:9px;color:#c4cfdb;font-size:29px}
    .dash-bottom-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.dash-table{margin:0}.dash-table thead th{padding:12px 15px;border:0;border-bottom:1px solid var(--dash-line);background:#f8fafd;color:#52627b;font-weight:800;white-space:nowrap}.dash-table td{padding:13px 15px;vertical-align:middle;border-color:#edf1f6}.dash-primary-text{display:block;color:var(--dash-ink);font-weight:800}.dash-secondary-text{display:block;margin-top:2px;color:var(--dash-muted);font-size:.76rem}.dash-money{display:inline-block;font:800 .82rem Arial,sans-serif;direction:ltr}.dash-status{display:inline-flex;padding:4px 8px;border-radius:999px;font-size:.72rem;font-weight:800}.dash-status-draft{background:#fff4dc;color:#a66d00}.dash-status-received{background:#e8f9ef;color:#168452}.dash-status-cancelled{background:#eef1f5;color:#6c7585}
    .dash-live-sales{margin-bottom:18px;border-color:#a9cdfd}.dash-live-count{display:inline-flex;align-items:center;justify-content:center;min-width:28px;height:28px;padding:0 8px;border-radius:999px;background:#1769ef;color:#fff;font:800 .78rem Arial,sans-serif}.dash-live-row-needs_attention{background:#fff9e8}.dash-live-status{display:inline-flex;padding:4px 8px;border-radius:999px;background:#eaf2ff;color:#1769ef;font-size:.72rem;font-weight:800}.dash-live-row-needs_attention .dash-live-status{background:#fff0c7;color:#966200}.dash-live-row-claimed .dash-live-status{background:#e7f8fa;color:#137989}
    @media(max-width:1250px){.dash-metrics{grid-template-columns:repeat(3,1fr)}}
    @media(max-width:991.98px){.dash-layout,.dash-bottom-grid{grid-template-columns:1fr}.shop-dashboard-hero{align-items:flex-start;flex-direction:column}}
    @media(max-width:767.98px){.shop-dashboard-shell{padding:0 12px}.shop-dashboard-hero{padding:23px 19px}.shop-dashboard-hero-actions{width:100%;flex-direction:column}.shop-dashboard-hero-actions a{width:100%;justify-content:center}.dash-metrics{grid-template-columns:1fr}.dash-metric{min-height:96px}.dash-chart{padding:20px 10px}.dash-chart-bars{gap:5px}.dash-chart-value{display:none}.dash-chart-bar{width:65%}.dash-table,.dash-table tbody,.dash-table tr,.dash-table td{display:block;width:100%}.dash-table thead{display:none}.dash-table tr{margin:8px;border:1px solid var(--dash-line);border-radius:9px;padding:6px;width:calc(100% - 16px)}.dash-table td{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:8px;border-top:1px solid #edf1f6}.dash-table td:first-child{border-top:0}.dash-table td::before{content:attr(data-label);color:var(--dash-muted);font-weight:800}}
</style>
@endpush

@section('content')
@php
    $trendMax = max(1, (float) $salesTrend->max('total'));
    $trendTotal = (float) $salesTrend->sum('total');
    $purchaseStatus = ['draft' => 'زیرِ تیاری', 'received' => 'وصول شدہ', 'cancelled' => 'منسوخ'];
    $liveSaleStatus = ['active' => 'جاری', 'needs_attention' => 'توجہ طلب', 'claimed' => 'زیرِ کار'];
@endphp
<section class="main-content shop-dashboard" dir="rtl">
<div class="shop-dashboard-shell">
    <header class="shop-dashboard-hero">
        <div class="shop-dashboard-hero-copy"><span class="shop-dashboard-kicker"><i class="fas fa-store"></i> دکان اور فروخت ورک اسپیس</span><h1>دکان ڈیش بورڈ</h1><p>فروخت، اسٹاک، خریداری اور سپلائرز کی آج کی مکمل صورتحال</p></div>
        <div class="shop-dashboard-hero-actions">@if($canSales)<a href="{{ route('admin.counter-orders.create') }}" class="dash-hero-primary"><i class="fas fa-cash-register"></i> نیا آرڈر</a>@endif @if($canPurchases)<a href="{{ route('admin.purchases.create') }}" class="dash-hero-secondary"><i class="fas fa-plus"></i> نئی خریداری</a>@endif</div>
    </header>

    <div class="dash-metrics">
        @if($canInventory)<article class="dash-metric"><div><small>اسٹاک میں میٹر</small><strong>{{ number_format($clothing['meters'], 2) }}</strong></div><span class="dash-metric-icon"><i class="fas fa-ruler-combined"></i></span></article><article class="dash-metric"><div><small>اسٹاک کی مالیت</small><strong>Rs. {{ number_format($clothing['inventory_value'], 0) }}</strong></div><span class="dash-metric-icon"><i class="fas fa-coins"></i></span></article><article class="dash-metric"><div><small>کم اسٹاک اشیاء</small><strong>{{ $clothing['low_stock'] }}</strong></div><span class="dash-metric-icon"><i class="fas fa-exclamation-triangle"></i></span></article>@endif
        @if($canPurchases)<article class="dash-metric"><div><small>زیرِ تیاری خریداریاں</small><strong>{{ $clothing['draft_purchases'] }}</strong></div><span class="dash-metric-icon"><i class="fas fa-truck-loading"></i></span></article>@endif
        @if($canSales)<article class="dash-metric"><div><small>اس ماہ کی فروخت</small><strong>Rs. {{ number_format($clothing['month_sales'], 0) }}</strong></div><span class="dash-metric-icon"><i class="fas fa-chart-line"></i></span></article>@endif
        @if($canSales)<article class="dash-metric"><div><small>اس ماہ نئے گاہک</small><strong>{{ $clothing['new_customers_month'] }}</strong><span class="dash-metric-meta">اس ہفتے {{ $clothing['new_customers_week'] }}</span></div><span class="dash-metric-icon"><i class="fas fa-user-plus"></i></span></article>@endif
    </div>

    @if($canSales)
    <section class="dash-panel dash-live-sales">
        <div class="dash-panel-head">
            <h2 class="dash-panel-title"><i class="fas fa-mobile-alt"></i> سیلز ایجنٹ کی لائیو فروخت</h2>
            <div><span class="dash-live-count" id="dashboard-live-sale-count">{{ $liveSaleSessions->count() }}</span> <a class="dash-panel-link mr-2" href="{{ route('admin.sales-sessions.index') }}">سیلز اِن باکس</a></div>
        </div>
        <div class="table-responsive"><table class="table dash-table"><thead><tr><th>ایجنٹ</th><th>گاہک</th><th>اسکین شدہ آئٹمز</th><th>حالت</th><th>آخری تبدیلی</th><th></th></tr></thead><tbody id="dashboard-live-sale-list">
            @forelse($liveSaleSessions as $session)
            <tr class="dash-live-row-{{ $session->status }}">
                <td data-label="ایجنٹ">{{ $session->agent?->name ?? '—' }}</td>
                <td data-label="گاہک">{{ data_get($session->customer_data, 'name', $session->customer_mode === 'walk-in' ? 'Walk-in' : '—') }}</td>
                <td data-label="اسکین شدہ آئٹمز">{{ collect($session->items)->filter(fn ($item) => filled($item['setCode'] ?? null))->count() }}</td>
                <td data-label="حالت"><span class="dash-live-status">{{ $liveSaleStatus[$session->status] ?? $session->status }}</span></td>
                <td data-label="آخری تبدیلی">{{ $session->updated_at?->diffForHumans() }}</td>
                <td><a class="btn btn-sm btn-outline-primary" href="{{ route('admin.sales-sessions.show', $session) }}">کھولیں</a></td>
            </tr>
            @empty
            <tr><td colspan="6" class="dash-empty"><i class="fas fa-mobile-alt"></i>موبائل سے کوئی لائیو فروخت شروع نہیں ہوئی</td></tr>
            @endforelse
        </tbody></table></div>
    </section>
    @endif

    @if($canSales || $canInventory)
    <div class="dash-layout">
        @if($canSales)<section class="dash-panel"><div class="dash-panel-head"><h2 class="dash-panel-title"><i class="fas fa-chart-bar"></i> گزشتہ 7 دن کی فروخت</h2><span class="dash-panel-link">آج: Rs. {{ number_format($clothing['today_sales'], 0) }}</span></div><div class="dash-chart"><div class="dash-chart-bars">@foreach($salesTrend as $point)<div class="dash-chart-column"><span class="dash-chart-value">{{ number_format($point['total'], 0) }}</span><span class="dash-chart-bar" style="height:{{ max(2, round(($point['total'] / $trendMax) * 100)) }}%"></span><span class="dash-chart-day">{{ $point['date']->format('D') }}</span></div>@endforeach</div><div class="dash-chart-summary"><span>سات دن کی کل فروخت</span><strong>Rs. {{ number_format($trendTotal, 2) }}</strong></div></div></section>@endif
        @if($canInventory)<section class="dash-panel"><div class="dash-panel-head"><h2 class="dash-panel-title"><i class="fas fa-exclamation-circle"></i> کم اسٹاک الرٹس</h2><a class="dash-panel-link" href="{{ route('admin.cloth.index') }}">تمام اسٹاک دیکھیں</a></div>@forelse($lowStockItems as $item)<div class="dash-alert-list"><div class="dash-alert-item"><span class="dash-alert-icon"><i class="fas fa-box-open"></i></span><div class="dash-alert-copy"><strong>{{ $item->cloth->brand->name ?? 'برانڈ' }} / {{ $item->color }}</strong><small>{{ $item->cloth->type->name ?? 'قسم درج نہیں' }}</small></div><span class="dash-alert-qty">{{ number_format((float) $item->length, 2) }} m</span></div></div>@empty<div class="dash-empty"><i class="fas fa-check-circle"></i>تمام کپڑوں کا اسٹاک مناسب ہے۔</div>@endforelse</section>@endif
    </div>
    @endif

    <div class="dash-bottom-grid">
        @if($canPurchases)<section class="dash-panel"><div class="dash-panel-head"><h2 class="dash-panel-title"><i class="fas fa-truck-loading"></i> حالیہ خریداریاں</h2><a class="dash-panel-link" href="{{ route('admin.purchases.index') }}">تمام دیکھیں</a></div><div class="table-responsive"><table class="table dash-table"><thead><tr><th>خریداری</th><th>سپلائر</th><th>حالت</th><th>رقم</th></tr></thead><tbody>@forelse($recentPurchases as $purchase)<tr><td data-label="خریداری"><span class="dash-primary-text">{{ $purchase->purchase_number }}</span><span class="dash-secondary-text">{{ $purchase->purchase_date->format('d M Y') }}</span></td><td data-label="سپلائر">{{ $purchase->supplier->name }}</td><td data-label="حالت"><span class="dash-status dash-status-{{ $purchase->status }}">{{ $purchaseStatus[$purchase->status] ?? $purchase->status }}</span></td><td data-label="رقم"><span class="dash-money">Rs. {{ number_format($purchase->total_amount, 2) }}</span></td></tr>@empty<tr><td colspan="4" class="dash-empty"><i class="fas fa-inbox"></i>کوئی خریداری موجود نہیں</td></tr>@endforelse</tbody></table></div></section>@endif
        @if($canSales)<section class="dash-panel"><div class="dash-panel-head"><h2 class="dash-panel-title"><i class="fas fa-receipt"></i> حالیہ فروخت</h2><a class="dash-panel-link" href="{{ route('admin.counter-orders.create') }}">نیا آرڈر</a></div><div class="table-responsive"><table class="table dash-table"><thead><tr><th>گاہک</th><th>کپڑا</th><th>مقدار</th><th>رقم</th></tr></thead><tbody>@forelse($recentSales as $sale)<tr><td data-label="گاہک"><span class="dash-primary-text">{{ $sale->c_name }}</span><span class="dash-secondary-text">{{ \Illuminate\Support\Carbon::parse($sale->sellDate)->format('d M Y') }}</span></td><td data-label="کپڑا">{{ $sale->brand->name ?? 'برانڈ' }}@if(filled($sale->color)) / {{ $sale->color }}@endif</td><td data-label="مقدار"><span class="dash-money">{{ number_format($sale->length, 2) }} m</span></td><td data-label="رقم"><span class="dash-money">Rs. {{ number_format((float) $sale->selling_price * (float) $sale->length, 2) }}</span></td></tr>@empty<tr><td colspan="4" class="dash-empty"><i class="fas fa-inbox"></i>کوئی فروخت موجود نہیں</td></tr>@endforelse</tbody></table></div></section>@endif
    </div>
</div>
</section>
@endsection

@if($canSales)
@push('scripts')
<script>
(function () {
    const body = document.getElementById('dashboard-live-sale-list');
    const count = document.getElementById('dashboard-live-sale-count');
    const showUrl = @json(route('admin.sales-sessions.show', '__UUID__'));
    const openStatuses = new Set(['active', 'needs_attention', 'claimed']);
    const statusLabels = { active: 'جاری', needs_attention: 'توجہ طلب', claimed: 'زیرِ کار' };

    window.addEventListener('sales-session-feed', function (event) {
        const sessions = (event.detail?.data || []).filter(session => openStatuses.has(session.status));
        count.textContent = String(sessions.length);
        body.innerHTML = '';
        if (!sessions.length) {
            const row = body.insertRow(); const cell = row.insertCell(); cell.colSpan = 6;
            cell.className = 'dash-empty'; cell.textContent = 'موبائل سے کوئی لائیو فروخت شروع نہیں ہوئی';
            return;
        }
        sessions.forEach(function (session) {
            const row = body.insertRow(); row.className = 'dash-live-row-' + session.status;
            const scannedItems = (session.items || []).filter(item => item.setCode).length;
            const values = [
                session.agent?.name || '—',
                session.customer?.name || (session.customerMode === 'walk-in' ? 'Walk-in' : '—'),
                String(scannedItems), statusLabels[session.status] || session.status,
                session.updatedAt ? new Date(session.updatedAt).toLocaleTimeString() : '—',
            ];
            values.forEach(function (value, index) {
                const cell = row.insertCell(); cell.textContent = value;
                if (index === 3) cell.className = 'dash-live-status';
            });
            const action = row.insertCell(); const link = document.createElement('a');
            link.className = 'btn btn-sm btn-outline-primary'; link.textContent = 'کھولیں';
            link.href = showUrl.replace('__UUID__', encodeURIComponent(session.uuid)); action.appendChild(link);
        });
    });
})();
</script>
@endpush
@endif
