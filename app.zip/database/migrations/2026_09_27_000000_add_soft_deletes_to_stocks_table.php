<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('stocks') && ! Schema::hasColumn('stocks', 'deleted_at')) {
            Schema::table('stocks', function (Blueprint $table) {
                $table->softDeletes();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('stocks') && Schema::hasColumn('stocks', 'deleted_at')) {
            Schema::table('stocks', function (Blueprint $table) {
                $table->dropSoftDeletes();
            });
        }
    }
};
