@extends('main')

@section('content')
    <style>
        .customer-orders-page {
            min-height: calc(100vh - 70px);
            padding: 28px 0;
            background: #f3f6fa;
            direction: rtl
        }

        .customer-orders-shell {
            width: min(100% - 32px, 1720px);
            margin: 0 auto
        }

        .customer-orders-hero {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 24px 28px;
            margin-bottom: 20px;
            color: #fff;
            background: linear-gradient(135deg, #102a43, #1769aa);
            border-radius: 18px;
            box-shadow: 0 14px 32px rgba(16, 42, 67, .16)
        }

        .customer-orders-hero h1 {
            margin: 0 0 7px;
            color: #fff;
            font-size: 1.65rem;
            font-weight: 900
        }

        .customer-orders-hero p {
            margin: 0;
            color: rgba(255, 255, 255, .78)
        }

        .customer-orders-hero__meta {
            display: flex;
            align-items: center;
            gap: 9px;
            flex-wrap: wrap;
            margin-top: 12px
        }

        .customer-orders-hero__meta span {
            padding: 6px 10px;
            background: rgba(255, 255, 255, .12);
            border-radius: 8px;
            font-size: .85rem;
            font-weight: 700
        }

        .customer-orders-back {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 10px 14px;
            color: #163a5f;
            background: #fff;
            border-radius: 10px;
            font-weight: 800;
            white-space: nowrap
        }

        .customer-orders-back:hover {
            color: #1769aa;
            text-decoration: none
        }

        .customer-orders-alert {
            display: flex;
            align-items: center;
            gap: 9px;
            padding: 13px 16px;
            margin-bottom: 16px;
            color: #146c43;
            background: #eaf8f1;
            border: 1px solid #ccebdc;
            border-radius: 12px;
            font-weight: 700
        }

        .customer-orders-panel {
            overflow: hidden;
            background: #fff;
            border: 1px solid #dde5ef;
            border-radius: 17px;
            box-shadow: 0 8px 28px rgba(21, 47, 81, .06)
        }

        .customer-orders-panel__head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 19px 22px;
            border-bottom: 1px solid #e3eaf2;
            background: linear-gradient(135deg, #f7faff, #fff)
        }

        .customer-orders-panel__head h2 {
            margin: 0 0 4px;
            color: #102a43;
            font-size: 1.22rem;
            font-weight: 900
        }

        .customer-orders-panel__head p {
            margin: 0;
            color: #718096;
            font-size: .88rem
        }

        .customer-orders-panel__icon {
            display: grid;
            place-items: center;
            width: 46px;
            height: 46px;
            color: #1769aa;
            background: #eaf3ff;
            border-radius: 13px;
            font-size: 1.1rem
        }

        .customer-orders-table-wrap {
            width: 100%;
            overflow-x: auto
        }

        .customer-order-table {
            width: 100% !important;
            min-width: 0;
            margin: 0 !important;
            table-layout: fixed
        }

        .customer-order-table thead th {
            padding: 14px 8px !important;
            color: #53647b !important;
            background: #f5f8fc !important;
            border: 0 !important;
            border-bottom: 1px solid #dde5ef !important;
            text-align: right;
            white-space: normal;
            font-size: .84rem;
            font-weight: 800;
            line-height: 1.6
        }

        .customer-order-table tbody td {
            padding: 14px 8px !important;
            border-top: 0 !important;
            border-bottom: 1px solid #edf1f6 !important;
            text-align: right;
            vertical-align: middle !important;
            white-space: normal;
            font-size: .9rem;
            overflow-wrap: anywhere
        }

        .customer-order-table th:nth-child(1) {
            width: 4%
        }

        .customer-order-table th:nth-child(2),
        .customer-order-table th:nth-child(3),
        .customer-order-table th:nth-child(4) {
            width: 7%
        }

        .customer-order-table th:nth-child(5) {
            width: 11%
        }

        .customer-order-table th:nth-child(6),
        .customer-order-table th:nth-child(7) {
            width: 8%
        }

        .customer-order-table th:nth-child(8) {
            width: 7%
        }

        .customer-order-table th:nth-child(9) {
            width: 8%
        }

        .customer-order-table th:nth-child(10) {
            width: 13%
        }

        .customer-order-table th:nth-child(11) {
            width: 10%
        }

        .customer-order-table th:nth-child(12) {
            width: 6%
        }

        .customer-order-table th:nth-child(13) {
            width: 4%
        }

        .customer-orders-tabs {
            gap: 8px;
            padding: 12px 22px 0;
            border-bottom: 1px solid #e3eaf2;
            background: #fff
        }

        .customer-orders-tabs .nav-link {
            margin-bottom: -1px;
            padding: 10px 18px;
            color: #53647b;
            border: 1px solid transparent;
            border-radius: 12px 12px 0 0;
            font-weight: 800
        }

        .customer-orders-tabs .nav-link:hover {
            color: #1769aa
        }

        .customer-orders-tabs .nav-link.active {
            color: #1769aa;
            background: #f5f8fc;
            border-color: #dde5ef #dde5ef #f5f8fc
        }

        .customer-order-table.customer-sales-table {
            table-layout: auto
        }

        .sale-actions-toggle {
            width: 36px;
            height: 36px;
            color: #53647b;
            border: 1px solid #dde5ef;
            border-radius: 10px
        }

        .sale-actions-menu {
            position: fixed;
            z-index: 1060;
            display: none;
            min-width: 210px;
            padding: 6px;
            background: #fff;
            border: 1px solid #dde5ef;
            border-radius: 12px;
            box-shadow: 0 14px 35px rgba(31, 45, 61, .18)
        }

        .sale-actions-menu.is-open {
            display: block
        }

        .sale-action {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            padding: 9px 12px;
            color: #243b53;
            background: transparent;
            border: 0;
            border-radius: 8px;
            font-size: .9rem;
            font-weight: 700;
            text-align: right
        }

        .sale-action:hover {
            text-decoration: none;
            background: #f5f8fc
        }

        .sale-action.sale-payment-button {
            color: #146c43
        }

        .sale-action--return {
            color: #c0392b
        }

        .customer-order-table.customer-sales-table th {
            width: auto
        }

        .order-money {
            direction: ltr;
            display: inline-block;
            font-weight: 800
        }

        .order-money.is-paid {
            color: #138455
        }

        .order-money.is-due {
            color: #cf3f4d
        }

        .order-payment-cell,
        .order-status-cell {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            flex-wrap: wrap
        }

        .order-payment-status {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 30px;
            padding: 5px 9px;
            border-radius: 999px;
            font-size: .76rem;
            font-weight: 800
        }

        .order-payment-status.is-paid {
            color: #087747;
            background: #e6f7ef
        }

        .order-payment-status.is-partial {
            color: #9a6500;
            background: #fff3d6
        }

        .order-payment-status.is-unpaid {
            color: #b12f3c;
            background: #ffecef
        }

        .order-payment-button {
            min-height: 32px;
            padding: 5px 9px;
            border: 1px solid #bce5d1;
            border-radius: 8px;
            color: #087747;
            background: #effaf4;
            font-size: .76rem;
            font-weight: 800
        }

        .order-payment-button:hover {
            border-color: #83cfaa;
            background: #ddf5e9
        }

        .customer-order-status {
            min-width: 112px;
            border: 1px solid transparent;
            border-radius: 9px;
            font-weight: 900;
            box-shadow: 0 5px 14px rgba(25, 45, 75, .08)
        }

        .customer-order-status.order-stage-unassigned {
            color: #6b4d08;
            border-color: #ead08c;
            background: #fff8df
        }

        .customer-order-status.order-stage-workshop {
            color: #9b6200;
            border-color: #f2cf82;
            background: #fff3cf
        }

        .customer-order-status.order-stage-ready,
        .customer-order-status.order-stage-delivered {
            color: #fff;
            border-color: #1769e0;
            background: linear-gradient(135deg, #2478ec, #1159bd)
        }

        .customer-order-status.disabled {
            cursor: default;
            opacity: 1
        }

        .order-delivery-form {
            margin: 0
        }

        .customer-orders-hero__actions {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .order-delivery-action,
        .order-delivered-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-height: 34px;
            padding: 6px 10px;
            border-radius: 9px;
            font-size: .74rem;
            font-weight: 900
        }

        .order-delivery-action {
            color: #087747;
            border: 1px solid #8bd0ad;
            background: #e9f8f0
        }

        .order-delivery-action:hover {
            color: #fff;
            border-color: #15945c;
            background: #15945c
        }

        .order-delivered-badge {
            color: #fff;
            border: 1px solid #15945c;
            background: linear-gradient(135deg, #1daa6a, #087747)
        }

        .quick-tailor-open {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-height: 36px;
            padding: 6px 11px;
            border: 1px solid #8ebbe9;
            border-radius: 9px;
            color: #1769aa;
            background: #eef6ff;
            font-size: .76rem;
            font-weight: 900
        }

        .quick-tailor-open:hover {
            color: #fff;
            background: #1769aa
        }

        .quick-tailor-empty {
            display: block;
            color: #9a6500;
            font-size: .72rem;
            font-weight: 700
        }

        .tailor-assignment-context {
            display: flex;
            align-items: center;
            gap: 9px;
            padding: 11px 13px;
            margin-bottom: 16px;
            color: #164e75;
            background: #eff8ff;
            border: 1px solid #cbe8fa;
            border-radius: 10px;
            font-weight: 800
        }

        .tailor-assignment-rate-note {
            display: block;
            margin-top: 6px;
            color: #718096;
            font-size: .76rem
        }

        .customer-orders-page .dataTables_wrapper {
            padding: 14px
        }

        .customer-orders-page .dataTables_filter {
            float: left;
            text-align: left
        }

        .customer-orders-page .dataTables_length {
            float: right
        }

        .customer-orders-page .modal-content {
            overflow: hidden;
            border: 0;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(12, 35, 68, .22)
        }

        @media(max-width:1300px) {
            .customer-order-table {
                min-width: 1320px;
                table-layout: auto
            }

            .customer-order-table.customer-sales-table {
                min-width: 900px
            }

            .customer-order-table thead th {
                white-space: nowrap
            }
        }

        @media(max-width:767px) {
            .customer-orders-page {
                padding-top: 18px
            }

            .customer-orders-shell {
                width: min(100% - 20px, 1720px)
            }

            .customer-orders-hero {
                align-items: stretch;
                flex-direction: column;
                padding: 20px
            }

            .customer-orders-back {
                justify-content: center
            }

            .customer-orders-panel__head {
                padding: 16px
            }
        }
    </style>

    <section class="main-content customer-orders-page">
        <div class="customer-orders-shell">
            <header class="customer-orders-hero">
                <div>
                    <h1>{{ $customer->name }} اور خاندان کے آرڈرز</h1>
                    <p>آرڈر، ادائیگی، بقایا، مرحلہ، درزی اور ریک نمبر ایک الگ صفحے پر دیکھیں اور تبدیل کریں۔</p>

                    <div class="customer-orders-hero__meta">
                        <span>
                            <i class="fas fa-phone ml-1"></i>
                            <bdi>{{ $customer->phone_number1 }}</bdi>
                        </span>

                        @if ($selectedCustomer->id !== $customer->id)
                            <span>
                                <i class="fas fa-users ml-1"></i>
                                {{ $customer->name }} کا خاندانی ناپ
                            </span>
                        @endif
                    </div>
                </div>

                <div class="customer-orders-hero__actions">

                    @include('customer.partials.action-menu', [
                        'customer' => $customer,
                        'selectedCustomer' => $selectedCustomer,
                    ])
                </div>
            </header>

            <div id="customerOrdersAjaxAlert" class="customer-orders-alert" style="display:none"><i
                    class="fas fa-check-circle"></i><span></span></div>
            @if (session('insert'))
                <div class="customer-orders-alert"><i class="fas fa-check-circle"></i><span>{{ session('insert') }}</span>
                </div>
            @endif
            @if (session('success'))
                <div class="customer-orders-alert"><i class="fas fa-check-circle"></i><span>{{ session('success') }}</span>
                </div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger text-right"><strong>تبدیلی محفوظ نہیں ہو سکی۔</strong>
                    <ul class="mb-0 mt-2">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <section id="orderDetail" class="customer-orders-panel" aria-live="polite">
                <div class="customer-orders-panel__head">
                    <div>
                        <h2>آرڈر ریکارڈ</h2>
                        <p>{{ $customer->name }} اور تمام خاندانی پروفائلز کے سلائی آرڈرز اور کپڑے کی خریداری، تازہ ترین پہلے۔</p>
                    </div>
                    <span class="customer-orders-panel__icon"><i class="fas fa-receipt"></i></span>
                </div>
                @if ($canViewShop)
                    <ul class="nav customer-orders-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link {{ $activeTab === 'tailoring' ? 'active' : '' }}" id="tailoringTabLink" data-toggle="tab"
                                href="#tailoringTab" role="tab" aria-controls="tailoringTab" data-tab="tailoring"
                                aria-selected="{{ $activeTab === 'tailoring' ? 'true' : 'false' }}"><i class="fas fa-cut ml-1"></i> سلائی</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ $activeTab === 'sales' ? 'active' : '' }}" id="salesTabLink" data-toggle="tab"
                                href="#salesTab" role="tab" aria-controls="salesTab" data-tab="sales"
                                aria-selected="{{ $activeTab === 'sales' ? 'true' : 'false' }}"><i class="fas fa-shopping-bag ml-1"></i> فروخت
                                <span class="badge badge-light">{{ $sales->count() }}</span></a>
                        </li>
                    </ul>
                @endif
                <div class="tab-content">
                    <div class="tab-pane fade {{ $activeTab === 'tailoring' ? 'show active' : '' }}" id="tailoringTab" role="tabpanel" aria-labelledby="tailoringTabLink">
                        <div class="customer-orders-table-wrap">
                            <table class="table js-sortable-table customer-order-table" id="cc-table-data-order-history"
                                data-return-orders="{{ $selectedCustomer->id }}">
                                <thead>
                                    <tr>
                                        <th>نمبر</th>
                                        <th>کل رقم</th>
                                        <th>ادا شدہ</th>
                                        <th>بقایا</th>
                                        <th>ادائیگی</th>
                                        <th>آرڈر کی تاریخ</th>
                                        <th>واپسی کی تاریخ</th>
                                        <th>کپڑوں کی تعداد</th>
                                        <th>درزی</th>
                                        <th>مرحلہ</th>
                                        <th>ریک نمبر</th>
                                        <th>تبدیلی</th>
                                        <th>پرنٹ</th>
                                    </tr>
                                </thead>
                                <tbody class="tbody"></tbody>
                            </table>
                        </div>
                    </div>
                    @if ($canViewShop)
                        <div class="tab-pane fade {{ $activeTab === 'sales' ? 'show active' : '' }}" id="salesTab" role="tabpanel" aria-labelledby="salesTabLink">
                            <div class="customer-orders-table-wrap">
                                <table class="table customer-order-table customer-sales-table text-right mb-0" id="customerSalesTable">
                                    <thead>
                                        <tr>
                                            <th>رسید نمبر</th>
                                            <th>تاریخ</th>
                                            <th>تفصیل</th>
                                            <th>اشیاء</th>
                                            <th>کل رقم</th>
                                            <th>وصول شدہ</th>
                                            <th>بقایا</th>
                                            <th class="text-center">اختیارات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($sales as $sale)
                                            <tr class="{{ $sale->status === 'cancelled' ? 'text-muted' : '' }}">
                                                <td><span dir="ltr">{{ $sale->display_number }}</span>
                                                    @if ($sale->status === 'cancelled')
                                                        <span class="badge badge-danger">منسوخ</span>
                                                    @endif
                                                </td>
                                                <td>{{ $sale->created_at?->format('d-m-Y') }}</td>
                                                <td>{{ $sale->summary ?: 'کپڑے کی فروخت' }}
                                                    @if ($sale->cancellation_reason)
                                                        <br><small>وجہ: {{ $sale->cancellation_reason }}</small>
                                                    @endif
                                                    @if (($sale->returned_total ?? 0) > 0)
                                                        <br><small class="text-danger">آئٹم واپسی: Rs {{ number_format($sale->returned_total, 2) }}</small>
                                                    @endif
                                                </td>
                                                <td>{{ $sale->items_count }}</td>
                                                <td>Rs {{ number_format($sale->amount, 2) }}</td>
                                                <td>Rs {{ number_format($sale->status === 'cancelled' ? 0 : $sale->received, 2) }}</td>
                                                <td>Rs {{ number_format($sale->status === 'cancelled' ? 0 : $sale->balance, 2) }}</td>
                                                <td class="text-center">@include('customer.partials.sale-actions', ['sale' => $sale, 'customer' => $customer, 'asMenu' => true, 'canPay' => $canViewBalances])</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    @endif
                </div>
            </section>

            <button type="button" id="loadCustomerOrders" class="getCustomer d-none" data-id="{{ $customer->id }}"
                data-profile-id="{{ $selectedCustomer->id }}" data-name="{{ $selectedCustomer->name }}"
                aria-hidden="true"></button>
        </div>

        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form id="orderStatusForm" action="{{ $detailedWorkflow ? '' : url('admin/order-status') }}"
                        method="post"
                        @if ($detailedWorkflow) data-action-base="{{ url('admin/tailor-jobs') }}" @endif>
                        @csrf @if ($detailedWorkflow)
                            @method('PATCH')
                        @endif
                        <input type="hidden" id="order_id" name="order_id">
                        <div class="modal-header">
                            <h4 class="modal-title">آرڈر کا اگلا مرحلہ</h4><button type="button" class="close mr-auto ml-0"
                                data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body text-right"><label for="orderStatusSelect" class="font-weight-bold">نیا مرحلہ
                                منتخب کریں</label><select id="orderStatusSelect" class="form-control order-status"
                                name="{{ $detailedWorkflow ? 'status' : 'order_status' }}" required></select></div>
                        <div class="modal-footer"><button type="submit" class="btn btn-primary" id="submit-button">محفوظ
                                کریں</button><button type="button" class="btn btn-light" data-dismiss="modal">منسوخ
                                کریں</button></div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="tailorAssignmentModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form id="quickTailorAssignmentForm" method="post">
                        @csrf @method('PATCH')
                        <div class="modal-header">
                            <h4 class="modal-title">درزی مقرر کریں</h4><button type="button" class="close mr-auto ml-0"
                                data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body text-right">
                            <div class="tailor-assignment-context"><i class="fas fa-receipt"></i><span>آرڈر <bdi
                                        id="tailorAssignmentOrderNumber"></bdi></span></div>
                            <div class="form-group"><label for="quickTailorSelect" class="font-weight-bold">1. درزی منتخب
                                    کریں</label><select id="quickTailorSelect" class="form-control" name="tailor_id"
                                    required>
                                    <option value="">درزی منتخب کریں</option>
                                </select></div>
                            <div class="form-group mb-0"><label for="quickTailorRateSelect" class="font-weight-bold">2.
                                    سلائی کی شرح / رقم</label><select id="quickTailorRateSelect" class="form-control"
                                    name="tailor_price" required disabled>
                                    <option value="">پہلے درزی منتخب کریں</option>
                                </select><small class="tailor-assignment-rate-note">یہ فی سوٹ درزی کی اجرت ہے؛ محفوظ شدہ
                                    شرح ہی آرڈر پر لاگو ہوگی۔</small></div>
                        </div>
                        <div class="modal-footer"><button type="submit" class="btn btn-primary" id="quickTailorSubmit"
                                disabled><i class="fas fa-user-check ml-1"></i> درزی مقرر کریں</button><button
                                type="button" class="btn btn-light" data-dismiss="modal">منسوخ کریں</button></div>
                    </form>
                </div>
            </div>
        </div>

        @if ($canViewBalances)
            <div class="modal fade" id="myModalpayment" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <form action="{{ route('admin.DirectPayment') }}" method="post">@csrf
                            <input type="hidden" id="customer_id" name="customer_id"><input type="hidden"
                                id="payment_order_id" name="order_id"><input type="hidden" id="payment_receipt_id" name="counter_sale_receipt_id">
                            <div class="modal-header">
                                <h4 class="modal-title" id="paymentModalTitle">آرڈر کی ادائیگی</h4><button type="button"
                                    class="close mr-auto ml-0" data-dismiss="modal"><span>&times;</span></button>
                            </div>
                            <div class="modal-body text-right">
                                <div id="paymentAjaxFeedback" class="alert alert-danger" style="display:none"></div>
                                <div id="orderPaymentContext" class="alert alert-info" style="display:none"></div>
                                <div class="form-group"><label for="directPaymentAmount" class="font-weight-bold">وصول
                                        شدہ رقم</label>
                                    <div class="input-group" dir="ltr">
                                        <div class="input-group-prepend"><span class="input-group-text">Rs.</span></div>
                                        <input id="directPaymentAmount" type="number" min="0" step="0.01"
                                            name="DirectPayment" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group mb-0"><label for="directPaymentComment"
                                        class="font-weight-bold">نوٹ / حوالہ</label>
                                    <textarea id="directPaymentComment" class="form-control" rows="3" name="comment"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer"><button type="submit" class="btn btn-success">ادائیگی محفوظ
                                    کریں</button><button type="button" class="btn btn-light" data-dismiss="modal">منسوخ
                                    کریں</button></div>
                        </form>
                    </div>
                </div>
            </div>
        @endif
    </section>

    <script>
        $(document).ready(function() {
            setTimeout(function() {
                $('#loadCustomerOrders').trigger('click');
            }, 100);

            try {
                var notice = sessionStorage.getItem('customerOrdersNotice');
                if (notice) {
                    sessionStorage.removeItem('customerOrdersNotice');
                    $('#customerOrdersAjaxAlert').show().find('span').text(notice);
                }
            } catch (e) {}

            // Same search + paging as the tailoring table; server order (newest first) is kept.
            if ($.fn.DataTable && $('#customerSalesTable').length) {
                $('#customerSalesTable').DataTable({
                    order: [],
                    columnDefs: [{ targets: -1, orderable: false, searchable: false }],
                    language: { emptyTable: 'ابھی کوئی کپڑے کی خریداری موجود نہیں۔' }
                });
            }

            // Sale ⋮ menus: fixed-positioned so the table's scroll box doesn't clip them.
            function closeSaleMenus() {
                $('.sale-actions-menu.is-open').removeClass('is-open');
                $('.sale-actions-toggle[aria-expanded="true"]').attr('aria-expanded', 'false');
            }
            $(document).on('click', '.sale-actions-toggle', function(event) {
                event.stopPropagation();
                var toggle = $(this),
                    menu = toggle.siblings('.sale-actions-menu'),
                    wasOpen = menu.hasClass('is-open');
                closeSaleMenus();
                if (wasOpen) {
                    return;
                }
                menu.addClass('is-open');
                toggle.attr('aria-expanded', 'true');
                var rect = this.getBoundingClientRect(),
                    menuWidth = menu.outerWidth(),
                    menuHeight = menu.outerHeight(),
                    top = rect.bottom + 6,
                    left = rect.right - menuWidth;
                if (top + menuHeight > window.innerHeight - 8) {
                    top = Math.max(8, rect.top - menuHeight - 6);
                }
                left = Math.min(Math.max(8, left), window.innerWidth - menuWidth - 8);
                menu.css({ top: top, left: left });
            });
            $(document).on('click', '.sale-actions-menu .sale-action', closeSaleMenus);
            $(document).on('click', function(event) {
                if (!$(event.target).closest('.sale-actions-menu').length) {
                    closeSaleMenus();
                }
            });
            $(document).on('keydown', function(event) {
                if (event.key === 'Escape') {
                    closeSaleMenus();
                }
            });
            $(window).on('resize', closeSaleMenus);
            window.addEventListener('scroll', closeSaleMenus, true);

            // Sale rows reuse the payment modal but pay against the sale receipt (own class, so custom.js's
            // tailoring .order-payment-button handler never touches these fields).
            $(document).on('click', '.customer_payment_paid, .order-payment-button', function() {
                $('#payment_receipt_id').val('');
            });
            $(document).on('click', '.sale-payment-button', function() {
                var button = $(this),
                    remaining = Number(button.data('remaining') || 0).toFixed(2);
                $('#customer_id').val(button.data('customerid'));
                $('#payment_order_id').val('');
                $('#payment_receipt_id').val(button.data('receiptid'));
                $('#directPaymentAmount').attr('max', remaining).val('');
                $('#paymentAjaxFeedback').hide().text('');
                $('#paymentModalTitle').html('<i class="fas fa-wallet text-success ml-2"></i> فروخت ' + $('<span>').text(button.data('number')).html() + ' کی ادائیگی');
                $('#orderPaymentContext').text('اس فروخت کا موجودہ بقایا: Rs. ' + remaining).show();
            });

            // Keep the open tab in the URL so a return/cancel that redirects back reopens it.
            $('.customer-orders-tabs a[data-toggle="tab"]').on('shown.bs.tab', function() {
                var url = new URL(window.location.href);
                url.searchParams.set('tab', $(this).data('tab'));
                window.history.replaceState(null, '', url);
                if ($.fn.dataTable) {
                    $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
                }
            });

            $('#myModalpayment form').on('submit', function(event) {
                event.preventDefault();
                var form = $(this),
                    button = form.find('button[type="submit"]'),
                    feedback = $('#paymentAjaxFeedback');
                feedback.hide().text('');
                button.prop('disabled', true);
                $.ajax({
                    url: form.attr('action'),
                    type: 'POST',
                    data: form.serialize(),
                    dataType: 'json',
                    headers: {
                        Accept: 'application/json'
                    },
                    success: function(response) {
                        if ($('#payment_receipt_id').val()) {
                            // The sales table is server-rendered: reload so its balance updates (the open tab is in the URL).
                            try { sessionStorage.setItem('customerOrdersNotice', response.message); } catch (e) {}
                            window.location.reload();
                            return;
                        }
                        $('#myModalpayment').modal('hide');
                        $('#customerOrdersAjaxAlert').show().find('span').text(response
                            .message);
                        form[0].reset();
                        $('#loadCustomerOrders').trigger('click');
                    },
                    error: function(xhr) {
                        var response = xhr.responseJSON || {};
                        feedback.text(response.message ||
                                'ادائیگی محفوظ نہیں ہو سکی۔ معلومات چیک کرکے دوبارہ کوشش کریں۔')
                            .show();
                    },
                    complete: function() {
                        button.prop('disabled', false);
                    }
                });
            });
        });
    </script>
@endsection
