<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="icon" href="{{ asset('assets/images/favicon.ico') }}" type="image/x-icon">

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <title>سلائی آرڈر رسید</title>
    <style>
        @font-face {
            font-family: 'Noto Nastaliq Urdu';
            src: url('/assets/fonts/noto-nastaliq-urdu/NotoNastaliqUrdu-VariableFont_wght.woff2') format('woff2');
            font-weight: 200 400;
            font-style: normal;
            font-display: swap;
        }

        body {
            font-family: 'Noto Nastaliq Urdu', serif;
        }

        body.tms-order-print {
            margin: 0;
            background: #eef2f6;
        }

        body.tms-order-print #invoice-POS {
            margin: 0 auto;
        }

        body.tms-order-print #orderSection {
            background: #fff;
        }

        body.tms-order-print.tms-paper-receipt_80 #invoice-POS {
            width: 80mm;
            padding: 4mm;
        }

        body.tms-order-print.tms-paper-a4 #invoice-POS {
            width: 210mm;
            min-height: 297mm;
            padding: 14mm;
        }

        body.tms-order-print.tms-paper-a4 #orderSection,
        body.tms-order-print.tms-paper-a4 #sizeSection {
            max-width: none !important;
            margin-top: 0 !important;
        }

        body.tms-order-print.tms-paper-a4 .order-detail-row {
            display: grid;
            grid-template-columns: minmax(0, 56%) minmax(0, 44%);
        }

        .measurement-row > .measurement-column-empty {
            min-height: 1px;
        }

        .order-print-toolbar {
            direction: rtl;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            gap: 7px;
            width: min(760px, calc(100% - 24px));
            margin: 12px auto 18px;
        }

        .order-print-toolbar a,
        .order-print-toolbar button {
            appearance: none;
            border: 1px solid #1677c8;
            border-radius: 7px;
            padding: 7px 12px;
            color: #155f9d;
            background: #fff;
            font: inherit;
            line-height: 1.4;
            text-decoration: none;
            white-space: nowrap;
            cursor: pointer;
        }

        .order-print-toolbar .is-primary,
        .order-print-toolbar .is-active {
            color: #fff;
            background: #1677c8;
        }

        /* #invoice-POS {
            box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5);
            padding: 2mm;
            margin-left: 10px !important;
            width: 88mm;
            background: #FFF;

        } */
        #invoice-POS {
            box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5);
            padding-left: 5mm;
            /* Remove all padding */
            padding-right: 0mm;
            margin: 0;
            width: 100mm;
            /* Increase the width */
            background: #FFF;
        }

        ::selection {
            background: #f31544;
            color: #FFF;
        }

        ::moz-selection {
            background: #f31544;
            color: #FFF;
        }

        h1,
        h2,
        h3 {
            color: #000;
            /* Darken the font color */
        }

        h1 {
            font-size: 18px;
            /*color: #222;*/
        }

        h2 {
            font-size: 12px;
        }

        h3 {
            font-size: 12px;
            font-weight: 300;
            line-height: 2em;
        }

        p {
            font-size: 10px;
            color: #666;
            line-height: 1px;
        }

        #top,
        #mid,
        #bot {
            /* Targets all id with 'col-' */
            border-bottom: 1px solid #EEE;
        }

        #top {
            min-height: 100px;
        }

        #mid {
            min-height: 80px;
        }

        #bot {
            min-height: 50px;
        }

        #top .logo {
            //float: left;
            height: 60px;
            width: 60px;
            background: url(http://michaeltruong.ca/images/logo1.png) no-repeat;
            background-size: 60px 60px;
        }

        .clientlogo {
            float: left;
            height: 60px;
            width: 60px;
            background: url(http://michaeltruong.ca/images/client.jpg) no-repeat;
            background-size: 60px 60px;
            border-radius: 50px;
        }

        .info {
            display: block;
            margin-left: 0;
        }

        .title {
            float: right;
        }

        .title p {
            text-align: right;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        .tabletitle {
            font-size: 14px;
            background: #EEE;
        }

        .service {
            border-bottom: 1px solid #EEE;
        }

        .item {
            width: 24mm;
        }

        .itemtext {
            font-size: 8px;
        }

        #legalcopy {
            margin-top: 5mm;
        }

        .desing-flex {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .receipt-reference {
            color: #000 !important;
            font-size: 16px !important;
            font-weight: 900 !important;
            line-height: 1.6 !important;
        }

        .measurement-row {
            align-items: flex-start;
            margin-bottom: 4px;
        }

        .measurement-row,
        .measurement-row * {
            box-sizing: border-box;
            line-height: 1.5 !important;
        }

        .measurement-label {
            color: #000 !important;
            font-weight: 900 !important;
        }

        /* Long labels wrap inside their column instead of running past the slip. */
        .measurement-row .col-6 {
            min-width: 0;
        }

        .measurement-row .measurement-label {
            max-width: 65%;
            flex-shrink: 1 !important;
            white-space: normal !important;
        }

        /* Right column: the number takes only its own width, so the label has room to stay on one line. */
        .measurement-row .col-6 > div > .measurement-value:first-child:not(.measurement-preference-value) {
            width: auto !important;
            flex: 0 0 auto;
        }

        .measurement-row .col-6 > div > .measurement-value:first-child:not(.measurement-preference-value) + .measurement-label {
            width: auto !important;
            max-width: none;
            flex: 1 1 auto;
        }

        /* English labels are longer than the Urdu ones, so print them a little smaller. */
        html[lang="en"] .measurement-row .measurement-label {
            font-size: 17px !important;
            line-height: 1.25 !important;
        }

        .measurement-value {
            color: #000 !important;
            font-weight: 900 !important;
        }

        .measurement-preference-value {
            flex: 1 1 auto;
            min-width: 0;
            direction: rtl;
            unicode-bidi: plaintext;
            text-align: left;
            white-space: normal;
            word-break: normal;
            overflow-wrap: normal;
        }

        .measurement-header {
            padding: 7mm 8px 0;
            break-inside: avoid;
            page-break-inside: avoid;
        }

        .measurement-logo-wrap {
            margin: 0 !important;
            line-height: 1;
        }

        .measurement-logo {
            display: block;
            width: 82px;
            max-height: 70px;
            margin: 0 auto;
            object-fit: contain;
        }

        .measurement-shop-name {
            margin: 4px 0 7px !important;
            font-weight: 900 !important;
            line-height: 1.4;
            text-align: center;
        }

        .measurement-meta {
            padding-right: 8px !important;
            padding-left: 8px !important;
        }

        .measurement-meta-row {
            display: grid !important;
            grid-template-columns: minmax(0, 42%) minmax(0, 58%);
            align-items: baseline;
            gap: 8px;
            margin-bottom: 5px !important;
            padding-bottom: 4px;
            border-bottom: 1px dotted #aaa;
        }

        .measurement-meta-cell {
            min-width: 0;
            color: #000;
            font-size: 15px;
            font-weight: 800;
            line-height: 1.45;
        }

        .measurement-serial {
            direction: ltr;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: 800;
            text-align: left;
            white-space: nowrap;
        }

        .measurement-meta-label {
            text-align: right;
            white-space: nowrap
        }

        .measurement-meta-value {
            text-align: left;
            overflow-wrap: anywhere
        }

        .measurement-footer {
            margin-top: 8px;
            padding: 7px 8px 5px;
            border-top: 1px solid #777;
            text-align: center;
        }

        .measurement-footer,
        .measurement-footer * {
            color: #000 !important;
            font-size: 14px !important;
            font-weight: 900 !important;
            line-height: 1.7 !important;
        }

        .measurement-footer p {
            margin: 0 !important;
        }

        .measurement-footer-contact {
            direction: ltr;
            font-family: Arial, sans-serif;
            letter-spacing: .2px;
        }

        .receipt-builder-credit {
            direction: ltr;
            margin-top: 3px !important;
            padding-top: 3px !important;
            border-top: 1px solid #777;
            font-family: Arial, sans-serif !important;
            font-size: 11px !important;
            font-weight: 800 !important;
            letter-spacing: .15px;
            line-height: 1.35 !important;
            text-align: center;
            white-space: nowrap;
        }

        .order-detail-list {
            display: flex;
            flex-direction: column;
            gap: 8px;
            direction: rtl;
        }

        .order-detail-row {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 14px;
            min-height: 30px;
            background-image: linear-gradient(to right, #b8b8b8, #b8b8b8);
            background-position: left bottom;
            background-repeat: no-repeat;
            background-size: 100% 1px;
        }

        .order-detail-label {
            flex: 0 0 66%;
            color: #000;
            font-size: 18px;
            font-weight: 900;
            line-height: 1.65;
            text-align: right;
        }

        .order-detail-value {
            flex: 1 1 34%;
            min-width: 0;
            color: #000;
            direction: ltr;
            font-size: 18px;
            font-weight: 800;
            line-height: 1.5;
            overflow-wrap: normal;
            word-break: normal;
            text-align: left;
        }

        .order-footer {
            width: 100%;
            margin-top: 3px;
            padding: 3px 6px 2px;
            border-top: 0;
            text-align: center;
        }

        .order-footer,
        .order-footer * {
            color: #000 !important;
            font-size: 13px !important;
            font-weight: 900 !important;
            line-height: 1.45 !important;
        }

        .order-footer p {
            margin: 0 !important;
            padding: 0 !important;
        }

        .order-footer-contact {
            direction: ltr;
            font-family: Arial, sans-serif;
            letter-spacing: .2px;
        }

        .order-detail-date {
            font-size: 17px;
            white-space: nowrap;
        }

        body.tms-order-print.tms-paper-receipt_80 .order-detail-label,
        body.tms-order-print.tms-paper-receipt_80 .order-detail-value {
            min-width: 0;
            font-size: 14px;
            line-height: 1.7;
        }

        body.tms-order-print.tms-paper-receipt_80 .order-summary-row .order-detail-label {
            flex: 0 0 28%;
        }

        body.tms-order-print.tms-paper-receipt_80 .order-summary-row .order-detail-value {
            flex: 1 1 72%;
        }

        .order-tracking-qr {
            direction: rtl;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin: 12px 0 7px;
            padding: 9px 0;
            border-top: 1px solid #999;
            border-bottom: 1px solid #999;
            break-inside: avoid;
            page-break-inside: avoid;
        }

        .order-tracking-qr svg {
            display: block;
            flex: 0 0 105px;
            width: 105px;
            height: 105px;
        }

        .order-tracking-qr__text {
            max-width: 145px;
            color: #000;
            font-size: 12px;
            font-weight: 900;
            line-height: 1.9;
            text-align: right;
        }

        .size .col-6 {
            font-weight: 300;
        }

        @media print {
            @page {
                margin: 6mm 0 3mm;
            }

            html,
            body,
            #invoice-POS {
                margin-top: 0 !important;
                padding-top: 0 !important;
            }

            #top {
                height: 0 !important;
                min-height: 0 !important;
                overflow: hidden;
                border: 0;
            }

            #orderSection {
                margin-top: 0 !important;
            }

            #sizeSection {
                margin-top: 0 !important;
                padding-top: 4mm !important;
            }

            #orderSection>p:first-child {
                margin: 0 !important;
                line-height: normal;
            }

            .btn {
                display: none;
            }

            .order-print-toolbar {
                display: none !important;
            }
        }

        @media screen and (max-width: 520px) {

            body.tms-order-print #invoice-POS,
            body.tms-order-print.tms-paper-a4 #invoice-POS {
                width: 100%;
                min-height: 0;
                padding: 10px;
            }
        }

        /* .printbtn{
                position: relative;
            } */
    </style>
    @include('print.partials.bold-ink')
</head>

<body class="tms-order-print tms-paper-{{ $printConfig['paper'] }}">
    @php
        $displaySerial =
            $receiptSerial ??
            ($orderDetail->customers?->serial_number ?? ($orderDetail->suitNum ?: $orderDetail->sub_customer));
    @endphp

    <nav class="order-print-toolbar" aria-label="سلائی رسید پرنٹ اختیارات">
        <button type="button" class="print-order is-primary">صرف آرڈر پرنٹ کریں</button>
        <button type="button" class="print-length">صرف پیمائش پرنٹ کریں</button>
        <button type="button" class="print-full">مکمل رسید پرنٹ کریں</button>
        @if (count($printConfig['paper_options']) > 1)
            @foreach ($printConfig['paper_options'] as $paper => $label)
                <a href="{{ request()->fullUrlWithQuery(['paper' => $paper]) }}"
                    class="{{ $printConfig['paper'] === $paper ? 'is-active' : '' }}">{{ $label }}</a>
            @endforeach
        @endif
        <button type="button" class="go">واپس جائیں</button>
    </nav>

    <div id="invoice-POS">

        <div id="fullSection">
            <div id="orderSection" style="max-width: 350px;" class="ticket order-section">
                @if ($setting?->logo_url)
                    <p align="center"><img src="{{ $setting->logo_url }}" width="100"
                            alt="{{ $setting->name }} لوگو"></p>
                @endif
                {{-- Pulled up under the logo only; without a logo it would slide off the top of the slip. --}}
                <h1 class="text-center" style="text-align: center;margin-top:{{ $setting?->logo_url ? '-10px' : '0' }}; ">{{ $setting->name }}
                </h1>
                <div class="pl-3 pr-3" style="margin-top: 0px">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h2 class="receipt-reference">رسید نمبر {{ $receiptSerial ?? $orderDetail->id }}
                            </h2>
                        </div>
                        <div style="font-weight:900;">
                            <h3 class="receipt-reference"><span
                                    class="receipt-date">{{ date('d-m-Y', strtotime($orderDetail->created_at)) }}</span>
                            </h3>
                        </div>
                    </div>
                    <hr>
                    <div class="order-detail-list">
                        <div class="order-detail-row order-summary-row"><span
                                class="order-detail-label">نام:</span><strong
                                class="order-detail-value">{{ $orderDetail->customers->name }}</strong></div>
                        <div class="order-detail-row"><span class="order-detail-label">سوٹ کی تعداد:</span><strong
                                class="order-detail-value">{{ $orderDetail->suitQuantity }}</strong></div>
                        <div class="order-detail-row"><span class="order-detail-label">سیریل نمبر:</span><strong
                                class="order-detail-value">{{ $displaySerial }}</strong></div>
                        <div class="order-detail-row"><span class="order-detail-label">آرڈر کی رقم:</span><strong
                                class="order-detail-value">{{ $orderDetail->totalPayment }}</strong></div>
                        <div class="order-detail-row"><span class="order-detail-label">موجودہ رقم کی
                                ادائیگی:</span><strong
                                class="order-detail-value">{{ $orderDetail->transactions->first()?->recivedPayment ?? 0 }}</strong>
                        </div>
                        @if ($orderBalance > 0)
                            <div class="order-detail-row"><span class="order-detail-label">موجودہ ادائیگی واجب
                                    الادا:</span><strong class="order-detail-value">{{ $orderBalance }}</strong></div>
                        @endif
                        @if ($previousBalance > 0)
                            <div class="order-detail-row"><span class="order-detail-label">گزشتہ ادائیگی کے
                                    واجبات:</span><strong class="order-detail-value">{{ $previousBalance }}</strong>
                            </div>
                        @endif
                        @if ($latestBalance > 0)
                            <div class="order-detail-row"><span class="order-detail-label">کل ادائیگی واجب
                                    الادا:</span><strong class="order-detail-value">{{ $latestBalance }}</strong></div>
                        @endif
                        <div class="order-detail-row"><span class="order-detail-label">واپسی کی تاریخ:</span><strong
                                class="order-detail-value order-detail-date">{{ $orderDetail->returnDate ? \Illuminate\Support\Carbon::parse($orderDetail->returnDate)->format('d-m-Y') : '—' }}</strong>
                        </div>
                    </div>
                    <aside class="order-tracking-qr" data-tracking-url="{{ $trackingUrl }}"
                        aria-label="آرڈر کی صورتحال دیکھنے کا QR کوڈ">
                        {!! $trackingQrSvg !!}
                        <div class="order-tracking-qr__text">آرڈر کی صورتحال اور بقایا دیکھنے کے لیے اسکین کریں۔</div>
                    </aside>
                    <div>
                        <h3 class="text-center font-weight-900 order-note" dir="auto"
                            style="font-size: 18px; margin: 25px 0 0 0;">
                            {{ $orderDetail->remarks }}</h3>
                    </div>
                    <div class="order-footer">
                        <p>{!! $setting->address !!}</p>
                        <p class="order-footer-contact">{{ $setting->contact_no }}</p>
                        <p>{{ $setting->note }}</p>
                        <p class="receipt-builder-credit">Built by IT Linked</p>
                        @if ($printConfig['show_qr'])
                            <p class="receipt-reference">{{ $receiptSerial ? 'TECHNICAL REF' : 'ORDER REF' }}: {{ $orderDetail->id }}</p>
                        @endif
                    </div>
                </div>

                <!--<p style="text-align:center; font-size: 10px">{{ $setting->note }}</p>-->
                <!--<hr>-->
            </div>
            <div id="sizeSection" style="max-width: 350px;" class="ticket size-section">
                <div class="measurement-header">
                    @if ($setting?->logo_url)
                        <p align="center" class="measurement-logo-wrap"><img class="measurement-logo"
                                src="{{ $setting->logo_url }}" alt="{{ $setting->name }} لوگو"></p>
                    @endif
                    <h1 class="text-center measurement-shop-name">{{ $setting->name }}</h1>
                </div>
                <div class="pl-1 pr-1 measurement-meta">
                    <hr style="margin-top:4px;">
                    <div class="measurement-meta-row"><span class="measurement-meta-cell measurement-meta-label">آئٹم سیریل</span><strong
                            class="measurement-meta-cell measurement-meta-value measurement-serial">{{ $displaySerial }}</strong>
                    </div>
                    <div class="measurement-meta-row"><span
                            class="measurement-meta-cell measurement-meta-label">گاہک</span><strong
                            class="measurement-meta-cell measurement-meta-value">{{ $orderDetail->customers->name }}</strong>
                    </div>
                    <div class="measurement-meta-row"><span
                            class="measurement-meta-cell measurement-meta-label">درزی</span><strong
                            class="measurement-meta-cell measurement-meta-value">{{ $tailor?->name ?? 'بعد میں مقرر ہوگا' }}</strong>
                    </div>
                    <div class="measurement-meta-row"><span
                            class="measurement-meta-cell measurement-meta-label">موبائل</span><strong
                            class="measurement-meta-cell measurement-meta-value"
                            dir="ltr">{{ $orderDetail->customers->phone_number1 }}</strong></div>
                    <div class="measurement-meta-row"><span class="measurement-meta-cell measurement-meta-label">آرڈر
                            تاریخ</span><strong class="measurement-meta-cell measurement-meta-value"
                            dir="ltr">{{ date('d-m-Y h:i A', strtotime($orderDetail->created_at)) }}</strong>
                    </div>
                    @if ($orderDetail->measurementTemplate)
                        <div class="measurement-meta-cell" style="margin-bottom:7px;text-align:center;">
                            {{ $orderDetail->measurementTemplate->name }}
                        </div>
                    @endif
                    @if (filled($orderDetail->remarks))
                        <div class="measurement-meta-cell" dir="auto"
                            style="margin:8px 0;padding:7px 9px;border:1px solid #777;text-align:right;">
                            <strong>خصوصی سلائی ہدایت:</strong> {{ $orderDetail->remarks }}
                        </div>
                    @endif
                    @if ($printMeasurements->count())
                        @php
                            $allMeasurements = $printMeasurements->keyBy('source_key');

                            // Older production snapshots can miss this field because the
                            // legacy database column is named `Chuta` instead of `chuta`.
                            if (!$allMeasurements->has('system.chuta') && filled($orderDetail->customers->chuta)) {
                                $allMeasurements->put(
                                    'system.chuta',
                                    (object) [
                                        'source_key' => 'system.chuta',
                                        'label' => 'چوتھا',
                                        'value' => (string) $orderDetail->customers->chuta,
                                    ],
                                );
                            }

                            // Printed in the template's sections, columns and order.
                            $tpl = $orderDetail->measurementTemplate;
                        @endphp

                        <hr>

                        @include('order.partials.measurement-print-sections')
                    @else
                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 mt-2 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->necktype }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">گلہ</div>
                                </div>
                            </div>
                            <div class="col-6" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->length }}
                                    </div>
                                    <div style="font-weight:600; font-size:22px">لمبائی</div>
                                </div>
                            </div>
                        </div>

                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->sleeve }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">کف</div>
                                </div>
                            </div>
                            <div class="col-6 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->arms }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">بازو</div>
                                </div>
                            </div>
                        </div>

                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 mt-2 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->Daaman }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">دامن</div>
                                </div>
                            </div>
                            <div class="col-6" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div>{{ $orderDetail->customers->teraa }}</div>
                                    <div style="font-weight:600; font-size:20px;">تیرا</div>
                                </div>

                            </div>
                        </div>

                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 mt-2 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex; justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->jeab }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">جیب</div>
                                </div>
                            </div>
                            <div class="col-6" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex; justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->senaChorai }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">سینہ چوڑائی</div>
                                </div>
                            </div>
                        </div>

                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 mt-2 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between mb-2"
                                    style="display: flex;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->swingtype }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">سلائی</div>
                                </div>
                            </div>
                            <div class="col-6" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->damanchorai }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">دامن چوڑائی</div>
                                </div>
                            </div>

                        </div>

                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 mt-2 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between mb-1"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->button }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">بٹن</div>
                                </div>
                            </div>
                            <div class="col-6" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->shalwar }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">شلوار</div>
                                </div>
                            </div>
                        </div>

                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 mt-2 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->plate_type }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">پلیٹ</div>
                                </div>
                            </div>
                            <div class="col-6" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->pancha }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">پانچہ</div>
                                </div>
                            </div>
                        </div>

                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 mt-2 mb-2" style="width: 45%">

                            </div>
                            <div class="col-6 mt-2 " style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->shalwarGheer }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">شلوار گھیر</div>
                                </div>
                            </div>
                        </div>

                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 " style="width: 45%">

                            </div>

                            <div class="col-6 mt-2 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->shoulder }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">مونڈا</div>
                                </div>
                            </div>

                        </div>
                        <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                            <div class="col-6 mt-2" style="width: 45%">

                            </div>

                            <div class="col-6  mt-2 mb-2" style="width: 45%">
                                <div class="d-flex justify-content-between"
                                    style="display: flex;justify-content: space-between;font-weight:600;">
                                    <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                        {{ $orderDetail->customers->chuta }}
                                    </div>
                                    <div style="font-weight:600; font-size:20px;">چوتھا</div>
                                </div>
                            </div>

                        </div>
                    @endif
                    <hr>
                    <div>
                        <div align="center">
                            <div>
                                <h3 class="text-center font-weight-900"
                                    style="font-size: 18px; margin-top:-20px; margin-bottom:0px">
                                    {{ $orderDetail->remarks }}</h3>
                            </div>
                            <div class="measurement-footer">
                                <p>{!! $setting->address !!}</p>
                                <p class="measurement-footer-contact">{{ $setting->contact_no }}</p>
                                <p class="receipt-builder-credit">Built by IT Linked</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div><!--End Invoice-->
    <script>
        // $(document).ready(function() {
        //     function PrintElem(id) {
        //         var divContents = document.getElementById(id).innerHTML;

        //         var mywindow = window.open('', 'PRINT', 'height=500,width=322');

        //         mywindow.document.write('</head><body >');
        //         //              mywindow.document.write('<h1>' + document.title  + '</h1>');
        //         mywindow.document.write(divContents);
        //         mywindow.document.write('</body></html>');

        //         mywindow.document.close(); // necessary for IE >= 10
        //         mywindow.focus(); // necessary for IE >= 10*/

        //         mywindow.print();
        //         //              mywindow.close();

        //         return true;
        //     }

        //     var status = $('#status').val();
        //     //          var elemTarget = $("#myDiv");
        //     //          var elemId = 'myDiv';
        //     if (status == 'default') {
        //         //        window.print();
        //         //            $("#myDiv").printElement();
        //         PrintElem("myDiv");
        //     } else {
        //         $('.naap').on('click', function() {
        //             $('.naap-button, .order-section').css('display', 'none');
        //             //                window.print();
        //             //                $("#myDiv").printElement();
        //             PrintElem("orderSection");
        //         });

        //         $('.order').on('click', function() {
        //             $('.naap-button, .size-section').css('display', 'none');
        //             //                window.print();
        //             //                 $("#myDiv").printElement();
        //             PrintElem("sizeSection");
        //         });
        //         $('.full').on('click', function() {
        //             $('.naap-button').css('display', 'none');
        //             //                window.print();
        //             //                  $("#myDiv").printElement();
        //             PrintElem("fullSection");
        //         });
        //     }

        // });

        //new js code
        // Function to print only the order details
        function printOrderDetails() {
            // Hide the fullSection and show only the orderSection
            document.getElementById('sizeSection').style.display = 'none';
            document.getElementById('orderSection').style.display = 'block';

            // Print the order details
            window.print();

            // Show the fullSection again after printing
            document.getElementById('sizeSection').style.display = 'block';
            document.getElementById('orderSection').style.display = 'block';
        }

        //function to print length details
        function printLength() {
            document.getElementById('sizeSection').style.display = 'block';
            document.getElementById('orderSection').style.display = 'none';

            //print details
            window.print();

            //show after prin
            document.getElementById('sizeSection').style.display = 'block';
            document.getElementById('orderSection').style.display = 'block';
        }

        // Function to print the whole page
        function printWholePage() {
            // Print the entire page
            window.print();
        }

        // Event listener for the رسید پرنٹ کریں۔ button
        document.querySelector('.order-print-toolbar .print-order').addEventListener('click', function() {
            printOrderDetails();
        });

        // Event listener for the مکمل رسید پرنٹ کریں۔ button
        document.querySelector('.order-print-toolbar .print-full').addEventListener('click', function() {
            printWholePage();
        });

        // Event listener for the length button
        document.querySelector('.order-print-toolbar .print-length').addEventListener('click', function() {
            printLength();
        });
        //to go back to order
        document.querySelector('.go').addEventListener('click', function() {
            window.history.back();
        });

        //to print reciept
        // var printpage = document.querySelector(".btn button");
        // printpage.addEventListener('click', function() {
        //     window.print();
        // });


        //   to open print blade into new tab
        //   var orderId = {{ $order->id }};

        //  function openPrintViewInNewTab(orderId) {
        //     window.open(url, '_blank'); // Open the URL in a new tab
        // }

        // // Use the window.onload event handler to call the function once when the page loads
        // window.onload = function() {
        //     // Check if the page is the main window, not a popup window (to avoid multiple tabs)
        //     if (window.opener === null) {
        //         openPrintViewInNewTab(orderId);
        //     }
        // };
    </script>

    {{-- <script>
    function printReceipt() {
        // Open a new window with the URL of prints.blade.php
        var printWindow = window.open('{{ route('admin.prints') }}', '_blank', 'width=800,height=600');

        // Check if the new window was successfully opened
        if (printWindow) {
            // Focus on the new window
            printWindow.focus();
        } else {
            // Display an error message if the window couldn't be opened
            alert('Could not open print window. Please ensure pop-ups are allowed for this site.');
        }
    }
</script> --}}



</body>

</html>
