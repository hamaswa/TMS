<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="icon" href="{{ asset('assets/images/favicon.ico') }}" type="image/x-icon">

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <title>Tailor Managment Order Recipt</title>
    <style>
        @font-face {
            font-family: 'Noto Nastaliq Urdu';
            src: url('/assets/fonts/noto-nastaliq-urdu/NotoNastaliqUrdu-VariableFont_wght.woff2') format('woff2');
            font-weight: 200 400;
            font-style: normal;
            font-display: swap;
        }

        body {
            font-family: 'Noto Nastaliq Urdu', serif;
        }

        /* #invoice-POS {
            box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5);
            padding: 2mm;
            margin-left: 10px !important;
            width: 88mm;
            background: #FFF;

        } */
        #invoice-POS {
            box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5);
            padding-left: 5mm;
            /* Remove all padding */
            padding-right: 0mm;
            margin: 0;
            /* Ensure no margin at the top */
            width: 100mm;
            /* Increase the width */
            background: #FFF;
        }

        ::selection {
            background: #f31544;
            color: #FFF;
        }

        ::moz-selection {
            background: #f31544;
            color: #FFF;
        }

        h1,
        h2,
        h3 {
            color: #000;
            /* Darken the font color */
        }

        h1 {
            font-size: 18px;
            /*color: #222;*/
        }

        h2 {
            font-size: 12px;
        }

        h3 {
            font-size: 12px;
            font-weight: 300;
            line-height: 2em;
        }

        p {
            font-size: 10px;
            color: #666;
            line-height: 1px;
        }

        #top,
        #mid,
        #bot {
            /* Targets all id with 'col-' */
            border-bottom: 1px solid #EEE;
        }

        #top {
            min-height: 100px;
        }

        #mid {
            min-height: 80px;
        }

        #bot {
            min-height: 50px;
        }

        #top .logo {
            //float: left;
            height: 60px;
            width: 60px;
            background: url(http://michaeltruong.ca/images/logo1.png) no-repeat;
            background-size: 60px 60px;
        }

        .clientlogo {
            float: left;
            height: 60px;
            width: 60px;
            background: url(http://michaeltruong.ca/images/client.jpg) no-repeat;
            background-size: 60px 60px;
            border-radius: 50px;
        }

        .info {
            display: block;
            margin-left: 0;
        }

        .title {
            float: right;
        }

        .title p {
            text-align: right;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        .tabletitle {
            font-size: 14px;
            background: #EEE;
        }

        .service {
            border-bottom: 1px solid #EEE;
        }

        .item {
            width: 24mm;
        }

        .itemtext {
            font-size: 8px;
        }

        #legalcopy {
            margin-top: 5mm;
        }

        .desing-flex {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .receipt-reference {
            color: #000 !important;
            font-size: 16px !important;
            font-weight: 900 !important;
            line-height: 2 !important;
        }

        .measurement-row {
            align-items: flex-start;
            margin-bottom: 6px;
        }

        /* Nastaliq letters reach far above and below the line, so rows and wrapped notes need tall lines to stay apart. */
        .measurement-row,
        .measurement-row * {
            box-sizing: border-box;
            line-height: 2.1 !important;
        }

        .measurement-label {
            color: #000 !important;
            font-weight: 900 !important;
        }

        /* Long labels wrap inside their column instead of running past the slip. */
        .measurement-row .col-6 {
            min-width: 0;
        }

        .measurement-row .measurement-label {
            max-width: 65%;
            flex-shrink: 1 !important;
            white-space: normal !important;
        }

        /* Right column: the number takes only its own width, so the label has room to stay on one line. */
        .measurement-row .col-6 > div > .measurement-value:first-child:not(.measurement-preference-value) {
            width: auto !important;
            flex: 0 0 auto;
        }

        .measurement-row .col-6 > div > .measurement-value:first-child:not(.measurement-preference-value) + .measurement-label {
            width: auto !important;
            max-width: none;
            flex: 1 1 auto;
        }

        /* English labels are longer than the Urdu ones, so print them a little smaller. */
        html[lang="en"] .measurement-row .measurement-label {
            font-size: 17px !important;
            line-height: 1.25 !important;
        }

        .measurement-value {
            color: #000 !important;
            font-weight: 900 !important;
        }

        .measurement-preference-value {
            flex: 1 1 auto;
            min-width: 0;
            direction: rtl;
            unicode-bidi: plaintext;
            text-align: left;
            white-space: normal;
            word-break: normal;
            overflow-wrap: normal;
        }

        /* The printer's page margin already leaves room at the top, so the header adds only a little. */
        .measurement-header {
            padding: 1mm 8px 0;
            break-inside: avoid;
            page-break-inside: avoid;
        }

        .measurement-logo-wrap {
            margin: 0 !important;
            line-height: 1;
        }

        .measurement-logo {
            display: block;
            width: 82px;
            max-height: 70px;
            margin: 0 auto;
            object-fit: contain;
        }

        .measurement-shop-name {
            margin: 4px 0 7px !important;
            font-weight: 900 !important;
            line-height: 1.4;
            text-align: center;
        }

        .measurement-meta {
            padding-right: 8px !important;
            padding-left: 8px !important;
        }

        .measurement-meta-row {
            display: grid !important;
            grid-template-columns: minmax(0, 42%) minmax(0, 58%);
            align-items: baseline;
            gap: 8px;
            margin-bottom: 5px !important;
            padding-bottom: 4px;
            border-bottom: 1px dotted #aaa;
        }

        .measurement-meta-list {
            margin: 4px 0 6px;
        }

        .meta-row {
            display: grid;
            grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
            direction: rtl;
            border-bottom: 1px dotted #888;
        }

        .meta-row-full {
            grid-template-columns: 1fr;
        }

        .meta-line {
            display: flex;
            align-items: baseline;
            gap: 5px;
            min-width: 0;
            padding: 2px 3px;
            white-space: nowrap;
        }

        /* thin divider between the two cells */
        .meta-row:not(.meta-row-full) .meta-line:first-child {
            border-left: 1px dotted #888;
        }

        .meta-label {
            flex: 0 0 auto;
            color: #000;
            font-size: 14px;
            font-weight: 900;
            line-height: 1.6;
        }

        .meta-value {
            flex: 1 1 auto;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            color: #000;
            font-size: 15px;
            font-weight: 900;
            line-height: 1.6;
            text-align: right;
            unicode-bidi: plaintext;
        }

        .meta-ltr {
            direction: ltr;
            text-align: right;
            font-family: Arial, sans-serif;
            font-size: 14px;
            letter-spacing: 0;
        }

        .measurement-footer,
        .measurement-footer * {
            color: #000 !important;
            font-size: 14px !important;
            font-weight: 900 !important;
            line-height: 1.7 !important;
        }

        .measurement-footer p {
            margin: 0 !important;
        }

        .measurement-footer-contact {
            direction: ltr;
            font-family: Arial, sans-serif;
            letter-spacing: .2px;
        }

        .receipt-builder-credit {
            direction: ltr;
            margin-top: 3px !important;
            padding-top: 3px !important;
            border-top: 1px solid #777;
            font-family: Arial, sans-serif !important;
            font-size: 11px !important;
            font-weight: 800 !important;
            letter-spacing: .15px;
            line-height: 1.35 !important;
            text-align: center;
            white-space: nowrap;
        }

        .order-detail-list {
            display: flex;
            flex-direction: column;
            gap: 8px;
            direction: rtl;
        }

        .order-detail-row {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 14px;
            min-height: 34px;
            padding: 3px 0;
            background-image: linear-gradient(to right, #b8b8b8, #b8b8b8);
            background-position: left bottom;
            background-repeat: no-repeat;
            background-size: 100% 1px;
        }

        .order-detail-label {
            flex: 0 0 66%;
            color: #000;
            font-size: 18px;
            font-weight: 900;
            line-height: 2.1;
            text-align: right;
        }

        .order-detail-value {
            flex: 1 1 34%;
            min-width: 0;
            color: #000;
            direction: ltr;
            font-size: 18px;
            font-weight: 800;
            line-height: 2.1;
            overflow-wrap: anywhere;
            text-align: left;
        }

        .order-footer {
            width: 100%;
            margin-top: 3px;
            padding: 3px 6px 2px;
            border-top: 0;
            text-align: center;
        }

        .order-footer,
        .order-footer * {
            color: #000 !important;
            font-size: 13px !important;
            font-weight: 900 !important;
            line-height: 2 !important;
        }

        .order-footer p {
            margin: 0 !important;
            padding: 0 !important;
        }

        .order-footer-contact {
            direction: ltr;
            font-family: Arial, sans-serif;
            letter-spacing: .2px;
        }

        .order-detail-date {
            font-size: 17px;
            white-space: nowrap;
        }

        .order-tracking-qr {
            direction: rtl;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin: 12px 0 7px;
            padding: 9px 0;
            border-top: 1px solid #999;
            border-bottom: 1px solid #999;
            break-inside: avoid;
            page-break-inside: avoid;
        }

        .order-tracking-qr svg {
            display: block;
            flex: 0 0 105px;
            width: 105px;
            height: 105px;
        }

        .order-tracking-qr__text {
            max-width: 145px;
            color: #000;
            font-size: 12px;
            font-weight: 900;
            line-height: 2.1;
            text-align: right;
        }

        .measurement-serial-row {
            text-align: center;
            padding-bottom: 10px;
            margin: 0;
            line-height: 1.3;
            border-bottom: 1px dotted #bbb;
        }

        .measurement-meta-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 0px;
            width: 100%;
            margin: 0;
            padding: 0;
        }

        .measurement-meta-row {
            display: flex;
            align-items: baseline;
            justify-content: center;
            gap: 3px;
            min-width: 0;
            margin: 0;
            padding: 0;
            line-height: 1.25;
            border-bottom: 1px dotted #bbb;
        }

        .measurement-meta-label {
            flex-shrink: 0;
            white-space: nowrap;
        }

        .measurement-meta-value {
            min-width: 0;
            overflow-wrap: anywhere;
            text-align: center;
        }

        .measurement-meta-row strong {
            margin: 0;
        }

        @media print {
            @page {
                margin: 6mm 0 3mm;
            }

            html,
            body,
            #invoice-POS {
                margin-top: 0 !important;
                padding-top: 0 !important;
            }

            #top {
                height: 0 !important;
                min-height: 0 !important;
                overflow: hidden;
                border: 0;
            }

            #orderSection {
                margin-top: 0 !important;
            }

            #sizeSection {
                margin-top: 0 !important;
                padding-top: 0 !important;
            }

            /* Printed under the order slip (مکمل): keep room to tear between the two. */
            #orderSection:not([style*="display: none"]) + #sizeSection {
                padding-top: 6mm !important;
            }

            #orderSection>p:first-child {
                margin: 0 !important;
                line-height: normal;
            }

            .btn {
                display: none;
            }

            .measurement-meta-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        /* .printbtn{
                position: relative;
            } */
    </style>
    @include('print.partials.bold-ink')
    <style>
        /* The bold-ink outline fills in Nastaliq's thin overlapping strokes, so words print blotchy like spread ink.
           Text here is already solid black at full weight, so this slip prints without the outline. */

    </style>
</head>

<body class="tms-order-print tms-paper-{{ $printConfig['paper'] }}">
    @php
        $displaySerial =
            $receiptSerial ??
            ($orderDetail->customers?->serial_number ?? ($orderDetail->suitNum ?: $orderDetail->sub_customer));
    @endphp

    <div class="serial-label-toolbar" style="text-align:center;padding:10px">
        <a target="_blank" rel="noopener"
            href="{{ route('admin.order-prints', ['id' => $order->id, 'serial_only' => 1]) }}">صرف سیریل پرنٹ</a>
    </div>
    <style>
        @media print {
            .serial-label-toolbar {
                display: none !important
            }
        }
    </style>
    <div id="invoice-POS">

        <center id="top">
            <div class="info">
                <div class="naap-button">
                    <button class="btn btn-primary btn-sm go">آرڈر پر واپس جائیں </button>
                    <button class="btn btn-primary btn-sm naap">پیمائش</button>
                    <button class="btn btn-primary btn-sm order">آرڈر تفصیل</button>
                    <button class="btn btn-primary btn-sm full">مکمل </button>
                </div>
            </div><!--End Info-->
        </center><!--End InvoiceTop-->
        <div id="fullSection">
            <div id="orderSection" style="max-width: 350px; margin-top:-60px;" class="ticket order-section">
                @if ($setting?->logo_url)
                    <p align="center"><img src="{{ $setting->logo_url }}" width="100"
                            alt="{{ $setting->name }} لوگو"></p>
                @endif
                {{-- Pulled up under the logo only; without a logo it would slide off the top of the slip. --}}
                <h1 class="text-center" style="font-size: 16px;font-weight: 600;text-align: center;margin-top:{{ $setting?->logo_url ? '-20px' : '0' }}; ">
                    {{ $setting->name }}
                </h1>
                <div class="pl-3 pr-3">
                    <div class="d-flex justify-content-between ">
                        <div>
                            <h2 class="receipt-reference">{{ $receiptSerial ?? $orderDetail->id }} : رسید نمبر
                            </h2>
                        </div>
                        <div>
                            <h2 class="receipt-reference">{{ date('d-m-Y', strtotime($orderDetail->created_at)) }}</h2>
                        </div>
                    </div>
                    <hr>
                    <div class="order-detail-list">
                        <div class="order-detail-row"><span class="order-detail-label">نام:</span><strong
                                class="order-detail-value">{{ $orderDetail->customers->name }}</strong></div>
                        <div class="order-detail-row"><span class="order-detail-label">سوٹ کی تعداد:</span><strong
                                class="order-detail-value">{{ $orderDetail->suitQuantity }}</strong></div>
                        <div class="order-detail-row"><span class="order-detail-label">سیریل نمبر:</span><strong
                                class="order-detail-value">{{ $displaySerial }}</strong></div>
                        <div class="order-detail-row"><span class="order-detail-label">آرڈر کی رقم:</span><strong
                                class="order-detail-value">{{ $orderDetail->totalPayment }}</strong></div>
                        <div class="order-detail-row"><span class="order-detail-label">موجودہ رقم کی
                                ادائیگی:</span><strong
                                class="order-detail-value">{{ $orderDetail->transactions->first()?->recivedPayment ?? 0 }}</strong>
                        </div>
                        @if ($orderBalance > 0)
                            <div class="order-detail-row"><span class="order-detail-label">موجودہ ادائیگی واجب
                                    الادا:</span><strong class="order-detail-value">{{ $orderBalance }}</strong></div>
                        @endif
                        @if ($previousBalance > 0)
                            <div class="order-detail-row"><span class="order-detail-label">گزشتہ ادائیگی کے
                                    واجبات:</span><strong class="order-detail-value">{{ $previousBalance }}</strong>
                            </div>
                        @endif
                        @if ($latestBalance > 0)
                            <div class="order-detail-row"><span class="order-detail-label">کل ادائیگی واجب
                                    الادا:</span><strong class="order-detail-value">{{ $latestBalance }}</strong></div>
                        @endif
                        <div class="order-detail-row"><span class="order-detail-label">واپسی کی تاریخ:</span><strong
                                class="order-detail-value order-detail-date">{{ $orderDetail->returnDate ? \Illuminate\Support\Carbon::parse($orderDetail->returnDate)->format('d-m-Y') : '—' }}</strong>
                        </div>
                    </div>
                    <aside class="order-tracking-qr" data-tracking-url="{{ $trackingUrl }}"
                        aria-label="آرڈر کی صورتحال دیکھنے کا QR کوڈ">
                        {!! $trackingQrSvg !!}
                        <div class="order-tracking-qr__text">آرڈر کی صورتحال اور بقایا دیکھنے کے لیے اسکین کریں۔</div>
                    </aside>
                    <div>
                        <h3 class="text-center font-weight-bold mt-2" style="font-size:18px;line-height:2.1;">
                            {{ $orderDetail->remarks }}
                        </h3>
                    </div>
                    <div class="order-footer">
                        <p>{!! $setting->address !!}</p>
                        <p class="order-footer-contact">{{ $setting->contact_no }}</p>
                        <p>{{ $setting->note }}</p>
                        <p class="receipt-builder-credit">Built by IT Linked</p>
                    </div>
                </div>

                <!--<p style="text-align:center; font-size: 10px">{{ $setting->note }}</p>-->
                <!--<hr>-->
            </div>
            <div id="sizeSection" style="max-width: 350px;" class="ticket size-section">
                <div class="measurement-header">
                    @if ($setting?->logo_url)
                        <p align="center" class="measurement-logo-wrap"><img class="measurement-logo"
                                src="{{ $setting->logo_url }}" alt="{{ $setting->name }} لوگو"></p>
                    @endif
                    <h1 class="text-center measurement-shop-name">{{ $setting->name }}</h1>
                </div>
                <div class="pl-1 pr-1 measurement-meta">
                    <hr style="margin:2px 0 4px;">
                    {{-- Item serial centered --}}
                    <div class="measurement-meta-list">
                        {{-- Serial: full row (longest value) --}}
                        <div class="meta-row meta-row-full">
                            <div class="meta-line">
                                <span class="meta-label">آئٹم سیریل:</span>
                                <strong class="meta-value meta-ltr">{{ $displaySerial }}</strong>
                            </div>
                        </div>

                        {{-- Customer | Mobile --}}
                        <div class="meta-row">
                            <div class="meta-line">
                                <span class="meta-label">گاہک:</span>
                                <strong class="meta-value">{{ $orderDetail->customers->name }}</strong>
                            </div>
                            <div class="meta-line">
                                <span class="meta-label">موبائل:</span>
                                <strong
                                    class="meta-value meta-ltr">{{ $orderDetail->customers->phone_number1 }}</strong>
                            </div>
                        </div>

                        {{-- Tailor | Return date --}}
                        <div class="meta-row">
                            <div class="meta-line">
                                <span class="meta-label">درزی:</span>
                                <strong class="meta-value">{{ $tailor?->name ?? 'بعد میں' }}</strong>
                            </div>
                            <div class="meta-line">
                                <span class="meta-label">تاریخ واپسی :</span>
                                <strong
                                    class="meta-value meta-ltr">{{ $orderDetail->returnDate ? \Illuminate\Support\Carbon::parse($orderDetail->returnDate)->format('d-m-Y') : '—' }}</strong>
                            </div>
                        </div>
                    </div>
                </div>
                @if ($orderDetail->measurementTemplate)
                    <div class="measurement-meta-cell" style="margin-bottom:7px;text-align:center;">
                        {{ $orderDetail->measurementTemplate->name }}
                    </div>
                @endif
                @if ($orderDetail->measurementTemplate || $printMeasurements->isNotEmpty())

                    {{-- ============ TEMPLATE ORDER (or saved rows without a template): print ONLY these fields ============ --}}
                    @php
                        $tpl = $orderDetail->measurementTemplate;
                        $layoutMap = collect($tpl?->field_layout ?? [])->keyBy('source');

                        $allMeasurements = $printMeasurements->keyBy('source_key');

                        // Use the saved layout to filter only when it actually matches the saved rows.
                        // If the template has no layout (or none of its keys match), print every saved row.
                        if ($layoutMap->isNotEmpty()) {
                            $matched = $allMeasurements->filter(fn($m) => $layoutMap->has($m->source_key));
                            if ($matched->isNotEmpty()) {
                                $allMeasurements = $matched;
                            }
                        }

                    @endphp

                    @if ($allMeasurements->count())
                        <hr style="margin:4px 0 8px;">

                        @include('order.partials.measurement-print-sections')
                    @endif
                @else
                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 mt-2 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:800;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->necktype }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">گلہ</div>
                            </div>
                        </div>
                        <div class="col-6" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->length }}
                                </div>
                                <div style="font-weight:600; font-size:22px">لمبائی</div>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->sleeve }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">کف</div>
                            </div>
                        </div>
                        <div class="col-6 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->arms }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">بازو</div>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 mt-2 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->Daaman }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">دامن</div>
                            </div>
                        </div>
                        <div class="col-6" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div>{{ $orderDetail->customers->teraa }}</div>
                                <div style="font-weight:600; font-size:20px;">تیرا</div>
                            </div>

                        </div>
                    </div>

                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 mt-2 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex; justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->jeab }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">جیب</div>
                            </div>
                        </div>
                        <div class="col-6" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex; justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->senaChorai }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">سینہ چوڑائی</div>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 mt-2 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between mb-2" style="display: flex;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->swingtype }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">سلائی</div>
                            </div>
                        </div>
                        <div class="col-6" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->damanchorai }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">دامن چوڑائی</div>
                            </div>
                        </div>

                    </div>

                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 mt-2 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between mb-1"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->button }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">بٹن</div>
                            </div>
                        </div>
                        <div class="col-6" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->shalwar }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">شلوار</div>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 mt-2 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->plate_type }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">پلیٹ</div>
                            </div>
                        </div>
                        <div class="col-6" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->pancha }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">پانچہ</div>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 mt-2 mb-2" style="width: 45%">

                        </div>
                        <div class="col-6 mt-2 " style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->shalwarGheer }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">شلوار گھیر</div>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 " style="width: 45%">

                        </div>

                        <div class="col-6 mt-2 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->shoulder }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">مونڈا</div>
                            </div>
                        </div>

                    </div>
                    <div class="row" style="display: flex; justify-content: space-between; padding: 0 10px">
                        <div class="col-6 mt-2" style="width: 45%">

                        </div>

                        <div class="col-6  mt-2 mb-2" style="width: 45%">
                            <div class="d-flex justify-content-between"
                                style="display: flex;justify-content: space-between;font-weight:600;">
                                <div style="word-break: break-word; white-space: normal; min-width: 0;">
                                    {{ $orderDetail->customers->chuta }}
                                </div>
                                <div style="font-weight:600; font-size:20px;">چوتھا</div>
                            </div>
                        </div>

                    </div>
                @endif
                <hr>
                <div>
                    <div align="center">
                        <div>
                            @if (filled($orderDetail->remarks))
                                <h3 class="text-center font-weight-400 mt-2" style="font-size: 16px;">
                                    <strong>خصوصی سلائی ہدایت:</strong> {{ $orderDetail->remarks }}
                                </h3>
                            @endif
                        </div>
                        <div class="measurement-footer">
                            <p>{!! $setting->address !!}</p>
                            <p class="measurement-footer-contact">{{ $setting->contact_no }}</p>
                            <p class="receipt-builder-credit">Built by IT Linked</p>
                        </div>
                    </div>
                </div>
                <!--<p style="text-align:center">{{ $setting->note }}</p>-->
            </div>
        </div>
    </div>



    </div><!--End Invoice-->
    <script>
        $(document).ready(function() {

            var status = $('#status').val();

            if (status == 'default') {

                window.print();

            } else {

                $('.naap').on('click', function() {

                    $('.naap-button').hide();
                    $('.order-section').hide();

                    window.print();

                    $('.naap-button').show();
                    $('.order-section').show();

                });

                $('.order').on('click', function() {

                    $('.naap-button').hide();
                    $('.size-section').hide();

                    window.print();

                    $('.naap-button').show();
                    $('.size-section').show();

                });

                $('.full').on('click', function() {

                    $('.naap-button').hide();

                    window.print();

                    $('.naap-button').show();

                });

            }

            // Back Button
            $('.go').on('click', function() {
                window.history.back();
            });

        });

        //   to open print blade into new tab
        //   var orderId = {{ $order->id }};

        //  function openPrintViewInNewTab(orderId) {
        //     window.open(url, '_blank'); // Open the URL in a new tab
        // }

        // // Use the window.onload event handler to call the function once when the page loads
        // window.onload = function() {
        //     // Check if the page is the main window, not a popup window (to avoid multiple tabs)
        //     if (window.opener === null) {
        //         openPrintViewInNewTab(orderId);
        //     }
        // };
    </script>
</body>

</html>
