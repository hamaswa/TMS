@extends('main')

@section('content')
<style>
    .storefront-orders-head{display:flex;justify-content:space-between;align-items:center;gap:18px}
    .storefront-orders-head h1{line-height:1.8}.storefront-order-card{border:1px solid #e0e7f0!important;border-radius:13px!important;background:#fff;box-shadow:0 4px 16px rgba(25,48,78,.04)}.storefront-order-summary{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:18px;align-items:start}.storefront-order-details{margin-top:14px;border:1px solid #e6ebf2;border-radius:10px;background:#f9fbfd}.storefront-order-details>summary{padding:12px 14px;cursor:pointer;color:#3f536d;font-weight:800}.storefront-order-details-body{padding:0 14px 14px}.storefront-order-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.storefront-order-more{width:100%;margin-top:9px}.storefront-order-more>summary{cursor:pointer;color:#687b92;font-size:.88rem;font-weight:700}
    @media(max-width:575px){
        .storefront-orders-head{display:block}
        .storefront-orders-head .btn{display:inline-block;margin-top:10px}
    }
</style>
<section class="main-content" dir="rtl">
    <div class="container">
        <div class="card">
            <div class="card-body">
                <div class="storefront-orders-head mb-3">
                    <div><div class="text-muted small">آن لائن دکان</div><h1 class="h3 mb-0">کپڑے اور سلائی کے آن لائن آرڈرز</h1></div>
                    @if(Auth::user()->hasBusinessPermission('storefront.manage'))<a class="btn btn-outline-secondary" href="{{ route('admin.storefront.edit') }}">دکان کی ترتیب</a>@endif
                </div>
                @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                @if($errors->any())<div class="alert alert-danger">{{ $errors->first() }}</div>@endif
                <form method="GET" class="form-row mb-4">
                    <div class="col-md-6 mb-2"><label for="order_search">حوالہ، نام یا فون</label><input id="order_search" class="form-control" name="search" value="{{ request('search') }}"></div>
                    <div class="col-md-4 mb-2"><label for="order_status">حالت</label><select id="order_status" class="form-control" name="status"><option value="">تمام</option><option value="pending" @selected(request('status')==='pending')>زیرِ انتظار</option><option value="confirmed" @selected(request('status')==='confirmed')>تصدیق شدہ</option><option value="complete" @selected(request('status')==='complete')>مکمل</option><option value="cancelled" @selected(request('status')==='cancelled')>منسوخ</option></select></div>
                    <div class="col-md-2 mb-2 d-flex align-items-end"><button class="btn btn-primary btn-block">تلاش کریں</button></div>
                </form>
                @forelse($orders as $order)
                    @php
                        $statusLabels=['pending'=>'زیرِ انتظار','confirmed'=>'تصدیق شدہ','complete'=>'مکمل','cancelled'=>'منسوخ'];
                        $statusClasses=['pending'=>'warning','confirmed'=>'primary','complete'=>'success','cancelled'=>'secondary'];
                    @endphp
                    <article class="storefront-order-card p-3 mb-3">
                        <div class="storefront-order-summary">
                            <div><strong dir="ltr">{{ $order->reference }}</strong><div>{{ $order->customer->name }} · <span dir="ltr">{{ $order->customer->phone_number1 }}</span></div><small class="text-muted">{{ $order->placed_at->format('d-m-Y h:i A') }}</small></div>
                            <div class="text-left"><span class="badge badge-{{ $statusClasses[$order->status] ?? 'secondary' }}">{{ $statusLabels[$order->status] ?? $order->status }}</span><div class="h5 mt-2">Rs {{ number_format($order->subtotal,2) }}</div></div>
                        </div>
                        <details class="storefront-order-details">
                            <summary>آرڈر کی تفصیل، ادائیگی اور آئٹمز</summary>
                            <div class="storefront-order-details-body">
                        <div class="border rounded bg-light p-3">
                            <div><strong>وصولی:</strong> {{ $order->fulfillment_method === 'delivery' ? 'ڈیلیوری' : 'دکان سے وصولی' }}</div>
                            @if($order->delivery_address)<div class="mt-1"><strong>ڈیلیوری پتہ:</strong> {{ $order->delivery_address }}</div>@endif
                            @if($order->customer_note)<div class="mt-1"><strong>گاہک کا نوٹ:</strong> {{ $order->customer_note }}</div>@endif
                            @if($order->confirmed_at)
                                <small class="text-muted d-block mt-2">تصدیق: {{ $order->confirmed_at->format('d-m-Y h:i A') }}@if($order->confirmedBy) · {{ $order->confirmedBy->name ?: $order->confirmedBy->username }}@endif</small>
                            @endif
                        </div>
                        <div class="mt-2"><strong>ادائیگی:</strong> {{ \App\Models\StorefrontOrder::paymentMethods()[$order->payment_method] ?? $order->payment_method }}
                            @if(\App\Models\StorefrontOrder::requiresManualVerification($order->payment_method))
                                @if($order->payment_sender_phone) · <span dir="ltr">{{ $order->payment_sender_phone }}</span>@endif
                                · <code>{{ $order->payment_reference }}</code>
                                <span class="badge badge-{{ $order->payment_verification_status === \App\Models\StorefrontOrder::VERIFICATION_VERIFIED ? 'success' : ($order->payment_verification_status === \App\Models\StorefrontOrder::VERIFICATION_REJECTED ? 'danger' : 'info') }}">{{ \App\Models\StorefrontOrder::verificationStatuses()[$order->payment_verification_status] ?? 'دستی تصدیق درکار' }}</span>
                            @endif
                            · وصول شدہ <strong>{{ \App\Support\PakistanCurrency::format($order->paid_amount) }}</strong>
                            · بقایا <strong>{{ \App\Support\PakistanCurrency::format($order->balance_amount) }}</strong>
                        </div>
                        @if($order->payment_collected_at)
                            <div class="alert alert-success mt-3 mb-0">
                                <strong>رقم وصول ہو گئی:</strong> {{ \App\Support\PakistanCurrency::format($order->paid_amount) }}
                                · {{ $order->payment_collected_at->format('d-m-Y h:i A') }}
                                @if($order->paymentCollectedBy) · {{ $order->paymentCollectedBy->name ?: $order->paymentCollectedBy->username }}@endif
                                @if($order->payment_collection_reference) · حوالہ: <span dir="ltr">{{ $order->payment_collection_reference }}</span>@endif
                                @if($order->payment_collection_notes)<div class="small mt-1">{{ $order->payment_collection_notes }}</div>@endif
                            </div>
                        @endif
                        @if(\App\Models\StorefrontOrder::requiresManualVerification($order->payment_method))
                            @php
                                $verificationLabels = \App\Models\StorefrontOrder::verificationStatuses();
                                $verificationClass = match($order->payment_verification_status) {
                                    \App\Models\StorefrontOrder::VERIFICATION_VERIFIED => 'success',
                                    \App\Models\StorefrontOrder::VERIFICATION_REJECTED => 'danger',
                                    default => 'warning',
                                };
                            @endphp
                            <div class="border rounded bg-light p-3 mt-3">
                                <div class="d-flex flex-wrap justify-content-between align-items-center">
                                    <strong>{{ \App\Models\StorefrontOrder::paymentMethods()[$order->payment_method] ?? $order->payment_method }} تصدیق</strong>
                                    <span class="badge badge-{{ $verificationClass }}">{{ $verificationLabels[$order->payment_verification_status] ?? $order->payment_verification_status }}</span>
                                </div>
                                @if($order->paymentVerifier)
                                    <small class="text-muted d-block mt-2">
                                        کارروائی: {{ $order->paymentVerifier->name ?: $order->paymentVerifier->username }}
                                        · {{ ($order->payment_verified_at ?: $order->payment_rejected_at)?->format('d-m-Y h:i A') }}
                                    </small>
                                @endif
                                @if($order->payment_verification_notes)
                                    <div class="small mt-2">{{ $order->payment_verification_notes }}</div>
                                @endif
                                @if($order->payment_evidence_path)
                                    <div class="mt-2">
                                        <a class="btn btn-sm btn-outline-primary" target="_blank" rel="noopener" href="{{ route('admin.storefront.orders.payment-evidence', $order) }}">
                                            <i class="fas fa-paperclip ml-1"></i> ادائیگی کا ثبوت دیکھیں
                                        </a>
                                        <small class="text-muted mr-2">{{ $order->payment_evidence_original_name }} · {{ number_format(($order->payment_evidence_size ?? 0) / 1024, 1) }} KB</small>
                                    </div>
                                @else
                                    <div class="small text-muted mt-2">گاہک نے ادائیگی کا ثبوت منسلک نہیں کیا۔</div>
                                @endif
                                @if($order->payment_verification_status !== \App\Models\StorefrontOrder::VERIFICATION_VERIFIED)
                                    <form method="POST" action="{{ route('admin.storefront.orders.payment-verification', $order) }}" class="mt-3">
                                        @csrf @method('PATCH')
                                        <label for="order_payment_notes_{{ $order->id }}">تصدیقی نوٹ <small class="text-muted">(مسترد کرنے پر ضروری)</small></label>
                                        <textarea id="order_payment_notes_{{ $order->id }}" name="payment_verification_notes" class="form-control mb-2" rows="2" maxlength="1000"></textarea>
                                        <button name="decision" value="verified" class="btn btn-success">ادائیگی تصدیق کریں</button>
                                        <button name="decision" value="rejected" class="btn btn-outline-danger">دعویٰ مسترد کریں</button>
                                    </form>
                                @endif
                            </div>
                        @endif
                        <ul class="mt-2 mb-3">
                            @foreach($order->items as $item)<li><strong>کپڑا:</strong> {{ $item->item_name }}@if($item->cloth?->hasSelectableColors()) — {{ $item->color }}@endif، {{ number_format($item->quantity,2) }} میٹر</li>@endforeach
                            @foreach($order->tailoringItems as $item)
                                <li>
                                    <strong>سلائی:</strong> {{ $item->service_name }} — {{ \App\Models\StorefrontTailoringService::measurementMethodLabels()[$item->measurement_method] ?? $item->measurement_method }}
                                    @if($item->standard_size) ({{ $item->standard_size }}) @endif
                                    · {{ $item->quantity }} لباس
                                    @if($item->clothingItem) · {{ $item->clothingItem->item_name }} @endif
                                    @if($item->preferred_date) · مطلوبہ تاریخ {{ $item->preferred_date->format('d-m-Y') }} @endif
                                    <div class="small text-muted">
                                        @if($item->measurementTemplate)ٹیمپلیٹ: {{ $item->measurementTemplate->name }} @endif
                                        @if($item->measurement_values) · پیمائش: {{ collect($item->measurement_values)->map(fn($row) => ($row['label'] ?? $row['source_key'] ?? '').': '.($row['value'] ?? '').($row['unit'] ?? ''))->filter()->join('، ') }} @endif
                                        @if($item->notes) · نوٹ: {{ $item->notes }} @endif
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                            </div>
                        </details>
                        @if($order->returns->isNotEmpty())
                            <div class="border rounded bg-light p-3 mt-3">
                                <strong>جزوی واپسی اور تبدیلی کی تاریخ</strong>
                                @foreach($order->returns as $return)
                                    @php $returnItem = $return->items->first(); @endphp
                                    <div class="small border-top pt-2 mt-2">
                                        <span dir="ltr">{{ $return->reference }}</span>
                                        · {{ \App\Models\StorefrontOrderReturn::types()[$return->type] ?? $return->type }}
                                        · {{ $returnItem?->orderItem?->item_name }}
                                        · {{ number_format((float) $returnItem?->quantity, 2) }} میٹر
                                        @if((float) $return->refund_amount > 0) · {{ \App\Support\PakistanCurrency::format($return->refund_amount) }}@endif
                                        @if($returnItem?->replacementColor) · متبادل رنگ: {{ $returnItem->replacementColor->color }}@endif
                                        · {{ $returnItem?->restocked ? 'اسٹاک میں واپس' : 'خراب / اسٹاک میں واپس نہیں' }}
                                        <span class="d-block text-muted">{{ $return->processed_at->format('d-m-Y h:i A') }}</span>
                                    </div>
                                @endforeach
                            </div>
                        @endif
                        @if($order->status !== \App\Models\StorefrontOrder::STATUS_CANCELLED && $order->refunds->isEmpty())
                            <div class="storefront-order-actions mt-3">
                                @foreach($order->items as $item)
                                    @php
                                        $processedQuantity = (float) $item->returnItems->sum('quantity');
                                        $returnableQuantity = max(0, (float) $item->quantity - $processedQuantity);
                                    @endphp
                                    @if($returnableQuantity > 0)
                                        <details class="border rounded p-2 mb-2">
                                            <summary class="font-weight-bold" style="cursor:pointer">{{ $item->item_name }} — جزوی واپسی یا رنگ تبدیل کریں <small class="text-muted">(دستیاب {{ number_format($returnableQuantity, 2) }} میٹر)</small></summary>
                                            <form method="POST" action="{{ route('admin.storefront.orders.returns.store', $order) }}" class="mt-3"
                                                data-confirm="مقدار، رقم اور اسٹاک کی تفصیل دوبارہ دیکھ لی ہے؟" data-confirm-variant="warning">
                                                @csrf
                                                <input type="hidden" name="order_item_id" value="{{ $item->id }}">
                                                <div class="form-row">
                                                    <div class="col-md-3 mb-2"><label for="return_type_{{ $item->id }}">کارروائی</label><select id="return_type_{{ $item->id }}" name="return_type" class="form-control" required>@foreach(\App\Models\StorefrontOrderReturn::types() as $value=>$label)<option value="{{ $value }}">{{ $label }}</option>@endforeach</select></div>
                                                    <div class="col-md-2 mb-2"><label for="return_quantity_{{ $item->id }}">مقدار (میٹر)</label><input id="return_quantity_{{ $item->id }}" name="quantity" type="number" class="form-control" min="0.01" max="{{ $returnableQuantity }}" step="0.01" required></div>
                                                    <div class="col-md-3 mb-2"><label for="replacement_color_{{ $item->id }}">متبادل رنگ <small class="text-muted">(صرف تبدیلی)</small></label><select id="replacement_color_{{ $item->id }}" name="replacement_cloth_color_id" class="form-control"><option value="">منتخب کریں</option>@foreach($item->cloth?->colors ?? [] as $color)@if($color->id !== $item->cloth_color_id)<option value="{{ $color->id }}">{{ $color->color }} — {{ number_format((float)$color->length,2) }} میٹر</option>@endif @endforeach</select></div>
                                                    @if((float) $order->paid_amount > 0)
                                                        <div class="col-md-2 mb-2"><label for="partial_refund_method_{{ $item->id }}">رقم واپسی <small class="text-muted">(صرف واپسی)</small></label><select id="partial_refund_method_{{ $item->id }}" name="refund_method" class="form-control"><option value="">منتخب کریں</option>@foreach(\App\Models\StorefrontOrderRefund::methods() as $value=>$label)<option value="{{ $value }}">{{ $label }}</option>@endforeach</select></div>
                                                        <div class="col-md-2 mb-2"><label for="partial_refund_reference_{{ $item->id }}">ادائیگی حوالہ</label><input id="partial_refund_reference_{{ $item->id }}" name="refund_reference" class="form-control" maxlength="100" dir="ltr"></div>
                                                    @endif
                                                </div>
                                                <div class="form-row align-items-end">
                                                    <div class="col-md-7 mb-2"><label for="return_notes_{{ $item->id }}">اندرونی نوٹ <small class="text-muted">(اختیاری)</small></label><input id="return_notes_{{ $item->id }}" name="return_notes" class="form-control" maxlength="1000"></div>
                                                    <div class="col-md-3 mb-2"><div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="restock_{{ $item->id }}" name="restock" value="1" checked><label class="custom-control-label" for="restock_{{ $item->id }}">کپڑا قابلِ فروخت ہے، اسٹاک میں واپس کریں</label></div></div>
                                                    <div class="col-md-2 mb-2"><button class="btn btn-warning btn-block">درج کریں</button></div>
                                                </div>
                                            </form>
                                        </details>
                                    @endif
                                @endforeach
                            </div>
                        @endif
                        @if($order->refunds->isNotEmpty())
                            @foreach($order->refunds as $refund)
                                <div class="alert alert-info mt-3 mb-0">
                                    <strong>رقم واپس کی گئی:</strong> {{ \App\Support\PakistanCurrency::format($refund->amount) }}
                                    · {{ \App\Models\StorefrontOrderRefund::methods()[$refund->method] ?? $refund->method }}
                                    · <span dir="ltr">{{ $refund->reference }}</span>
                                    @if($refund->external_reference) · بیرونی حوالہ: <span dir="ltr">{{ $refund->external_reference }}</span>@endif
                                    <small class="d-block mt-1">{{ $refund->refunded_at->format('d-m-Y h:i A') }}</small>
                                </div>
                            @endforeach
                        @endif
                        @if(in_array($order->status, [\App\Models\StorefrontOrder::STATUS_PENDING, \App\Models\StorefrontOrder::STATUS_CONFIRMED], true))
                            <div class="mt-3">
                                @if($order->status === \App\Models\StorefrontOrder::STATUS_PENDING)
                                    <form method="POST" action="{{ route('admin.storefront.orders.update',$order) }}" class="d-inline-block ml-2">@csrf @method('PATCH')<input type="hidden" name="status" value="confirmed"><button class="btn btn-primary" @disabled(\App\Models\StorefrontOrder::requiresManualVerification($order->payment_method) && $order->payment_verification_status !== \App\Models\StorefrontOrder::VERIFICATION_VERIFIED)>آرڈر کی تصدیق کریں</button></form>
                                @else
                                    <a class="btn btn-dark ml-2" target="_blank" rel="noopener" href="{{ route('admin.storefront.orders.dispatch-print', $order) }}"><i class="fas fa-print ml-1"></i> ڈسپیچ شیٹ پرنٹ کریں</a>
                                    @if(in_array($order->payment_method, [\App\Models\StorefrontOrder::PAYMENT_COD, \App\Models\StorefrontOrder::PAYMENT_UNPAID], true) && (float) $order->balance_amount > 0)
                                        <details class="border border-success rounded p-3 mt-3">
                                            <summary class="font-weight-bold text-success" style="cursor:pointer">مکمل رقم وصول کریں</summary>
                                            <form method="POST" action="{{ route('admin.storefront.orders.collect-payment',$order) }}" class="mt-3" data-confirm="کیا مکمل رقم واقعی وصول ہو گئی ہے؟">
                                                @csrf @method('PATCH')
                                                <p>وصول کی جانے والی رقم: <strong>{{ \App\Support\PakistanCurrency::format($order->balance_amount) }}</strong></p>
                                                <div class="form-row">
                                                    <div class="col-md-5 mb-2"><label for="collection_reference_{{ $order->id }}">رسید / ادائیگی حوالہ <small class="text-muted">(اختیاری)</small></label><input id="collection_reference_{{ $order->id }}" name="payment_collection_reference" class="form-control" maxlength="100" dir="ltr"></div>
                                                    <div class="col-md-7 mb-2"><label for="collection_notes_{{ $order->id }}">اندرونی نوٹ <small class="text-muted">(اختیاری)</small></label><input id="collection_notes_{{ $order->id }}" name="payment_collection_notes" class="form-control" maxlength="1000"></div>
                                                </div>
                                                <button class="btn btn-success">مکمل رقم وصول درج کریں</button>
                                            </form>
                                        </details>
                                    @endif
                                    <form method="POST" action="{{ route('admin.storefront.orders.update',$order) }}" class="d-inline-block ml-2 mt-2">@csrf @method('PATCH')<input type="hidden" name="status" value="complete"><button class="btn btn-success" @disabled($order->payment_method === \App\Models\StorefrontOrder::PAYMENT_COD && (float) $order->balance_amount > 0)>مکمل کریں</button></form>
                                    @if($order->payment_method === \App\Models\StorefrontOrder::PAYMENT_COD && (float) $order->balance_amount > 0)<small class="text-danger d-block mt-1">COD آرڈر مکمل کرنے سے پہلے رقم وصول درج کریں۔</small>@endif
                                @endif
                                <details class="storefront-order-more"><summary>مزید کارروائیاں</summary><div class="mt-2">
                                @if($order->returns->isNotEmpty())
                                    <div class="alert alert-light mt-2 mb-0">اس آرڈر پر جزوی واپسی یا تبدیلی موجود ہے، اس لیے مکمل منسوخی دستیاب نہیں۔ باقی مقدار الگ واپسی یا تبدیلی سے درج کریں۔</div>
                                @elseif((float) $order->paid_amount <= 0)
                                    <form method="POST" action="{{ route('admin.storefront.orders.update',$order) }}" class="d-inline-block" data-confirm="آرڈر منسوخ کرنے سے اسٹاک اور گاہک کا بقایا واپس ہوگا۔ جاری رکھیں؟">@csrf @method('PATCH')<input type="hidden" name="status" value="cancelled"><button class="btn btn-outline-danger">منسوخ کریں</button></form>
                                @else
                                    <div class="border border-danger rounded p-3 mt-3">
                                        <h2 class="h5">مکمل رقم واپس کر کے آرڈر منسوخ کریں</h2>
                                        <p class="mb-3">واپس کی جانے والی رقم: <strong>{{ \App\Support\PakistanCurrency::format($order->paid_amount) }}</strong>۔ یہ کارروائی اسٹاک واپس کرے گی اور ایک قابلِ جانچ مالی اندراج بنائے گی۔</p>
                                        <form method="POST" action="{{ route('admin.storefront.orders.update',$order) }}" data-confirm="کیا رقم واقعی گاہک کو واپس کر دی گئی ہے؟ یہ کارروائی دوبارہ نہیں کی جا سکے گی۔">
                                            @csrf @method('PATCH')
                                            <input type="hidden" name="status" value="cancelled">
                                            <div class="form-row">
                                                <div class="col-md-4 mb-2"><label for="refund_method_{{ $order->id }}">رقم واپسی کا طریقہ</label><select id="refund_method_{{ $order->id }}" name="refund_method" class="form-control" required>@foreach(\App\Models\StorefrontOrderRefund::methods() as $value=>$label)<option value="{{ $value }}">{{ $label }}</option>@endforeach</select></div>
                                                <div class="col-md-4 mb-2"><label for="refund_reference_{{ $order->id }}">واپسی کا بیرونی حوالہ <small class="text-muted">(نقد کے علاوہ ضروری)</small></label><input id="refund_reference_{{ $order->id }}" name="refund_reference" class="form-control" maxlength="100" dir="ltr"></div>
                                                <div class="col-md-4 mb-2"><label for="refund_notes_{{ $order->id }}">اندرونی نوٹ <small class="text-muted">(اختیاری)</small></label><input id="refund_notes_{{ $order->id }}" name="refund_notes" class="form-control" maxlength="1000"></div>
                                            </div>
                                            <button class="btn btn-danger">رقم واپس اور آرڈر منسوخ کریں</button>
                                        </form>
                                    </div>
                                @endif
                                </div></details>
                            </div>
                        @endif
                    </article>
                @empty
                    <div class="alert alert-light text-center">کوئی آن لائن آرڈر موجود نہیں۔</div>
                @endforelse
                {{ $orders->links() }}
            </div>
        </div>
    </div>
</section>
@endsection
