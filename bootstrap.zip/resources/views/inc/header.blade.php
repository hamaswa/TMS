@php($isSuperAdminSurface = request()->is('administrator') || request()->is('administrator/*'))
@php($isSuperAdmin = $isSuperAdminSurface || (Auth::check() && Auth::user()->hasRole('administrative')))
@php($isEnglishUi = $isSuperAdmin || ($uiLocale ?? 'ur') === 'en')
@php($enabledWorkspaces = Auth::check() && Auth::user()->isBusinessMember() ? Auth::user()->enabledModules() : [])
@php($hasMultipleWorkspaces = count($enabledWorkspaces) > 1)
@php($canShopSales = Auth::check() && Auth::user()->hasModule('clothing') && Auth::user()->hasBusinessPermission('clothing.sales'))
@php($canShopInventory = Auth::check() && Auth::user()->hasBusinessPermission('clothing.inventory'))
@php($canShopPurchases = Auth::check() && Auth::user()->hasBusinessPermission('clothing.purchases'))
@php($canShopSuppliers = Auth::check() && Auth::user()->hasBusinessPermission('clothing.suppliers'))
@php($canTailorCustomers = Auth::check() && Auth::user()->hasBusinessPermission('tailoring.customers'))
@php($canTailorWorkshop = Auth::check() && Auth::user()->hasBusinessPermission('tailoring.workshop'))
@php($canTailorOrders = Auth::check() && Auth::user()->hasBusinessPermission('tailoring.orders'))
@php($canTailorTailors = Auth::check() && Auth::user()->hasBusinessPermission('tailoring.tailors'))
@php($canTailorConfiguration = Auth::check() && Auth::user()->hasBusinessPermission('tailoring.configuration'))
@php($canCustomerBalances = Auth::check() && Auth::user()->hasBusinessPermission('customers.balances'))
@php($unreadNotificationCount = Auth::check() && Auth::user()->isBusinessOwner() ? Auth::user()->unreadNotifications()->count() : 0)
@php($salesAttentionCount = $canShopSales && \Illuminate\Support\Facades\Schema::hasTable('sale_sessions') ? \App\Models\SaleSession::where('user_id', Auth::user()->businessOwnerId())->where('status', 'needs_attention')->count() : 0)
@php($salesOpenCount = $canShopSales && \Illuminate\Support\Facades\Schema::hasTable('sale_sessions') ? \App\Models\SaleSession::where('user_id', Auth::user()->businessOwnerId())->whereIn('status', ['active','needs_attention','claimed'])->count() : 0)
@php($isTailorOfflineActor = Session::get('tailor') && session()->has('tailor_id'))
@php($isBusinessOfflineActor = Auth::check() && Auth::user()->isBusinessMember())
@php($offlineCapable = ! $isSuperAdmin && ($isTailorOfflineActor || $isBusinessOfflineActor))
@php($offlineSyncUrl = $isTailorOfflineActor ? route('tailor.offline.sync') : ($canTailorWorkshop ? route('admin.offline.sync') : null))
@php($offlineManifestUrl = $isTailorOfflineActor ? route('tailor.offline.manifest') : ($isBusinessOfflineActor ? route('admin.offline.manifest') : null))
@php($offlineActorKey = $isTailorOfflineActor ? 'tailor:'.session('tailor_id') : ($isBusinessOfflineActor ? 'user:'.Auth::id() : null))
@php($isLocalShopHub = config('shop_hub.mode') === 'hub')
@php($pendingHubEvents = $isLocalShopHub && Auth::check() && Auth::user()->isBusinessMember() && \Illuminate\Support\Facades\Schema::hasTable('shop_hub_events') ? \App\Models\ShopHubEvent::where('business_owner_user_id', Auth::user()->businessOwnerId())->where('status', 'pending')->count() : 0)
<!doctype html>
<html lang="{{ $isEnglishUi ? 'en' : 'ur' }}" dir="{{ $isEnglishUi ? 'ltr' : 'rtl' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="tms-shop-connection" content="{{ $isLocalShopHub ? 'shop' : 'cloud' }}">
    @if($isLocalShopHub && config('shop_hub.id'))<meta name="tms-shop-hub-id" content="{{ config('shop_hub.id') }}">@endif
    @if($offlineCapable)
        <meta name="theme-color" content="#174f78">
        <meta name="tms-offline-enabled" content="1">
        <meta name="tms-offline-actor" content="{{ $offlineActorKey }}">
        @if($offlineManifestUrl)<meta name="tms-offline-manifest-url" content="{{ $offlineManifestUrl }}">@endif
        @if($offlineSyncUrl)<meta name="tms-offline-sync-url" content="{{ $offlineSyncUrl }}">@endif
        <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
        <link rel="apple-touch-icon" href="{{ asset('assets/images/web-app-manifest-192x192.png') }}">
    @endif
    <title>{{ $isSuperAdmin ? 'BuyNStitch Super Admin' : 'BuyNStitch' }}</title>
    <link rel="icon" href="{{ asset('assets/images/favicon.ico') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/main.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/responsive.css') }}" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.css" rel="stylesheet">
    <style data-ltr-ready>
        body{direction:{{ $isEnglishUi ? 'ltr' : 'rtl' }};text-align:{{ $isEnglishUi ? 'left' : 'right' }};background:#f5f7fa;color:#243b53;font-family:{{ $isEnglishUi ? 'Arial,sans-serif' : '"Noto Nastaliq Urdu","Noto Sans Arabic",Tahoma,Arial,sans-serif' }}}.tms-nav{background:linear-gradient(90deg,#102a43,#174f78);box-shadow:0 5px 18px rgba(15,42,67,.18)}.tms-nav .navbar-brand{font-weight:800;letter-spacing:.04em}.tms-nav .nav-link{color:rgba(255,255,255,.82)!important;font-weight:600;padding:.8rem .72rem!important}.tms-nav .nav-link:hover{color:#fff!important}.tms-nav .dropdown-menu{direction:{{ $isEnglishUi ? 'ltr' : 'rtl' }};text-align:{{ $isEnglishUi ? 'left' : 'right' }};border:0;border-radius:12px;box-shadow:0 14px 35px rgba(31,45,61,.18);padding:.5rem}.tms-nav .dropdown-item{border-radius:8px;padding:.55rem .8rem}.module-pill{font-size:.65rem;border:1px solid rgba(255,255,255,.25);border-radius:999px;padding:.25rem .5rem;color:#bfe8f3}.main-content{direction:{{ $isEnglishUi ? 'ltr' : 'rtl' }};text-align:{{ $isEnglishUi ? 'left' : 'right' }};min-height:calc(100vh - 70px)}body{top:0!important}
        .flatpickr-calendar{direction:{{ $isEnglishUi ? 'ltr' : 'rtl' }};border:1px solid #dfe7f1;border-radius:12px;box-shadow:0 14px 35px rgba(31,45,61,.18);font-family:{{ $isEnglishUi ? 'Arial,sans-serif' : '"Noto Nastaliq Urdu","Noto Sans Arabic",Tahoma,Arial,sans-serif' }}}
        .flatpickr-calendar.arrowTop:before,.flatpickr-calendar.arrowTop:after{border-bottom-color:#fff}.flatpickr-months{padding:6px 4px 2px}.flatpickr-months .flatpickr-month{height:42px;color:#14213d}.flatpickr-current-month{padding-top:5px;font-size:1rem}.flatpickr-current-month .flatpickr-monthDropdown-months,.flatpickr-current-month input.cur-year{font-weight:700}.flatpickr-weekday{color:#718096!important;font-weight:700!important}.flatpickr-day{border-radius:8px}.flatpickr-day.today{border-color:#1769ef;color:#1769ef}.flatpickr-day.selected,.flatpickr-day.startRange,.flatpickr-day.endRange,.flatpickr-day.selected:hover{border-color:#1769ef;background:#1769ef;color:#fff}.flatpickr-day:hover{border-color:#e7efff;background:#e7efff}.flatpickr-input[readonly]:not([type=hidden]){cursor:pointer;background-color:#fff}.flatpickr-input.form-control:not([type=hidden]){padding-left:40px;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%2356677f' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='4' width='18' height='18' rx='2' ry='2'/%3E%3Cline x1='16' y1='2' x2='16' y2='6'/%3E%3Cline x1='8' y1='2' x2='8' y2='6'/%3E%3Cline x1='3' y1='10' x2='21' y2='10'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:left 12px center}
        html[lang="ur"] body{line-height:1.9}
        html[lang="ur"] h1,html[lang="ur"] h2,html[lang="ur"] h3,html[lang="ur"] h4,html[lang="ur"] h5,html[lang="ur"] h6{line-height:1.65}
        html[lang="ur"] p,html[lang="ur"] small,html[lang="ur"] .small,html[lang="ur"] .form-text{line-height:1.9}
        html[lang="ur"] .form-group>label:not(.custom-control-label),html[lang="ur"] label.form-label{display:block;line-height:1.9;min-height:1.9em;margin-bottom:.4rem!important}
        html[lang="ur"] .form-control{height:auto;min-height:48px;padding-top:.55rem;padding-bottom:.65rem;line-height:1.7}
        html[lang="ur"] textarea.form-control{height:auto;min-height:110px}
        html[lang="ur"] .input-group-text{min-height:48px;line-height:1.7}
        html[lang="ur"] .btn{line-height:1.7}
        html[lang="ur"] .badge{line-height:1.65;padding-top:.35em;padding-bottom:.45em}
        .sales-attention-modal .modal-content{border:0;border-radius:18px;overflow:hidden;box-shadow:0 24px 70px rgba(15,42,67,.28)}
        .sales-attention-modal .modal-header{border:0;background:linear-gradient(135deg,#102a43,#1769ef);color:#fff;padding:1.25rem 1.4rem}
        .sales-attention-modal .modal-title{font-weight:900}.sales-attention-modal .close{color:#fff;opacity:.85;text-shadow:none}
        .sales-attention-modal .modal-body{padding:1.4rem}.sales-attention-icon{display:flex;align-items:center;justify-content:center;width:62px;height:62px;margin:0 auto 1rem;border-radius:20px;background:#fff3cd;color:#966200;font-size:1.65rem}
        .sales-attention-message{text-align:center;color:#425466;margin-bottom:1rem}.sales-attention-details{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:.65rem}
        .sales-attention-detail{padding:.8rem;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc;text-align:center}.sales-attention-detail small{display:block;color:#718096}.sales-attention-detail strong{display:block;color:#123b5d;margin-top:.2rem}
        .sales-attention-modal .modal-footer{border:0;padding:0 1.4rem 1.4rem;gap:.5rem}@media(max-width:575.98px){.sales-attention-details{grid-template-columns:1fr}.sales-attention-modal .modal-dialog{margin:.75rem}}
    </style>
    <script src="{{ asset('assets/js/jquery-3.5.1.min.js') }}"></script>
    <script src="{{ asset('assets/js/popper.min.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
    @stack('styles')
</head>
<body>
<header class="tms-nav sticky-top"><div class="container-fluid px-3 px-lg-4"><nav class="navbar navbar-expand-xl navbar-dark p-0">
    @if(Session::get('tailor'))
        <a class="navbar-brand" href="{{ url('tailor/tailor-dashboard') }}"><i class="fas fa-cut mr-2"></i>BuyNStitch</a>
    @else
        <a class="navbar-brand" href="{{ $isSuperAdmin ? route('administrator.index') : route('admin.home') }}"><i class="fas fa-cut mr-2"></i>BuyNStitch</a>
    @endif
    @unless($isSuperAdmin)<span class="ml-auto mr-xl-3 order-xl-last d-inline-flex align-items-center">@unless($isEnglishUi)<button type="button" id="tmsUrduKeyboardToggle" class="tms-ukb-toggle" aria-pressed="false" title="اردو کی بورڈ"><i class="fas fa-keyboard"></i><span class="d-none d-sm-inline">اردو کی بورڈ</span> <span data-state>بند</span></button>@endunless @include('inc.language-switch', ['variant' => 'nav'])</span>@endunless
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#tmsNavigation" aria-controls="tmsNavigation" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="tmsNavigation"><ul class="navbar-nav mr-auto align-items-xl-center">
        @if(Session::get('tailor'))
            <li class="nav-item"><a class="nav-link" href="{{ route('tailor.jobs.index') }}">میرے کام</a></li><li class="nav-item"><a class="nav-link" href="{{ url('tailor/logout') }}">لاگ آؤٹ</a></li>
        @elseif(Auth::check() && Auth::user()->isBusinessMember())
            <li class="nav-item"><a class="nav-link" href="{{ route('admin.home') }}">ڈیش بورڈ</a></li>
            @if(Auth::user()->hasModule('tailoring'))
                <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="tailoringMenu" data-toggle="dropdown">ٹیلرنگ <span class="module-pill ml-1">فعال</span></a><div class="dropdown-menu" aria-labelledby="tailoringMenu">
                    @if($canTailorOrders || $canTailorWorkshop)<a class="dropdown-item" href="{{ route('admin.order.total') }}"><i class="fas fa-route fa-fw ml-2 text-primary"></i>ٹیلرنگ ورک فلو</a>@endif
                    @if($canTailorCustomers)<a class="dropdown-item" href="{{ route('admin.Customers.index') }}"><i class="fas fa-user-friends fa-fw ml-2 text-primary"></i>گاہک اور پیمائش</a>@endif
                    @if($canTailorTailors && Auth::user()->hasBusinessPermission('team.manage'))<div class="dropdown-divider"></div><a class="dropdown-item" href="{{ route('admin.team.index') }}"><i class="fas fa-users-cog fa-fw ml-2 text-primary"></i>ٹیم اور کاریگر</a>@endif
                    @if($canTailorConfiguration)<div class="dropdown-divider"></div><a class="dropdown-item" href="{{ route('admin.OptionType.index') }}"><i class="fas fa-sliders-h fa-fw ml-2 text-primary"></i>پیمائش اور سلائی کے اختیارات</a>@endif
                    @if($canTailorConfiguration)<a class="dropdown-item" href="{{ route('admin.measurement-templates.index') }}"><i class="fas fa-clipboard-list fa-fw ml-2 text-primary"></i>لباس اور پیمائش ٹیمپلیٹس</a><a class="dropdown-item" href="{{ route('admin.design.index') }}"><i class="fas fa-palette fa-fw ml-2 text-primary"></i>سلائی ڈیزائن</a>@endif
                </div></li>
            @endif
            @if(Auth::user()->hasModule('clothing'))
                <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="clothingMenu" data-toggle="dropdown">کپڑے کی خرید و فروخت <span class="module-pill ml-1">فعال</span></a><div class="dropdown-menu" aria-labelledby="clothingMenu">
                    @if($canShopInventory)
                    <a class="dropdown-item" href="{{ route('admin.stock.index') }}"><i class="fas fa-layer-group fa-fw ml-2 text-info"></i>اسٹاک</a>
                    <a class="dropdown-item" href="{{ route('admin.cloth.index') }}"><i class="fas fa-swatchbook fa-fw ml-2 text-info"></i>کپڑے کی فہرست</a>
                    <a class="dropdown-item" href="{{ route('admin.clothtype.index') }}"><i class="fas fa-tags fa-fw ml-2 text-info"></i>کپڑے کی اقسام</a>
                    <a class="dropdown-item" href="{{ route('admin.clothcategory.index') }}"><i class="fas fa-sitemap fa-fw ml-2 text-info"></i>کپڑے کی کیٹیگریز</a>
                    <a class="dropdown-item" href="{{ route('admin.clothbrand.index') }}"><i class="fas fa-copyright fa-fw ml-2 text-info"></i>کپڑے کے برانڈز</a>
                    <a class="dropdown-item" href="{{ route('admin.inventory-ledger.index') }}"><i class="fas fa-exchange-alt fa-fw ml-2 text-info"></i>اسٹاک کھاتہ</a>
                    <a class="dropdown-item" href="{{ route('admin.inventory-valuation.index') }}"><i class="fas fa-balance-scale fa-fw ml-2 text-info"></i>اسٹاک کی مالیت</a>
                    @endif
                    @if($canShopSales)<a class="dropdown-item" href="{{ route('admin.counter-orders.start') }}"><i class="fas fa-cash-register fa-fw ml-2 text-info"></i>نیا آرڈر</a><a class="dropdown-item" href="{{ route('admin.sales-sessions.index') }}"><i class="fas fa-inbox fa-fw ml-2 text-warning"></i>سیلز اِن باکس @if($salesOpenCount)<span class="badge badge-danger">{{ min($salesOpenCount,99) }}</span>@endif</a>@endif
                    @if($canShopSales && Auth::user()->business?->storefront && Auth::user()->business->subscriptionAllowsFeature('allow_storefront'))<a class="dropdown-item" href="{{ route('admin.storefront.orders.index') }}"><i class="fas fa-shopping-bag fa-fw ml-2 text-info"></i>آن لائن آرڈرز</a>@endif
                    @if($canShopPurchases)<a class="dropdown-item" href="{{ route('admin.purchases.index') }}"><i class="fas fa-truck-loading fa-fw ml-2 text-info"></i>خریداری</a>@endif
                    @if($canShopSuppliers)<a class="dropdown-item" href="{{ route('admin.suppliers.index') }}"><i class="fas fa-building fa-fw ml-2 text-info"></i>سپلائرز</a>@endif
                </div></li>
            @endif
            <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="businessMenu" data-toggle="dropdown">کاروبار</a><div class="dropdown-menu" aria-labelledby="businessMenu">
                @if(Auth::user()->hasBusinessPermission('finance.view'))<a class="dropdown-item" href="{{ route('admin.financial-reports.index') }}"><i class="fas fa-chart-line fa-fw ml-2 text-success"></i>مالیاتی ڈیش بورڈ</a>@endif
                @if($canCustomerBalances)<a class="dropdown-item" href="{{ route('admin.customer-accounts.index') }}"><i class="fas fa-address-book fa-fw ml-2 text-success"></i>گاہکوں کے کھاتے</a>@endif
                @if(Auth::user()->hasBusinessPermission('expenses.manage'))<a class="dropdown-item" href="{{ route('admin.dailyexpense.index') }}"><i class="fas fa-receipt fa-fw ml-2 text-warning"></i>روزانہ اخراجات</a>
                <a class="dropdown-item" href="{{ route('admin.expense.index') }}"><i class="fas fa-calendar-alt fa-fw ml-2 text-warning"></i>ماہانہ اخراجات</a>@endif
                @if(Auth::user()->hasBusinessPermission('team.manage'))<div class="dropdown-divider"></div><a class="dropdown-item" href="{{ route('admin.team.index') }}"><i class="fas fa-users-cog fa-fw ml-2 text-primary"></i>ٹیم اور کاریگر</a>@endif
                @if(Auth::user()->hasBusinessPermission('activity.view'))<a class="dropdown-item" href="{{ route('admin.activity.index') }}"><i class="fas fa-history fa-fw ml-2 text-primary"></i>ملازمین کی سرگرمی</a>@endif
                @if(Auth::user()->hasBusinessPermission('storefront.manage'))<div class="dropdown-divider"></div><a class="dropdown-item" href="{{ route('admin.storefront.edit') }}"><i class="fas fa-globe-asia fa-fw ml-2 text-info"></i>آن لائن دکان</a>@endif
            </div></li>
        @elseif(Auth::check() && Auth::user()->hasRole('administrative'))
            <li class="nav-item"><a class="nav-link" href="{{ route('administrator.index') }}">Clients</a></li><li class="nav-item"><a class="nav-link" href="{{ route('administrator.subscriptions.index') }}">Subscriptions</a></li><li class="nav-item"><a class="nav-link" href="{{ route('administrator.subscription-plans.index') }}">Plans</a></li><li class="nav-item"><a class="nav-link" href="{{ route('administrator.payment-settings.edit') }}">Payments @php($pendingPlanRequests = \App\Models\SubscriptionPlanRequest::pending()->count())@if($pendingPlanRequests)<span class="badge badge-warning">{{ $pendingPlanRequests }}</span>@endif</a></li><li class="nav-item"><a class="nav-link" href="{{ route('administrator.marketplace.index') }}">Marketplace</a></li><li class="nav-item"><a class="nav-link" href="{{ route('administrator.create') }}">Create client</a></li>
        @endif
    </ul>
    @auth<ul class="navbar-nav ml-auto">@if($isLocalShopHub)<li class="nav-item"><span class="nav-link" title="اسی Wi-Fi پر موجود دکان کے صارفین مقامی طور پر منسلک ہیں"><i class="fas fa-wifi text-success ml-1"></i>دکان سے منسلک @if($pendingHubEvents)<span class="badge badge-warning" title="کلاؤڈ پر بھیجنے کے لیے باقی تبدیلیاں">{{ min($pendingHubEvents,99) }}</span>@endif</span></li>@endif @if($canShopSales)<li class="nav-item"><a class="nav-link" href="{{ route('admin.sales-sessions.index') }}" aria-label="سیلز اِن باکس" title="سیلز اِن باکس"><i class="fas fa-inbox"></i><span id="sales-inbox-badge" class="badge badge-danger" style="{{ $salesOpenCount ? '' : 'display:none' }}">{{ min($salesOpenCount,99) }}</span></a></li>@endif @if(Auth::user()->isBusinessOwner())<li class="nav-item"><a class="nav-link" href="{{ route('admin.notifications.index') }}" aria-label="اطلاعات"><i class="fas fa-bell"></i>@if($unreadNotificationCount)<span class="badge badge-danger">{{ min($unreadNotificationCount,99) }}</span>@endif</a></li>@endif<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="accountMenu" data-toggle="dropdown"><i class="fas fa-user-circle mr-1"></i>{{ Auth::user()->name }}</a><div class="dropdown-menu dropdown-menu-right" aria-labelledby="accountMenu">
        @if($isSuperAdmin)<a class="dropdown-item" href="{{ route('administrator.password.edit') }}">Change password</a><div class="dropdown-divider"></div>@elseif(Auth::user()->isBusinessOwner())<a class="dropdown-item" href="{{ route('admin.subscription.index') }}">سبسکرپشن اور ادائیگی</a><a class="dropdown-item" href="{{ route('admin.setting.index') }}">دکان کی ترتیبات</a><a class="dropdown-item" href="{{ route('admin.users') }}">اکاؤنٹ کی تفصیل</a><div class="dropdown-divider"></div>@else<a class="dropdown-item" href="{{ route('employee.password.edit') }}">پاس ورڈ تبدیل کریں</a><div class="dropdown-divider"></div>@endif
        <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">{{ $isSuperAdmin ? 'Logout' : 'لاگ آؤٹ' }}</a><form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">@csrf</form>
    </div></li></ul>@endauth
    </div>
</nav></div></header>
@include('inc.sidebar')
@if($canShopSales)
<div class="modal fade sales-attention-modal" id="salesAttentionModal" tabindex="-1" role="dialog" aria-labelledby="salesAttentionModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="salesAttentionModalTitle"><i class="fas fa-mobile-alt ml-2"></i>نئی موبائل فروخت</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="بند کریں"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <div class="sales-attention-icon"><i class="fas fa-bell"></i></div>
                <p class="sales-attention-message" id="sales-session-attention-message">سیلز ایجنٹ نے نئی فروخت آپ کو بھیجی ہے۔</p>
                <div class="sales-attention-details">
                    <div class="sales-attention-detail"><small>سیلز ایجنٹ</small><strong id="sales-session-attention-agent">—</strong></div>
                    <div class="sales-attention-detail"><small>گاہک</small><strong id="sales-session-attention-customer">—</strong></div>
                    <div class="sales-attention-detail"><small>آئٹمز</small><strong id="sales-session-attention-items">0</strong></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">بعد میں</button>
                <a class="btn btn-primary" id="sales-session-attention-open" href="{{ route('admin.sales-sessions.index') }}"><i class="fas fa-external-link-alt ml-1"></i>فروخت کھولیں</a>
            </div>
        </div>
    </div>
</div>
@push('scripts')
<script>
(function () {
    let knownOpen = {{ (int) $salesOpenCount }};
    const showUrl = @json(route('admin.sales-sessions.show', '__UUID__'));
    // Shared by every tab and kept across restarts, so each mobile sale pops up only once per browser.
    const seenStorageKey = @json('tms-sales-attention-seen-'.Auth::id());
    let seenAttention = new Set();
    seenAttention = loadSeenAttention();

    function loadSeenAttention() {
        try {
            return new Set(JSON.parse(window.localStorage.getItem(seenStorageKey) || '[]'));
        } catch (_) {
            return seenAttention;
        }
    }

    function rememberAttention(sessions) {
        seenAttention = loadSeenAttention();
        sessions.forEach(function (session) { seenAttention.add(session.uuid); });
        try {
            window.localStorage.setItem(seenStorageKey, JSON.stringify(Array.from(seenAttention).slice(-200)));
        } catch (_) {}
    }

    function showAttentionModal(session, extraCount) {
        const customer = session.customer?.name || (session.customerMode === 'walk-in' ? 'Walk-in' : '—');
        document.getElementById('sales-session-attention-agent').textContent = session.agent?.name || '—';
        document.getElementById('sales-session-attention-customer').textContent = customer;
        document.getElementById('sales-session-attention-items').textContent = String((session.items || []).length);
        document.getElementById('sales-session-attention-message').textContent = extraCount
            ? 'سیلز ایجنٹ نے یہ فروخت اور مزید ' + extraCount + ' فروخت آپ کو بھیجی ہیں۔'
            : 'سیلز ایجنٹ نے نئی فروخت آپ کو بھیجی ہے۔';
        document.getElementById('sales-session-attention-open').href = showUrl.replace('__UUID__', encodeURIComponent(session.uuid));
        if (window.jQuery) window.jQuery('#salesAttentionModal').modal('show');
    }

    async function refreshSalesInbox() {
        if (document.hidden) {
            window.setTimeout(refreshSalesInbox, 5000);
            return;
        }
        try {
            const response = await fetch(@json(route('admin.sales-sessions.feed')), {headers: {'Accept': 'application/json'}});
            if (!response.ok) return;
            const feed = await response.json();
            const badge = document.getElementById('sales-inbox-badge');
            if (badge) {
                badge.textContent = Math.min(feed.openCount, 99);
                badge.style.display = feed.openCount ? '' : 'none';
            }
            seenAttention = loadSeenAttention();
            const newAttention = (feed.data || []).filter(function (session) {
                return session.status === 'needs_attention' && !seenAttention.has(session.uuid);
            });
            if (newAttention.length) {
                rememberAttention(newAttention);
                showAttentionModal(newAttention[0], newAttention.length - 1);
            }
            if (feed.openCount > knownOpen) document.title = '(' + feed.openCount + ') لائیو سیلز — BuyNStitch';
            knownOpen = feed.openCount;
            window.dispatchEvent(new CustomEvent('sales-session-feed', {detail: feed}));
        } catch (_) {}
        finally { window.setTimeout(refreshSalesInbox, 5000); }
    }
    window.setTimeout(refreshSalesInbox, 800);
})();
</script>
@endpush
@endif
