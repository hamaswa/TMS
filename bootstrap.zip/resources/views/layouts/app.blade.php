<!doctype html>
@php($forceEnglishUi = ($uiLocale ?? 'ur') === 'en')
<html lang="{{ $forceEnglishUi ? 'en' : $__env->yieldContent('html_lang', str_replace('_', '-', app()->getLocale())) }}" dir="{{ $forceEnglishUi ? 'ltr' : $__env->yieldContent('html_dir', 'ltr') }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>BuyNStitch</title>
    @vite(['resources/sass/app.scss', 'resources/js/app.js'])
    @stack('styles')
    <style>
        html[lang="ur"] body { line-height: 2 }
        html[lang="ur"] h1,
        html[lang="ur"] h2,
        html[lang="ur"] h3,
        html[lang="ur"] h4,
        html[lang="ur"] h5,
        html[lang="ur"] h6 { line-height: 1.75 !important }
        html[lang="ur"] p,
        html[lang="ur"] label,
        html[lang="ur"] small,
        html[lang="ur"] .btn,
        html[lang="ur"] .form-control { line-height: 2 !important }
        html[lang="ur"] [lang="en"],
        html[lang="ur"] .latin-text { font-family: Inter, Arial, sans-serif; line-height: 1.55 !important }
    </style>
</head>
<body class="@yield('body_class')">
    @include('inc.language-switch', ['variant' => 'floating'])
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm app-navbar">
            <div class="container">
                <a class="navbar-brand fw-bold" href="{{ url('/') }}">{{ config('app.name', 'BuyNStitch') }}</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto"></ul>
                    <ul class="navbar-nav ms-auto">
                        @guest
                            @if (Route::has('login'))<li class="nav-item"><a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a></li>@endif
                            @if (Route::has('register'))<li class="nav-item"><a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a></li>@endif
                        @else
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{{ Auth::user()->name }}</a>
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">{{ __('Logout') }}</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">@csrf</form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-4 app-main">@yield('content')</main>
    </div>
</body>
</html>
