<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Models\BusinessSubscription;
use App\Models\SubscriptionPayment;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Services\SubscriptionPlanRequestService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class AdministratorSubscriptionController extends Controller
{
    public function index(Request $request)
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:100'],
            'state' => ['nullable', Rule::in(['requested', 'active', 'expiring', 'expired', 'unconfigured'])],
        ]);
        $today = now()->toDateString();
        $warningDate = now()->addDays(BusinessSubscription::EXPIRY_WARNING_DAYS)->toDateString();

        $businesses = Business::query()
            ->with([
                'owner:id,name,email',
                'pendingPlanRequest.plan:id,name',
                'latestSubscription' => fn ($query) => $query
                    ->withSum('activePayments', 'amount'),
            ])
            ->when($filters['search'] ?? null, fn ($query, $search) => $query
                ->where(fn ($inner) => $inner
                    ->where('name', 'like', "%{$search}%")
                    ->orWhereHas('owner', fn ($owner) => $owner
                        ->where('name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%"))))
            ->when($filters['state'] ?? null, function ($query, $state) use ($today, $warningDate) {
                if ($state === 'requested') {
                    $query->whereHas('planRequests', fn ($request) => $request->pending());
                } elseif ($state === 'unconfigured') {
                    $query->whereDoesntHave('subscriptions', fn ($subscription) => $subscription->whereNull('cancelled_at'));
                } elseif ($state === 'expired') {
                    $query->whereHas('latestSubscription', fn ($subscription) => $subscription->whereDate('ends_on', '<', $today));
                } elseif ($state === 'expiring') {
                    $query->whereHas('latestSubscription', fn ($subscription) => $subscription
                        ->whereDate('ends_on', '>=', $today)
                        ->whereDate('ends_on', '<=', $warningDate));
                } elseif ($state === 'active') {
                    $query->whereHas('latestSubscription', fn ($subscription) => $subscription->whereDate('ends_on', '>', $warningDate));
                }
            })
            ->orderBy('name')
            ->paginate(20)
            ->withQueryString();

        $metrics = [
            'clients' => Business::count(),
            'expiring' => Business::whereHas('latestSubscription', fn ($subscription) => $subscription
                ->whereDate('ends_on', '>=', $today)
                ->whereDate('ends_on', '<=', $warningDate))->count(),
            'expired' => Business::whereHas('latestSubscription', fn ($subscription) => $subscription
                ->whereDate('ends_on', '<', $today))->count(),
            'received' => (float) SubscriptionPayment::whereNull('reversed_at')->sum('amount'),
        ];

        return view('Administrator.subscriptions', compact('businesses', 'metrics'));
    }

    public function storeSubscription(Request $request, int $id)
    {
        $user = $this->client($id);
        $business = $user->ownedBusiness()->firstOrFail();
        $validated = $request->validate([
            'subscription_plan_id' => ['nullable', Rule::exists('subscription_plans', 'id')->where('is_active', true)],
            'plan_name' => ['nullable', 'required_without:subscription_plan_id', 'string', 'max:100'],
            'starts_on' => ['required', 'date'],
            'ends_on' => ['required', 'date', 'after_or_equal:starts_on'],
            'fee' => ['required', 'numeric', 'min:0', 'max:999999999999.99'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ]);
        $plan = ! empty($validated['subscription_plan_id'])
            ? SubscriptionPlan::where('is_active', true)->findOrFail($validated['subscription_plan_id'])
            : null;

        // A new client's first plan starts with the plan's free trial; payment is asked when it ends.
        $trial = $request->boolean('start_trial') && $business->startsWithFreeTrial($plan);
        if ($trial) {
            $trialStart = \Illuminate\Support\Carbon::parse($validated['starts_on'])->startOfDay();
            $trialEnd = $trialStart->copy()->addDays($plan->trial_days - 1);
            $validated = [
                ...$validated,
                'ends_on' => $trialEnd->toDateString(),
                'fee' => 0,
                'is_trial' => true,
                'trial_started_at' => $trialStart,
                'trial_ends_at' => $trialEnd->copy()->endOfDay(),
                'notes' => trim('Free trial assigned by the super admin. '.($validated['notes'] ?? '')),
            ];
        }

        DB::transaction(function () use ($business, $validated, $plan) {
            $lockedBusiness = Business::query()->lockForUpdate()->findOrFail($business->id);
            $overlap = $lockedBusiness->subscriptions()
                ->whereNull('cancelled_at')
                ->whereDate('starts_on', '<=', $validated['ends_on'])
                ->whereDate('ends_on', '>=', $validated['starts_on'])
                ->exists();
            if ($overlap) {
                throw ValidationException::withMessages([
                    'starts_on' => 'This subscription period overlaps an existing active subscription.',
                ]);
            }

            $attributes = [
                ...$validated,
                'plan_name' => $plan?->name ?? $validated['plan_name'],
                'created_by_user_id' => Auth::id(),
            ];
            if ($plan) {
                $attributes = [
                    ...$attributes,
                    'subscription_plan_id' => $plan->id,
                    ...$plan->entitlementSnapshot(),
                ];
            }

            $lockedBusiness->subscriptions()->create($attributes);
            // A subscription assigned by hand answers any plan request the shop has open.
            app(SubscriptionPlanRequestService::class)->closePendingFor($lockedBusiness, Auth::user());
        });

        return redirect()->route('administrator.clients.show', $user)
            ->with('success', $trial
                ? "Free trial of {$plan->trial_days} days started. The shop is asked to pay when it ends on ".\Illuminate\Support\Carbon::parse($validated['ends_on'])->format('d M Y').'.'
                : 'Subscription period created. You can now record its payment.');
    }

    public function storePayment(Request $request, int $id, BusinessSubscription $subscription)
    {
        $user = $this->client($id);
        $business = $user->ownedBusiness()->firstOrFail();
        abort_unless($subscription->business_id === $business->id && ! $subscription->cancelled_at, 404);
        $errorBag = 'subscription_payment_'.$subscription->id;
        $validated = $request->validateWithBag($errorBag, [
            'paid_on' => ['required', 'date'],
            'amount' => ['required', 'numeric', 'gt:0', 'max:999999999999.99'],
            'payment_method' => ['required', Rule::in(array_keys(SubscriptionPayment::METHODS))],
            'reference' => [
                Rule::requiredIf(fn () => $request->input('payment_method') !== 'cash'),
                'nullable',
                'string',
                'max:150',
            ],
            'notes' => ['nullable', 'string', 'max:2000'],
        ]);

        DB::transaction(function () use ($business, $subscription, $validated) {
            $locked = BusinessSubscription::query()
                ->where('business_id', $business->id)
                ->lockForUpdate()
                ->findOrFail($subscription->id);
            $balance = $locked->balanceDue();
            if ((float) $validated['amount'] > $balance) {
                throw ValidationException::withMessages([
                    'amount' => 'Payment cannot exceed the outstanding subscription balance of Rs '.number_format($balance, 2).'.',
                ])->errorBag('subscription_payment_'.$subscription->id);
            }

            $locked->payments()->create([
                ...$validated,
                'business_id' => $business->id,
                'recorded_by_user_id' => Auth::id(),
            ]);
        });

        return redirect()->route('administrator.clients.show', $user)
            ->with('success', 'Subscription payment recorded.');
    }

    public function reversePayment(Request $request, int $id, SubscriptionPayment $payment)
    {
        $user = $this->client($id);
        $business = $user->ownedBusiness()->firstOrFail();
        abort_unless($payment->business_id === $business->id && ! $payment->reversed_at, 404);
        $validated = $request->validate([
            'reversal_reason' => ['required', 'string', 'max:1000'],
        ]);

        DB::transaction(function () use ($payment, $validated) {
            $locked = SubscriptionPayment::query()->lockForUpdate()->findOrFail($payment->id);
            abort_if($locked->reversed_at, 422, 'This payment is already reversed.');
            $locked->forceFill([
                'reversed_at' => now(),
                'reversed_by_user_id' => Auth::id(),
                'reversal_reason' => $validated['reversal_reason'],
            ])->save();
        });

        return redirect()->route('administrator.clients.show', $user)
            ->with('success', 'Subscription payment reversed. The audit record was preserved.');
    }

    public function cancelSubscription(Request $request, int $id, BusinessSubscription $subscription)
    {
        $user = $this->client($id);
        $business = $user->ownedBusiness()->firstOrFail();
        abort_unless($subscription->business_id === $business->id && ! $subscription->cancelled_at, 404);
        $validated = $request->validate([
            'cancellation_reason' => ['required', 'string', 'max:1000'],
        ]);

        $subscription->forceFill([
            'cancelled_at' => now(),
            'cancelled_by_user_id' => Auth::id(),
            'cancellation_reason' => $validated['cancellation_reason'],
        ])->save();

        return redirect()->route('administrator.clients.show', $user)
            ->with('success', 'Subscription cancelled without deleting its payment history.');
    }

    /**
     * Give a free trial more days. Plans already queued after the trial move forward by the
     * same days so they keep their full length, and a shop blocked by an ended trial reopens.
     */
    public function extendTrial(Request $request, int $id, BusinessSubscription $subscription)
    {
        $user = $this->client($id);
        $business = $user->ownedBusiness()->firstOrFail();
        abort_unless($subscription->business_id === $business->id && $subscription->is_trial && ! $subscription->cancelled_at, 404);
        $base = $subscription->trialExtensionBase();
        $validated = $request->validateWithBag('extendTrial', [
            'new_ends_on' => ['required', 'date', 'after:'.$base->toDateString(), 'before_or_equal:'.$base->copy()->addYear()->toDateString()],
            'extension_reason' => ['nullable', 'string', 'max:500'],
        ], [
            'new_ends_on.after' => 'The new end date must be after '.$base->format('d M Y').'.',
            'new_ends_on.before_or_equal' => 'A trial can be extended by at most one year at a time.',
        ]);

        $newEnd = \Illuminate\Support\Carbon::parse($validated['new_ends_on'])->startOfDay();
        $days = DB::transaction(function () use ($business, $subscription, $newEnd, $validated) {
            $trial = BusinessSubscription::query()->where('business_id', $business->id)->lockForUpdate()->findOrFail($subscription->id);
            $oldEnd = $trial->ends_on->copy()->startOfDay();
            $later = $business->subscriptions()
                ->whereNull('cancelled_at')
                ->whereKeyNot($trial->id)
                ->whereDate('starts_on', '>', $oldEnd->toDateString())
                ->lockForUpdate()
                ->get();
            if ($later->contains(fn (BusinessSubscription $plan) => $plan->starts_on->lte(now()))) {
                throw ValidationException::withMessages([
                    'new_ends_on' => 'This shop is already on a paid plan after the trial, so the trial cannot be extended.',
                ])->errorBag('extendTrial');
            }

            $shift = (int) $oldEnd->diffInDays($newEnd);
            $added = (int) $trial->trialExtensionBase()->diffInDays($newEnd);
            foreach ($later as $plan) {
                $plan->forceFill([
                    'starts_on' => $plan->starts_on->copy()->addDays($shift),
                    'ends_on' => $plan->ends_on->copy()->addDays($shift),
                ])->save();
            }

            $note = BusinessSubscription::TRIAL_EXTENDED_NOTE." by {$added} days on ".now()->format('d M Y')
                .' ('.$oldEnd->format('d M Y').' → '.$newEnd->format('d M Y').') by '.Auth::user()->name
                .(filled($validated['extension_reason'] ?? null) ? ': '.trim($validated['extension_reason']) : '');
            $trial->forceFill([
                'ends_on' => $newEnd->toDateString(),
                'trial_ends_at' => $newEnd->copy()->endOfDay(),
                'notes' => trim(trim((string) $trial->notes)."\n".$note),
            ])->save();

            return $added;
        });

        return redirect()->route('administrator.clients.show', $user)
            ->with('success', "Free trial extended by {$days} days. It now ends on ".$newEnd->format('d M Y').' and payment is asked after that.');
    }

    private function client(int|string $id): User
    {
        return User::role('shop_owner')->findOrFail($id);
    }
}
