<?php

namespace Tests\Feature;

use App\Models\ClothBrand;
use App\Models\ClothType;
use App\Models\MeasurementTemplate;
use App\Models\Options;
use App\Models\OptionType;
use App\Models\User;
use App\Services\ClothingBrandDefaultsService;
use App\Services\ClothingTypeDefaultsService;
use App\Services\TailoringOptionDefaultsService;
use Database\Seeders\ClothingShopBrandsSeeder;
use Database\Seeders\ClothingShopTypesSeeder;
use Database\Seeders\OptionTypesSeeder;
use Database\Seeders\TailoringShopOptionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Role;
use Tests\TestCase;

class ClientModuleAccessTest extends TestCase
{
    use RefreshDatabase;

    public function test_tailoring_only_client_can_use_tailoring_but_not_clothing(): void
    {
        $client = $this->client(true, false);

        $this->actingAs($client)->get(route('admin.home'))->assertRedirect(route('admin.dashboard.tailoring'));
        $this->actingAs($client)->get(route('admin.dashboard.tailoring'))->assertOk()->assertSeeText('ٹیلرنگ ڈیش بورڈ')->assertDontSeeText('دکان ڈیش بورڈ', false);
        $this->actingAs($client)->get(route('admin.tailor-jobs.index'))->assertRedirect(route('admin.order.total'));
        $this->actingAs($client)->get(route('admin.purchases.index'))->assertForbidden();
        $this->actingAs($client)->get(route('admin.financial-reports.index'))->assertOk()->assertDontSeeText('کاؤنٹر کپڑا فروخت');
    }

    public function test_clothing_only_client_can_use_sales_and_purchases_but_not_tailoring(): void
    {
        $client = $this->client(false, true);

        $this->actingAs($client)->get(route('admin.home'))->assertRedirect(route('admin.dashboard.clothing'));
        $this->actingAs($client)->get(route('admin.dashboard.clothing'))->assertOk()->assertSeeText('دکان ڈیش بورڈ')->assertDontSeeText('ٹیلرنگ ڈیش بورڈ');
        $this->actingAs($client)->get(route('admin.purchases.index'))->assertOk();
        $this->actingAs($client)->get(route('admin.tailor-jobs.index'))->assertForbidden();
        $this->actingAs($client)->get(route('admin.financial-reports.index'))->assertOk()->assertDontSeeText('ٹیلرنگ آرڈرز');
    }

    public function test_combined_client_can_use_both_modules(): void
    {
        $client = $this->client(true, true);

        $this->actingAs($client)->get(route('admin.home'))->assertOk()->assertSee('ٹیلرنگ ورک اسپیس')->assertSee('دکان اور فروخت ورک اسپیس');
        $this->actingAs($client)->get(route('admin.workspace.switch', 'tailoring'))
            ->assertRedirect(route('admin.dashboard.tailoring'))->assertSessionMissing('active_workspace');
        $this->assertSame('tailoring', $client->fresh()->preferred_workspace);
        $this->actingAs($client)->get(route('admin.dashboard.clothing'))
            ->assertOk()
            ->assertSeeText('ٹیلرنگ')
            ->assertSeeText('کپڑے کی خرید و فروخت')
            ->assertSessionMissing('active_workspace');
        $this->actingAs($client)->get(route('admin.dashboard.tailoring'))
            ->assertOk()
            ->assertSeeText('ٹیلرنگ')
            ->assertSeeText('کپڑے کی خرید و فروخت');
        $this->actingAs($client)->get(route('admin.tailor-jobs.index'))->assertRedirect(route('admin.order.total'));
        $this->actingAs($client)->get(route('admin.inventory-ledger.index'))->assertOk();
    }

    public function test_new_tailoring_client_can_access_template_specific_sewing_choices(): void
    {
        $this->seed(OptionTypesSeeder::class);
        $client = $this->client(true, false);
        $template = app(TailoringOptionDefaultsService::class)->seedMeasurementTemplateForOwner($client->id);

        $this->actingAs($client)->get(route('admin.OptionType.index', ['template' => $template->id]))
            ->assertOk()
            ->assertSeeText($template->name)
            ->assertSeeText('سلائی کی قسم')
            ->assertSee('choiceModal_1', false);
    }

    public function test_super_admin_can_create_and_change_client_module_access(): void
    {
        $adminRole = Role::firstOrCreate(['name' => 'administrative', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $admin = User::factory()->create(['tailoring_access' => false, 'clothing_access' => false]);
        $admin->assignRole($adminRole);

        $this->actingAs($admin)->post(route('administrator.insert'), [
            'name' => 'Clothing Client', 'email' => 'clothing@example.com',
            'password' => 'secure-password', 'role' => 'shop_owner', 'modules' => ['clothing'],
        ]);

        $client = User::where('email', 'clothing@example.com')->firstOrFail();
        $this->assertEquals('pending', $client->ownedBusiness->status);
        $this->assertFalse($client->tailoring_access);
        $this->assertTrue($client->clothing_access);
        $this->assertTrue($client->hasRole('shop_owner'));
        $this->assertDatabaseCount('options', 0);
        $this->assertSame(
            ClothingBrandDefaultsService::BRANDS,
            ClothBrand::where('user_id', $client->id)->orderBy('id')->pluck('name')->all()
        );

        $this->seed(ClothingShopBrandsSeeder::class);
        $this->seed(ClothingShopBrandsSeeder::class);
        $this->assertSame(
            count(ClothingBrandDefaultsService::BRANDS),
            ClothBrand::where('user_id', $client->id)->count()
        );
        $this->assertSame(
            ClothingTypeDefaultsService::TYPES,
            ClothType::where('user_id', $client->id)->orderBy('id')->pluck('name')->all()
        );

        $this->seed(ClothingShopTypesSeeder::class);
        $this->seed(ClothingShopTypesSeeder::class);
        $this->assertSame(
            count(ClothingTypeDefaultsService::TYPES),
            ClothType::where('user_id', $client->id)->count()
        );

        $this->actingAs($admin)->post(route('administrator.update', $client), [
            'name' => $client->name, 'email' => $client->email,
            'role' => 'shop_owner', 'modules' => ['tailoring', 'clothing'],
        ])->assertRedirect(route('administrator.index'));

        $client->refresh();
        $this->assertTrue($client->tailoring_access);
        $this->assertTrue($client->clothing_access);
        $sewingTypeId = OptionType::where('slug', TailoringOptionDefaultsService::SEWING_TYPE_SLUG)->value('id');
        $this->assertSame(
            TailoringOptionDefaultsService::SEWING_TYPE_CHOICES,
            Options::where('user_id', $client->id)
                ->whereNull('measurement_template_id')
                ->where('option_id', $sewingTypeId)
                ->orderBy('id')
                ->pluck('Name')
                ->all()
        );

        $this->seed(TailoringShopOptionsSeeder::class);
        $this->seed(TailoringShopOptionsSeeder::class);
        $this->assertSame(
            $this->defaultTailoringChoiceCount(),
            Options::where('user_id', $client->id)->whereNull('measurement_template_id')->count()
        );
        $this->assertSame(
            $this->defaultTailoringChoiceCount(),
            Options::where('user_id', $client->id)->whereNotNull('measurement_template_id')->count()
        );
    }

    public function test_each_new_tailoring_shop_receives_its_own_default_tailoring_choices(): void
    {
        $adminRole = Role::firstOrCreate(['name' => 'administrative', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $admin = User::factory()->create();
        $admin->assignRole($adminRole);

        foreach (['first@example.com', 'second@example.com'] as $index => $email) {
            $this->actingAs($admin)->post(route('administrator.insert'), [
                'name' => 'Tailoring Client '.($index + 1),
                'email' => $email,
                'password' => 'secure-password',
                'role' => 'shop_owner',
                'modules' => ['tailoring'],
            ])->assertSessionHasNoErrors();

            $owner = User::where('email', $email)->firstOrFail();
            $this->assertSame(
                $this->defaultTailoringChoiceCount() * 2,
                Options::where('user_id', $owner->id)->count()
            );
            $template = MeasurementTemplate::where('user_id', $owner->id)
                ->where('name', TailoringOptionDefaultsService::DEFAULT_MEASUREMENT_TEMPLATE_NAME)
                ->firstOrFail();
            $this->assertTrue($template->is_default);
            $this->assertTrue($template->is_active);
            $this->assertSame(
                $this->defaultTailoringChoiceCount(),
                Options::where('user_id', $owner->id)
                    ->where('measurement_template_id', $template->id)->count()
            );
        }

        $this->assertDatabaseCount(
            'options',
            $this->defaultTailoringChoiceCount() * 4
        );
    }

    public function test_shop_owner_client_must_have_at_least_one_module(): void
    {
        $adminRole = Role::firstOrCreate(['name' => 'administrative', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $admin = User::factory()->create();
        $admin->assignRole($adminRole);

        $this->actingAs($admin)->from(route('administrator.create'))->post(route('administrator.insert'), [
            'name' => 'No Modules', 'email' => 'none@example.com',
            'password' => 'secure-password', 'role' => 'shop_owner',
        ])->assertRedirect(route('administrator.create'))->assertSessionHasErrors('modules');

        $this->assertDatabaseMissing('users', ['email' => 'none@example.com']);
    }

    public function test_super_admin_client_management_excludes_business_employees(): void
    {
        $adminRole = Role::firstOrCreate(['name' => 'administrative', 'guard_name' => 'web']);
        $ownerRole = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $employeeRole = Role::firstOrCreate(['name' => 'sales_staff', 'guard_name' => 'web']);

        $admin = User::factory()->create();
        $admin->assignRole($adminRole);
        $owner = User::factory()->create(['name' => 'Business Owner']);
        $owner->assignRole($ownerRole);
        $employee = User::factory()->create(['name' => 'Counter Employee']);
        $employee->assignRole($employeeRole);

        $this->actingAs($admin)->get(route('administrator.index'))
            ->assertOk()
            ->assertSeeText('Business Owner')
            ->assertDontSeeText('Counter Employee')
            ->assertSeeText('Change password');

        $this->actingAs($admin)->get(route('administrator.edit', $employee))->assertNotFound();
        $this->actingAs($admin)->post(route('administrator.update', $employee), [
            'name' => $employee->name,
            'email' => $employee->email,
            'role' => 'shop_owner',
            'modules' => ['clothing'],
        ])->assertNotFound();
    }

    public function test_super_admin_cannot_create_a_staff_account_from_client_management(): void
    {
        $adminRole = Role::firstOrCreate(['name' => 'administrative', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'sales_staff', 'guard_name' => 'web']);
        $admin = User::factory()->create();
        $admin->assignRole($adminRole);

        $this->actingAs($admin)->from(route('administrator.create'))->post(route('administrator.insert'), [
            'name' => 'Unexpected Employee',
            'email' => 'employee@example.com',
            'password' => 'secure-password',
            'role' => 'sales_staff',
        ])->assertRedirect(route('administrator.create'))->assertSessionHasErrors('role');

        $this->assertDatabaseMissing('users', ['email' => 'employee@example.com']);
    }

    public function test_tailoring_only_pages_hide_clothing_controls(): void
    {
        $owner = $this->client(true, false);
        $owner->update(['is_business_owner' => true]);
        $business = \App\Models\Business::create([
            'name' => 'Tailoring shop', 'owner_user_id' => $owner->id,
            'tailoring_enabled' => true, 'clothing_enabled' => false, 'status' => 'active',
        ]);
        $owner->update(['business_id' => $business->id]);
        $this->actingAs($owner)->get(route('admin.team.index'))->assertOk()
            ->assertSeeText('دفتری / کارخانے کا عملہ')
            ->assertDontSee('data-filter="sales"', false);
        $response = $this->actingAs($owner)->get(route('admin.storefront.edit'))->assertOk();
        foreach (['product_columns', 'product_columns_tablet', 'product_columns_mobile', 'product_image_ratio', 'show_nav_categories', 'show_nav_brands', 'show_featured_products', 'show_product_brand', 'show_product_category', 'show_product_stock'] as $field) {
            $response->assertDontSee('name="'.$field.'"', false);
        }
        $business->update(['clothing_enabled' => true]);
        $owner->update(['clothing_access' => true]);
        $this->actingAs($owner->fresh())->get(route('admin.storefront.edit'))->assertOk()
            ->assertSee('name="product_columns"', false);
    }
    private function client(bool $tailoring, bool $clothing): User
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $user = User::factory()->create([
            'tailoring_access' => $tailoring,
            'clothing_access' => $clothing,
        ]);
        $user->assignRole($role);

        return $user;
    }

    private function defaultTailoringChoiceCount(): int
    {
        return collect(app(TailoringOptionDefaultsService::class)->defaultOptionTypes())
            ->sum(fn ($defaults) => count(array_unique($defaults['choices'])));
    }
}
