<?php

namespace Tests\Feature;

use App\Models\Customers;
use App\Models\MeasurementField;
use App\Models\Order;
use App\Models\Sale;
use App\Models\Setting;
use App\Models\Tailor;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\URL;
use Spatie\Permission\Models\Role;
use Tests\TestCase;

class LegacyRouteCleanupTest extends TestCase
{
    use RefreshDatabase;

    public function test_debug_and_blank_legacy_routes_are_not_registered(): void
    {
        $routes = app('router')->getRoutes();

        $this->assertNull($routes->getByName('admin.payment-received'));
        $this->assertNull($routes->getByName('admin.tailor-rates.edit'));
        $this->get('/new-tab')->assertNotFound();
    }

    public function test_legacy_public_registration_cannot_create_an_unscoped_user(): void
    {
        $this->get('/register')->assertRedirect('/', 301);

        $this->post('/register', [
            'name' => 'Unscoped customer',
            'email' => 'unscoped@example.test',
            'password' => 'Password@2026',
            'password_confirmation' => 'Password@2026',
        ])->assertRedirect('/', 301);

        $this->assertDatabaseMissing('users', ['email' => 'unscoped@example.test']);
    }

    public function test_order_print_uses_a_safe_default_when_shop_setup_is_missing(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();

        $this->actingAs($owner)
            ->get(route('admin.order-print', $order))
            ->assertOk()
            ->assertViewIs('order.print')
            ->assertSeeText($owner->name);

        $this->assertDatabaseHas('settings', [
            'user_id' => $owner->id,
            'status' => 1,
        ]);
    }

    public function test_old_order_receipts_show_new_customer_measurement_fields_missing_from_snapshot(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();
        $field = MeasurementField::create([
            'user_id' => $owner->id,
            'label' => 'کہنی',
            'key' => 'elbow',
            'field_type' => 'number',
            'unit' => 'inch',
            'is_required' => false,
            'is_active' => true,
            'sort_order' => 10,
        ]);
        $order->customers->measurementValues()->create([
            'measurement_field_id' => $field->id,
            'value' => '8',
        ]);

        foreach (['admin.order-print', 'admin.order-prints'] as $route) {
            $this->actingAs($owner)
                ->get(route($route, $order))
                ->assertOk()
                ->assertSeeText('کہنی')
                ->assertSeeText('8');
        }

        $this->assertDatabaseMissing('order_measurement_values', [
            'order_id' => $order->id,
            'source_key' => 'custom.'.$field->id,
        ]);
    }

    public function test_sale_print_uses_a_safe_default_when_shop_setup_is_missing(): void
    {
        [$owner] = $this->orderWithoutActiveSetting();
        $sale = Sale::create(['user_id' => $owner->id, 'customer_name' => 'Walk-in customer']);

        $this->actingAs($owner)
            ->get(route('admin.sale-print', $sale))
            ->assertOk()
            ->assertViewIs('sale.print')
            ->assertSeeText($owner->name);
    }

    public function test_active_order_print_routes_render_measurement_profile_serials_and_their_intended_views(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();
        $order->customers()->update(['serial_number' => 1404]);
        $order->update([
            'suitNum' => '1404',
            'remarks' => 'Bring matching buttons - کالر نرم رکھیں',
        ]);
        Setting::forceCreate([
            'user_id' => $owner->id,
            'name' => 'QA Tailors',
            'status' => 1,
            'note' => '',
            'address' => '',
            'logo' => '',
            'contact_no' => '',
        ]);
        Transaction::create([
            'customerId' => $order->customerId,
            'userId' => $owner->id,
            'Order_type' => 'Sale',
            'remainingBalance' => 300,
        ]);
        Transaction::create([
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'recivedPayment' => 500,
            'remainingBalance' => 500,
        ]);
        Transaction::create([
            'customerId' => $order->customerId,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'remainingBalance' => 700,
        ]);

        $this->actingAs($owner)->get(route('admin.order-print', $order))
            ->assertOk()
            ->assertViewIs('order.print')
            ->assertSeeText('آئٹم سیریل')
            ->assertSeeText('1404')
            ->assertSeeText('موجودہ ادائیگی واجب')
            ->assertSeeText('گزشتہ ادائیگی کے')
            ->assertSeeText('کل ادائیگی واجب')
            ->assertViewHas('orderBalance', fn ($balance) => (float) $balance === 500.0)
            ->assertViewHas('previousBalance', fn ($balance) => (float) $balance === 1000.0)
            ->assertViewHas('latestBalance', fn ($balance) => (float) $balance === 1500.0);

        $this->actingAs($owner)->get(route('admin.order-prints', $order))
            ->assertOk()
            ->assertViewIs('order.prints')
            ->assertSeeText('آئٹم سیریل')
            ->assertSeeText('1404');
    }

    public function test_receipts_are_locked_to_80mm_and_include_qr_references(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();
        $order->update(['suitNum' => json_encode(['Suit 1'])]);
        $setting = Setting::forceCreate([
            'user_id' => $owner->id,
            'name' => 'QA Tailors',
            'shop_slug' => 'qa-tailors',
            'status' => 1,
            'note' => '',
            'address' => '',
            'logo' => '',
            'contact_no' => '',
            'print_paper_size' => Setting::PRINT_PAPER_RECEIPT_80,
            'print_show_qr' => true,
        ]);
        Transaction::create([
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'recivedPayment' => 500,
            'remainingBalance' => 500,
        ]);

        $this->actingAs($owner)
            ->get(route('admin.order-print', $order).'?paper=a4')
            ->assertOk()
            ->assertSee('tms-paper-receipt_80', false)
            ->assertDontSee('A4 مکمل صفحہ')
            ->assertSee('class="receipt-date"', false)
            ->assertSee('order-summary-row', false)
            ->assertSee('order-note', false)
            ->assertSee('dir="auto"', false)
            ->assertSee('unicode-bidi: plaintext', false)
            ->assertSee('body.tms-order-print #orderSection', false)
            ->assertSee('grid-template-columns: minmax(0, 56%) minmax(0, 44%)', false)
            ->assertSee('.measurement-row > .measurement-column-empty', false)
            ->assertSee('@media screen and (max-width: 520px)', false)
            ->assertSee('ORDER REF: '.$order->id)
            ->assertSee('<svg', false);

        $this->actingAs($owner)
            ->get(route('admin.order-print', $order).'?paper=unsupported')
            ->assertOk()
            ->assertSee('tms-paper-receipt_80', false);

        $setting->update(['print_show_qr' => false]);

        $this->actingAs($owner)
            ->get(route('admin.order-print', $order))
            ->assertOk()
            ->assertDontSee('ORDER REF: '.$order->id);
    }

    public function test_order_receipt_qr_opens_signed_public_status_and_payment_page(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();
        $order->update(['status' => 'ready', 'returnDate' => '2026-08-30']);
        Transaction::create([
            'customerId' => $order->customerId,
            'userId' => $owner->id,
            'Order_type' => 'Sale',
            'remainingBalance' => 200,
        ]);
        Transaction::create([
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'remainingBalance' => 450,
        ]);

        $trackingUrl = URL::signedRoute('orders.track', ['order' => $order->id]);

        $this->get(route('orders.track', $order))->assertForbidden();

        $this->get($trackingUrl)
            ->assertOk()
            ->assertViewIs('order.track')
            ->assertSeeText('تیار ہے')
            ->assertSeeText('Test customer')
            ->assertSeeText('ادائیگی موصول نہیں ہوئی')
            ->assertSeeText('پچھلا بقایا باقی ہے')
            ->assertSeeText('200.00')
            ->assertDontSeeText('موجودہ باقی بقایا')
            ->assertDontSeeText('آرڈر کی پیش رفت');

        Transaction::create([
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'userId' => $owner->id,
            'Order_type' => 'Payment',
            'recivedPayment' => 450,
            'remainingBalance' => -450,
        ]);

        $this->get($trackingUrl)
            ->assertOk()
            ->assertSeeText('ادائیگی موصول ہو گئی ہے')
            ->assertSeeText('پچھلا بقایا باقی ہے')
            ->assertSeeText('200.00')
            ->assertDontSeeText('ادائیگی موصول نہیں ہوئی');

        Transaction::create([
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'userId' => $owner->id,
            'Order_type' => 'Payment',
            'recivedPayment' => 200,
            'remainingBalance' => -200,
        ]);

        $this->get($trackingUrl)
            ->assertOk()
            ->assertSeeText('ادائیگی موصول ہو گئی ہے')
            ->assertDontSeeText('پچھلا بقایا باقی ہے')
            ->assertDontSeeText('200.00');

        $this->actingAs($owner)
            ->get(route('admin.order-print', $order))
            ->assertOk()
            ->assertViewHas('previousBalance', 0.0)
            ->assertViewHas('latestBalance', 0.0)
            ->assertSee('class="order-tracking-qr"', false)
            // The QR holds the short link (a full signed URL is too dense to scan from a thermal print),
            // which opens the same signed status page.
            ->assertSee(e(\App\Support\OrderTrackingLink::url($order->id)), false)
            ->assertSee('<svg', false);
        $this->get(\App\Support\OrderTrackingLink::url($order->id))->assertRedirect($trackingUrl);

        $this->actingAs($owner)
            ->get(route('admin.order-prints', $order))
            ->assertOk()
            ->assertViewHas('previousBalance', 0.0)
            ->assertViewHas('latestBalance', 0.0)
            ->assertSee('class="order-tracking-qr"', false);
    }

    public function test_shared_payment_is_applied_to_oldest_order_on_receipts(): void
    {
        [$owner, $firstOrder] = $this->orderWithoutActiveSetting();
        $firstOrder->update(['totalPayment' => 1500]);
        $secondOrder = Order::create([
            'customerId' => $firstOrder->customerId,
            'sub_customer' => $firstOrder->sub_customer,
            'suitQuantity' => 1,
            'totalPayment' => 1500,
            'userId' => $owner->id,
            'tailorId' => $firstOrder->tailorId,
        ]);

        foreach ([$firstOrder, $secondOrder] as $order) {
            Transaction::create([
                'customerId' => $order->customerId,
                'orderId' => $order->id,
                'userId' => $owner->id,
                'Order_type' => 'Tailor',
                'recivedPayment' => 0,
                'remainingBalance' => 1500,
            ]);
        }

        Transaction::create([
            'customerId' => $firstOrder->customerId,
            'userId' => $owner->id,
            'Order_type' => 'Payment',
            'recivedPayment' => 1500,
            'remainingBalance' => -1500,
        ]);

        foreach (['admin.order-print', 'admin.order-prints'] as $route) {
            $this->actingAs($owner)
                ->get(route($route, $secondOrder))
                ->assertOk()
                ->assertViewHas('previousBalance', 0.0)
                ->assertViewHas('orderBalance', 1500.0)
                ->assertViewHas('latestBalance', 1500.0)
                ->assertDontSeeText('3000');
        }

        $this->actingAs($owner)
            ->get(route('admin.order-print', $firstOrder))
            ->assertOk()
            ->assertViewHas('previousBalance', 1500.0)
            ->assertViewHas('orderBalance', 0.0)
            ->assertViewHas('latestBalance', 1500.0);
    }

    public function test_customer_order_payment_is_linked_and_reported_for_that_order(): void
    {
        [$owner, $firstOrder] = $this->orderWithoutActiveSetting();
        $firstOrder->update(['totalPayment' => 1500]);
        $secondOrder = Order::create([
            'customerId' => $firstOrder->customerId,
            'sub_customer' => $firstOrder->sub_customer,
            'suitQuantity' => 1,
            'totalPayment' => 1500,
            'userId' => $owner->id,
            'tailorId' => $firstOrder->tailorId,
        ]);

        foreach ([$firstOrder, $secondOrder] as $order) {
            Transaction::create([
                'customerId' => $order->customerId,
                'orderId' => $order->id,
                'userId' => $owner->id,
                'Order_type' => 'Tailor',
                'recivedPayment' => 0,
                'remainingBalance' => 1500,
            ]);
        }

        $this->actingAs($owner)->post(route('admin.DirectPayment'), [
            'customer_id' => $secondOrder->customerId,
            'order_id' => $secondOrder->id,
            'DirectPayment' => 500,
            'comment' => 'Order-specific payment',
        ])->assertRedirect('/admin/Customers');

        $this->assertDatabaseHas('transactions', [
            'customerId' => $secondOrder->customerId,
            'orderId' => $secondOrder->id,
            'Order_type' => 'Payment',
            'recivedPayment' => 500,
            'remainingBalance' => -500,
        ]);

        $orders = $this->actingAs($owner)
            ->getJson(route('admin.getCustomer', ['id' => $secondOrder->customerId]))
            ->assertOk()
            ->json();
        $firstRow = collect($orders)->firstWhere('orderId', $firstOrder->id);
        $secondRow = collect($orders)->firstWhere('orderId', $secondOrder->id);

        $this->assertSame(1500.0, (float) $firstRow['remainingAmount']);
        $this->assertSame('unpaid', $firstRow['paymentStatus']['key']);
        $this->assertSame(500.0, (float) $secondRow['paidAmount']);
        $this->assertSame(1000.0, (float) $secondRow['remainingAmount']);
        $this->assertSame('partial', $secondRow['paymentStatus']['key']);

        $this->actingAs($owner)
            ->get(route('admin.order-print', $secondOrder))
            ->assertOk()
            ->assertViewHas('previousBalance', 1500.0)
            ->assertViewHas('orderBalance', 1000.0)
            ->assertViewHas('latestBalance', 2500.0);
    }

    public function test_legacy_order_balance_that_includes_previous_dues_is_not_added_twice_on_receipt(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();
        $order->update(['totalPayment' => 9500]);

        Transaction::create([
            'customerId' => $order->customerId,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'remainingBalance' => 4500,
        ]);
        Transaction::create([
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'remainingBalance' => 14000,
        ]);

        foreach (['admin.order-print', 'admin.order-prints'] as $route) {
            $this->actingAs($owner)
                ->get(route($route, $order))
                ->assertOk()
                ->assertViewHas('previousBalance', 4500.0)
                ->assertViewHas('orderBalance', 9500.0)
                ->assertViewHas('latestBalance', 14000.0)
                ->assertDontSeeText('18500');
        }
    }

    public function test_customer_payment_returns_to_the_searched_customer_context(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();
        $order->update(['totalPayment' => 1500]);
        Transaction::create([
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'recivedPayment' => 0,
            'remainingBalance' => 1500,
        ]);

        $expectedUrl = url('admin/Customers').'?'.http_build_query([
            'customer' => $order->customerId,
            'search' => '9123',
        ]).'#orderDetail';

        $this->actingAs($owner)->post(route('admin.DirectPayment'), [
            'customer_id' => $order->customerId,
            'order_id' => $order->id,
            'DirectPayment' => 500,
            'preserve_customer_context' => 1,
            'customer_search' => '9123',
        ])->assertRedirect($expectedUrl);
    }

    public function test_customer_payment_can_be_saved_by_ajax_without_a_page_reload(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();
        $order->update(['totalPayment' => 1500]);
        Transaction::create([
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'recivedPayment' => 0,
            'remainingBalance' => 1500,
        ]);

        $this->actingAs($owner)->postJson(route('admin.DirectPayment'), [
            'customer_id' => $order->customerId,
            'order_id' => $order->id,
            'DirectPayment' => 500,
        ])->assertOk()
            ->assertJsonPath('customerId', $order->customerId)
            ->assertJsonPath('balance', 1000)
            ->assertJsonPath('stats.totalBalance', 1000)
            ->assertJsonPath('stats.customersWithBalance', 1);

        $this->assertDatabaseHas('transactions', [
            'customerId' => $order->customerId,
            'orderId' => $order->id,
            'Order_type' => 'Payment',
            'recivedPayment' => 500,
            'remainingBalance' => -500,
        ]);
    }

    public function test_legacy_order_creation_url_redirects_to_the_unified_order_desk(): void
    {
        [$owner, $order] = $this->orderWithoutActiveSetting();

        $this->actingAs($owner)
            ->get(route('admin.order.create', $order->customerId))
            ->assertRedirect(route('admin.counter-orders.create', [
                'customer' => $order->customerId,
                'profile' => $order->customerId,
            ]));
    }

    private function orderWithoutActiveSetting(): array
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true]);
        $owner->assignRole($role);
        $customer = Customers::create([
            'name' => 'Test customer',
            'phone_number1' => '03001234567',
            'user_id' => $owner->id,
        ]);
        $tailor = Tailor::create([
            'name' => 'Test tailor',
            'phone_number1' => '03007654321',
            'user_id' => $owner->id,
        ]);
        $order = Order::create([
            'customerId' => $customer->id,
            'sub_customer' => $customer->id,
            'suitQuantity' => 1,
            'totalPayment' => 1000,
            'userId' => $owner->id,
            'tailorId' => $tailor->id,
        ]);

        return [$owner, $order];
    }
}
