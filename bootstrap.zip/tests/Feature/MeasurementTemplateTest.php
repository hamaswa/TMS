<?php

namespace Tests\Feature;

use App\Models\Customers;
use App\Models\MeasurementField;
use App\Models\MeasurementTemplate;
use App\Models\Order;
use App\Models\StandardMeasurementProfile;
use App\Models\User;
use App\Services\MeasurementService;
use App\Services\TailoringOptionDefaultsService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Role;
use Tests\TestCase;

class MeasurementTemplateTest extends TestCase
{
    use RefreshDatabase;

    public function test_builtin_shalwar_kameez_is_the_permanent_default(): void
    {
        $owner = $this->owner();
        $builtin = app(TailoringOptionDefaultsService::class)->seedMeasurementTemplateForOwner($owner->id);

        $this->assertTrue($builtin->is_builtin);
        $this->assertTrue($builtin->is_default);
        $this->assertTrue($builtin->is_active);
        $this->assertSame(array_keys(MeasurementService::SYSTEM_FIELDS), $builtin->system_fields);

        $this->actingAs($owner)->post(route('admin.measurement-templates.store'), [
            'name' => 'واسکٹ',
            'system_fields' => ['length', 'necktype', 'jeab'],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $template = MeasurementTemplate::where('user_id', $owner->id)->where('name', 'واسکٹ')->firstOrFail();
        $this->assertFalse($template->is_default);

        $this->actingAs($owner)->delete(route('admin.measurement-templates.destroy', $builtin))
            ->assertRedirect()->assertSessionHasErrors('template');

        $this->assertTrue($builtin->fresh()->is_active);
    }

    public function test_template_selector_also_controls_sewing_preference_groups(): void
    {
        $owner = $this->owner();
        app(TailoringOptionDefaultsService::class)->seedForOwner($owner->id);
        $waistcoat = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'واسکٹ',
            'system_fields' => ['length', 'necktype', 'jeab'],
            'custom_field_ids' => [],
            'is_default' => false,
            'is_active' => true,
        ]);

        $response = $this->actingAs($owner)->get(route('admin.Customers.create'));

        $response->assertOk()
            ->assertSee('data-template-system-field="necktype"', false)
            ->assertSee('data-template-system-field="jeab"', false)
            ->assertSee('data-template-system-field="sleeve"', false)
            ->assertSee('selectedSystem.indexOf(input.dataset.templateSystemField)', false)
            ->assertSee('value="'.$waistcoat->id.'"', false);
    }

    public function test_directory_stays_compact_and_each_template_has_its_own_builder(): void
    {
        $owner = $this->owner();
        $template = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'واسکٹ',
            'system_fields' => ['length', 'necktype', 'jeab'],
            'custom_field_ids' => [],
            'is_default' => true,
            'is_active' => true,
        ]);

        $this->actingAs($owner)->get(route('admin.measurement-templates.index'))
            ->assertOk()
            ->assertSeeText('واسکٹ')
            ->assertSeeText('ٹیمپلیٹ کھولیں')
            ->assertDontSee('name="system_fields[]"', false);

        $this->actingAs($owner)->get(route('admin.measurement-templates.edit', $template))
            ->assertOk()
            ->assertSeeText('جسمانی پیمائش')
            ->assertSeeText('سلائی اور ڈیزائن کی پسند')
            ->assertSeeText('گاہک فارم کی ترتیب')
            ->assertSeeText('ایک کالم')
            ->assertSeeText('دو کالم')
            ->assertSee('move-column', false)
            ->assertSee('name="system_fields[]"', false);
    }

    public function test_client_can_manage_only_their_own_template_and_layout(): void
    {
        $owner = $this->owner();
        $otherOwner = $this->owner();
        $field = $this->field($owner, 'گھٹنے کی چوڑائی');
        $template = app(TailoringOptionDefaultsService::class)->seedMeasurementTemplateForOwner($owner->id);

        $this->actingAs($owner)->put(route('admin.measurement-templates.update', $template), [
            'name' => 'نام تبدیل نہ ہو',
            'description' => 'مکمل سوٹ',
            'system_fields' => ['length', 'arms', 'chuta'],
            'custom_field_ids' => [$field->id],
            'layout_columns' => 1,
            'field_layout' => [
                ['source' => 'system.length', 'column' => 'right', 'order' => 10],
                ['source' => 'custom.'.$field->id, 'column' => 'left', 'order' => 20],
            ],
        ])->assertRedirect();

        $template->refresh();
        $this->assertTrue($template->is_default);
        $this->assertTrue($template->is_builtin);
        $this->assertSame('مردانہ شلوار قمیض', $template->name);
        $this->assertSame(['length', 'arms', 'chuta'], $template->system_fields);
        $this->assertSame([$field->id], $template->custom_field_ids);
        $this->assertSame(1, $template->layout_columns);
        $this->assertSame('left', collect($template->field_layout)->firstWhere('source', 'custom.'.$field->id)['column']);

        $this->actingAs($otherOwner)->put(route('admin.measurement-templates.update', $template), [
            'name' => 'Changed',
            'system_fields' => ['length'],
        ])->assertNotFound();
        $this->assertSame('مردانہ شلوار قمیض', $template->fresh()->name);

        $this->actingAs($owner)->get(route('admin.measurement-templates.edit', $template))
            ->assertOk()
            ->assertSeeText('مردانہ شلوار قمیض')
            ->assertSeeText('گھٹنے کی چوڑائی');
    }

    public function test_template_saves_sections_each_with_their_own_columns(): void
    {
        $owner = $this->owner();
        $template = app(TailoringOptionDefaultsService::class)->seedMeasurementTemplateForOwner($owner->id);

        $this->actingAs($owner)->put(route('admin.measurement-templates.update', $template), [
            'name' => $template->name,
            'system_fields' => ['length', 'necktype', 'shalwar', 'pancha'],
            'layout_sections' => [
                ['title' => 'قمیض', 'columns' => 2],
                ['title' => 'شلوار', 'columns' => 1],
            ],
            'field_layout' => [
                ['source' => 'system.length', 'column' => 'right', 'order' => 10, 'section' => 0],
                ['source' => 'system.necktype', 'column' => 'left', 'order' => 10, 'section' => 0],
                ['source' => 'system.shalwar', 'column' => 'right', 'order' => 10, 'section' => 1],
                ['source' => 'system.pancha', 'column' => 'right', 'order' => 20, 'section' => 1],
            ],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $template->refresh();
        $this->assertSame([
            ['title' => 'قمیض', 'columns' => 2],
            ['title' => 'شلوار', 'columns' => 1],
        ], $template->layout_sections);
        $this->assertSame(2, $template->layout_columns);
        $layout = collect($template->field_layout)->keyBy('source');
        $this->assertSame(['source' => 'system.shalwar', 'section' => 1, 'column' => 'right', 'order' => 1010], $layout['system.shalwar']);
        $this->assertSame(['source' => 'system.necktype', 'section' => 0, 'column' => 'left', 'order' => 10], $layout['system.necktype']);
        // Forms that only sort by order still list the first section before the second.
        $this->assertSame(['system.length', 'system.necktype', 'system.shalwar', 'system.pancha'],
            collect($template->field_layout)->pluck('source')->all());

        $this->actingAs($owner)->get(route('admin.measurement-templates.edit', $template))
            ->assertOk()
            ->assertSee('id="templateSections"', false)
            ->assertSeeText('نیا سیکشن');
    }

    public function test_template_without_sections_reads_as_one_section(): void
    {
        $template = new MeasurementTemplate(['layout_columns' => 1, 'layout_sections' => null]);

        $this->assertSame([['title' => null, 'columns' => 1]], $template->sections());
    }

    public function test_print_slip_follows_the_template_sections(): void
    {
        $template = new MeasurementTemplate([
            'layout_columns' => 2,
            'layout_sections' => [['title' => 'قمیض', 'columns' => 2], ['title' => 'شلوار', 'columns' => 1], ['title' => 'خالی', 'columns' => 2]],
            'field_layout' => [
                ['source' => 'system.length', 'section' => 0, 'column' => 'right', 'order' => 10],
                ['source' => 'system.necktype', 'section' => 0, 'column' => 'left', 'order' => 10],
                // Left in a one-column section still prints in its single column.
                ['source' => 'system.pancha', 'section' => 1, 'column' => 'left', 'order' => 1020],
                ['source' => 'system.shalwar', 'section' => 1, 'column' => 'right', 'order' => 1010],
            ],
        ]);
        $rows = collect([
            'system.length' => (object) ['source_key' => 'system.length', 'label' => 'لمبائی', 'value' => '39'],
            'system.necktype' => (object) ['source_key' => 'system.necktype', 'label' => 'گلہ', 'value' => 'کالر'],
            'system.shalwar' => (object) ['source_key' => 'system.shalwar', 'label' => 'شلوار', 'value' => '41'],
            'system.pancha' => (object) ['source_key' => 'system.pancha', 'label' => 'پانچہ', 'value' => '7.5'],
        ]);

        $sections = MeasurementTemplate::arrangeForPrint($template, $rows);

        // The empty third section is left off the slip.
        $this->assertCount(2, $sections);
        $this->assertSame(['system.length'], $sections[0]['right']);
        $this->assertSame(['system.necktype'], $sections[0]['left']);
        $this->assertSame(1, $sections[1]['columns']);
        $this->assertSame(['system.shalwar', 'system.pancha'], $sections[1]['right']);

        $html = view('order.partials.measurement-print-sections', ['tpl' => $template, 'allMeasurements' => $rows])->render();
        $this->assertSame(1, substr_count($html, 'measurement-section-divider"'));
        $this->assertStringNotContainsString('خالی', $html);
        // Each row writes its left cell first, so check the right column's order across rows and sections.
        $positions = array_map(fn ($text) => mb_strpos($html, $text), ['قمیض', 'لمبائی', 'شلوار</div>', '41', '7.5']);
        $sorted = $positions;
        sort($sorted);
        $this->assertSame($sorted, $positions);
    }

    public function test_unticked_template_field_leaves_the_form_but_stays_listed(): void
    {
        $owner = $this->owner();
        $template = app(TailoringOptionDefaultsService::class)->seedMeasurementTemplateForOwner($owner->id);
        $kept = $this->field($owner, 'کہنی');
        $dropped = $this->field($owner, 'چاک تیار');
        $kept->update(['measurement_template_id' => $template->id]);
        $dropped->update(['measurement_template_id' => $template->id]);
        $template->update(['custom_field_ids' => [$kept->id, $dropped->id]]);

        $this->actingAs($owner)->put(route('admin.measurement-templates.update', $template), [
            'name' => $template->name,
            'system_fields' => ['length'],
            'custom_field_ids' => [$kept->id],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $this->assertSame([$kept->id], $template->fresh()->custom_field_ids);
        $this->assertTrue($dropped->fresh()->is_active);

        $html = $this->actingAs($owner)->get(route('admin.measurement-templates.edit', $template))
            ->assertOk()
            ->assertSeeText('چاک تیار')
            ->getContent();
        $this->assertMatchesRegularExpression('/value="'.$kept->id.'" data-source="custom\.'.$kept->id.'"[^>]*checked/', $html);
        $this->assertDoesNotMatchRegularExpression('/value="'.$dropped->id.'" data-source="custom\.'.$dropped->id.'"[^>]*checked/', $html);
    }

    public function test_dragged_layout_order_columns_and_column_count_are_saved(): void
    {
        $owner = $this->owner();
        $template = app(TailoringOptionDefaultsService::class)->seedMeasurementTemplateForOwner($owner->id);
        $payload = fn (int $columns, array $right, array $left) => [
            'name' => $template->name,
            'system_fields' => ['length', 'arms', 'chuta', 'Daaman', 'jeab'],
            'layout_columns' => $columns,
            'field_layout' => array_merge(
                array_map(fn ($source, $i) => ['source' => $source, 'column' => 'right', 'order' => ($i + 1) * 10], $right, array_keys($right)),
                array_map(fn ($source, $i) => ['source' => $source, 'column' => 'left', 'order' => ($i + 1) * 10], $left, array_keys($left)),
            ),
        ];
        $savedColumn = fn (string $column) => collect($template->fresh()->field_layout)
            ->where('column', $column)->sortBy('order')->pluck('source')->values()->all();

        // Drag chuta to the top of the right column and jeab above Daaman on the left.
        $this->actingAs($owner)->put(route('admin.measurement-templates.update', $template),
            $payload(2, ['system.chuta', 'system.length', 'system.arms'], ['system.jeab', 'system.Daaman']))
            ->assertRedirect(route('admin.measurement-templates.edit', $template));

        $this->assertSame(['system.chuta', 'system.length', 'system.arms'], $savedColumn('right'));
        $this->assertSame(['system.jeab', 'system.Daaman'], $savedColumn('left'));
        $this->assertSame(2, $template->fresh()->layout_columns);

        // Move arms to the left column with the arrow, then reorder again.
        $this->actingAs($owner)->put(route('admin.measurement-templates.update', $template),
            $payload(2, ['system.length', 'system.chuta'], ['system.Daaman', 'system.arms', 'system.jeab']))
            ->assertRedirect();

        $this->assertSame(['system.length', 'system.chuta'], $savedColumn('right'));
        $this->assertSame(['system.Daaman', 'system.arms', 'system.jeab'], $savedColumn('left'));

        // The builder rebuilds its preview from the saved order and re-syncs it on submit.
        $this->actingAs($owner)->get(route('admin.measurement-templates.edit', $template))
            ->assertOk()
            ->assertSeeInOrder(['layout["system.length"]', 'layout["system.Daaman"]', 'layout["system.chuta"]', 'layout["system.arms"]', 'layout["system.jeab"]'], false)
            ->assertSee("builder.addEventListener('submit', syncLayout)", false);

        // One-column mode stacks everything in a single saved column.
        $this->actingAs($owner)->put(route('admin.measurement-templates.update', $template),
            $payload(1, ['system.jeab', 'system.length', 'system.Daaman', 'system.chuta', 'system.arms'], []))
            ->assertRedirect();

        $this->assertSame(1, $template->fresh()->layout_columns);
        $this->assertSame(['system.jeab', 'system.length', 'system.Daaman', 'system.chuta', 'system.arms'], $savedColumn('right'));
        $this->assertSame([], $savedColumn('left'));
    }

    public function test_builtin_template_field_stays_removed_after_reseeding(): void
    {
        $owner = $this->owner();
        $service = app(TailoringOptionDefaultsService::class);
        $service->seedForOwner($owner->id);
        $template = MeasurementTemplate::where('user_id', $owner->id)->where('is_builtin', true)->firstOrFail();
        $withoutNeck = array_values(array_diff($template->system_fields, ['necktype']));

        $this->actingAs($owner)->get(route('admin.measurement-templates.edit', $template))
            ->assertOk()
            ->assertSee('value="necktype"', false)
            ->assertDontSee('type="hidden" name="system_fields[]"', false);

        $this->actingAs($owner)->put(route('admin.measurement-templates.update', $template), [
            'name' => $template->name,
            'system_fields' => $withoutNeck,
        ])->assertRedirect()->assertSessionHasNoErrors();
        $this->assertSame($withoutNeck, $template->fresh()->system_fields);

        $service->seedForOwner($owner->id);

        $this->assertSame($withoutNeck, $template->fresh()->system_fields);
        $this->assertTrue($template->fresh()->is_builtin);
        $this->actingAs($owner)->get(route('admin.OptionType.index', ['template' => $template->id]))
            ->assertOk()
            ->assertDontSeeText('افغانی گلہ');
    }

    public function test_selected_template_controls_required_customer_measurements(): void
    {
        $owner = $this->owner();
        $included = $this->field($owner, 'کالر اونچائی', true);
        $excluded = $this->field($owner, 'کف چوڑائی', true);
        $template = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'قمیض',
            'system_fields' => ['length', 'arms'],
            'custom_field_ids' => [$included->id],
            'is_default' => true,
            'is_active' => true,
        ]);

        $this->actingAs($owner)->post(route('admin.Customers.store'), [
            'name' => 'Template Customer',
            'contact' => '03006660000',
            'measurement_template_id' => $template->id,
            'length' => 42,
            'arms' => 24,
            'custom_measurements' => [$included->id => '3.5'],
        ])->assertRedirect(route('admin.Customers.index', ['created' => 1]));

        $customer = Customers::where('user_id', $owner->id)->firstOrFail();
        $this->assertSame($template->id, $customer->measurement_template_id);
        $this->assertDatabaseHas('customer_measurement_values', [
            'customer_id' => $customer->id,
            'measurement_field_id' => $included->id,
            'value' => '3.5',
        ]);
        $this->assertDatabaseMissing('customer_measurement_values', [
            'customer_id' => $customer->id,
            'measurement_field_id' => $excluded->id,
        ]);
        $this->assertDatabaseHas('customer_measurement_histories', [
            'customer_id' => $customer->id,
            'measurement_template_id' => $template->id,
            'source' => 'customer_created',
        ]);
        $history = $customer->measurementHistories()->firstOrFail();
        $this->assertDatabaseHas('customer_measurement_history_values', [
            'customer_measurement_history_id' => $history->id,
            'source_key' => 'system.length',
            'value' => '42',
        ]);

        $this->actingAs($owner)->get(route('admin.Customers.create'))
            ->assertOk()
            ->assertSee('name="measurement_template_id"', false)
            ->assertSeeText('قمیض');
    }

    public function test_history_is_added_only_when_measurements_change(): void
    {
        $owner = $this->owner();
        $field = $this->field($owner, 'کالر اونچائی');
        $template = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'تاریخ ٹیمپلیٹ',
            'system_fields' => ['length'],
            'custom_field_ids' => [$field->id],
            'is_default' => true,
            'is_active' => true,
        ]);

        $this->actingAs($owner)->post(route('admin.Customers.store'), [
            'name' => 'History Customer',
            'contact' => '03008880000',
            'measurement_template_id' => $template->id,
            'length' => 42,
            'custom_measurements' => [$field->id => '3.5'],
        ])->assertRedirect();
        $customer = Customers::where('user_id', $owner->id)->firstOrFail();
        $this->assertCount(1, $customer->measurementHistories);

        $this->actingAs($owner)->put(route('admin.Customers.update', $customer), [
            'name' => 'History Customer',
            'contact' => '03008880001',
            'measurement_template_id' => $template->id,
            'length' => 42,
            'custom_measurements' => [$field->id => '3.5'],
        ])->assertRedirect();
        $this->assertSame(1, $customer->measurementHistories()->count());

        $this->actingAs($owner)->put(route('admin.Customers.update', $customer), [
            'name' => 'History Customer',
            'contact' => '03008880001',
            'measurement_template_id' => $template->id,
            'length' => 43,
            'custom_measurements' => [$field->id => '3.5'],
        ])->assertRedirect();
        $this->assertSame(2, $customer->measurementHistories()->count());
        $latest = $customer->measurementHistories()->with('values')->firstOrFail();
        $this->assertSame('customer_update', $latest->source);
        $this->assertSame('43', $latest->values->firstWhere('source_key', 'system.length')->value);

        $this->actingAs($owner)->get(route('admin.customers.statement', ['id' => $customer->id, 'tab' => 'measurements']))
            ->assertOk()
            ->assertSeeText('پیمائش کی تاریخ')
            ->assertSeeText('تبدیل شدہ پیمائش')
            ->assertSeeText('43');
    }

    public function test_order_snapshot_contains_only_the_selected_template_fields(): void
    {
        $owner = $this->owner();
        $included = $this->field($owner, 'گھٹنے کی چوڑائی');
        $excluded = $this->field($owner, 'کف چوڑائی');
        $template = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'واسکٹ',
            'system_fields' => ['length'],
            'custom_field_ids' => [$included->id],
            'is_default' => false,
            'is_active' => true,
        ]);
        $customer = Customers::create([
            'name' => 'Snapshot Template Customer',
            'phone_number1' => '03007770000',
            'user_id' => $owner->id,
            'measurement_template_id' => $template->id,
            'length' => 42,
            'arms' => 24,
        ]);
        $customer->measurementValues()->createMany([
            ['measurement_field_id' => $included->id, 'value' => '18'],
            ['measurement_field_id' => $excluded->id, 'value' => '10'],
        ]);
        $order = Order::create([
            'customerId' => $customer->id,
            'sub_customer' => $customer->id,
            'measurement_template_id' => $template->id,
            'userId' => $owner->id,
        ]);

        app(MeasurementService::class)->snapshotOrder($order, $customer, $template);

        $this->assertDatabaseHas('order_measurement_values', ['order_id' => $order->id, 'source_key' => 'system.length']);
        $this->assertDatabaseHas('order_measurement_values', ['order_id' => $order->id, 'source_key' => 'custom.'.$included->id]);
        $this->assertDatabaseMissing('order_measurement_values', ['order_id' => $order->id, 'source_key' => 'system.arms']);
        $this->assertDatabaseMissing('order_measurement_values', ['order_id' => $order->id, 'source_key' => 'custom.'.$excluded->id]);

        $this->actingAs($owner)->get(route('admin.order.create', $customer))
            ->assertRedirect(route('admin.counter-orders.create', [
                'customer' => $customer->id,
                'profile' => $customer->id,
            ]));
    }

    public function test_order_form_exposes_missing_template_measurements_before_submit(): void
    {
        $owner = $this->owner();
        $template = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'نامکمل واسکٹ',
            'system_fields' => ['length', 'teraa'],
            'custom_field_ids' => [],
            'is_default' => true,
            'is_active' => true,
        ]);
        $customer = Customers::create([
            'name' => 'Missing Measurement Customer',
            'phone_number1' => '03007770111',
            'user_id' => $owner->id,
            'measurement_template_id' => $template->id,
            'length' => 42,
            'teraa' => null,
        ]);

        $this->actingAs($owner)->get(route('admin.order.create', $customer))
            ->assertRedirect(route('admin.counter-orders.create', [
                'customer' => $customer->id,
                'profile' => $customer->id,
            ]));
    }

    public function test_shop_owner_can_save_arbitrarily_named_standard_measurements_per_template(): void
    {
        $owner = $this->owner();
        $otherOwner = $this->owner();
        $field = $this->field($owner, 'کالر اونچائی', true);
        $template = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'مردانہ شلوار قمیض',
            'system_fields' => ['length', 'arms'],
            'custom_field_ids' => [$field->id],
            'is_default' => true,
            'is_active' => true,
        ]);

        $this->actingAs($owner)->post(route('admin.standard-measurement-profiles.store', $template), [
            'name' => 'Medium A',
            'sort_order' => 20,
            'values' => [
                'system' => ['length' => '41.5', 'arms' => '24'],
                'custom' => [$field->id => '3.25'],
            ],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $profile = StandardMeasurementProfile::firstOrFail();
        $this->assertSame('Medium A', $profile->name);
        $this->assertSame($template->id, $profile->measurement_template_id);
        $this->assertSame(['system.length', 'system.arms', 'custom.'.$field->id], collect($profile->measurement_values)->pluck('source_key')->all());
        $this->actingAs($owner)->get(route('admin.standard-measurement-profiles.index', $template))
            ->assertOk()->assertSeeText('Medium A')->assertSeeText('3 پیمائشیں');

        $this->actingAs($otherOwner)->put(route('admin.standard-measurement-profiles.update', $profile), [
            'name' => 'Changed',
            'values' => ['system' => ['length' => '40', 'arms' => '23']],
        ])->assertNotFound();
        $this->assertSame('Medium A', $profile->fresh()->name);
    }

    public function test_standard_sizes_contain_measurements_not_sewing_preferences(): void
    {
        $owner = $this->owner();
        $template = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'واسکٹ',
            'system_fields' => ['length', 'necktype', 'jeab'],
            'custom_field_ids' => [],
            'is_default' => true,
            'is_active' => true,
        ]);

        $this->actingAs($owner)->get(route('admin.standard-measurement-profiles.index', $template))
            ->assertOk()
            ->assertSee('name="values[system][length]"', false)
            ->assertDontSee('name="values[system][necktype]"', false)
            ->assertDontSee('name="values[system][jeab]"', false);

        $this->actingAs($owner)->post(route('admin.standard-measurement-profiles.store', $template), [
            'name' => 'Medium',
            'values' => ['system' => ['length' => '26']],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $this->assertSame(
            ['system.length'],
            collect(StandardMeasurementProfile::firstOrFail()->measurement_values)->pluck('source_key')->all(),
        );
    }

    public function test_measurement_update_refreshes_only_unfinished_orders(): void
    {
        $owner = $this->owner();
        $template = MeasurementTemplate::create([
            'user_id' => $owner->id,
            'name' => 'آرڈر ٹیمپلیٹ',
            'system_fields' => ['length', 'necktype'],
            'custom_field_ids' => [],
            'is_default' => true,
            'is_active' => true,
        ]);

        $this->actingAs($owner)->post(route('admin.Customers.store'), [
            'name' => 'Order Customer',
            'contact' => '03007770000',
            'measurement_template_id' => $template->id,
            'length' => 42,
            'add_neck_type' => 'بین 13',
        ])->assertRedirect();
        $customer = Customers::where('user_id', $owner->id)->firstOrFail();

        $orders = collect(['stitching', 'ready'])->mapWithKeys(function (string $status) use ($owner, $customer, $template) {
            $order = Order::create([
                'userId' => $owner->id,
                'customerId' => $customer->id,
                'sub_customer' => $customer->id,
                'measurement_template_id' => $template->id,
                'suitQuantity' => 1,
                'totalPayment' => 1000,
                'status' => $status,
            ]);
            app(MeasurementService::class)->snapshotOrder($order, $customer, $template);

            return [$status => $order];
        });

        $this->actingAs($owner)->put(route('admin.Customers.update', $customer), [
            'name' => 'Order Customer',
            'contact' => '03007770000',
            'measurement_template_id' => $template->id,
            'length' => 44,
            'add_neck_type' => 'بین 14',
        ])->assertRedirect();

        $values = fn (Order $order) => $order->measurementValues()->pluck('value', 'source_key')->all();
        $this->assertSame(['system.length' => '44', 'system.necktype' => 'بین 14'], $values($orders['stitching']));
        $this->assertSame(['system.length' => '42', 'system.necktype' => 'بین 13'], $values($orders['ready']));
    }

    private function field(User $owner, string $label, bool $required = false): MeasurementField
    {
        return MeasurementField::create([
            'user_id' => $owner->id,
            'label' => $label,
            'key' => 'field_'.uniqid(),
            'field_type' => 'number',
            'unit' => 'inch',
            'is_required' => $required,
            'is_active' => true,
        ]);
    }

    private function owner(): User
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true, 'clothing_access' => false]);
        $owner->assignRole($role);

        return $owner;
    }
}
