<?php

namespace Tests\Feature;

use App\Models\Customers;
use App\Models\Order;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Tests\TestCase;

class CustomerCreationTest extends TestCase
{
    use RefreshDatabase;

    public function test_customer_list_exposes_a_clear_create_customer_action(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true, 'is_business_owner' => true]);
        $owner->assignRole($role);
        $customer = Customers::create([
            'user_id' => $owner->id,
            'name' => 'محمد اسلم',
            'phone_number1' => '03001234567',
        ]);

        $this->actingAs($owner)->get(route('admin.Customers.index'))
            ->assertOk()
            ->assertSee(route('admin.Customers.create'), false)
            ->assertSeeText('نیا گاہک شامل کریں')
            ->assertSee('href="'.route('admin.customers.statement', $customer).'"', false)
            ->assertSeeText('پروفائل اور کھاتہ دیکھیں')
            ->assertSeeText('حالیہ آرڈر دیکھیں')
            ->assertSee('href="'.route('admin.customer.orders', $customer).'"', false)
            ->assertSeeText('خاندان کا نیا ناپ شامل کریں')
            ->assertSee('data-toggle="dropdown"', false)
            ->assertSee('data-boundary="viewport"', false)
            ->assertSee('show.bs.dropdown', false)
            ->assertSee('aria-label="'.$customer->name.' کی مزید کارروائیاں"', false)
            ->assertSee('aria-label="'.$customer->name.' کی ادائیگی درج کریں"', false);

        $this->actingAs($owner)->get(route('admin.customer.orders', $customer))
            ->assertOk()
            ->assertSeeText($customer->name.' اور خاندان کے آرڈرز')
            ->assertSee('id="cc-table-data-order-history"', false)
            ->assertSee('data-return-orders="'.$customer->id.'"', false)
            ->assertSee('id="loadCustomerOrders"', false);
    }

    public function test_customer_directory_uses_server_pagination_and_supports_ajax_server_search(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true, 'is_business_owner' => true]);
        $owner->assignRole($role);

        foreach (range(1, 26) as $number) {
            Customers::create([
                'user_id' => $owner->id,
                'name' => sprintf('Directory Customer %02d', $number),
                'phone_number1' => '0300'.str_pad((string) $number, 7, '0', STR_PAD_LEFT),
            ]);
        }
        $familyParent = Customers::where('user_id', $owner->id)
            ->where('name', 'Directory Customer 10')
            ->firstOrFail();
        Customers::create([
            'user_id' => $owner->id,
            'parent_id' => $familyParent->id,
            'name' => 'Directory Family Member',
            'phone_number1' => $familyParent->phone_number1,
        ]);

        $this->actingAs($owner)->get(route('admin.Customers.index'))
            ->assertOk()
            ->assertSeeText('Directory Customer 26')
            ->assertDontSeeText('Directory Customer 01')
            ->assertSeeText('کل 26 گاہکوں میں سے 1 تا 25 دکھائے جا رہے ہیں۔');

        $this->actingAs($owner)->get(route('admin.Customers.index', ['page' => 2]))
            ->assertOk()
            ->assertSeeText('Directory Customer 01')
            ->assertDontSeeText('Directory Customer 26');

        $response = $this->actingAs($owner)->getJson(route('admin.customers.search', [
            'search' => 'Directory Customer 01',
        ]))->assertOk()
            ->assertJsonPath('count', 1)
            ->assertJsonPath('from', 1)
            ->assertJsonPath('to', 1);

        $this->assertStringContainsString('Directory Customer 01', $response->json('html'));
        $this->assertStringNotContainsString('Directory Customer 02', $response->json('html'));

        $familyResponse = $this->actingAs($owner)->getJson(route('admin.customers.search', [
            'search' => 'Directory Family Member',
        ]))->assertOk()->assertJsonPath('count', 1);

        $this->assertStringContainsString('Directory Customer 10', $familyResponse->json('html'));
        $this->assertStringContainsString('Directory Family Member', $familyResponse->json('html'));
    }

    public function test_customer_serial_numbers_are_sequential_within_each_shop(): void
    {
        $firstOwner = User::factory()->create();
        $secondOwner = User::factory()->create();

        $firstCustomer = Customers::create([
            'user_id' => $firstOwner->id,
            'name' => 'First Shop Customer',
            'phone_number1' => '03001111111',
        ]);
        $otherShopCustomer = Customers::create([
            'user_id' => $secondOwner->id,
            'name' => 'Other Shop Customer',
            'phone_number1' => '03002222222',
        ]);
        $secondCustomer = Customers::create([
            'user_id' => $firstOwner->id,
            'name' => 'Second Shop Customer',
            'phone_number1' => '03003333333',
        ]);

        $this->assertSame(1, $firstCustomer->serial_number);
        $this->assertSame(1, $otherShopCustomer->serial_number);
        $this->assertSame(2, $secondCustomer->serial_number);
        $this->assertNotSame($secondCustomer->id, $secondCustomer->serial_number);
    }

    public function test_sale_only_buyers_take_a_serial_only_with_their_first_tailoring_order(): void
    {
        $owner = User::factory()->create();
        $create = fn (string $name, array $extra = []) => Customers::create($extra + [
            'user_id' => $owner->id, 'name' => $name, 'phone_number1' => '0300'.random_int(1000000, 9999999),
        ]);

        $regular = $create('Tailoring Customer');
        $saleBuyers = collect(['counter_sale', 'counter_order', 'sales_agent'])
            ->map(fn (string $source) => $create('Buyer '.$source, ['acquisition_source' => $source]));
        $walkIn = Customers::newWalkIn($owner->id);
        $next = $create('Next Tailoring Customer');

        // Cloth buyers and walk-ins don't use up numbers, so tailoring customers stay consecutive.
        $this->assertSame(1, $regular->serial_number);
        $saleBuyers->each(fn (Customers $buyer) => $this->assertNull($buyer->fresh()->serial_number));
        $this->assertNull($walkIn->fresh()->serial_number);
        $this->assertSame(2, $next->serial_number);

        // Their first stitching order makes them a tailoring customer and prints the new serial.
        $buyer = $saleBuyers->first();
        $order = Order::create([
            'customerId' => $buyer->id, 'sub_customer' => $buyer->id, 'suitQuantity' => 1, 'totalPayment' => 1500,
            'returnDate' => now()->addWeek()->toDateString(), 'userId' => $owner->id, 'suitNum' => (string) $buyer->id,
        ]);
        $this->assertSame(3, $buyer->fresh()->serial_number);
        $this->assertSame('3', $order->fresh()->suitNum);

        // A second order keeps the same number.
        Order::create([
            'customerId' => $buyer->id, 'sub_customer' => $buyer->id, 'suitQuantity' => 1, 'totalPayment' => 900,
            'returnDate' => now()->addWeek()->toDateString(), 'userId' => $owner->id, 'suitNum' => '3',
        ]);
        $this->assertSame(3, $buyer->fresh()->serial_number);
        $this->assertSame(4, $create('Later Customer')->serial_number);
    }

    public function test_restored_customers_with_missing_or_stale_serials_are_repaired_in_record_order(): void
    {
        $owner = User::factory()->create();
        $first = Customers::create(['user_id' => $owner->id, 'name' => 'First', 'phone_number1' => '03001111111']);
        $second = Customers::create(['user_id' => $owner->id, 'name' => 'Second', 'phone_number1' => '03002222222']);
        $third = Customers::create(['user_id' => $owner->id, 'name' => 'Third', 'phone_number1' => '03003333333']);

        DB::table('customers')->where('id', $second->id)->update(['serial_number' => null]);
        DB::table('customers')->where('id', $third->id)->update(['serial_number' => 2]);
        DB::table('customer_serial_sequences')->where('user_id', $owner->id)->update(['next_number' => 2]);

        $migration = require database_path('migrations/2026_09_28_000000_repair_restored_customer_serial_numbers.php');
        $migration->up();

        $this->assertSame(1, $first->fresh()->serial_number);
        $this->assertSame(2, $second->fresh()->serial_number);
        $this->assertSame(3, $third->fresh()->serial_number);
        $this->assertDatabaseHas('customer_serial_sequences', ['user_id' => $owner->id, 'next_number' => 4]);

        $fourth = Customers::create(['user_id' => $owner->id, 'name' => 'Fourth', 'phone_number1' => '03004444444']);
        $this->assertSame(4, $fourth->serial_number);
    }

    public function test_customer_directory_searches_and_displays_the_shop_serial_number(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true, 'is_business_owner' => true]);
        $otherOwner = User::factory()->create();
        $owner->assignRole($role);

        Customers::create([
            'user_id' => $owner->id,
            'name' => 'Serial One',
            'phone_number1' => '03004444444',
        ]);
        Customers::create([
            'user_id' => $otherOwner->id,
            'name' => 'Global Gap',
            'phone_number1' => '03005555555',
        ]);
        $serialTwo = Customers::create([
            'user_id' => $owner->id,
            'name' => 'Serial Two',
            'phone_number1' => '03006666666',
        ]);

        $response = $this->actingAs($owner)->getJson(route('admin.customers.search', [
            'search' => '2',
        ]))->assertOk()->assertJsonPath('count', 1);

        $this->assertSame(2, $serialTwo->serial_number);
        $this->assertStringContainsString('Serial Two', $response->json('html'));
        $this->assertStringNotContainsString('Global Gap', $response->json('html'));
    }

    public function test_tailoring_client_can_create_a_customer_with_default_design_options(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true, 'clothing_access' => false]);
        $owner->assignRole($role);

        $this->actingAs($owner)->get(route('admin.Customers.create'))
            ->assertOk()
            ->assertSeeText('بنیادی معلومات')
            ->assertSeeText('پیمائش اور سلائی کی پسند')
            ->assertSee('class="customer-details-grid customer-tailoring-layout"', false)
            ->assertSee('class="combined-panel measurement-panel"', false)
            ->assertSee('class="combined-panel preference-panel"', false)
            ->assertSee('id="measurement-length" name="length"', false)
            ->assertDontSee('data-step="3"', false)
            ->assertSeeText('گاہک اکاؤنٹ');

        $response = $this->actingAs($owner)->post(route('admin.Customers.store'), [
            'name' => 'QA Urdu Customer',
            'contact' => '03001234567',
            'length' => 42,
            'arms' => 24,
            'teraa' => 18,
            'senaChorai' => 22,
            'damanchorai' => 24,
            'shalwar' => 40,
            'pancha' => 8,
            'shalwarGheer' => 26,
            'monda' => 10,
            'chuta' => 15,
            'note' => 'اردو ٹیسٹ ریکارڈ',
            'mobile_pin' => '482913',
        ])->assertSessionHas('customer_pin', '482913');

        $this->assertDatabaseHas('customers', [
            'name' => 'QA Urdu Customer',
            'user_id' => $owner->id,
            'Daaman' => null,
            'phone_number1_normalized' => '+923001234567',
        ]);
        $this->assertTrue(Hash::check('482913', Customers::firstOrFail()->mobile_pin));
        $customer = Customers::firstOrFail();
        $response->assertRedirect(route('admin.Customers.index', ['created' => $customer->id]));
        $this->followRedirects($response)
            ->assertSeeText('گاہک کامیابی سے شامل کر دیا گیا ہے۔')
            ->assertSee('data-customer-row="'.$customer->id.'"', false)
            ->assertSee('data-order="'.$customer->id.'"', false);
        $this->actingAs($owner)->get(route('admin.Customers.edit', $customer))
            ->assertOk()
            ->assertSeeInOrder(['name="chuta"', 'value="15"'], false);
    }

    public function test_duplicate_mobile_automatically_creates_a_family_measurement_profile(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true]);
        $owner->assignRole($role);
        $existing = Customers::create([
            'name' => 'Existing Customer',
            'phone_number1' => '03001234567',
            'user_id' => $owner->id,
        ]);

        $response = $this->actingAs($owner)->post(route('admin.Customers.store'), [
            'name' => 'Duplicate Customer',
            'contact' => '+92 300 1234567',
        ]);

        $profile = Customers::where('parent_id', $existing->id)->firstOrFail();
        $response->assertRedirect(route('admin.customers.statement', [
            'id' => $existing->id,
            'tab' => 'measurements',
            'profile' => $profile->id,
        ]))->assertSessionHas('insert');

        $this->assertSame('Duplicate Customer', $profile->name);
        $this->assertSame($existing->phone_number1, $profile->phone_number1);
        $this->assertDatabaseCount('customers', 2);
    }

    public function test_owner_can_add_a_secondary_measurement_profile_for_an_existing_phone(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true]);
        $owner->assignRole($role);
        $existing = Customers::create([
            'name' => 'Main Customer',
            'phone_number1' => '03001234567',
            'user_id' => $owner->id,
        ]);

        $this->actingAs($owner)->post(route('admin.Customers.store'), [
            'name' => 'Second Measurement Profile',
            'contact' => '+92 300 1234567',
            'length' => 44,
            'arms' => 25,
        ])->assertSessionHas('insert');

        $profile = Customers::where('parent_id', $existing->id)->firstOrFail();
        $this->assertSame('Second Measurement Profile', $profile->name);
        $this->assertSame('03001234567', $existing->fresh()->phone_number1);
        $this->assertNull($profile->phone_number1_normalized);
        $this->assertTrue($profile->phone_normalization_conflict);
        $this->assertSame($existing->id, Customers::findByPhoneForOwner($owner->id, '+92 300 1234567')?->id);
    }

    public function test_family_profile_orders_are_listed_with_the_parent_account(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true]);
        $owner->assignRole($role);
        $customer = Customers::create([
            'name' => 'Main Customer',
            'phone_number1' => '03001234567',
            'user_id' => $owner->id,
        ]);
        $family = Customers::create([
            'name' => 'Family Customer',
            'parent_id' => $customer->id,
            'phone_number1' => $customer->phone_number1,
            'user_id' => $owner->id,
        ]);
        $mainOrder = Order::create([
            'customerId' => $customer->id,
            'sub_customer' => $customer->id,
            'suitQuantity' => 1,
            'totalPayment' => 1200,
            'returnDate' => now()->addWeek()->toDateString(),
            'userId' => $owner->id,
        ]);
        $familyOrder = Order::create([
            'customerId' => $customer->id,
            'sub_customer' => $family->id,
            'suitQuantity' => 2,
            'totalPayment' => 2400,
            'returnDate' => now()->addWeek()->toDateString(),
            'userId' => $owner->id,
        ]);
        Transaction::create([
            'customerId' => $customer->id,
            'orderId' => $mainOrder->id,
            'userId' => $owner->id,
            'Order_type' => 'Tailor',
            'remainingBalance' => 1200,
            'recivedPayment' => 0,
        ]);

        $directory = $this->actingAs($owner)->get(route('admin.Customers.index'));
        $directory->assertOk();
        $directoryHtml = $directory->getContent();
        $this->assertStringContainsString('data-customer-row="'.$customer->id.'"', $directoryHtml);
        $this->assertStringNotContainsString('data-customer-row="'.$family->id.'"', $directoryHtml);
        $this->assertStringContainsString('data-customer-balance="'.$customer->id.'"', $directoryHtml);
        $this->assertStringContainsString('Rs. 1,200.00', $directoryHtml);
        $this->assertStringContainsString('بقایا والے کھاتے', $directoryHtml);
        $this->assertStringContainsString('data-family-profile="'.$family->id.'"', $directoryHtml);
        // Family rows no longer link to a per-profile orders page; the parent's orders page lists the whole family.
        $this->assertStringNotContainsString('href="'.route('admin.customer.orders', $family).'"', $directoryHtml);
        $this->assertStringContainsString('Rs. 2,400.00', $directoryHtml);
        $this->assertStringContainsString('1 آرڈر کی کل رقم · بقایا نہیں', $directoryHtml);
        $this->assertStringContainsString('customer-account-row has-family', $directoryHtml);
        $this->assertStringContainsString('class="customer-family-toggle"', $directoryHtml);
        $this->assertStringNotContainsString('data-customer-balance="'.$family->id.'"', $directoryHtml);

        $this->actingAs($owner)
            ->get(route('admin.customer.orders', $family))
            ->assertOk()
            ->assertSee('data-profile-id="'.$family->id.'"', false);

        $familyOrders = $this->actingAs($owner)->getJson(route('admin.getCustomer', [
            'id' => $customer->id,
            'profile_id' => $family->id,
        ]));
        // Tailoring orders for the parent and all family profiles are listed together, newest first.
        $familyOrders->assertOk()->assertJsonCount(2)
            ->assertJsonPath('0.orderId', $familyOrder->id)
            ->assertJsonPath('1.orderId', $mainOrder->id);

        $mainOrders = $this->actingAs($owner)->getJson(route('admin.getCustomer', [
            'id' => $customer->id,
            'profile_id' => $customer->id,
        ]));
        $mainOrders->assertOk()->assertJsonCount(2)
            ->assertJsonPath('0.orderId', $familyOrder->id)
            ->assertJsonPath('1.orderId', $mainOrder->id);
    }

    public function test_owner_can_manage_family_measurement_profiles_from_the_primary_customer(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create([
            'tailoring_access' => true,
            'is_business_owner' => true,
        ]);
        $owner->assignRole($role);
        $customer = Customers::create([
            'name' => 'Muhammad Aslam',
            'phone_number1' => '03007771111',
            'user_id' => $owner->id,
        ]);

        $this->actingAs($owner)->get(route('admin.Customers.create', ['parent' => $customer->id]))
            ->assertOk()
            ->assertSeeText('خاندان کا نیا ناپ شامل کریں')
            ->assertSee('name="parent_customer_id" value="'.$customer->id.'"', false)
            // The create form relies on server-side validation, so the phone input has no HTML "required".
            ->assertSee('value="03007771111"', false)
            ->assertSee('readonly', false)
            ->assertDontSee('name="mobile_pin"', false);

        $response = $this->actingAs($owner)->post(route('admin.Customers.store'), [
            'name' => 'Ali Aslam',
            'contact' => '03009999999',
            'parent_customer_id' => $customer->id,
            'length' => 40,
            'arms' => 23,
        ]);

        $profile = Customers::where('parent_id', $customer->id)->firstOrFail();
        $response->assertRedirect(route('admin.customers.statement', [
            'id' => $customer->id,
            'tab' => 'measurements',
            'profile' => $profile->id,
        ]));
        $this->assertSame($customer->phone_number1, $profile->phone_number1);

        $newerCustomer = Customers::create([
            'name' => 'Newer Customer',
            'phone_number1' => '03008882222',
            'user_id' => $owner->id,
        ]);
        $this->actingAs($owner)->get(route('admin.Customers.index'))
            ->assertOk()
            ->assertSeeInOrder([
                'data-customer-row="'.$newerCustomer->id.'"',
                'data-customer-row="'.$customer->id.'"',
            ], false);

        $directoryResponse = $this->actingAs($owner)->getJson(route('admin.customers.search', ['search' => 'Ali Aslam']))
            ->assertOk()
            ->assertJsonPath('count', 1);
        $directoryHtml = $directoryResponse->json('html');
        $this->assertStringContainsString('Ali Aslam', $directoryHtml);
        $this->assertStringContainsString('خاندانی افراد', $directoryHtml);
        $this->assertStringContainsString('data-family-profile="'.$profile->id.'"', $directoryHtml);
        // Family rows no longer link to a per-profile orders page; the parent's orders page lists the whole family.
        $this->assertStringNotContainsString('href="'.route('admin.customer.orders', $profile).'"', $directoryHtml);
        $this->assertStringContainsString(e(route('admin.customers.statement', [
            'id' => $customer->id,
            'tab' => 'measurements',
            'profile' => $profile->id,
        ])), $directoryHtml);
        $this->assertStringContainsString('action="'.e(route('admin.counter-orders.store')).'"', $directoryHtml);
        $this->assertStringContainsString('name="customer_id" value="'.$customer->id.'"', $directoryHtml);
        $this->assertStringContainsString('name="profile_id" value="'.$profile->id.'"', $directoryHtml);

        $this->actingAs($owner)->get(route('admin.customers.statement', [
            'id' => $customer->id,
            'tab' => 'measurements',
            'profile' => $profile->id,
        ]))->assertOk()
            ->assertSeeText('خاندان کے محفوظ ناپ')
            ->assertSee('id="family-profile-select"', false)
            ->assertSee('name="profile"', false)
            ->assertSee('value="'.$profile->id.'" selected', false)
            ->assertDontSee('family-profile-card', false)
            ->assertSeeText('Ali Aslam کی محفوظ شدہ پیمائش')
            ->assertSeeText('40');

        $this->actingAs($owner)->get(route('admin.Customers.edit', $profile))
            ->assertOk()
            ->assertSeeText('خاندانی پیمائش پروفائل')
            ->assertSeeText('حالیہ آرڈر دیکھیں')
            ->assertSee('href="'.route('admin.customer.orders', $profile).'"', false)
            ->assertSee('name="contact" value="03007771111"', false)
            ->assertSee('readonly', false)
            ->assertDontSee('name="mobile_pin"', false);

        $template = \App\Models\MeasurementTemplate::create([
            'user_id' => $owner->id, 'name' => 'کرتا', 'system_fields' => ['length', 'arms'],
            'custom_field_ids' => [], 'is_default' => true, 'is_active' => true,
        ]);
        $this->actingAs($owner)->put(route('admin.Customers.update', $profile), [
            'name' => 'Ali Aslam',
            'contact' => '03009999999',
            'measurement_template_id' => $template->id,
            'length' => 42,
            'arms' => 24,
            'return_customer' => $profile->id,
            'return_search' => '03007771111',
        ])->assertSessionHasNoErrors()
            ->assertRedirect(route('admin.Customers.edit', $profile).'?'.http_build_query([
                'return_customer' => $profile->id,
                'return_search' => '03007771111',
                'measurement_template_id' => $template->id,
            ]))
            ->assertSessionHas('insert');

        $profile->refresh();
        $this->assertSame($customer->phone_number1, $profile->phone_number1);
        // Edited measurements are saved in the profile's template history.
        $savedRows = app(\App\Services\MeasurementService::class)
            ->savedMeasurementRows($profile, $owner->id, $template)->pluck('value', 'source_key');
        $this->assertEquals(42, $savedRows->get('system.length'));
        $this->assertEquals(24, $savedRows->get('system.arms'));

        $this->actingAs($owner)
            ->withSession(['insert' => 'گاہک کی معلومات محفوظ کر دی گئی ہیں۔'])
            ->get(route('admin.Customers.edit', $profile))
            ->assertOk()
            ->assertSeeText('گاہک کی معلومات محفوظ کر دی گئی ہیں۔');
    }

    public function test_updating_customer_measurements_saves_template_history_without_changing_existing_order_snapshots(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true]);
        $owner->assignRole($role);
        $customer = Customers::create([
            'name' => 'Measurement Customer',
            'phone_number1' => '03005551234',
            'user_id' => $owner->id,
            'length' => 42,
        ]);
        $deliveredOrder = Order::create([
            'customerId' => $customer->id,
            'sub_customer' => $customer->id,
            'suitQuantity' => 1,
            'totalPayment' => 3000,
            'returnDate' => now()->addWeek()->toDateString(),
            'userId' => $owner->id,
            'status' => 'delivered',
            'created_at' => now()->subDay(),
        ]);
        $deliveredOrder->measurementValues()->create([
            'source_key' => 'system.length',
            'label' => 'لمبائی',
            'value' => '40',
            'unit' => 'inch',
            'sort_order' => 0,
        ]);
        $firstOpenOrder = Order::create([
            'customerId' => $customer->id,
            'sub_customer' => $customer->id,
            'suitQuantity' => 1,
            'totalPayment' => 3200,
            'returnDate' => now()->addWeek()->toDateString(),
            'userId' => $owner->id,
            'status' => 'assigned',
            'created_at' => now()->subHour(),
        ]);
        $firstOpenOrder->measurementValues()->create([
            'source_key' => 'system.length',
            'label' => 'لمبائی',
            'value' => '41',
            'unit' => 'inch',
            'sort_order' => 0,
        ]);
        $secondOpenOrder = Order::create([
            'customerId' => $customer->id,
            'sub_customer' => $customer->id,
            'suitQuantity' => 1,
            'totalPayment' => 3400,
            'returnDate' => now()->addWeek()->toDateString(),
            'userId' => $owner->id,
            'status' => 'stitching',
            'created_at' => now(),
        ]);
        $secondOpenOrder->measurementValues()->create([
            'source_key' => 'system.length',
            'label' => 'لمبائی',
            'value' => '43',
            'unit' => 'inch',
            'sort_order' => 0,
        ]);

        $template = \App\Models\MeasurementTemplate::create([
            'user_id' => $owner->id, 'name' => 'شلوار قمیض', 'system_fields' => ['length'],
            'custom_field_ids' => [], 'is_default' => true, 'is_active' => true,
        ]);

        $this->actingAs($owner)->put(route('admin.Customers.update', $customer), [
            'name' => $customer->name,
            'contact' => $customer->phone_number1,
            'measurement_template_id' => $template->id,
            'length' => 44,
        ])->assertSessionHasNoErrors();

        // New measurements are kept in the customer's template history for future orders...
        $this->assertSame('44', (string) app(\App\Services\MeasurementService::class)
            ->savedMeasurementRows($customer->fresh(), $owner->id, $template)
            ->firstWhere('source_key', 'system.length')['value']);
        // ...while every existing order keeps the measurement snapshot it was created with.
        $this->assertDatabaseHas('order_measurement_values', [
            'order_id' => $firstOpenOrder->id,
            'source_key' => 'system.length',
            'value' => '41',
        ]);
        $this->assertDatabaseHas('order_measurement_values', [
            'order_id' => $secondOpenOrder->id,
            'source_key' => 'system.length',
            'value' => '43',
        ]);
        $this->assertDatabaseHas('order_measurement_values', [
            'order_id' => $deliveredOrder->id,
            'source_key' => 'system.length',
            'value' => '40',
        ]);
    }

    public function test_client_can_reset_customer_pin_and_existing_mobile_sessions_are_revoked(): void
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true]);
        $owner->assignRole($role);
        $customer = Customers::create([
            'name' => 'PIN Reset Customer',
            'phone_number1' => '03007654321',
            'user_id' => $owner->id,
            'mobile_pin' => Hash::make('123456'),
        ]);
        $customer->createToken('old-device');

        $this->actingAs($owner)->put(route('admin.Customers.update', $customer), [
            'name' => $customer->name,
            'contact' => $customer->phone_number1,
            'mobile_pin' => '654321',
            'add_daaman_type' => '0 - 0',
            'plate_type' => '0 - 0',
            'add_neck_type' => '0 - 0',
            'add_pocket_type' => '0 - 0',
            'add_button_type' => '0 - 0',
            'add_sewing_type' => '0 - 0',
            'add_shirt_button_type' => '0 - 0',
            'add_sleeve_opening_type' => '0 - 0',
        ])->assertRedirect(route('admin.Customers.edit', $customer))
            ->assertSessionHas('customer_pin', '654321');

        $this->assertTrue(Hash::check('654321', $customer->fresh()->mobile_pin));
        $this->assertDatabaseMissing('personal_access_tokens', [
            'tokenable_type' => Customers::class,
            'tokenable_id' => $customer->id,
        ]);
    }
}
