<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customers;
use App\Models\Order;
use App\Models\OrderNotificationDelivery;
use App\Models\OrderStatusHistory;
use App\Models\rack as Rack;
use App\Models\Tailor;
use App\Models\TailorRecord;
use App\Models\User;
use App\Services\OrderLifecycleNotificationService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;
use Spatie\Permission\Models\Role;
use Tests\TestCase;

class TailorJobLifecycleTest extends TestCase
{
    use RefreshDatabase;

    public function test_shop_owner_workflow_is_consolidated_in_the_calendar_without_financial_controls(): void
    {
        [$owner, $tailor, $activeOrder] = $this->job([
            'returnDate' => now()->addDays(3)->toDateString(),
            'status' => 'assigned',
        ]);
        $deliveredOrder = Order::create([
            'customerId' => $activeOrder->customerId,
            'sub_customer' => $activeOrder->sub_customer,
            'suitQuantity' => 1,
            'totalPayment' => 1800,
            'tailorId' => $tailor->id,
            'tailor_price' => 500,
            'userId' => $owner->id,
            'returnDate' => now()->subWeek()->toDateString(),
            'status' => 'delivered',
        ]);

        $this->actingAs($owner)->get(route('admin.tailor-jobs.index'))
            ->assertRedirect(route('admin.order.total'));

        $orders = $this->actingAs($owner)->get(route('admin.order.total', ['week' => $activeOrder->returnDate]));
        $orders
            ->assertOk()
            ->assertSeeText('ٹیلرنگ ورک فلو')
            ->assertSee('js-tailor-picker', false)
            ->assertSee('id="wo-worker-filter"', false)
            ->assertSee(route('admin.tailor-jobs.assign', $activeOrder), false)
            ->assertSee('href="'.route('admin.order-prints', $activeOrder).'" target="_blank" rel="noopener"', false)
            ->assertDontSee('title="مرحلہ محفوظ کریں"', false)
            ->assertDontSeeText('فہرست')
            ->assertDontSeeText('رقم / بقایا')
            ->assertDontSeeText('گاہک سے رقم وصول کریں')
            ->assertDontSeeText('درزی کی ادائیگی');
    }

    public function test_order_can_wait_for_tailor_and_be_assigned_later_using_the_saved_rate(): void
    {
        [$owner, $tailor, $order] = $this->job([
            'tailorId' => null,
            'rateId' => null,
            'tailor_price' => 0,
            'status' => 'unassigned',
        ]);
        $rateId = DB::table('tailorsalaries')->insertGetId([
            'tailor_id' => $tailor->id,
            'options_id' => null,
            'type' => 'Mens suit',
            'price' => 650,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $calendarUrl = route('admin.order.total', ['week' => $order->returnDate]);
        $this->actingAs($owner)
            ->get($calendarUrl)
            ->assertOk()
            ->assertSee('js-tailor-picker', false)
            ->assertSee(route('admin.tailor-jobs.assign', $order), false)
            ->assertSeeText('0 جاری کام');

        $this->actingAs($owner)
            ->from($calendarUrl)
            ->post(route('admin.order.status'), [
                'order_id' => $order->id,
                'order_status' => 'start',
            ])
            ->assertRedirect($calendarUrl)
            ->assertSessionHasErrors('order_status');
        $this->assertSame('unassigned', $order->fresh()->status);

        $this->actingAs($owner)->patch(route('admin.tailor-jobs.assign', $order), [
            'tailor_id' => $tailor->id,
            // The amount in the browser value is not trusted; the saved rate is authoritative.
            'tailor_price' => $rateId.'-1',
        ])->assertRedirect()->assertSessionHas('success');

        $order->refresh();
        $this->assertSame('assigned', $order->status);
        $this->assertSame($tailor->id, (int) $order->tailorId);
        $this->assertSame($rateId, (int) $order->rateId);
        $this->assertEquals(650, (float) $order->tailor_price);
        $this->assertDatabaseHas('order_status_histories', [
            'order_id' => $order->id,
            'from_status' => 'unassigned',
            'to_status' => 'assigned',
            'tailor_id' => $tailor->id,
        ]);
        $this->assertDatabaseHas('order_work_assignments', [
            'order_id' => $order->id,
            'status' => 'assigned',
            'rate' => 650,
        ]);

        $customerOrders = $this->actingAs($owner)->getJson(route('admin.getCustomer', [
            'id' => $order->customerId,
            'profile_id' => $order->sub_customer,
        ]))->assertOk();
        $customerOrders
            ->assertJsonPath('0.canAssignTailor', false)
            ->assertJsonPath('0.tailorOptions', []);

        $this->actingAs($owner)
            ->from(route('admin.tailor-jobs.index'))
            ->patch(route('admin.tailor-jobs.assign', $order), [
                'tailor_id' => $tailor->id,
                'tailor_price' => $rateId.'-650',
            ])
            ->assertRedirect(route('admin.tailor-jobs.index'))
            ->assertSessionHasErrors('tailor_id');
    }

    public function test_customer_order_list_exposes_quick_tailor_and_rate_selection(): void
    {
        [$owner, $tailor, $order] = $this->job([
            'tailorId' => null,
            'rateId' => null,
            'tailor_price' => 0,
            'status' => 'unassigned',
        ]);
        $rateId = DB::table('tailorsalaries')->insertGetId([
            'tailor_id' => $tailor->id,
            'options_id' => null,
            'type' => 'Mens suit',
            'price' => 650,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->actingAs($owner)->getJson(route('admin.getCustomer', [
            'id' => $order->customerId,
            'profile_id' => $order->sub_customer,
        ]))
            ->assertOk()
            ->assertJsonPath('0.canAssignTailor', true)
            ->assertJsonPath('0.tailorOptions.0.tailorId', $tailor->id)
            ->assertJsonPath('0.tailorOptions.0.tailorName', $tailor->name)
            ->assertJsonPath('0.tailorOptions.0.rateName', 'Mens suit')
            ->assertJsonPath('0.tailorOptions.0.price', 650)
            ->assertJsonPath('0.tailorOptions.0.rateValue', $rateId.'-650')
            ->assertJsonPath('0.tailorAssignmentUrl', route('admin.tailor-jobs.assign', $order));

        $script = file_get_contents(public_path('assets/js/custom.js'));
        $this->assertStringContainsString('quick-tailor-open', $script);
        $this->assertStringContainsString('quickTailorRateSelect', $script);

        $this->actingAs($owner)->get(route('admin.customer.orders', $order->sub_customer))
            ->assertOk()
            ->assertSee('id="tailorAssignmentModal"', false)
            ->assertSeeText('سلائی کی شرح / رقم');
    }

    public function test_confirmed_inline_reassignment_changes_tailor_and_keeps_an_audit_history(): void
    {
        [$owner, $firstTailor, $order] = $this->job(['status' => 'cutting']);
        $secondTailor = Tailor::create([
            'name' => 'Second QA Tailor',
            'phone_number1' => '03009992009',
            'password' => bcrypt('password'),
            'user_id' => $owner->id,
        ]);
        $rateId = DB::table('tailorsalaries')->insertGetId([
            'tailor_id' => $secondTailor->id,
            'options_id' => null,
            'type' => 'Replacement rate',
            'price' => 725,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->actingAs($owner)->patchJson(route('admin.tailor-jobs.assign', $order), [
            'tailor_id' => $secondTailor->id,
            'tailor_price' => $rateId.'-1',
            'confirm_reassign' => 1,
        ])->assertOk()
            ->assertJsonPath('tailor.id', $secondTailor->id)
            ->assertJsonPath('tailor.name', $secondTailor->name);

        $order->refresh();
        $this->assertSame('cutting', $order->status);
        $this->assertSame($secondTailor->id, (int) $order->tailorId);
        $this->assertEquals(725, (float) $order->tailor_price);
        $this->assertDatabaseHas('order_status_histories', [
            'order_id' => $order->id,
            'tailor_id' => $secondTailor->id,
            'from_status' => 'cutting',
            'to_status' => 'cutting',
        ]);
        $this->assertStringContainsString(
            $firstTailor->name,
            (string) OrderStatusHistory::where('order_id', $order->id)->latest('id')->value('note'),
        );

        $order->update(['tailor_paid_amount' => 100]);
        $this->actingAs($owner)->patch(route('admin.tailor-jobs.assign', $order), [
            'tailor_id' => $secondTailor->id,
            'tailor_price' => $rateId.'-1',
            'confirm_reassign' => 1,
        ])->assertSessionHasErrors('tailor_id');
        $this->assertSame($secondTailor->id, (int) $order->fresh()->tailorId);
    }

    public function test_shop_owner_can_progress_a_job_and_an_audit_event_is_created(): void
    {
        [$owner, $tailor, $order] = $this->job();

        $this->actingAs($owner)->patch(route('admin.tailor-jobs.status', $order), [
            'status' => 'cutting',
            'note' => 'Pattern prepared',
        ])->assertRedirect();

        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'cutting']);
        $this->assertNotNull($order->fresh()->started_at);
        $this->assertDatabaseHas('order_status_histories', [
            'order_id' => $order->id,
            'from_status' => 'assigned',
            'to_status' => 'cutting',
            'changed_by_type' => 'shop_owner',
            'note' => 'Pattern prepared',
        ]);
        $this->assertDatabaseHas('order_notification_deliveries', [
            'order_id' => $order->id,
            'customer_id' => $order->sub_customer,
            'stage' => 'cutting',
            'status' => 'sent',
            'attempt_count' => 1,
        ]);
        $this->assertDatabaseHas('notifications', [
            'notifiable_type' => Customers::class,
            'notifiable_id' => $order->sub_customer,
            'type' => 'tailor_job_status',
        ]);
    }

    public function test_weekly_orders_status_control_switches_between_workshop_and_ready(): void
    {
        [$owner, , $order] = $this->job(['status' => 'cutting']);
        $rack = Rack::where('user_id', $owner->id)->firstOrFail();

        $this->actingAs($owner)->postJson(route('admin.order.status'), [
            'order_id' => $order->id,
            'order_status' => 'complete',
            'rack_no' => $rack->rack_no,
        ])->assertOk()
            ->assertJsonPath('status', 'ready')
            ->assertJsonPath('next_actions.0.value', 'start')
            ->assertJsonPath('next_actions.1.value', 'deliver')
            ->assertJsonPath('tailor_change_allowed', false);

        $this->assertSame('ready', $order->fresh()->status);

        $this->actingAs($owner)->postJson(route('admin.order.status'), [
            'order_id' => $order->id,
            'order_status' => 'start',
        ])->assertUnprocessable()
            ->assertJsonValidationErrors('note');

        $this->assertSame('ready', $order->fresh()->status);

        $this->actingAs($owner)->postJson(route('admin.order.status'), [
            'order_id' => $order->id,
            'order_status' => 'start',
            'note' => 'گاہک نے درستگی کے لیے واپس کیا',
        ])->assertOk()
            ->assertJsonPath('status', 'cutting')
            ->assertJsonPath('next_actions.0.value', 'complete')
            ->assertJsonPath('tailor_change_allowed', true);

        $this->assertSame('cutting', $order->fresh()->status);
        $this->assertNull($order->fresh()->ready_at);
        $this->assertNull($order->fresh()->rack_no);
        $this->assertDatabaseHas('order_status_histories', [
            'order_id' => $order->id,
            'from_status' => 'ready',
            'to_status' => 'cutting',
            'changed_by_type' => 'shop_owner',
            'note' => 'گاہک نے درستگی کے لیے واپس کیا',
        ]);
    }

    public function test_ready_garment_accepts_an_optional_rack_and_saves_a_selected_location(): void
    {
        [$owner, , $order] = $this->job(['status' => 'cutting']);

        $this->actingAs($owner)->post(route('admin.order.status'), [
            'order_id' => $order->id,
            'order_status' => 'complete',
        ])->assertRedirect()->assertSessionHas('success');

        $this->assertSame('ready', $order->fresh()->status);
        $this->assertNull($order->fresh()->rack_no);

        [$secondOwner, , $secondOrder] = $this->job(['status' => 'cutting']);

        $this->actingAs($secondOwner)->post(route('admin.tailor-racks.store'), [
            'rack_no' => 'EID-12',
        ])->assertRedirect()->assertSessionHas('success');

        $this->actingAs($secondOwner)->post(route('admin.order.status'), [
            'order_id' => $secondOrder->id,
            'order_status' => 'complete',
            'rack_no' => 'EID-12',
        ])->assertRedirect()->assertSessionHas('success');

        $this->assertDatabaseHas('orders', [
            'id' => $secondOrder->id,
            'status' => 'ready',
            'rack_no' => 'EID-12',
        ]);
    }

    public function test_workshop_page_uses_two_statuses_and_tailor_can_mark_an_order_ready(): void
    {
        [$owner, $tailor, $order] = $this->job(['status' => 'assigned']);
        $rack = Rack::where('user_id', $owner->id)->firstOrFail();

        $this->actingAs($owner)
            ->get(route('admin.order.total', ['week' => $order->returnDate]))
            ->assertOk()
            ->assertSee('name="order_status"', false)
            ->assertSee('value="complete"', false);

        $this->app['auth']->guard()->logout();
        $session = [
            'tailor-login-success' => $tailor->name,
            'tailor' => 'tailor',
            'tailor_id' => $tailor->id,
        ];

        $this->withSession($session)->post(route('tailor.order.status'), [
            'order_id' => $order->id,
            'order_status' => 'complete',
            'rack_no' => $rack->rack_no,
        ])->assertRedirect()->assertSessionHas('success');

        $this->assertSame('ready', $order->fresh()->status);
        $this->assertSame($rack->rack_no, $order->fresh()->rack_no);
        $this->assertDatabaseHas('order_status_histories', [
            'order_id' => $order->id,
            'from_status' => 'assigned',
            'to_status' => 'ready',
            'changed_by_type' => 'tailor',
        ]);

        $this->withSession($session)
            ->from(route('tailor.jobs.index'))
            ->post(route('tailor.order.status'), [
                'order_id' => $order->id,
                'order_status' => 'deliver',
            ])
            ->assertRedirect(route('tailor.jobs.index'))
            ->assertSessionHasErrors('order_status');

        $this->assertSame('ready', $order->fresh()->status);
    }

    public function test_simple_workflow_allows_the_shop_owner_to_deliver_a_ready_order(): void
    {
        [$owner, , $order] = $this->job(['status' => 'ready']);

        $customerOrders = $this->actingAs($owner)
            ->getJson(route('admin.getCustomer', ['id' => $order->customerId]))
            ->assertOk()
            ->json();
        $historyOrder = collect($customerOrders)->firstWhere('orderId', $order->id);

        $this->assertSame('تیار ہے', $historyOrder['button']);
        $this->assertSame([
            ['value' => 'start', 'label' => 'کارخانے میں ہے'],
            ['value' => 'complete', 'label' => 'تیار ہے'],
        ], $historyOrder['nextStatuses']);
        $this->assertTrue($historyOrder['canMarkDelivered']);
        $this->assertFalse($historyOrder['isDelivered']);

        $this->actingAs($owner)->post(route('admin.order.status'), [
            'order_id' => $order->id,
            'order_status' => 'deliver',
        ])->assertRedirect()->assertSessionHas('success');

        $this->assertSame('delivered', $order->fresh()->status);
        $this->assertNotNull($order->fresh()->delivered_at);
        $this->assertDatabaseHas('order_status_histories', [
            'order_id' => $order->id,
            'from_status' => 'ready',
            'to_status' => 'delivered',
            'changed_by_type' => 'shop_owner',
        ]);

        $deliveredOrders = $this->actingAs($owner)
            ->getJson(route('admin.getCustomer', ['id' => $order->customerId]))
            ->assertOk()
            ->json();
        $deliveredOrder = collect($deliveredOrders)->firstWhere('orderId', $order->id);

        $this->assertSame('تیار ہے', $deliveredOrder['button']);
        $this->assertSame([], $deliveredOrder['nextStatuses']);
        $this->assertSame('order-stage-ready', $deliveredOrder['btnClass']);
        $this->assertFalse($deliveredOrder['canMarkDelivered']);
        $this->assertTrue($deliveredOrder['isDelivered']);
    }

    public function test_tailor_order_history_uses_the_selected_workflow_statuses(): void
    {
        [$owner, $tailor, $order] = $this->job(['status' => 'assigned']);

        $this->actingAs($owner)
            ->get(route('admin.tailor-orders', $tailor))
            ->assertOk()
            ->assertSeeText('کارخانے میں ہے')
            ->assertDontSeeText('درزی مقرر');

        $order->update(['status' => 'delivered']);

        $this->actingAs($owner)
            ->get(route('admin.tailor-orders', $tailor))
            ->assertOk()
            ->assertSeeText('تیار ہے')
            ->assertSeeText('گاہک کے حوالے ہو گیا')
            ->assertSee('to-status is-delivered', false);

        $owner->business->update(['tailoring_status_mode' => Business::TAILORING_STATUS_DETAILED]);

        $this->actingAs($owner)
            ->get(route('admin.tailor-orders', $tailor))
            ->assertOk()
            ->assertSeeText('حوالہ شدہ')
            ->assertDontSeeText('گاہک کے حوالے ہو گیا');
    }

    public function test_shop_can_enable_detailed_statuses_for_workshop_weekly_orders_and_qr(): void
    {
        [$owner, , $order] = $this->job(['status' => 'stitching']);

        $this->actingAs($owner)->put(route('admin.tailoring-workflow.update'), [
            'tailoring_status_mode' => Business::TAILORING_STATUS_DETAILED,
        ])->assertRedirect()->assertSessionHas('success');

        $this->assertDatabaseHas('businesses', [
            'owner_user_id' => $owner->id,
            'tailoring_status_mode' => Business::TAILORING_STATUS_DETAILED,
        ]);

        $this->actingAs($owner)
            ->get(route('admin.order.total', ['week' => $order->returnDate]))
            ->assertOk()
            ->assertSeeText('سلائی')
            ->assertSee(route('admin.tailor-jobs.status', $order), false)
            ->assertSee('name="status"', false)
            ->assertDontSeeText('فہرست')
            ->assertDontSeeText('رقم / بقایا');

        $this->actingAs($owner)
            ->get(route('admin.Customers.index'))
            ->assertOk()
            ->assertSee(route('admin.customers.statement', $order->customerId), false)
            ->assertDontSee('name="status"', false)
            ->assertDontSee('data-action-base="'.url('admin/tailor-jobs').'"', false);

        $this->actingAs($owner)
            ->get(route('admin.customers.statement', ['id' => $order->customerId, 'tab' => 'tailoring']))
            ->assertOk()
            ->assertSeeText('سلائی')
            ->assertDontSee('name="status"', false);

        $customerOrders = $this->actingAs($owner)
            ->getJson(route('admin.getCustomer', ['id' => $order->customerId]))
            ->assertOk()
            ->json();
        $historyOrder = collect($customerOrders)->firstWhere('orderId', $order->id);

        $this->assertSame('سلائی', $historyOrder['button']);
        $this->assertSame(Order::nextStatusOptionsFor('stitching'), $historyOrder['nextStatuses']);

        $trackingUrl = URL::signedRoute('orders.track', ['order' => $order->id]);
        $this->get($trackingUrl)
            ->assertOk()
            ->assertSeeText('سلائی')
            ->assertDontSeeText('کارخانے میں ہے');
    }

    public function test_lifecycle_notification_delivery_is_idempotent(): void
    {
        [$owner, , $order] = $this->job(['status' => 'cutting']);
        $service = app(OrderLifecycleNotificationService::class);

        $service->send($order, 'cutting', 'First attempt');
        $service->send($order, 'cutting', 'Duplicate attempt');
        $order->customers->delete();
        $service->send($order, 'cutting', 'Customer later unavailable');

        $this->assertSame(1, OrderNotificationDelivery::where('order_id', $order->id)->count());
        $this->assertSame(1, $order->customers->notifications()->count());
        $this->assertSame(1, OrderNotificationDelivery::first()->attempt_count);
        $this->assertSame('sent', OrderNotificationDelivery::first()->status);
    }

    public function test_missing_customer_is_logged_and_can_be_safely_retried_after_restore(): void
    {
        [$owner, , $order] = $this->job();
        $customer = $order->customers;
        $customer->delete();

        $this->actingAs($owner)->patch(route('admin.tailor-jobs.status', $order), [
            'status' => 'cutting',
        ])->assertRedirect();

        $delivery = OrderNotificationDelivery::where('order_id', $order->id)->firstOrFail();
        $this->assertSame('skipped', $delivery->status);
        $this->assertSame('cutting', $order->fresh()->status);

        $customer->restore();
        $this->actingAs($owner)->post(
            route('admin.tailor-jobs.notifications.retry', [$order, $delivery]),
        )->assertRedirect()->assertSessionHas('success');

        $this->assertSame('sent', $delivery->fresh()->status);
        $this->assertSame(1, $customer->notifications()->count());
    }

    public function test_job_cannot_skip_a_required_lifecycle_stage(): void
    {
        [$owner, , $order] = $this->job();

        $this->actingAs($owner)->from(route('admin.tailor-jobs.index'))
            ->patch(route('admin.tailor-jobs.status', $order), ['status' => 'stitching'])
            ->assertRedirect(route('admin.tailor-jobs.index'))
            ->assertSessionHasErrors('status');

        $this->assertSame('assigned', $order->fresh()->status);
    }

    public function test_trial_rework_is_labelled_clearly_without_duplicate_status_options(): void
    {
        $options = Order::nextStatusOptionsFor('trial');

        $this->assertSame(['stitching', 'ready'], array_column($options, 'value'));
        $this->assertSame(count($options), count(array_unique(array_column($options, 'value'))));
        $this->assertSame('سلائی پر واپس (ترمیم / دوبارہ کام)', $options[0]['label']);
        $this->assertSame('تیار', $options[1]['label']);

        $readyOptions = Order::nextStatusOptionsFor('ready');
        $this->assertSame(['stitching', 'delivered'], array_column($readyOptions, 'value'));
    }

    public function test_detailed_ready_order_requires_a_reason_before_returning_to_production(): void
    {
        [$owner, , $order] = $this->job(['status' => 'ready']);

        $this->actingAs($owner)->patchJson(route('admin.tailor-jobs.status', $order), [
            'status' => 'stitching',
        ])->assertUnprocessable()->assertJsonValidationErrors('note');

        $this->assertSame('ready', $order->fresh()->status);

        $this->actingAs($owner)->patchJson(route('admin.tailor-jobs.status', $order), [
            'status' => 'stitching',
            'note' => 'بازو کی لمبائی درست کرنی ہے',
        ])->assertOk()->assertJsonPath('status', 'stitching');

        $this->assertDatabaseHas('order_status_histories', [
            'order_id' => $order->id,
            'from_status' => 'ready',
            'to_status' => 'stitching',
            'note' => 'بازو کی لمبائی درست کرنی ہے',
        ]);
    }

    public function test_tailor_can_only_update_their_own_jobs_and_cannot_mark_delivery(): void
    {
        [, $tailor, $order] = $this->job(['status' => 'ready']);
        [, $otherTailor, $otherOrder] = $this->job();

        $session = [
            'tailor-login-success' => $tailor->name,
            'tailor' => 'tailor',
            'tailor_id' => $tailor->id,
        ];

        $this->withSession($session)
            ->patch(route('tailor.jobs.status', $otherOrder), ['status' => 'cutting'])
            ->assertNotFound();

        $this->withSession($session)
            ->from(route('tailor.jobs.index'))
            ->patch(route('tailor.jobs.status', $order), ['status' => 'delivered'])
            ->assertRedirect(route('tailor.jobs.index'))
            ->assertSessionHasErrors('status');

        $this->assertSame('ready', $order->fresh()->status);
        $this->assertSame('assigned', $otherOrder->fresh()->status);
    }

    public function test_tailor_can_progress_their_own_job_and_history_allows_a_session_actor(): void
    {
        [, $tailor, $order] = $this->job(['status' => 'assigned']);
        $session = [
            'tailor-login-success' => $tailor->name,
            'tailor' => 'tailor',
            'tailor_id' => $tailor->id,
        ];

        $this->withSession($session)
            ->patch(route('tailor.jobs.status', $order), [
                'status' => 'cutting',
                'note' => 'کپڑا کاٹ دیا گیا ہے',
            ])
            ->assertRedirect()
            ->assertSessionHas('success');

        $this->assertSame('cutting', $order->fresh()->status);
        $this->assertDatabaseHas('order_status_histories', [
            'order_id' => $order->id,
            'user_id' => null,
            'tailor_id' => $tailor->id,
            'changed_by_type' => 'tailor',
            'from_status' => 'assigned',
            'to_status' => 'cutting',
        ]);
    }

    public function test_tailor_payment_updates_status_and_creates_an_audit_record(): void
    {
        [$owner, $tailor, $order] = $this->job([
            'suitQuantity' => 2,
            'tailor_price' => 500,
        ]);

        $this->actingAs($owner)->patch(route('admin.tailor-jobs.payment', $order), [
            'paid_amount' => 400,
        ])->assertRedirect();

        $order->refresh();
        $this->assertSame('partial', $order->tailor_payment_status);
        $this->assertEquals(400, (float) $order->tailor_paid_amount);
        $this->assertDatabaseHas('tailor_records', [
            'tailor_id' => $tailor->id,
            'order_id' => $order->id,
            'amount' => 400,
            'comment' => 'salary',
        ]);

        $this->actingAs($owner)->patch(route('admin.tailor-jobs.payment', $order), [
            'paid_amount' => 1000,
        ])->assertRedirect();

        $this->assertSame('paid', $order->fresh()->tailor_payment_status);
        $this->assertEquals(1000, (float) TailorRecord::where('order_id', $order->id)->sum('amount'));
    }

    public function test_tailor_overpayment_shows_a_local_urdu_error_and_preserves_saved_amount(): void
    {
        [$owner, , $order] = $this->job([
            'suitQuantity' => 2,
            'tailor_price' => 500,
            'tailor_paid_amount' => 400,
        ]);

        $response = $this->actingAs($owner)
            ->from(route('admin.Tailor.index'))
            ->patch(route('admin.tailor-jobs.payment', $order), ['paid_amount' => 1100]);

        $response->assertRedirect(route('admin.Tailor.index'))
            ->assertSessionHasErrors(
                'paid_amount',
                'ادا شدہ رقم درزی کی کل کمائی سے زیادہ نہیں ہو سکتی۔',
                'tailorPayment'.$order->id,
            );
        $this->assertEquals(400, (float) $order->fresh()->tailor_paid_amount);

    }

    public function test_shop_owner_cannot_access_another_shops_job(): void
    {
        [$owner] = $this->job();
        [, , $otherOrder] = $this->job();

        $this->actingAs($owner)
            ->patch(route('admin.tailor-jobs.status', $otherOrder), ['status' => 'cutting'])
            ->assertNotFound();
    }

    public function test_tailoring_dashboard_separates_upcoming_overdue_and_ready_orders_with_filtered_result_links(): void
    {
        [$owner, $tailor, $overdueOrder] = $this->job([
            'returnDate' => now()->subDay()->toDateString(),
            'status' => 'stitching',
        ]);
        $overdueOrder->customers->forceFill(['serial_number' => 1404])->save();
        $baseOrder = [
            'customerId' => $overdueOrder->customerId,
            'sub_customer' => $overdueOrder->sub_customer,
            'suitQuantity' => 1,
            'totalPayment' => 2000,
            'tailorId' => $tailor->id,
            'tailor_price' => 500,
            'userId' => $owner->id,
        ];
        $upcomingOrder = Order::create($baseOrder + [
            'returnDate' => now()->addDays(2)->toDateString(),
            'status' => 'assigned',
        ]);
        $readyOrder = Order::create($baseOrder + [
            'returnDate' => now()->subDays(2)->toDateString(),
            'status' => 'ready',
        ]);
        $deliveredOrder = Order::create($baseOrder + [
            'returnDate' => now()->subDays(3)->toDateString(),
            'status' => 'delivered',
        ]);
        $otherOwner = User::factory()->create();
        $otherCustomer = Customers::create([
            'name' => 'Another Shop Customer',
            'phone_number1' => fake()->unique()->numerify('03#########'),
            'user_id' => $otherOwner->id,
        ]);
        $crossShopOrder = Order::create(array_merge($baseOrder, [
            'customerId' => $otherCustomer->id,
            'sub_customer' => $otherCustomer->id,
            'returnDate' => now()->subDays(4)->toDateString(),
            'status' => 'stitching',
        ]));

        $dashboard = $this->actingAs($owner)->get(route('admin.dashboard.tailoring'));
        $dashboard
            ->assertOk()
            ->assertSeeText('قریب آنے والی حوالگیاں')
            ->assertSeeText('تاخیر کا شکار آرڈرز')
            ->assertSeeText('تیار، حوالگی کے منتظر')
            ->assertSee(route('admin.order.total', ['filter' => 'upcoming']), false)
            ->assertSee(route('admin.order.total', ['filter' => 'overdue']), false)
            ->assertSee(route('admin.order.total', ['filter' => 'ready']), false)
            ->assertSee('<span class="operation-id">#1404</span>', false)
            ->assertDontSeeText('Another Shop Customer');
        $dashboard->assertViewHas('operationalOrders', fn ($orders) => $orders->pluck('id')->all() === [$upcomingOrder->id]);
        $dashboard->assertViewHas('overdueOrders', fn ($orders) => $orders->pluck('id')->all() === [$overdueOrder->id]);
        $dashboard->assertViewHas('readyForHandoverOrders', fn ($orders) => $orders->pluck('id')->all() === [$readyOrder->id]);

        $overdueResults = $this->actingAs($owner)->get(route('admin.order.total', ['filter' => 'overdue']));
        $overdueResults
            ->assertOk()
            ->assertViewIs('All_Total.order')
            ->assertSeeText('تاخیر کا شکار آرڈرز')
            ->assertSee('id="wo-search"', false)
            ->assertSee('id="wo-status-filter"', false)
            ->assertSee('id="wo-tailor-filter"', false)
            ->assertSee('class="wo-table-head"', false)
            ->assertSeeText('کام کا مرحلہ')
            ->assertDontSeeText('رقم / بقایا');
        $overdueResults->assertViewHas('weekDays', fn ($days) => $days
            ->flatMap(fn ($day) => $day['orders'])->pluck('id')->all() === [$overdueOrder->id]);
        $this->assertNotContains($crossShopOrder->id, $overdueResults->viewData('weekDays')
            ->flatMap(fn ($day) => $day['orders'])->pluck('id'));

        $readyResults = $this->actingAs($owner)->get(route('admin.order.total', ['filter' => 'ready']));
        $readyResults
            ->assertOk()
            ->assertViewIs('All_Total.order')
            ->assertSeeText('تیار، حوالگی کے منتظر');
        $readyResults->assertViewHas('weekDays', fn ($days) => $days
            ->flatMap(fn ($day) => $day['orders'])->pluck('id')->all() === [$readyOrder->id]);
    }

    private function job(array $overrides = []): array
    {
        $role = Role::firstOrCreate(['name' => 'shop_owner', 'guard_name' => 'web']);
        $owner = User::factory()->create(['tailoring_access' => true, 'is_business_owner' => true]);
        $owner->assignRole($role);
        $business = Business::create([
            'name' => $owner->name,
            'owner_user_id' => $owner->id,
            'tailoring_enabled' => true,
            'clothing_enabled' => false,
            'status' => Business::STATUS_ACTIVE,
        ]);
        $owner->forceFill(['business_id' => $business->id])->save();
        $rack = new Rack(['rack_no' => 'A-01']);
        $rack->user_id = $owner->id;
        $rack->save();
        $tailor = Tailor::create([
            'name' => fake()->name(),
            'phone_number1' => fake()->unique()->numerify('03#########'),
            'password' => bcrypt('password'),
            'user_id' => $owner->id,
        ]);
        $customer = Customers::create([
            'name' => fake()->name(),
            'phone_number1' => fake()->unique()->numerify('03#########'),
            'user_id' => $owner->id,
        ]);
        $order = Order::create(array_merge([
            'customerId' => $customer->id,
            'sub_customer' => $customer->id,
            'suitQuantity' => 1,
            'totalPayment' => 2000,
            'tailorId' => $tailor->id,
            'tailor_price' => 500,
            'returnDate' => now()->addDays(3)->toDateString(),
            'userId' => $owner->id,
            'status' => 'assigned',
            'tailor_paid_amount' => 0,
            'tailor_payment_status' => 'unpaid',
            'rack_no' => in_array($overrides['status'] ?? 'assigned', ['ready', 'delivered'], true) ? $rack->rack_no : null,
        ], $overrides));

        return [$owner, $tailor, $order];
    }
}
