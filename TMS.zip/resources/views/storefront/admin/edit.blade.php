@extends('main')

@section('content')
<section class="main-content storefront-admin">
    <style>
        .storefront-admin{background:#f3f7f8;min-height:calc(100vh - 70px)}
        .storefront-hero{background:linear-gradient(135deg,#0f5132,#14805e);border-radius:22px;color:#fff;padding:1.8rem 2rem;box-shadow:0 16px 36px rgba(15,81,50,.2)}
        .storefront-hero h1{color:#fff!important}.storefront-hero p{color:rgba(255,255,255,.78)}
        .storefront-card{border:0;border-radius:18px;box-shadow:0 10px 28px rgba(31,45,61,.08);overflow:hidden}
        .storefront-card .card-header{background:#fff;border-bottom:1px solid #e8eef2;padding:1rem 1.25rem}
        .storefront-card .card-body{padding:1.35rem}
        .module-choice{display:block;border:1px solid #dbe7e2;border-radius:16px;padding:1rem;height:100%;background:#fbfefd;cursor:pointer}
        .module-choice:hover{border-color:#14805e}.module-choice input{margin-left:.55rem}
        .publish-state{border-radius:999px;padding:.45rem .8rem;font-weight:700}
        .preview-box{background:#eef8f4;border:1px dashed #78b89e;border-radius:14px;padding:1rem;word-break:break-word}
        .onboarding-step{display:flex;align-items:flex-start;gap:.7rem;padding:.65rem 0;border-bottom:1px solid #edf1f3}
        .onboarding-step:last-child{border-bottom:0}.onboarding-step i{margin-top:.25rem}
        .sticky-actions{position:sticky;bottom:0;background:rgba(255,255,255,.96);border-top:1px solid #e1e9ed;padding:1rem;z-index:10}
        @media(max-width:767px){.storefront-hero{border-radius:15px;padding:1.25rem}.storefront-card .card-body{padding:1rem}.sticky-actions .btn{width:100%;margin:.25rem 0!important}}
    </style>
    <div class="container-fluid px-3 px-md-4 py-4">
        <div class="storefront-hero mb-4 d-flex flex-wrap justify-content-between align-items-center">
            <div>
                <div class="small mb-2">عوامی تشہیر اور آن لائن کاروبار</div>
                <h1 class="h3 mb-2">آن لائن دکان</h1>
                <p class="mb-0">اپنی دکان کا تعارف، رابطہ معلومات اور عوام کو دکھائے جانے والے شعبے ترتیب دیں۔</p>
            </div>
            <span class="publish-state mt-3 mt-md-0 {{ $storefront->is_published ? 'bg-success' : 'bg-light text-dark' }}">
                {{ $storefront->is_published ? 'شائع شدہ' : 'مسودہ' }}
            </span>
        </div>

        @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
        @if($storefront->exists && $storefront->moderation_status === 'paused')
            <div class="alert alert-danger"><strong>عوامی دکان عارضی طور پر روکی گئی ہے۔</strong><br>{{ $storefront->moderation_reason }}<br><small>آپ کی دکان، آرڈرز، گاہک اور تمام ریکارڈ محفوظ ہیں۔ مسئلہ حل ہونے کے بعد سپر ایڈمن عوامی رسائی دوبارہ بحال کر سکتا ہے۔</small></div>
        @endif
        @if($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif

        <form method="POST" action="{{ route('admin.storefront.update') }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="row">
                <div class="col-lg-8">
                    <div class="card storefront-card mb-4">
                        <div class="card-header"><h2 class="h5 mb-1">دکان کا تعارف</h2><p class="small text-muted mb-0">یہ معلومات ہر آنے والے گاہک کو نظر آئیں گی۔</p></div>
                        <div class="card-body">
                            <div class="form-row">
                                <div class="form-group col-md-7"><label for="display_name">عوامی دکان کا نام</label><input id="display_name" name="display_name" class="form-control" maxlength="150" required value="{{ old('display_name',$storefront->display_name) }}"></div>
                                <div class="form-group col-md-5"><label for="slug">دکان کا مستقل لنک</label><div class="input-group" dir="ltr"><div class="input-group-prepend"><span class="input-group-text">/shops/</span></div><input id="slug" name="slug" class="form-control" maxlength="100" pattern="[a-z0-9]+(?:-[a-z0-9]+)*" required value="{{ old('slug',$storefront->slug) }}"></div><small class="text-muted">صرف چھوٹے انگریزی حروف، اعداد اور ڈیش</small></div>
                            </div>
                            <div class="form-group"><label for="tagline">مختصر تعارفی جملہ</label><input id="tagline" name="tagline" class="form-control" maxlength="180" value="{{ old('tagline',$storefront->tagline) }}" placeholder="مثلاً معیاری کپڑا، نفیس سلائی اور بروقت فراہمی"></div>
                            <div class="form-group"><label for="description">کاروبار کی تفصیل</label><textarea id="description" name="description" class="form-control" rows="5" maxlength="3000" placeholder="اپنی خصوصیات، تجربہ اور خدمات بیان کریں۔">{{ old('description',$storefront->description) }}</textarea></div>
                            <div class="form-row">
                                <div class="form-group col-md-6"><label for="logo">لوگو <span class="text-muted">(اختیاری)</span></label><input id="logo" type="file" name="logo" class="form-control-file" accept="image/*"></div>
                                <div class="form-group col-md-6"><label for="cover">سرورق تصویر <span class="text-muted">(اختیاری)</span></label><input id="cover" type="file" name="cover" class="form-control-file" accept="image/*"></div>
                            </div>
                        </div>
                    </div>

                    @if($business->clothing_enabled || $business->tailoring_enabled)
                    <div class="card storefront-card mb-4">
                        <div class="card-header">
                            <h2 class="h5 mb-1">ہر شعبے کی الگ ترتیب</h2>
                            <p class="small text-muted mb-0">آرڈر، درخواست، ادائیگی اور فراہمی متعلقہ شعبے میں الگ کنٹرول کریں۔</p>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                @if($business->tailoring_enabled)
                                <div class="col-md-6 mb-2">
                                    @if($storefront->exists)
                                    <a class="module-choice d-flex text-decoration-none h-100" href="{{ route('admin.storefront.module-settings.edit', 'tailoring') }}">
                                        <i class="fas fa-cut text-primary ml-3 mt-1"></i>
                                        <span><strong class="d-block text-dark">ٹیلرنگ کی ترتیب</strong><small class="text-muted">درخواستیں، ادائیگی، پیمائش/وصولی اور فراہمی</small></span>
                                    </a>
                                    @else
                                    <div class="module-choice d-flex h-100 text-muted" aria-disabled="true">
                                        <i class="fas fa-cut ml-3 mt-1"></i>
                                        <span><strong class="d-block">ٹیلرنگ کی ترتیب</strong><small>پہلے بنیادی معلومات محفوظ کریں، پھر ٹیلرنگ کی ترتیب دستیاب ہوگی۔</small></span>
                                    </div>
                                    @endif
                                </div>
                                @endif
                                @if($business->clothing_enabled)
                                <div class="col-md-6 mb-2">
                                    @if($storefront->exists)
                                    <a class="module-choice d-flex text-decoration-none h-100" href="{{ route('admin.storefront.module-settings.edit', 'clothing') }}">
                                        <i class="fas fa-shopping-bag text-success ml-3 mt-1"></i>
                                        <span><strong class="d-block text-dark">کپڑوں کی دکان کی ترتیب</strong><small class="text-muted">کیٹلاگ/آرڈر، ادائیگی، وصولی اور فراہمی</small></span>
                                    </a>
                                    @else
                                    <div class="module-choice d-flex h-100 text-muted" aria-disabled="true">
                                        <i class="fas fa-shopping-bag ml-3 mt-1"></i>
                                        <span><strong class="d-block">کپڑوں کی دکان کی ترتیب</strong><small>پہلے بنیادی معلومات محفوظ کریں، پھر کپڑوں کی دکان کی ترتیب دستیاب ہوگی۔</small></span>
                                    </div>
                                    @endif
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                    @php
                        $easypaisaSelected = (bool) ($errors->any() ? old('easypaisa_enabled') : old('easypaisa_enabled', $storefront->easypaisa_enabled));
                        $jazzcashSelected = (bool) ($errors->any() ? old('jazzcash_enabled') : old('jazzcash_enabled', $storefront->jazzcash_enabled));
                        $bankTransferSelected = (bool) ($errors->any() ? old('bank_transfer_enabled') : old('bank_transfer_enabled', $storefront->bank_transfer_enabled));
                        $raastSelected = (bool) ($errors->any() ? old('raast_enabled') : old('raast_enabled', $storefront->raast_enabled));
                        $savedPaymentMode = $storefront->unpaid_orders_enabled ? 'none' : 'methods';
                        $paymentCollectionMode = old('payment_collection_mode', $savedPaymentMode);
                        $showPaymentMethods = $paymentCollectionMode === 'methods';
                        $hasReceivingMethod = $easypaisaSelected || $jazzcashSelected || $bankTransferSelected || $raastSelected;
                    @endphp
                    <div class="card storefront-card mb-4 d-none" aria-hidden="true">
                        <div class="card-header">
                            <h2 class="h5 mb-1">آن لائن ادائیگی کے طریقے</h2>
                            <p class="small text-muted mb-0">کپڑوں کے آرڈر اور ٹیلرنگ درخواستوں کے لیے قبول شدہ طریقے الگ الگ کنٹرول کریں۔</p>
                        </div>
                        <div class="card-body">
                            <input type="hidden" name="commerce_settings_present" value="1">
                            @if($business->clothing_enabled)
                            <label class="module-choice d-block mb-3">
                                <div class="d-flex">
                                    <input type="checkbox" name="online_ordering_enabled" value="1" @checked(old('online_ordering_enabled',$storefront->online_ordering_enabled))>
                                    <div>
                                        <strong><i class="fas fa-shopping-cart text-success ml-1"></i> آن لائن آرڈر قبول کریں</strong>
                                        <div class="small text-muted mt-1">اسے بند رکھنے پر کپڑے، قیمت اور دستیابی نظر آئے گی مگر ٹوکری اور چیک آؤٹ نہیں ہوں گے۔</div>
                                    </div>
                                </div>
                            </label>
                            @endif
                            <h3 class="h6 mb-3">کیا آپ آرڈر یا درخواست کے ساتھ ادائیگی کا طریقہ دینا چاہتے ہیں؟</h3>
                            <div class="row d-none" aria-hidden="true">
                                <div class="col-md-6 mb-2">
                                    <label class="module-choice d-flex align-items-start">
                                        <input type="radio" name="payment_collection_mode" value="none" data-payment-mode @checked($paymentCollectionMode === 'none') required>
                                        <span><strong>نہیں — ابھی ادائیگی قبول نہیں کریں گے</strong><small class="d-block text-muted mt-1">گاہک آرڈر یا درخواست بغیر ادائیگی بھیج سکے گا۔</small></span>
                                    </label>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <label class="module-choice d-flex align-items-start">
                                        <input type="radio" name="payment_collection_mode" value="methods" data-payment-mode @checked($paymentCollectionMode === 'methods') required>
                                        <span><strong>ہاں — ادائیگی کے طریقے منتخب کریں</strong><small class="d-block text-muted mt-1">اگلے مرحلے میں COD، والٹ، بینک یا راست منتخب کریں۔</small></span>
                                    </label>
                                </div>
                            </div>
                            <div id="no-payment-note" class="alert alert-light border mt-3 mb-0" {{ $showPaymentMethods ? 'hidden' : '' }}>
                                <i class="fas fa-check-circle text-success ml-1"></i> ادائیگی کے تمام طریقے چھپا دیے گئے ہیں۔ گاہک بغیر آن لائن ادائیگی درخواست یا آرڈر بھیج سکے گا۔
                            </div>
                            <div id="payment-method-options" class="mt-3" {{ ! $showPaymentMethods ? 'hidden' : '' }}>
                                <h3 class="h6">قبول شدہ طریقے منتخب کریں</h3>
                                <div class="row">
                                    <div class="col-md-4 mb-2"><label class="module-choice d-flex align-items-center"><input type="checkbox" name="cod_enabled" value="1" data-payment-option @checked(old('cod_enabled',$storefront->cod_enabled)) @disabled(! $showPaymentMethods)> کیش آن ڈیلیوری</label></div>
                                    <div class="col-md-4 mb-2"><label class="module-choice d-flex align-items-center"><input type="checkbox" name="easypaisa_enabled" value="1" data-payment-option data-payment-method="easypaisa" @checked($easypaisaSelected) @disabled(! $showPaymentMethods)> ایزی پیسہ — دستی تصدیق</label></div>
                                    <div class="col-md-4 mb-2"><label class="module-choice d-flex align-items-center"><input type="checkbox" name="jazzcash_enabled" value="1" data-payment-option data-payment-method="jazzcash" @checked($jazzcashSelected) @disabled(! $showPaymentMethods)> جاز کیش — دستی تصدیق</label></div>
                                    <div class="col-md-4 mb-2"><label class="module-choice d-flex align-items-center"><input type="checkbox" name="bank_transfer_enabled" value="1" data-payment-option data-payment-method="bank" @checked($bankTransferSelected) @disabled(! $showPaymentMethods)> بینک ٹرانسفر — دستی تصدیق</label></div>
                                    <div class="col-md-4 mb-2"><label class="module-choice d-flex align-items-center"><input type="checkbox" name="raast_enabled" value="1" data-payment-option data-payment-method="raast" @checked($raastSelected) @disabled(! $showPaymentMethods)> راست / Raast QR — دستی تصدیق</label></div>
                                </div>
                            </div>
                            <div id="payment-details-empty" class="alert alert-light border mt-3 mb-0" {{ ! $showPaymentMethods || $hasReceivingMethod ? 'hidden' : '' }}>
                                <i class="fas fa-info-circle ml-1"></i> کیش آن ڈیلیوری کے لیے اکاؤنٹ کی تفصیلات درکار نہیں۔ والٹ، بینک یا راست منتخب کرنے پر متعلقہ خانے ظاہر ہوں گے۔
                            </div>
                            <div id="payment-receiving-details" class="border rounded p-3 mt-3" {{ ! $showPaymentMethods || ! $hasReceivingMethod ? 'hidden' : '' }}>
                                <h3 class="h6">عوام کو دکھائی جانے والی وصولی کی معلومات</h3>
                                <p class="small text-muted">صرف فعال ادائیگی کے طریقے کی معلومات چیک آؤٹ پر دکھائی جائیں گی۔ خفیہ PIN، OTP یا پاس ورڈ کبھی درج نہ کریں۔</p>
                                <div class="form-row">
                                    <div class="col-12 payment-detail-panel" data-payment-details-for="easypaisa" {{ ! $easypaisaSelected ? 'hidden' : '' }}><div class="form-row">
                                        <div class="form-group col-md-6"><label for="easypaisa_account_title">ایزی پیسہ اکاؤنٹ عنوان</label><input id="easypaisa_account_title" name="easypaisa_account_title" class="form-control" maxlength="150" value="{{ old('easypaisa_account_title',$storefront->easypaisa_account_title) }}" @disabled(! $easypaisaSelected) required></div>
                                        <div class="form-group col-md-6"><label for="easypaisa_account_number">ایزی پیسہ نمبر</label><input id="easypaisa_account_number" name="easypaisa_account_number" dir="ltr" class="form-control text-left" maxlength="50" value="{{ old('easypaisa_account_number',$storefront->easypaisa_account_number) }}" @disabled(! $easypaisaSelected) required></div>
                                    </div></div>
                                    <div class="col-12 payment-detail-panel" data-payment-details-for="jazzcash" {{ ! $jazzcashSelected ? 'hidden' : '' }}><div class="form-row">
                                        <div class="form-group col-md-6"><label for="jazzcash_account_title">جاز کیش اکاؤنٹ عنوان</label><input id="jazzcash_account_title" name="jazzcash_account_title" class="form-control" maxlength="150" value="{{ old('jazzcash_account_title',$storefront->jazzcash_account_title) }}" @disabled(! $jazzcashSelected) required></div>
                                        <div class="form-group col-md-6"><label for="jazzcash_account_number">جاز کیش نمبر</label><input id="jazzcash_account_number" name="jazzcash_account_number" dir="ltr" class="form-control text-left" maxlength="50" value="{{ old('jazzcash_account_number',$storefront->jazzcash_account_number) }}" @disabled(! $jazzcashSelected) required></div>
                                    </div></div>
                                    <div class="col-12 payment-detail-panel" data-payment-details-for="bank" {{ ! $bankTransferSelected ? 'hidden' : '' }}><div class="form-row">
                                        <div class="form-group col-md-4"><label for="bank_name">بینک کا نام</label><input id="bank_name" name="bank_name" class="form-control" maxlength="150" value="{{ old('bank_name',$storefront->bank_name) }}" @disabled(! $bankTransferSelected) required></div>
                                        <div class="form-group col-md-4"><label for="bank_account_title">بینک اکاؤنٹ عنوان</label><input id="bank_account_title" name="bank_account_title" class="form-control" maxlength="150" value="{{ old('bank_account_title',$storefront->bank_account_title) }}" @disabled(! $bankTransferSelected) required></div>
                                        <div class="form-group col-md-4"><label for="bank_account_number">اکاؤنٹ نمبر</label><input id="bank_account_number" name="bank_account_number" dir="ltr" class="form-control text-left" maxlength="100" value="{{ old('bank_account_number',$storefront->bank_account_number) }}" @disabled(! $bankTransferSelected)></div>
                                        <div class="form-group col-md-12"><label for="bank_iban">IBAN <small class="text-muted">(PK سے شروع ہونے والے 24 حروف)</small></label><input id="bank_iban" name="bank_iban" dir="ltr" class="form-control text-left text-uppercase" maxlength="24" value="{{ old('bank_iban',$storefront->bank_iban) }}" @disabled(! $bankTransferSelected)></div>
                                    </div></div>
                                    <div class="col-12 payment-detail-panel" data-payment-details-for="raast" {{ ! $raastSelected ? 'hidden' : '' }}><div class="form-row">
                                        <div class="form-group col-md-6"><label for="raast_account_title">راست اکاؤنٹ عنوان</label><input id="raast_account_title" name="raast_account_title" class="form-control" maxlength="150" value="{{ old('raast_account_title',$storefront->raast_account_title) }}" @disabled(! $raastSelected)></div>
                                        <div class="form-group col-md-6"><label for="raast_id">راست ID / مرچنٹ Alias</label><input id="raast_id" name="raast_id" dir="ltr" class="form-control text-left" maxlength="100" value="{{ old('raast_id',$storefront->raast_id) }}" @disabled(! $raastSelected)></div>
                                        <div class="form-group col-md-12"><label for="raast_qr">بینک یا والٹ کا جاری کردہ Raast QR <small class="text-muted">(اختیاری، زیادہ سے زیادہ 2 MB)</small></label><input id="raast_qr" type="file" name="raast_qr" class="form-control-file" accept="image/*" @disabled(! $raastSelected)>@if($storefront->raast_qr_url)<img src="{{ $storefront->raast_qr_url }}" alt="موجودہ Raast QR" style="display:block;max-width:180px;max-height:180px;margin-top:10px">@endif</div>
                                    </div></div>
                                </div>
                            </div>
                            <div id="manual-payment-help" class="alert alert-info mb-0 mt-2" {{ ! $showPaymentMethods || ! $hasReceivingMethod ? 'hidden' : '' }}>
                                <strong>اہم:</strong> یہ لائیو گیٹ وے نہیں ہیں۔ گاہک ادائیگی کر کے حوالہ درج کرتا ہے، اور دکان رقم اپنے والٹ یا بینک میں دیکھ کر دستی طور پر تصدیق کرتی ہے۔ صرف اپنے مالی ادارے کا جاری کردہ Raast QR اپ لوڈ کریں۔
                            </div>
                        </div>
                    </div>
                    @endif

                    <div class="card storefront-card mb-4">
                        <div class="card-header"><h2 class="h5 mb-1">عوام کو دکھائے جانے والے شعبے</h2><p class="small text-muted mb-0">صرف کاروبار کے فعال شعبے منتخب کیے جا سکتے ہیں۔</p></div>
                        <div class="card-body"><div class="row">
                            @if($business->clothing_enabled)<div class="col-md-6 mb-3"><label class="module-choice"><div class="d-flex"><input type="checkbox" name="show_clothing" value="1" @checked(old('show_clothing',$storefront->show_clothing))><div><strong><i class="fas fa-store text-success ml-1"></i> کپڑے کی دکان</strong><div class="small text-muted mt-1">کپڑے، رنگ، قیمت اور دستیاب اسٹاک</div></div></div></label></div>@endif
                            @if($business->tailoring_enabled)<div class="col-md-6 mb-3"><label class="module-choice"><div class="d-flex"><input type="checkbox" name="show_tailoring" value="1" @checked(old('show_tailoring',$storefront->show_tailoring))><div><strong><i class="fas fa-cut text-primary ml-1"></i> ٹیلرنگ خدمات</strong><div class="small text-muted mt-1">سلائی، ڈیزائن، پیمائش اور بکنگ</div></div></div></label></div>@endif
                        </div></div>
                    </div>

                    <div class="card storefront-card mb-4">
                        <div class="card-header"><h2 class="h5 mb-1">رابطہ اور سہولیات</h2></div>
                        <div class="card-body">
                            <div class="form-row">
                                <div class="form-group col-md-6"><label for="public_phone">عوامی فون نمبر</label><input id="public_phone" name="public_phone" dir="ltr" class="form-control text-left" maxlength="50" value="{{ old('public_phone',$storefront->public_phone) }}"></div>
                                <div class="form-group col-md-6"><label for="public_email">عوامی ای میل</label><input id="public_email" type="email" name="public_email" dir="ltr" class="form-control text-left" maxlength="150" value="{{ old('public_email',$storefront->public_email) }}"></div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-8"><label for="address">دکان کا پتہ</label><textarea id="address" name="address" class="form-control" rows="3" maxlength="1000">{{ old('address',$storefront->address) }}</textarea></div>
                                <div class="form-group col-md-4"><label for="city">شہر</label><input id="city" name="city" class="form-control" maxlength="100" value="{{ old('city',$storefront->city) }}"></div>
                            </div>
                            <div class="form-group">
                                <label for="default_locale">عوامی دکان کی بنیادی زبان</label>
                                <select id="default_locale" name="default_locale" class="form-control">
                                    <option value="ur" @selected(old('default_locale', $storefront->default_locale ?: 'ur') === 'ur')>اردو — دائیں سے بائیں</option>
                                    <option value="en" @selected(old('default_locale', $storefront->default_locale) === 'en')>English — left to right</option>
                                </select>
                                <small class="text-muted">گاہک زبان تبدیل کر سکتے ہیں؛ ان کا انتخاب اگلی بار بھی محفوظ رہے گا۔</small>
                            </div>
                            <div class="row d-none" aria-hidden="true">
                                <div class="col-md-4 mb-2"><label><input type="checkbox" name="inquiries_enabled" value="1" @checked(old('inquiries_enabled',$storefront->inquiries_enabled))> گاہک کے سوالات قبول کریں</label></div>
                                <div class="col-md-4 mb-2"><label><input type="checkbox" name="pickup_enabled" value="1" @checked(old('pickup_enabled',$storefront->pickup_enabled))> دکان سے وصولی</label></div>
                                <div class="col-md-4 mb-2"><label><input type="checkbox" name="delivery_enabled" value="1" @checked(old('delivery_enabled',$storefront->delivery_enabled))> گھر تک فراہمی</label></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    @php
                        $hasPublicContact = filled($storefront->public_phone) || filled($storefront->public_email) || filled($storefront->address);
                        $hasPublishedContent = ($storefront->published_clothing_listings_count ?? 0) > 0
                            || ($storefront->published_tailoring_services_count ?? 0) > 0;
                        $onboardingSteps = [
                            ['done' => $storefront->exists, 'label' => 'بنیادی معلومات محفوظ کریں'],
                            ['done' => $hasPublicContact, 'label' => 'رابطہ یا پتہ درج کریں'],
                            ['done' => $hasPublishedContent, 'label' => 'کم از کم ایک پروڈکٹ یا خدمت شائع کریں'],
                            ['done' => (bool) $storefront->is_published, 'label' => 'عوامی دکان شائع کریں'],
                        ];
                        $completedOnboardingSteps = collect($onboardingSteps)->where('done', true)->count();
                    @endphp
                    <div class="card storefront-card mb-4">
                        <div class="card-header">
                            <h2 class="h5 mb-1">دکان مکمل کرنے کے مراحل</h2>
                            <p class="small text-muted mb-0">{{ $completedOnboardingSteps }} از {{ count($onboardingSteps) }} مراحل مکمل</p>
                        </div>
                        <div class="card-body py-2">
                            @foreach($onboardingSteps as $step)
                                <div class="onboarding-step">
                                    <i class="fas {{ $step['done'] ? 'fa-check-circle text-success' : 'fa-circle text-muted' }}" aria-hidden="true"></i>
                                    <span class="{{ $step['done'] ? 'text-dark' : 'text-muted' }}">{{ $step['label'] }}</span>
                                </div>
                            @endforeach
                        </div>
                    </div>
                    <div class="card storefront-card mb-4">
                        <div class="card-header"><h2 class="h5 mb-0">عوامی لنک</h2></div>
                        <div class="card-body">
                            <div class="preview-box mb-3" dir="ltr">{{ url('/shops/'.$storefront->slug) }}</div>
                            @if($storefront->exists)<a class="btn btn-outline-primary btn-block mb-2" target="_blank" rel="noopener" href="{{ route('admin.storefront.preview') }}"><i class="fas fa-eye ml-1"></i> پیش منظر دیکھیں</a>@endif
                            @if($storefront->exists && $business->clothing_enabled)<a class="btn btn-outline-dark btn-block mb-2" href="{{ route('admin.storefront.clothing.index') }}"><i class="fas fa-tshirt ml-1"></i> کپڑوں کی عوامی فہرست</a>@endif
                            @if($storefront->exists && $business->clothing_enabled && Auth::user()->hasBusinessPermission('clothing.sales'))<a class="btn btn-outline-success btn-block mb-2" href="{{ route('admin.storefront.orders.index') }}"><i class="fas fa-shopping-bag ml-1"></i> آن لائن آرڈرز</a>@endif
                            @if($storefront->exists && $business->tailoring_enabled)<a class="btn btn-outline-dark btn-block mb-2" href="{{ route('admin.storefront.tailoring.services') }}"><i class="fas fa-cut ml-1"></i> ٹیلرنگ خدمات</a>@endif
                            @if($storefront->exists)<a class="btn btn-outline-info btn-block mb-2" href="{{ route('admin.storefront.inquiries.index') }}"><i class="fas fa-comments ml-1"></i> گاہکوں کی درخواستیں</a>@endif
                            @if($storefront->is_published)<a class="btn btn-outline-success btn-block" target="_blank" rel="noopener" href="{{ route('storefront.show',$storefront) }}"><i class="fas fa-external-link-alt ml-1"></i> عوامی دکان کھولیں</a>@endif
                        </div>
                    </div>
                    <div class="card storefront-card mb-4"><div class="card-body"><h3 class="h6">محفوظ اشاعت</h3><p class="small text-muted mb-0">مسودہ محفوظ کرنے سے دکان فوراً عوام کو نظر نہیں آئے گی۔ معلومات مکمل ہونے کے بعد الگ سے شائع کریں۔</p></div></div>
                </div>
            </div>
            <div class="sticky-actions d-flex flex-wrap justify-content-between">
                <button class="btn btn-primary px-4" type="submit"><i class="fas fa-save ml-1"></i> معلومات محفوظ کریں</button>
            </div>
        </form>

        @if($storefront->exists)
        <form method="POST" action="{{ route('admin.storefront.publish') }}" class="mt-3">
            @csrf
            @method('PATCH')
            <input type="hidden" name="published" value="{{ $storefront->is_published ? 0 : 1 }}">
            <button class="btn {{ $storefront->is_published ? 'btn-outline-danger' : 'btn-success' }}" type="submit">
                <i class="fas {{ $storefront->is_published ? 'fa-eye-slash' : 'fa-globe-asia' }} ml-1"></i>
                {{ $storefront->is_published ? 'عوامی دکان چھپائیں' : 'عوامی دکان شائع کریں' }}
            </button>
        </form>
        @endif
    </div>
</section>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var modeInputs = Array.from(document.querySelectorAll('[data-payment-mode]'));
    var optionInputs = Array.from(document.querySelectorAll('[data-payment-option]'));
    var methodInputs = Array.from(document.querySelectorAll('[data-payment-method]'));
    var methodOptions = document.getElementById('payment-method-options');
    var noPaymentNote = document.getElementById('no-payment-note');
    var detailsContainer = document.getElementById('payment-receiving-details');
    var emptyState = document.getElementById('payment-details-empty');
    var manualHelp = document.getElementById('manual-payment-help');

    function refreshPaymentDetails() {
        var methodsEnabled = modeInputs.some(function (input) {
            return input.checked && input.value === 'methods';
        });
        optionInputs.forEach(function (input) { input.disabled = !methodsEnabled; });
        if (methodOptions) methodOptions.hidden = !methodsEnabled;
        if (noPaymentNote) noPaymentNote.hidden = methodsEnabled;

        var anySelected = methodsEnabled && methodInputs.some(function (input) { return input.checked; });
        if (detailsContainer) detailsContainer.hidden = !anySelected;
        if (emptyState) emptyState.hidden = !methodsEnabled || anySelected;
        if (manualHelp) manualHelp.hidden = !anySelected;

        document.querySelectorAll('[data-payment-details-for]').forEach(function (panel) {
            var input = methodInputs.find(function (method) {
                return method.dataset.paymentMethod === panel.dataset.paymentDetailsFor;
            });
            var selected = Boolean(methodsEnabled && input && input.checked);
            panel.hidden = !selected;
            panel.querySelectorAll('input, select, textarea').forEach(function (field) {
                field.disabled = !selected;
            });
        });
    }

    methodInputs.forEach(function (input) {
        input.addEventListener('change', refreshPaymentDetails);
    });
    modeInputs.forEach(function (input) {
        input.addEventListener('change', refreshPaymentDetails);
    });
    refreshPaymentDetails();
});
</script>
@endsection
