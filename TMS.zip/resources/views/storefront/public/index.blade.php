@extends('storefront.public.layout')
@section('title', __('storefront.marketplace.title'))
@section('meta_description', __('storefront.marketplace.hero_text'))
@section('canonical_url', route('storefront.index'))
@push('structured_data')
    <script type="application/ld+json">{!! \App\Support\StorefrontSeo::json(\App\Support\StorefrontSeo::graph(
    \App\Support\StorefrontSeo::website(
        __('storefront.common.marketplace'),
        __('storefront.marketplace.hero_text'),
        route('storefront.index')
    )
)) !!}</script>
@endpush
@push('styles')
    .market-nav{background:#0b3d2e;color:#fff}.market-nav .nav-brand,.market-nav
    .nav-link{color:#fff}.market-hero{padding:68px 0;background:radial-gradient(circle at 15% 20%,#2ca679 0,transparent
    28%),linear-gradient(135deg,#0b3d2e,#126f50)}.market-filters{margin:-28px auto
    32px;position:relative}.market-filter-grid{display:grid;grid-template-columns:1.5fr .85fr 1.25fr 1.25fr
    auto;gap:12px;align-items:end}.filter-field
    label{display:block;font-size:.82rem;font-weight:800;margin-bottom:6px}.filter-actions{display:flex;gap:8px}.shop{padding:0;overflow:hidden;display:flex;flex-direction:column}.cover{height:170px;background:linear-gradient(135deg,#d9efe6,#9ed7c0);background-size:cover;background-position:center}.shop-body{padding:20px;display:flex;flex-direction:column;flex:1}.shop-body
    h2{margin:0}.tags{display:flex;flex-wrap:wrap;gap:7px;margin:12px 0}.shop
    .btn{margin-top:auto}@media(max-width:950px){.market-filter-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.filter-actions{grid-column:1/-1}}@media(max-width:600px){.market-filter-grid{grid-template-columns:1fr}}
@endpush
@section('body')
    <nav class="nav market-nav">
        <div class="shell"><a class="nav-brand"
                href="{{ route('storefront.index') }}">{{ __('storefront.common.marketplace') }}</a>
            <div class="nav-actions">@include('storefront.public.partials.language-switch')<a class="nav-link"
                    href="{{ route('login') }}">{{ __('storefront.common.business_login') }}</a></div>
        </div>
    </nav>
    <header class="hero market-hero">
        <div class="shell">
            <h1>{{ __('storefront.marketplace.hero_title') }}</h1>
            <p>{{ __('storefront.marketplace.hero_text') }}</p>
        </div>
    </header>
    <main class="section">
        <div class="shell">
            <form class="card market-filters" method="GET">
                <div class="market-filter-grid">
                    <div class="filter-field"><label
                            for="market_q">{{ __('storefront.marketplace.search_label') }}</label><input id="market_q"
                            class="control" name="q" value="{{ $filters['q'] ?? '' }}"
                            placeholder="{{ __('storefront.marketplace.search_placeholder') }}"></div>
                    <div class="filter-field"><label
                            for="market_city">{{ __('storefront.marketplace.city_label') }}</label><select id="market_city"
                            class="control" name="city">
                            <option value="">{{ __('storefront.marketplace.all_cities') }}</option>
                            @foreach ($cities as $city)
                                <option value="{{ $city }}" @selected(($filters['city'] ?? '') === $city)>{{ $city }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="filter-field"><label
                            for="market_category">{{ __('storefront.marketplace.category_label') }}</label><select
                            id="market_category" class="control" name="category">
                            <option value="">{{ __('storefront.marketplace.all_categories') }}</option>
                            <option value="clothing" @selected(($filters['category'] ?? '') === 'clothing')>{{ __('storefront.common.clothing') }}
                            </option>
                            <option value="tailoring" @selected(($filters['category'] ?? '') === 'tailoring')>{{ __('storefront.common.tailoring') }}
                            </option>
                            <option value="both" @selected(($filters['category'] ?? '') === 'both')>
                                {{ __('storefront.marketplace.both_categories') }}</option>
                        </select></div>
                    <div class="filter-field"><label
                            for="market_delivery">{{ __('storefront.marketplace.delivery_label') }}</label><select
                            id="market_delivery" class="control" name="delivery">
                            <option value="">{{ __('storefront.marketplace.any_delivery') }}</option>
                            <option value="1" @selected(($filters['delivery'] ?? '') === '1')>
                                {{ __('storefront.marketplace.delivery_available') }}</option>
                        </select></div>
                    <div class="filter-actions"><button
                            class="btn">{{ __('storefront.marketplace.apply_filters') }}</button>
                        @if (collect($filters)->contains(fn($value) => $value !== null && $value !== ''))
                            <a class="btn btn-secondary"
                                href="{{ route('storefront.index') }}">{{ __('storefront.marketplace.clear_filters') }}</a>
                        @endif
                    </div>
                </div>
            </form>
            <div class="row">
                <div>
                    <h2>{{ __('storefront.marketplace.shops') }}</h2>
                    <div class="muted">{{ __('storefront.marketplace.active_only') }}</div>
                </div>
                <div class="muted">{{ __('storefront.marketplace.shop_count', ['count' => $storefronts->total()]) }}</div>
            </div>
            @if ($storefronts->count())
                <div class="grid" style="margin-top:22px">
                    @foreach ($storefronts as $storefront)
                        <article class="card shop">
                            <div class="cover"
                                @if ($storefront->cover_url) style="background-image:url('{{ $storefront->cover_url }}')" @endif>
                            </div>
                            <div class="shop-body">
                                <h2>{{ $storefront->display_name }}</h2>
                                <div class="muted">{{ $storefront->city ?: __('storefront.common.pakistan') }}</div>
                                <p>{{ $storefront->tagline ?: __('storefront.marketplace.default_tagline') }}</p>
                                <div class="tags">
                                    @if ($storefront->show_clothing && $storefront->business->clothing_enabled)
                                        <span class="pill">{{ __('storefront.common.clothing') }}</span>
                                        @endif @if ($storefront->show_tailoring && $storefront->business->tailoring_enabled)
                                            <span class="pill">{{ __('storefront.common.tailoring') }}</span>
                                            @endif @if ($storefront->offersDelivery())
                                                <span class="pill">{{ __('storefront.common.delivery') }}</span>
                                            @endif
                                </div><a class="btn"
                                    href="{{ route('storefront.show', $storefront) }}">{{ __('storefront.marketplace.view_shop') }}</a>
                            </div>
                        </article>
                    @endforeach
                </div>
                <div style="margin-top:25px">{{ $storefronts->links() }}</div>
            @else<div class="card empty" style="margin-top:22px">
                    <h2>{{ __('storefront.marketplace.empty_title') }}</h2>
                    <p class="muted">{{ __('storefront.marketplace.empty_text') }}</p>
                </div>
            @endif
        </div>
    </main>
    <footer class="footer">
        <div class="shell">{{ __('storefront.marketplace.footer') }}</div>
    </footer>
@endsection
