# TMS implementation status

Last updated: 2026-07-23

## 23 July 2026 — Super-admin marketplace oversight and final storefront QA

- Added an English super-admin marketplace dashboard with configured/public/paused storefront totals, pending orders, non-cancelled order value, and filters for publication, moderation, client status, module, storefront, client, slug, and email.
- Added per-storefront published clothing/service counts, inquiry/order counts, pending-order badges, order value, client-detail links, and safe public-page links.
- Added non-destructive marketplace moderation. Pausing requires a reason and hides the directory, storefront, catalog, tailoring, inquiry, cart, checkout, and tracking surfaces while preserving all client data and back-office access.
- Clients see a clear Urdu moderation explanation inside their storefront settings. They cannot access or overwrite super-admin moderation controls.
- Every pause/resume action is recorded in an append-only history with from/to state, reason, super-admin identity, and timestamp.
- Enhanced English client details with storefront content/activity metrics, publication/moderation state, public URL safety, last moderator, and moderation history.
- Applied two additive moderation migrations; all existing storefronts defaulted to allowed and no client, customer, content, stock, order, payment, or transaction record was rewritten.
- Live Chrome QA verified 1 configured/public storefront, 1 clothing listing, 1 tailoring service, 1 inquiry, 1 pending Rs 4,950 order, client detail integration, and a reversible pause → public 404 → resume cycle.
- The live storefront was left **active and publicly accessible**. The QA pause/resume actions remain visible in moderation history.
- Automated result: **139 tests passed, 1,014 assertions**.
- The public storefront implementation plan is complete on `feature/client-public-storefronts`; stable `main` remains unchanged.

## 23 July 2026 — Locked storefront checkout and order tracking

- Added additive storefront order headers and immutable item snapshots, separate from the legacy application-user online-order table.
- Checkout requires a PIN-linked unified customer, an active cart, current publication/tenant ownership, and an unexpired reservation.
- Checkout locks the cart, its items, and all involved cloth-color rows in a deterministic order before rechecking physical stock. A stale or insufficient item rolls the complete operation back.
- A successful checkout deducts physical stock once, records cost snapshots and inventory movements, and posts one `Sale` charge to the customer's existing unified balance.
- Public checkout does not claim that money was received. General payments entered by the client continue reducing the customer's combined shop/tailoring balance without forcing per-order allocation.
- Added pickup/delivery selection, required delivery address validation, optional customer notes, a permanent human-readable reference, and PIN-protected Urdu order tracking.
- Added an Urdu client order queue with tenant-scoped search/status filtering, complete action, and one-time cancellation that restores stock and reverses the customer charge.
- Added storefront order revenue, cost, gross profit, and receivables to the existing financial report while retaining legacy online-order figures.
- Order creation sends a database notification to the client; notification failure cannot roll back or duplicate a committed order.
- Applied only the additive order migration; existing clients, customers, stock history, and legacy orders were not reset or rewritten.
- Live Chrome QA created pending pickup order `TMSO-20260723-TJEFLQ` for `فہد اقبال`: 3.00 m at Rs 1,650/m, Rs 4,950 total, stock 24.50 → 21.50, and one unified Sale balance charge.
- Public tracking and the client queue were verified on desktop and 390 px layouts with no horizontal overflow. A narrow-screen heading/button collision found during QA was corrected.
- Automated result: **136 tests passed, 968 assertions**.
- Next checkpoint: English super-admin marketplace oversight followed by the final end-to-end storefront regression and branch handoff.

## 23 July 2026 — Public cart and safe stock reservations

- Added a storefront-scoped guest cart with opaque session tokens and 30-minute, per-color cloth reservations.
- Public availability now subtracts only active item reservations belonging to active carts; expired carts and removed items immediately release quantity.
- Cart updates use database transactions and row locking so two shoppers cannot reserve more cloth than the physical stock on hand.
- Reservations do not change physical stock, inventory movements, sales, orders, payments, or customer balances. Those records remain untouched until a later confirmed checkout.
- Existing unified customers can link a cart with their shop-specific phone number and six-digit PIN. Cross-shop customer linking is rejected and repeated PIN failures are rate limited.
- Added a stabilization migration that uses `DATETIME` for cart deadlines. This prevents MySQL's legacy implicit `TIMESTAMP ON UPDATE` behavior from shortening an expiry when customer identity or cart activity changes.
- Chrome QA verified restored availability of 24.50 m, a fresh 3.00 m reservation, the recalculated Rs 4,950 total, and PIN linking to `فہد اقبال` without losing the cart.
- The full Urdu cart was checked at 390 px: all controls and the unified-customer card remain readable, with no horizontal overflow.
- Automated result: **127 tests passed, 875 assertions**.
- Next checkpoint: convert a confirmed cart into an online order using locked stock deduction, explicit payment allocation, and customer-facing order tracking.

## 23 July 2026 — Public tailoring services and inquiry queue

- Added tenant-managed public tailoring services with Urdu names/descriptions, starting prices, price units, estimated days, featured ordering, and independent publication controls.
- Added responsive public service list/detail pages with clear wording that prices and dates remain estimates until the client confirms measurements, design, and work.
- Added a rate-limited public inquiry form with service selection, contact details, preferred date, message, honeypot protection, and a permanent human-readable reference.
- Added an Urdu client inquiry queue with search/status filtering, internal notes, and New/Contacted/Closed follow-up states.
- Public inquiries are intentionally isolated from customers, tailoring orders, transactions, stock, worker assignments, and balances; no operational or financial record is created automatically.
- Enforced active-business, enabled-module, published-storefront, published-service, storefront ownership, and inquiry-enabled boundaries.
- The additive service/inquiry migration was inspected and executed without rewriting existing data.
- Chrome QA published `پریمیم مردانہ شلوار قمیض سلائی`, submitted the realistic `محمد حمزہ خان` request as `TMSI-000001`, and verified the client follow-up queue/status notes.
- Found and fixed an off-screen anti-spam layout defect during live QA; final desktop/mobile views have no horizontal overflow or browser console errors.
- Automated result: **122 tests passed, 840 assertions**.
- Next checkpoint: cart and safe inventory reservations connected to unified customer accounts.

## 23 July 2026 — Public clothing catalog

- Added a separate storefront publication layer for existing tenant-owned cloth records; no stock quantity, cost, movement, sale, or purchase record is duplicated.
- Clients can choose a public name and description, feature a cloth, control ordering, and publish/unpublish each item from an Urdu catalog-management screen.
- Public catalog pages show the current sale price and live per-color inventory quantity, with Urdu search and color filtering plus a responsive product detail view.
- Enforced storefront, business, cloth-owner, publication, module, and active-client boundaries on every public and administrative catalog route.
- Added image URL compatibility for both current public-storage uploads and valid legacy public paths, with a clean media-free fallback.
- Fixed cloth onboarding so images are genuinely optional, Urdu commas split colors correctly, and each selected color is safely paired with exactly one length.
- The additive listing migration was inspected and executed without changing historical data.
- Chrome QA created `صدیقی پریمیم فیبرکس` / `گرمیوں کا واش اینڈ ویئر`, published `صدیقی پریمیم سمر واش اینڈ ویئر`, and verified management, search, detail, desktop/mobile layout, and contact behavior with zero console errors or horizontal overflow.
- Automated result: **119 tests passed, 811 assertions**.
- Next checkpoint: tenant-managed tailoring service listings and public customer inquiries/bookings.

## 23 July 2026 — Public storefront foundation

- Started the additional marketplace work on the isolated `feature/client-public-storefronts` branch; stable `main` remains unchanged.
- Added an additive one-to-one public storefront profile for each client business, including a unique URL, Urdu business description, public contact details, logo/cover support, delivery/pickup options, and independent draft/published states.
- Added an Urdu client setup screen protected by the new `storefront.manage` business permission. Owners retain implicit access and clients may explicitly grant the permission to an employee role.
- Added a public Urdu shop directory at `/shops` and responsive storefront pages at `/shops/{slug}`.
- Public pages expose only published storefronts belonging to active businesses. Suspending a client hides its storefront without deleting its profile or business records.
- Added the storefront publication state and URL to the English super-admin client detail screen.
- Inspected and executed only the additive storefront migration; no existing table or live record was reset, deleted, or rewritten.
- Chrome QA published the realistic `صدیقی ٹیلرز اینڈ فیبرکس` storefront, verified desktop and 390 px mobile layouts, confirmed zero horizontal overflow, and found no browser console errors or warnings.
- Automated result: **115 tests passed, 792 assertions**.
- Next implementation checkpoint: tenant-managed public clothing listings connected to safe stock availability, followed by tailoring services/inquiries and checkout.

## 23 July 2026 — Final client/employee/worker/print QA

- Completed a Chrome desktop sweep of all client back-office areas in the feature inventory, plus tailoring, sales, and finance employee accounts, production-worker screens, and independent-tailor access.
- Repaired the finance-only employee report, balance-only customer statement access, cloth edit/stock alias/online-order failures, and blank or missing resource destinations.
- Reworked the active order, measurement, invoice, cloth receipt, and tailor weekly print surfaces for Urdu thermal output and stable layout.
- Added safe shop-logo URLs, earlier Urdu DataTables initialization, and regression tests for accountant totals, balance-only statement access, and cloth-brand resource navigation.
- No destructive migration, database reset, or production-data deletion was used.
- Final automated result: **111 tests passed, 765 assertions**.
- Resumed the timed-out Chrome print QA one route at a time; fixed an order-print 500, corrected the alternate order-print template, corrected sale invoice line totals, and removed legacy automatic print-popup JavaScript.

## 23 July 2026 — Super-admin client lifecycle and full QA

- Inventoried all application features and route surfaces in `docs/FEATURE_INVENTORY_AND_QA_MATRIX.md`.
- Added safe pending/active/suspended/rejected business lifecycle controls with full status audit history.
- Added an English super-admin client list and details screen with filters, module access, business metrics, approval metadata, and activate/deactivate actions.
- Preserved every existing business as active and disabled permanent client deletion to protect live data.
- Enforced account status for business owners and employees at login and on subsequent requests, using Urdu blocked-account messages on client-facing screens.
- Completed the full automated suite with 109 passing tests and 753 assertions.
- Browser QA found and fixed a MySQL-only client order-count failure caused by the legacy camel-case `orders.userId` column.
- Recorded current findings and the prioritized backlog in `docs/FULL_QA_REPORT_2026-07-23.md`.

## Completed

- Upgraded the application to Laravel 12.64.0.
- Verified clean migrations and seeders, route/config/view caches, tests, and production assets.
- Secured tailor passwords with hashing and transparent one-time migration of legacy plaintext passwords.
- Removed tailor password output from management screens.
- Added shop ownership checks to core tailor, order, sale, setting, expense, cart, and online-order operations.
- Extended shop ownership checks across cloth brands/types, cloth and stock records, designs, option categories/options, customers, and direct payments.
- Added validation and database transactions to core tailoring orders, payments, counter sales, cart reservations, and online-order stock changes.
- Rebuilt the stock-sale write path with row locking, server-side stock validation, atomic stock/payment updates, and shop-scoped printing and reporting.
- Added sale ownership through `sales.user_id` and backfilled existing sales from their transactions.
- Repaired legacy cloth/design schemas so both upgraded and freshly installed databases have the required catalog tables and ownership columns.
- Replaced unsafe original upload filenames in the cloth and brand workflows with framework-generated storage paths.
- Converted known destructive GET routes to DELETE/PATCH/POST routes with CSRF-protected forms.
- Fixed online-order cancellation/reorder inventory restoration and deduction.
- Fixed the dashboard tags-input JavaScript error and service-worker 404.
- Protected the mobile API with Sanctum tokens and restricted orders, transactions, notifications, and logout to the authenticated customer.
- Restricted account editing to the signed-in shop owner and require the current password before a password change.
- Added six tenant/security feature tests; the full suite now passes with 8 tests and 23 assertions.
- Fixed shared asset URLs under the PHP development server and browser-verified the dashboard, cloth-brand list, and stock list at port 8010.
- Added the tailor job lifecycle: assigned, cutting, stitching, trial, ready, and delivered.
- Added an admin/tailor job board with deadlines, overdue highlighting, workload counters, filters, and controlled next-stage actions.
- Added immutable status-history records identifying whether the shop owner or tailor made each transition.
- Added per-order tailor earnings, paid totals, unpaid/partial/paid state, and salary ledger entries.
- Restricted tailors to their own jobs and reserved final customer delivery confirmation for the shop owner.
- Normalized legacy `new`, `start`, and `complete` order states into the new lifecycle.
- Added five lifecycle/security tests; the full suite now passes with 13 tests and 47 assertions.
- Added tenant-scoped supplier management with contacts, opening balances, activation, and general supplier payments.
- Added draft purchase orders with multiple cloth/color lines, supplier references, dates, quantities, and unit costs.
- Added atomic goods receipt: locked color inventory updates, duplicate-receipt protection, and receipt timestamps.
- Added purchase returns with received-quantity and live-stock limits, payable adjustments, and automatic stock reduction.
- Added purchase-specific supplier payments with overpayment prevention and updated purchase balances.
- Added an inventory movement ledger for purchase receipts and supplier returns with signed quantities and source references.
- Added six purchase/security tests; the full suite now passes with 19 tests and 89 assertions.
- Centralized cloth quantity changes through a transactional inventory service with signed movement quantities and running balances.
- Extended the ledger to counter sales, direct online orders, online cancellations/reorders, cart reservations/releases, purchase receipts/returns, and manual adjustments.
- Added moving weighted-average cost per cloth color and automatic recalculation on purchases and positive adjustments.
- Added cost-per-meter and total cost-of-goods snapshots to counter-sale records.
- Added a tenant-scoped manual stock-adjustment workflow requiring a reason and preventing negative stock.
- Added stock valuation reporting for meters on hand, inventory cost, retail value, and potential margin.
- Repaired missing legacy sale, transaction, and shop-slug schema fields required by active application code.
- Added four costing/ledger tests and expanded cart assertions; the full suite now passes with 23 tests and 113 assertions.
- Added a shop-owner financial dashboard with selectable date ranges and clearly separated accrual profit and actual cash flow.
- Added revenue breakdowns for tailoring, counter cloth sales, manual product sales, and non-cancelled online orders.
- Added direct-cost reporting for counter/online cost of goods and accrued tailor labor, plus monthly, daily, and worker expenses.
- Added as-of-date customer receivables and supplier payables, period purchases/returns, and current stock-value summaries.
- Added CSV exports for financial summaries, receivables, and payables with spreadsheet-formula injection protection.
- Added cost snapshots to new online orders so online cost of goods is included in future profit reports.
- Added reconciliation and authorization tests; the full suite now passes with 25 tests and 130 assertions.
- Added database/mobile customer notifications for cutting, trial, ready, and delivered milestones.
- Added per-order notification delivery logs with sent, failed, and skipped states, attempt counts, timestamps, and captured errors.
- Added transaction-safe duplicate suppression so each customer receives at most one notification for each order milestone.
- Added delivery status to the tailor job board and owner-only retries for failed or skipped notifications.
- Kept lifecycle progress independent from notification availability so a delivery outage cannot roll back valid workshop work.
- Added notification idempotency and retry-recovery tests; the full suite now passes with 27 tests and 142 assertions.
- Replaced unbounded tailor-job, purchase, inventory-ledger, stock-valuation, receivable, and payable result loading with database pagination.
- Added server-side search, date, status, supplier, tailor, deadline, movement-type, and configurable page-size filters where relevant.
- Preserved active filters and independent page positions in pagination links, including separate receivable and payable pages on the financial dashboard.
- Reworked financial receivable/payable balances into grouped database queries so summary totals do not require loading every customer or supplier.
- Added Bootstrap-compatible pagination rendering and visible matching-record counts on operational lists.
- Added four pagination/filter regression tests; the full suite now passes with 31 tests and 159 assertions.
- Rebuilt the login page as a responsive TMS-branded workshop experience with clearer form hierarchy, accessible controls, mobile behavior, and secure-access messaging.
- Repaired the guest layout's broken legacy asset URLs by switching authentication pages to the compiled Vite asset manifest.
- Added branded-login asset coverage; the full suite now passes with 32 tests and 164 assertions.
- Added independent `tailoring` and `clothing` client entitlements with a safe migration that preserves both modules for every existing client.
- Added route middleware that enforces module access server-side for tailoring and clothing operations, including direct URL requests.
- Rebuilt super-admin client creation/editing around explicit Tailoring System and Clothing Sales & Purchases authorization cards, requiring at least one module for client accounts.
- Prevented individual client permission edits from mutating shared role permissions for every user in that role.
- Rebuilt the client navigation and dashboard so tailoring-only, clothing-only, and combined clients see a focused workspace with relevant metrics and shortcuts.
- Made financial reports module-aware so disabled-module revenue, costs, balances, purchases, and inventory are not exposed historically.
- Added the complete client access matrix and super-admin assignment coverage; the full suite now passes with 37 tests and 196 assertions.
- Added an Urdu workspace chooser for combined clients, with separate focused Tailoring and Shop dashboards and an explicit workspace switcher.
- Added module-aware post-login routing: single-module clients go directly to their dashboard, while combined clients choose their working area.
- Added a backward-compatible `businesses` membership layer and linked every existing client owner to a business while retaining the owner's existing tenant ID for all historical records.
- Added owner workspace preferences and business membership fields needed for future client-managed employees.
- Added workspace routing and entitlement regression coverage; the focused module-access suite passes with 5 tests and 42 assertions.
- Converted operational tailoring, sales, purchasing, stock, reporting, expenses, settings, and import/export controllers from signed-in-user ownership to the linked business owner's tenant ID.
- Added client-managed Urdu employee and role screens with permissions for Tailoring, Shop/Sales/Purchases, Finance, Expenses, Settings, and Team Management.
- Added automatic employee routing: one authorized workspace opens directly, while two authorized workspaces retain the chooser and explicit switcher.
- Added active/inactive employee enforcement, business-scoped role and employee editing, password hashing, and cross-client isolation.
- Browser-QA created a Shop-only employee, verified its automatic Shop dashboard redirect, confirmed Finance/Team links stay hidden, and found no browser console errors.
- The complete suite now passes with 41 tests and 226 assertions.
- Split Shop employee access into separately enforceable Sales, Inventory, Purchasing, and Supplier permissions, including direct URL protection and permission-aware dashboard metrics/navigation.
- Preserved existing Shop roles during the granular-permission migration, then narrowed the live Sales QA role to Sales and Online Orders only.
- Extended client-owned employee profiles with unique username, full name, phone, address, email, password, job title, role, active status, and login by either username or email.
- Added live client-owned Sales, Tailoring, and Manager QA profiles under the combined client, plus a tailoring customer/job and shop cloth/supplier/draft-purchase dataset shared through the business tenant.
- Browser-QA verified Sales-only inventory denial, Tailoring-only automatic routing and Shop denial, Manager workspace selection and Team Management, Urdu rendering, and zero console errors.
- The complete suite now passes with 43 tests and 243 assertions.
- Split Tailoring employee access into Customers/Measurements, Orders/Payments, Workshop Jobs, Tailor/Rates Management, and Design/Measurement Configuration permissions.
- Added direct-route enforcement and permission-aware Tailoring dashboard metrics, shortcuts, and navigation; existing Tailoring roles were safely backfilled.
- Narrowed the live Tailoring QA role to Customers, Orders, and Workshop duties, with Tailor Management and Configuration explicitly denied.
- Added a tenant-scoped employee activity audit that records successful mutating actions, employee identity, time, route, method, and record identifiers without storing passwords or submitted form contents.
- Added an Urdu activity dashboard with employee, date, and action filters, daily totals, active-user counts, pagination, and client-controlled `activity.view` authorization.
- Browser-QA verified the live Manager activity records and the narrowed Tailoring employee menu/direct-URL denial with zero console errors.
- The complete suite now passes with 45 tests and 262 assertions.
- Added client-issued temporary employee passwords with remembered-session invalidation, reset timestamps, and identification of the client user who issued each reset.
- Added mandatory first-login password replacement: employees cannot open any business route until they submit the current temporary password and choose a different confirmed password.
- Added a dedicated responsive Urdu employee security screen plus an optional employee self-service password-change link.
- Separated ordinary employee profile updates from credential resets so changing a name, phone, address, email, role, or status cannot silently alter a password.
- Added audit entries for both client-issued temporary passwords and employee-completed password changes without capturing either password.
- Completed 390x844 mobile QA for employee editing, password reset, first-login security, Sales dashboard return, and the activity report; corrected long email fields to render left-to-right.
- Restored the live Sales QA account password to `QaEmployee@2026` after the end-to-end reset test and left the Manager on the activity report showing all four audited changes.
- The complete suite now passes with 46 tests and 279 assertions.
- Replaced technical-only activity wording with friendly Urdu descriptions for employee security, team management, suppliers, purchases, stock, sales, tailoring jobs, orders, and payments, with a clear Urdu fallback for other audited routes.
- Added a tenant-scoped CSV activity export that reuses the screen's employee/date/action filters, writes an Excel-compatible UTF-8 file, and neutralizes spreadsheet-formula prefixes in every exported value.
- Browser-QA verified the updated live Urdu activity report, four friendly action descriptions, the CSV download control, and zero browser console errors.
- The complete suite now passes with 47 tests and 290 assertions.
- Added an optional client-controlled employee password-expiry policy with 30, 60, 90, 180, and 365-day choices; it remains disabled by default.
- Added a policy-change grace period so enabling or changing expiry does not immediately lock out existing staff, while genuinely expired employees are restricted to the password-security screen.
- Enforced strong employee and temporary passwords on the server: at least 8 characters with uppercase, lowercase, number, and symbol requirements.
- Added reusable interactive Urdu password-strength guidance to employee creation, temporary-password reset, and employee self-service password screens.
- Applied the password-policy migration and browser-QA verified the Manager's Urdu policy control, weak/strong meter transitions, and zero console errors without changing live credentials or enabling expiry.
- The complete suite now passes with 49 tests and 307 assertions.

## Next when the user says "go next" or "proceed"

1. Implement fixed-salary and commission payroll accrual.
2. Add dedicated portals for cutters and other production workers.

## Latest accounting checkpoint — 23 July 2026

- Included non-legacy production-worker earnings in tailoring direct costs and gross/net profit.
- Included their payments in cash out and net cash flow.
- Excluded mirrored legacy-tailor ledger entries to prevent double counting.
- Made worker payments atomic with a tenant-scoped row lock, balance recheck, and ledger insert in one transaction.
- Added database-enforced active work-assignment uniqueness while preserving cancelled history and reassignment.
- Applied the additive migration with all 6 live assignments preserved and verified.
- Added unique business shop codes and tenant-scoped tailor login using shop code, phone, and password.
- Applied the additive migration with all 3 businesses and both tailor accounts preserved.
- Completed live client-side tailor QA: created a tailor, advance transaction, sewing type, and per-suit rate.
- Fixed the missing live MySQL tailor-advance column, made advances additive/audited, and rebuilt the main tailor/rate/report UI in Urdu.
- Full regression suite: 109 tests and 753 assertions passing.

## Current continuation point

- The workspace chooser, focused dashboards, remembered workspace, and owner module authorization are implemented.
- The business membership migration is applied and existing clients are backfilled.
- Employee login and client-managed roles are enabled with safe business tenant scoping.
- Live client-owned QA profiles:
  - Sales: username `qa.shop.sales`, email `qa.employee.shop.09629983@example.test`, password `QaEmployee@2026`.
  - Tailoring: username `qa.tailoring.staff`, email `qa.employee.tailoring.09629983@example.test`, password `QaEmployee@2026`.
  - Manager: username `qa.business.manager`, email `qa.employee.manager.09629983@example.test`, password `QaManager@2026`.
- The in-app browser is left on the Urdu employee/role management screen as the Manager profile.
- The Manager profile is left signed in on the Urdu employee activity report with two live audited changes.
- The Manager profile is left signed in on the activity report, which includes the live temporary-password issuance and employee password-change events.
- The Manager is signed in and the in-app browser is left on the Urdu Team page with password expiry disabled.
- Resume with production-ready audit retention and backup/restore verification controls.

## Known remaining technical debt

- Some administrator-only global queries intentionally remain unscoped and need explicit role-policy coverage.
- The legacy stock-sale implementation remains unreachable below the new transactional path and should be removed in a cleanup pass.
- Mobile clients must be updated to send `shop_id` at login, save the returned Sanctum token, and use it as a Bearer token.
- Broader regression coverage is still needed for accounting totals and failure rollbacks.
- Vite/esbuild dependency advisories require a separate breaking frontend upgrade.
- Sass emits deprecated API and `@import` warnings.
- Browserslist's local `caniuse-lite` data is outdated.
- Historical stock mutations created before the inventory ledger was introduced are not retroactively reconstructed.
- Historical counter sales have no captured weighted-average cost; new counter sales record cost correctly.

## Latest Chrome QA checkpoint — 23 July 2026

- Completed live Google Chrome QA of the client tailor list, create form, advance modal, account report, rate list, and orders list.
- Verified محمد وقاص with a Rs. 500 advance transaction and a Rs. 400 سادہ شلوار قمیض rate.
- Fixed invisible outline-button labels on the tailor list by applying high-contrast action styles.
- Verified localized report content, clean filter URLs, and zero Chrome console errors or warnings.
- Focused tailor workflow regression: 3 tests, 33 assertions passing.
