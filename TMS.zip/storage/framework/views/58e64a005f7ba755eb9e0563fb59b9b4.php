<?php $__env->startPush('styles'); ?>
    <?php echo $__env->make('purchases._styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="main-content purchase-page" dir="rtl"><div class="purchase-shell">
    <header class="purchase-page-header">
        <div class="purchase-title-wrap"><span class="purchase-title-icon"><i class="fas fa-shopping-cart"></i></span><div><h1 class="h3 mb-1">خریداری کی فہرست</h1><div class="purchase-breadcrumb"><a href="<?php echo e(route('admin.home')); ?>">ڈیش بورڈ</a> <span class="mx-2">•</span> خریداری</div></div></div>
        <a href="<?php echo e(route('admin.purchases.create')); ?>" class="purchase-primary-btn"><i class="fas fa-plus"></i> نئی خریداری</a>
    </header>

    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>

    <div class="purchase-stats">
        <article class="purchase-stat"><div class="purchase-stat-copy"><small>کل خریداریاں</small><strong><?php echo e(number_format($summary['count'])); ?></strong></div><span class="purchase-stat-icon"><i class="far fa-clipboard"></i></span></article>
        <article class="purchase-stat"><div class="purchase-stat-copy"><small>کل رقم</small><strong>Rs. <?php echo e(number_format($summary['total'],2)); ?></strong></div><span class="purchase-stat-icon"><i class="fas fa-arrow-down"></i></span></article>
        <article class="purchase-stat"><div class="purchase-stat-copy"><small>بقیہ ادائیگی</small><strong>Rs. <?php echo e(number_format($summary['balance'],2)); ?></strong></div><span class="purchase-stat-icon"><i class="fas fa-shopping-cart"></i></span></article>
        <article class="purchase-stat"><div class="purchase-stat-copy"><small>ادا شدہ رقم</small><strong>Rs. <?php echo e(number_format($summary['paid'],2)); ?></strong></div><span class="purchase-stat-icon"><i class="fas fa-wallet"></i></span></article>
    </div>

    <form class="purchase-panel purchase-filter" method="GET">
        <h2 class="purchase-section-title"><i class="fas fa-filter"></i> فلٹرز</h2>
        <div class="form-row align-items-end">
            <div class="form-group col-xl-3 col-lg-4"><label for="purchase_q">بل نمبر / حوالہ</label><input id="purchase_q" name="q" maxlength="100" value="<?php echo e($filters['q'] ?? ''); ?>" class="form-control" placeholder="بل نمبر درج کریں"></div>
            <div class="form-group col-xl-2 col-lg-4"><label for="purchase_supplier">سپلائر</label><select id="purchase_supplier" name="supplier_id" class="form-control"><option value="">تمام سپلائرز</option><?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($supplier->id); ?>" <?php if((int)($filters['supplier_id'] ?? 0)===$supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="form-group col-xl-2 col-lg-4"><label for="purchase_status">حالت</label><select id="purchase_status" name="status" class="form-control"><option value="">تمام حالتیں</option><?php $__currentLoopData = ['draft','received','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(($filters['status'] ?? '') === $status): echo 'selected'; endif; ?>><?php echo e(['draft'=>'زیرِ تیاری','received'=>'وصول شدہ','cancelled'=>'منسوخ'][$status]); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="form-group col-xl-2 col-lg-4"><label for="purchase_from">تاریخ سے</label><input id="purchase_from" type="date" name="from_date" value="<?php echo e($filters['from_date'] ?? ''); ?>" class="form-control"></div>
            <div class="form-group col-xl-2 col-lg-4"><label for="purchase_to">تاریخ تک</label><input id="purchase_to" type="date" name="to_date" value="<?php echo e($filters['to_date'] ?? ''); ?>" class="form-control"></div>
            <div class="form-group col-xl-1 col-lg-4"><label for="purchase_rows">قطاریں</label><select id="purchase_rows" name="per_page" class="form-control"><?php $__currentLoopData = [15,25,50,100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($size); ?>" <?php if((int)($filters['per_page'] ?? 25)===$size): echo 'selected'; endif; ?>><?php echo e($size); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        </div>
        <div class="purchase-filter-actions"><button class="btn btn-primary"><i class="fas fa-search ml-1"></i> تلاش کریں</button><a href="<?php echo e(route('admin.purchases.index')); ?>" class="btn btn-outline-secondary"><i class="fas fa-redo ml-1"></i> ری سیٹ کریں</a></div>
    </form>

    <div class="purchase-panel purchase-list-card">
        <div class="purchase-card-head"><div><h2>خریداری کی فہرست</h2><p>کل <?php echo e($purchases->total()); ?> خریداریوں میں سے <?php echo e($purchases->firstItem() ?? 0); ?>–<?php echo e($purchases->lastItem() ?? 0); ?></p></div></div>
        <div class="table-responsive"><table class="table purchase-modern-table purchase-list-table"><thead><tr><th>بل نمبر</th><th>تاریخ</th><th>سپلائر</th><th>حالت</th><th>کل رقم</th><th>ادا شدہ</th><th>بقایا</th><th>عمل</th></tr></thead><tbody>
            <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php ($statusLabel=['draft'=>'زیرِ تیاری','received'=>'وصول شدہ','cancelled'=>'منسوخ'][$purchase->status] ?? $purchase->status); ?>
                <tr>
                    <td data-label="بل نمبر"><div class="purchase-number"><?php echo e($purchase->purchase_number); ?></div><div class="purchase-ref"><?php echo e($purchase->reference ?: '—'); ?></div></td>
                    <td data-label="تاریخ"><?php echo e($purchase->purchase_date->format('d M Y')); ?></td><td data-label="سپلائر"><?php echo e($purchase->supplier->name); ?></td>
                    <td data-label="حالت"><span class="purchase-status purchase-status-<?php echo e($purchase->status); ?>"><?php echo e($statusLabel); ?></span></td>
                    <td data-label="کل رقم"><span class="purchase-money">Rs. <?php echo e(number_format($purchase->total_amount,2)); ?></span></td><td data-label="ادا شدہ"><span class="purchase-money">Rs. <?php echo e(number_format($purchase->paid_amount,2)); ?></span></td><td data-label="بقایا"><span class="purchase-money purchase-balance">Rs. <?php echo e(number_format($purchase->balance_amount,2)); ?></span></td>
                    <td class="purchase-list-action" data-label="عمل"><a class="purchase-open" href="<?php echo e(route('admin.purchases.show',$purchase)); ?>" aria-label="خریداری کھولیں"><i class="fas fa-ellipsis-v"></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="8" class="text-center text-muted py-5">منتخب فلٹر کے مطابق کوئی خریداری موجود نہیں۔</td></tr><?php endif; ?>
        </tbody></table></div>
        <?php if($purchases->hasPages()): ?><div class="card-footer"><?php echo e($purchases->links()); ?></div><?php endif; ?>
    </div>
</div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/purchases/index.blade.php ENDPATH**/ ?>