<?php $__env->startSection('content'); ?>
<style>
span{
    font-size: 20px;
}
</style>
    <section class="main-content">
        <div class="container">

            <div class="card col-sm-10 mx-auto">
                <?php echo $__env->make('inc.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <h1 class="h4 mb-4 text-right">اخراجات شامل کریں</h1>
                <form id="cc-form__addCustomerForm" class="add-customer-form"
                    method="post" action="<?php echo e(route('admin.expense.insert')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">ماہانہ کرایہ</span> </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="rent">
                                    <?php $__errorArgs = ['rent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">ماہانہ بل</span> </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="bill" >
                                    <?php $__errorArgs = ['bill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">ملازمین کی تعداد</span></label>
                                <div class="col-sm-9">
                                    <input type="number" class="form-control" id="num_workers" name="num_workers" >
                                    <?php $__errorArgs = ['num_workers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="workers-container"></div>


                    <div class="form-group col-md-8 mx-auto row">
                        <div class="button-group">
                            <button type="submit" class="btn btn-blue mr-3">محفوظ کریں</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('public/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
    // Handle input event for the number of workers input
    $('#num_workers').on('input', function() {
        try {
            var numWorkers = $(this).val();
            var workersContainer = $('#workers-container');

            // Clear previous input fields
            workersContainer.empty();

            // Create input fields for each worker
            for (var i = 1; i <= numWorkers; i++) {
                var workerNameInput = '<input type="text" class="form-control" name="worker_name_' + i + '" placeholder="Worker ' + i + ' Name" >';
                var workerSalaryInput = '<input type="text" class="form-control" name="worker_salary_' + i + '" placeholder="Worker ' + i + ' Salary" >';

                // Append input fields to the container
                workersContainer.append('<div class="form-group row">' +
                    '<div class="col-md-8">' +
                    '<div class="form-row m-0">' +
                    '<label class="col-sm-3 col-form-label f"><span class="english">ملازم کا نام</span></label>' +
                    '<div class="col-sm-9">' +
                    workerNameInput +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<div class="form-group row">' +
                    '<div class="col-md-8">' +
                    '<div class="form-row m-0">' +
                    '<label class="col-sm-3 col-form-label f"><span class="english">ملازم تنخواہ</span></label>' +
                    '<div class="col-sm-9">' +
                    workerSalaryInput +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>');
            }
        } catch (error) {
            // Log errors to the console
            console.error('Error:', error);
        }
    });
});

</script>


<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/Expenses/create.blade.php ENDPATH**/ ?>