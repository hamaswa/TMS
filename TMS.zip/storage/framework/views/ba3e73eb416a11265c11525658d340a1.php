<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="container">
            <div class="card col-sm-10 mx-auto">
                <div class="row">
                    <div class="col-md-12">
                        <?php echo $__env->make('inc.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <p style="font-size: 24px;text-align:center;"><b>پورے سال کی آمدنی </b></p>

                        

                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <!-- First Table -->
                                    <table class="table js-sortable-table cc-table-data-options-history"
                                        id="cc-table-data-options-history1">
                                        <thead>
                                            <tr>
                                                <th scope="col" class="no-sort"> مہینہ </th>
                                                <th scope="col" class="no-sort"> فروخت کی آمدنی </th>
                                                <th scope="col" class="no-sort">کل اضافی اخراجات</th>
                                                <th scope="col" class="no-sort">ماہانہ بلوں کی رقم</th>
                                                <th scope="col" class="no-sort">ماہانہ کرایہ کی رقم</th>
                                                <th scope="col" class="no-sort">ملازمین کی ماہانہ تنخواہ</th>
                                                <th scope="col" class="no-sort">کل کمائی</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $totalsales = 0;
                                                $totalexpens = 0;
                                                $totalbills = 0;
                                                $totalrent = 0;
                                                $totalsalary = 0;
                                                $totalEarnings = 0;
                                            ?>
                                            <?php $__currentLoopData = $monthly_earnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthName => $earnings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($monthName); ?></td>
                                                    <td>Rs:<?php echo e(number_format($earnings['sales'])); ?></td>
                                                    <td>Rs:<?php echo e(number_format($earnings['extra_expense'])); ?></td>
                                                    <td>Rs:<?php echo e(number_format($earnings['monthly_bills'])); ?></td>
                                                    <td>Rs:<?php echo e(number_format($earnings['monthly_rent'])); ?></td>
                                                    <td>Rs:<?php echo e(number_format($earnings['monthly_salary'])); ?></td>
                                                    <td>
                                                        Rs:<?php echo e(number_format($earnings['sales'] - $earnings['extra_expense'] - $earnings['monthly_bills'] - $earnings['monthly_rent'] - $earnings['monthly_salary'])); ?>

                                                    </td>
                                                    <?php
                                                        // Update the total earnings for each iteration of the loop
                                                        $totalEarnings +=
                                                            $earnings['sales'] -
                                                            $earnings['extra_expense'] -
                                                            $earnings['monthly_bills'] -
                                                            $earnings['monthly_rent'] -
                                                            $earnings['monthly_salary'];
                                                    ?>
                                                </tr>
                                                <?php
                                                    $totalsales += $earnings['sales'];
                                                    $totalexpens += $earnings['extra_expense'];
                                                    $totalbills += $earnings['monthly_bills'];
                                                    $totalrent += $earnings['monthly_rent'];
                                                    $totalsalary += $earnings['monthly_salary'];
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr class="table-info">
                                                <td style="text-align: center;">
                                                    <b style="font-size: 18px;">
                                                        ٹوٹل:
                                                    </b>
                                                </td>
                                                <td><b style="font-size: 18px;">Rs:<?php echo e(number_format($totalsales)); ?></b></td>
                                                <td><b style="font-size: 18px;">Rs:<?php echo e(number_format($totalexpens)); ?></b></td>
                                                <td><b style="font-size: 18px;">Rs:<?php echo e(number_format($totalbills)); ?></b></td>
                                                <td><b style="font-size: 18px;">Rs:<?php echo e(number_format($totalrent)); ?></b></td>
                                                <td><b style="font-size: 18px;">Rs:<?php echo e(number_format($totalsalary)); ?></b></td>
                                                <td>
                                                    <b style="font-size: 18px;">
                                                        <?php echo e(number_format($totalEarnings)); ?> روپے
                                                    </b>
                                                </td>
                                            </tr>
                                        </tfoot>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/All_Total/earning.blade.php ENDPATH**/ ?>