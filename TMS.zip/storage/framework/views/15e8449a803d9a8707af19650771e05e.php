<?php $__env->startSection('content'); ?>
<section class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(Session::has('delete')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('delete')); ?></div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                <?php if(Session::has('error')): ?>
                <div class="alert alert-danger text-right" dir="rtl"><?php echo e(Session::get('error')); ?></div>
                <?php endif; ?>

                <?php if($business?->shop_code): ?>
                <div class="alert alert-info text-right mb-4">
                    <strong>درزی پورٹل کا دکان کوڈ:</strong>
                    <span dir="ltr" class="d-inline-block font-weight-bold mx-2"><?php echo e($business->shop_code); ?></span>
                    <div class="small mt-1">یہ کوڈ اپنے درزیوں کو فون نمبر اور پاس ورڈ کے ساتھ دیں۔</div>
                </div>
                <?php endif; ?>

                <div class="bg-white px-3 py-4">
                    <div class="tab-content" id="v-pills-tabContent">
                        <div class="tab-pane fade show active" id="v-pills-sewing" role="tabpanel"
                            aria-labelledby="v-pills-sewing-tab">
                            <form id="cc-form__optionsForm" action="<?php echo e(url('admin/OptionType')); ?>" method="post"
                                class="cc-form__box">
                                <?php echo csrf_field(); ?>

                                <div class="row text-right">
                                    <div class=" col-md-12">
                                        <a href="<?php echo e(url('admin/setting/add')); ?>" class="btn btn-blue mt-md-0 mt-3">ترتیب +
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="table-title  mb-4 mt-4">
                            <h5 class="text-right">تمام ترتیب کی تاریخ</h5>
                        </div>
                        <?php if($settings->isEmpty()): ?>
                            <div class="alert alert-warning text-right" dir="rtl">
                                رسید اور آرڈر پرنٹ کے لیے دکان کی ترتیب بنائیں۔
                                <a href="<?php echo e(route('admin.add-setting')); ?>" class="alert-link">ابھی ترتیب بنائیں</a>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table js-sortable-table cc-table-data-options-history"
                                        id="cc-table-data-options-history">
                                        <thead>
                                            <tr>
                                                <th scope="col" class="no-sort"></th>
                                                <th scope="col" class="no-sort">نام</th>
                                                <th scope="col" class="no-sort">تصویر</th>
                                                <th scope="col" class="no-sort">نمبر</th>
                                                <th scope="col" class="no-sort">نوٹ</th>
                                                <th scope="col" class="no-sort">پتہ</th>
                                                <th scope="col" class="no-sort">نوٹ</th>
                                                <th scope="col" class="no-sort">تبدیل</th>
                                                <th scope="col" class="no-sort"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td></td>
                                                <td><?php echo e($setting->name); ?></td>
                                                <td>
                                                    <?php if($setting->logo_url): ?>
                                                        <img src="<?php echo e($setting->logo_url); ?>" alt="<?php echo e($setting->name); ?> لوگو"
                                                            style="width:150px; height:100px">
                                                    <?php else: ?>
                                                        <span class="text-muted">لوگو شامل نہیں</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($setting->contact_no); ?></td>
                                                <td><?php echo e($setting->note); ?></td>
                                                <td><?php echo e($setting->address); ?></td>

                                                <td class="text-right">
                                                    <?php if($setting->status ==0): ?>
                                                    <form action="<?php echo e(route('admin.active-setting', $setting->id)); ?>" method="POST" class="d-inline"
                                                        data-confirm="کیا یہ دکان ترتیب فعال کرنا ہے؟" data-confirm-variant="success">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="btn btn-link p-0 delete-tr">فعال کریں</button>
                                                    </form>
                                                    <?php else: ?>
                                                    <form action="<?php echo e(route('admin.deactive-setting', $setting->id)); ?>" method="POST" class="d-inline"
                                                        data-confirm="کیا یہ دکان ترتیب غیر فعال کرنا ہے؟" data-confirm-variant="warning">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="btn btn-link p-0 delete-tr">غیر فعال کریں</button>
                                                    </form>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-right">
                                                    <a href="<?php echo e(url('admin/setting/edit',$setting->id)); ?>">
                                                        <i class="fa fa-edit" aria-hidden="true"></i>
                                                        </a>
                                                    <form action="<?php echo e(route('admin.delete-setting', $setting->id)); ?>" method="POST" class="d-inline" data-confirm="کیا آپ واقعی یہ دکان ترتیب حذف کرنا چاہتے ہیں؟">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-link p-0 delete-tr" aria-label="Delete setting"><i class="fa fa-trash" aria-hidden="true"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/setting/list.blade.php ENDPATH**/ ?>