<?php $__env->startPush('styles'); ?>
<style>
    .counter-sale-page{--sale-blue:#1769ef;--sale-ink:#14213d;--sale-muted:#718096;--sale-line:#e1e8f2;min-height:calc(100vh - 65px);padding:26px 0 46px;background:#f7f9fc;color:var(--sale-ink)}
    .counter-sale-shell{max-width:1560px;margin:auto;padding:0 24px}.counter-sale-breadcrumb{margin-bottom:12px;color:var(--sale-muted);font-size:.84rem}.counter-sale-breadcrumb a{color:inherit}.counter-sale-header{display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:18px}.counter-sale-heading{display:flex;align-items:center;gap:14px}.counter-sale-heading-icon{display:grid;place-items:center;width:52px;height:52px;border:1px solid var(--sale-line);border-radius:13px;background:#fff;color:var(--sale-blue);font-size:21px;box-shadow:0 5px 18px rgba(25,67,120,.06)}.counter-sale-heading h1{margin:0 0 4px;font-size:1.6rem;font-weight:800}.counter-sale-heading p{margin:0;color:var(--sale-muted)}
    .counter-sale-panel{margin-bottom:14px;border:1px solid var(--sale-line);border-radius:13px;background:#fff;box-shadow:0 5px 20px rgba(28,63,105,.045)}.counter-sale-section-head{display:flex;align-items:center;gap:10px;padding:15px 19px 0;color:var(--sale-blue);font-size:1.04rem;font-weight:800}.counter-sale-panel-body{padding:18px 19px}.counter-sale-page label{display:block;margin-bottom:7px;color:#52627b;font-weight:700}.counter-sale-page .required{color:#e53e3e}.counter-sale-page .form-control{min-height:44px;border-color:#d8e1ed;border-radius:7px;background:#fff}.counter-sale-page select.form-control{height:50px;min-height:50px;padding-top:4px;padding-bottom:10px;line-height:1.8}.counter-sale-page .form-control:focus{border-color:#7aafff;box-shadow:0 0 0 3px rgba(23,105,239,.1)}.counter-input{position:relative}.counter-input>i{position:absolute;z-index:2;top:50%;right:14px;transform:translateY(-50%);color:#8492a7}.counter-input .form-control{padding-right:42px}.counter-input .has-suffix{padding-left:48px}.counter-input-suffix{position:absolute;z-index:2;top:1px;bottom:1px;left:1px;display:flex;align-items:center;padding:0 13px;border-right:1px solid var(--sale-line);border-radius:7px 0 0 7px;background:#f8fafc;color:#66758d;font-weight:700}
    .counter-customer-modes{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-bottom:16px}.counter-customer-mode{margin:0!important;cursor:pointer}.counter-customer-mode input{position:absolute;opacity:0;pointer-events:none}.counter-customer-mode>span{display:flex;align-items:center;gap:10px;min-height:58px;padding:10px 13px;border:1px solid #d8e1ed;border-radius:10px;background:#fbfcfe;color:#52627b}.counter-customer-mode i{display:grid;place-items:center;flex:0 0 36px;width:36px;height:36px;border-radius:9px;color:#75869d;background:#edf2f7}.counter-customer-mode strong{display:block;color:#344a67}.counter-customer-mode small{display:block;margin-top:2px;color:#8190a3;font-size:.7rem}.counter-customer-mode input:checked+span{border-color:#86b5f8;background:#edf5ff;box-shadow:0 0 0 2px rgba(23,105,239,.08)}.counter-customer-mode input:checked+span i{color:#fff;background:var(--sale-blue)}.counter-customer-fields[hidden]{display:none!important}.counter-customer-note{margin:8px 0 0;color:#718096;font-size:.73rem}
    .counter-sale-item{position:relative;padding:17px;margin-bottom:13px;border:1px solid #e4eaf3;border-radius:11px;background:#fbfcfe}.counter-item-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}.counter-item-title{display:flex;align-items:center;gap:8px;color:#53647d;font-weight:800}.counter-item-number{display:grid;place-items:center;width:27px;height:27px;border-radius:7px;background:#eaf2ff;color:var(--sale-blue);font-family:Arial,sans-serif}.counter-line-total{padding:9px 12px;border-radius:7px;background:#eef4ff;color:var(--sale-blue);font:800 .9rem Arial,sans-serif;direction:ltr}.counter-remove-item{border:0;background:transparent;color:#dc3545}.counter-add-item{display:inline-flex;align-items:center;gap:8px;min-height:42px;padding:8px 15px;border:1px solid var(--sale-blue);border-radius:7px;background:#fff;color:var(--sale-blue);font-weight:800}.counter-add-item:hover{background:#edf4ff;color:#0f5ddf}
    .counter-summary-line{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin-top:8px;font-weight:800}.counter-summary-line strong{color:var(--sale-blue);font:800 1rem Arial,sans-serif;direction:ltr}.counter-payment-panel{border-color:#d9eee1;background:linear-gradient(135deg,#fbfffc,#f1fbf5)}.counter-payment-panel .counter-sale-section-head{color:#1a9b57}.counter-balance-line{display:flex;align-items:center;gap:18px;margin-top:10px;color:#52627b;font-weight:700}.counter-balance-line strong{color:#1a9b57;font:800 1rem Arial,sans-serif;direction:ltr}.counter-sale-submit{display:flex;justify-content:center;padding-top:4px}.counter-sale-submit button{min-width:280px;min-height:48px;border:0;border-radius:8px;background:linear-gradient(135deg,#1769ef,#287fff);color:#fff;font-weight:800;box-shadow:0 9px 23px rgba(23,105,239,.22)}.counter-sale-back{min-height:43px;padding:9px 16px;border-radius:8px;font-weight:700}.counter-sale-alert{border-radius:10px}
    @media(max-width:767.98px){.counter-sale-shell{padding:0 12px}.counter-sale-header{align-items:stretch;flex-direction:column}.counter-sale-back{width:100%}.counter-sale-panel-body{padding:15px 13px}.counter-customer-modes{grid-template-columns:1fr}.counter-sale-item{padding:14px 11px}.counter-sale-submit button{width:100%;min-width:0}.counter-balance-line{align-items:flex-start;flex-direction:column;gap:5px}}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="main-content counter-sale-page" dir="rtl">
<div class="counter-sale-shell" id="formContainer">
    <div class="counter-sale-breadcrumb"><a href="<?php echo e(route('admin.home')); ?>">ڈیش بورڈ</a><span class="mx-2">‹</span>فروخت<span class="mx-2">‹</span>کپڑے کی فروخت</div>
    <header class="counter-sale-header">
        <div class="counter-sale-heading"><span class="counter-sale-heading-icon"><i class="fas fa-tags"></i></span><div><h1>کپڑے کی فروخت کریں</h1><p>فروخت کی مکمل معلومات درج کریں</p></div></div>
        <a href="<?php echo e(route('admin.stock.index')); ?>" class="btn btn-outline-secondary counter-sale-back"><i class="fas fa-arrow-right ml-1"></i> واپس جائیں</a>
    </header>

    <?php echo $__env->make('inc.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger counter-sale-alert" role="alert"><strong>فروخت محفوظ نہیں ہو سکی:</strong><ul class="mb-0 mt-2"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.sellStock')); ?>" method="post" id="sellStockForm" data-customer-url="<?php echo e(url('/admin/getNmbr')); ?>" data-types-url="<?php echo e(url('/admin/getType')); ?>">
        <?php echo csrf_field(); ?>

        <section class="counter-sale-panel">
            <div class="counter-sale-section-head"><i class="far fa-file-alt"></i> بنیادی معلومات — گاہک کی معلومات</div>
            <?php ($saleCustomerMode = old('customer_mode', 'regular')); ?>
            <div class="counter-sale-panel-body">
                <div class="counter-customer-modes" role="radiogroup" aria-label="گاہک کی قسم">
                    <label class="counter-customer-mode"><input type="radio" name="customer_mode" value="regular" <?php if($saleCustomerMode === 'regular'): echo 'checked'; endif; ?>><span><i class="fas fa-users"></i><span><strong>ریگولر گاہک</strong><small>موجودہ گاہکوں کی فہرست سے منتخب کریں</small></span></span></label>
                    <label class="counter-customer-mode"><input type="radio" name="customer_mode" value="random" <?php if($saleCustomerMode === 'random'): echo 'checked'; endif; ?>><span><i class="fas fa-user-plus"></i><span><strong>رینڈم / نیا گاہک</strong><small>نام لکھیں، نمبر اختیاری ہے</small></span></span></label>
                </div>
                <input type="hidden" name="c_name" id="legacy_c_name" value="<?php echo e(old('c_name')); ?>">
                <div class="counter-customer-fields" id="regularCustomerFields" <?php if($saleCustomerMode !== 'regular'): ?> hidden <?php endif; ?>><div class="form-row">
                    <div class="form-group col-md-6 mb-md-0"><label for="existing_customer_id">گاہک کا نام <span class="required">*</span></label><div class="counter-input"><i class="far fa-user"></i><select name="existing_customer_id" class="form-control custom-select" id="existing_customer_id"><option value="">گاہک منتخب کریں</option><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($customer->id); ?>" data-legacy="<?php echo e($customer->name.'|'.$customer->id); ?>" <?php if((string) old('existing_customer_id') === (string) $customer->id): echo 'selected'; endif; ?>><?php echo e($customer->name); ?> (#<?php echo e($customer->id); ?>)</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div><?php $__errorArgs = ['existing_customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="form-group col-md-6 mb-md-0"><label for="nmbr">رابطہ نمبر</label><div class="counter-input"><i class="fas fa-phone"></i><input type="tel" inputmode="tel" class="form-control" name="phone" id="nmbr" value="<?php echo e(old('phone')); ?>" placeholder="منتخب گاہک کا رابطہ نمبر" autocomplete="tel" readonly></div></div>
                </div></div>
                <div class="counter-customer-fields" id="randomCustomerFields" <?php if($saleCustomerMode !== 'random'): ?> hidden <?php endif; ?>><div class="form-row">
                    <div class="form-group col-md-6 mb-md-0"><label for="random_customer_name">نئے گاہک کا نام <span class="required">*</span></label><div class="counter-input"><i class="far fa-user"></i><input type="text" class="form-control" name="random_customer_name" id="random_customer_name" value="<?php echo e(old('random_customer_name')); ?>" maxlength="255" placeholder="گاہک کا نام لکھیں" autocomplete="name"></div><?php $__errorArgs = ['random_customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="form-group col-md-6 mb-md-0"><label for="random_customer_phone">رابطہ نمبر <small>(اختیاری)</small></label><div class="counter-input"><i class="fas fa-phone"></i><input type="tel" inputmode="tel" class="form-control" name="random_customer_phone" id="random_customer_phone" value="<?php echo e(old('random_customer_phone')); ?>" maxlength="30" placeholder="نمبر ہو تو لکھیں" autocomplete="tel"></div><?php $__errorArgs = ['random_customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                </div><p class="counter-customer-note"><i class="fas fa-info-circle ml-1"></i>فروخت محفوظ ہونے پر یہ گاہک خود بخود گاہکوں کی فہرست میں شامل ہو جائے گا۔</p></div>
            </div>
        </section>

        <section class="counter-sale-panel">
            <div class="counter-sale-section-head"><i class="fas fa-plus-square"></i> فروخت کے آئٹمز شامل کریں</div>
            <div class="counter-sale-panel-body">
                <div id="stockDataContainer" aria-live="polite">
                    <article class="stock-data counter-sale-item">
                        <div class="counter-item-head"><div class="counter-item-title"><span class="counter-item-number">1</span><span>کپڑے کی تفصیل</span></div><div class="d-flex align-items-center"><span class="counter-line-total">Rs. 0.00</span></div></div>
                        <div class="form-row">
                            <div class="form-group col-xl-3 col-md-6"><label>برانڈ <span class="required">*</span></label><select class="form-control js-brand" name="brand_name[]" required><option value="" disabled selected>برانڈ منتخب کریں</option><?php $__currentLoopData = $cloths->unique('cloth_brand_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cloth->cloth_brand_id); ?>"><?php echo e($cloth->brand->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                            <div class="form-group col-xl-3 col-md-6"><label>کپڑے کی قسم <span class="required">*</span></label><select class="form-control js-cloth-type" name="cloth_type[]" required><option value="" disabled selected>پہلے برانڈ منتخب کریں</option></select></div>
                            <div class="form-group col-xl-3 col-md-6"><label>رنگ <span class="required">*</span></label><select class="form-control js-color" name="color[]" required><option value="" disabled selected>پہلے کپڑے کی قسم منتخب کریں</option></select></div>
                            <div class="form-group col-xl-3 col-md-6"><label>میٹر / گز <span class="required">*</span></label><div class="counter-input"><i class="fas fa-ruler"></i><input type="number" class="form-control" name="length[]" min="0.01" step="0.01" placeholder="مقدار درج کریں" required></div></div>
                            <div class="form-group col-xl-4 col-md-6 mb-xl-0"><label>کل قیمت <span class="required">*</span></label><div class="counter-input"><i class="fas fa-money-bill-wave"></i><input type="number" class="form-control has-suffix" name="item_total[]" min="0" step="0.01" placeholder="اس کپڑے کی کل قیمت" required><input type="hidden" name="per_meter[]" value="0"><span class="counter-input-suffix">Rs.</span></div></div>
                            <div class="form-group col-xl-4 col-md-6 mb-xl-0"><label>فیبرک رول / ریک</label><div class="counter-input"><i class="fas fa-warehouse"></i><input type="text" class="form-control" name="clothes_rack[]" maxlength="100" placeholder="ریک یا رول نمبر"></div></div>
                            <div class="form-group col-xl-4 col-md-12 mb-0"><label>ریٹ فی میٹر <small>(خودکار)</small></label><input type="text" class="form-control js-rate-per-meter" value="Rs. 0.00" readonly></div>
                        </div>
                    </article>
                </div>
                <button type="button" class="counter-add-item" id="addMoreBtn"><i class="fas fa-plus"></i> مزید کپڑا شامل کریں</button>
                <div class="counter-summary-line"><span>کل رقم:</span><strong id="itemsTotalText">Rs. 0.00</strong></div>
            </div>
        </section>

        <section class="counter-sale-panel counter-payment-panel">
            <div class="counter-sale-section-head"><i class="fas fa-wallet"></i> ادائیگی کی تفصیل</div>
            <div class="counter-sale-panel-body">
                <div class="form-row">
                    <div class="form-group col-xl-3 col-md-6"><label for="counter_sale_method">ادائیگی کا طریقہ <span class="required">*</span></label><select id="counter_sale_method" name="payment_method" class="form-control" required><?php $__currentLoopData = \App\Support\PaymentMethods::LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $methodValue => $methodLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($methodValue); ?>" <?php if(old('payment_method','cash') === $methodValue): echo 'selected'; endif; ?>><?php echo e($methodLabel); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="form-group col-xl-3 col-md-6"><label for="counter_sale_paid_on">ادائیگی کی تاریخ <span class="required">*</span></label><input id="counter_sale_paid_on" type="date" name="paid_on" value="<?php echo e(old('paid_on',now()->toDateString())); ?>" class="form-control" required></div>
                    <div class="form-group col-xl-3 col-md-6"><label for="payment">رقم وصول <span class="required">*</span></label><div class="counter-input"><i class="fas fa-money-bill"></i><input type="number" class="form-control has-suffix" name="payment" id="payment" min="0" step="0.01" value="<?php echo e(old('payment')); ?>" placeholder="وصول شدہ رقم" required><span class="counter-input-suffix">Rs.</span></div></div>
                    <div class="form-group col-xl-3 col-md-6"><label for="remain">بقایا رقم</label><input type="number" class="form-control" name="remain" id="remain" step="0.01" readonly></div>
                    <div class="form-group col-md-6 mb-md-0"><label for="counter_sale_reference">حوالہ / ٹرانزیکشن نمبر</label><input id="counter_sale_reference" type="text" name="payment_reference" value="<?php echo e(old('payment_reference')); ?>" maxlength="255" class="form-control" placeholder="بینک، والٹ، راست یا چیک نمبر"><small id="counter_sale_reference_hint" class="form-text text-muted">نقد ادائیگی کے لیے اختیاری ہے۔</small></div>
                    <div class="form-group col-md-6 mb-md-0"><label for="total">کل فروخت</label><input type="number" class="form-control" name="total" id="total" step="0.01" readonly></div>
                </div>
                <div class="counter-balance-line"><span>کل فروخت: <strong id="paymentTotalText">Rs. 0.00</strong></span><span>بقایا: <strong id="balanceText">Rs. 0.00</strong></span></div>
            </div>
        </section>

        <div class="counter-sale-submit"><button type="submit"><i class="far fa-save ml-2"></i> فروخت محفوظ کریں</button></div>
    </form>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('sellStockForm');
    const container = document.getElementById('stockDataContainer');
    const addButton = document.getElementById('addMoreBtn');
    const customerModes = form.querySelectorAll('[name="customer_mode"]');
    const customer = document.getElementById('existing_customer_id');
    const legacyCustomer = document.getElementById('legacy_c_name');
    const regularCustomerFields = document.getElementById('regularCustomerFields');
    const randomCustomerFields = document.getElementById('randomCustomerFields');
    const randomCustomerName = document.getElementById('random_customer_name');
    const phone = document.getElementById('nmbr');
    const total = document.getElementById('total');
    const payment = document.getElementById('payment');
    const remaining = document.getElementById('remain');
    const method = document.getElementById('counter_sale_method');
    const reference = document.getElementById('counter_sale_reference');
    const referenceHint = document.getElementById('counter_sale_reference_hint');
    const inventoryOptions = <?php echo json_encode($inventoryOptions, 15, 512) ?>;

    const money = value => 'Rs. ' + value.toFixed(2);
    const refreshItemNumbers = function () {
        container.querySelectorAll('.stock-data').forEach(function (item, index) {
            item.querySelector('.counter-item-number').textContent = index + 1;
        });
    };
    const calculateTotals = function () {
        let saleTotal = 0;
        container.querySelectorAll('.stock-data').forEach(function (item) {
            const length = Number.parseFloat(item.querySelector('[name="length[]"]').value) || 0;
            const lineTotal = Number.parseFloat(item.querySelector('[name="item_total[]"]').value) || 0;
            const rate = length > 0 ? lineTotal / length : 0;
            saleTotal += lineTotal;
            item.querySelector('[name="per_meter[]"]').value = rate.toFixed(2);
            item.querySelector('.js-rate-per-meter').value = money(rate);
            item.querySelector('.counter-line-total').textContent = money(lineTotal);
        });
        const received = Number.parseFloat(payment.value) || 0;
        const balance = Math.max(0, saleTotal - received);
        total.value = saleTotal.toFixed(2);
        remaining.value = balance.toFixed(2);
        document.getElementById('itemsTotalText').textContent = money(saleTotal);
        document.getElementById('paymentTotalText').textContent = money(saleTotal);
        document.getElementById('balanceText').textContent = money(balance);
    };
    const loadClothTypes = async function (item) {
        const brand = item.querySelector('.js-brand');
        const clothType = item.querySelector('.js-cloth-type');
        const color = item.querySelector('.js-color');
        clothType.innerHTML = '<option value="" disabled selected>لوڈ ہو رہا ہے…</option>';
        color.innerHTML = '<option value="" disabled selected>پہلے کپڑے کی قسم منتخب کریں</option>';
        try {
            const response = await fetch(form.dataset.typesUrl + '?id=' + encodeURIComponent(brand.value), {headers:{'Accept':'application/json'}});
            if (!response.ok) throw new Error();
            const payload = await response.json();
            clothType.innerHTML = '<option value="" disabled selected>کپڑے کی قسم منتخب کریں</option>';
            (payload.data || []).forEach(function (entry) { const option = document.createElement('option'); option.value = entry.cloth_type_id; option.textContent = entry.type ? entry.type.name : ''; clothType.appendChild(option); });
        } catch (error) { clothType.innerHTML = '<option value="" disabled selected>اقسام لوڈ نہیں ہو سکیں</option>'; }
    };
    const loadColors = function (item) {
        const brandId = item.querySelector('.js-brand').value;
        const typeId = item.querySelector('.js-cloth-type').value;
        const color = item.querySelector('.js-color');
        const match = inventoryOptions.find(entry => entry.brand_id === brandId && entry.type_id === typeId);
        color.innerHTML = '<option value="" disabled selected>رنگ منتخب کریں</option>';
        (match?.colors || []).filter(entry => entry.length > 0).forEach(function (entry) {
            const option = document.createElement('option');
            option.value = entry.name;
            option.textContent = entry.name + ' (' + entry.length + ' میٹر)';
            color.appendChild(option);
        });
        if (!match || !match.colors.some(entry => entry.length > 0)) {
            color.innerHTML = '<option value="" disabled selected>اس کپڑے کا کوئی رنگ اسٹاک میں نہیں</option>';
        }
    };
    const bindItem = function (item) {
        item.querySelector('.js-brand').addEventListener('change', () => loadClothTypes(item));
        item.querySelector('.js-cloth-type').addEventListener('change', () => loadColors(item));
        item.querySelectorAll('[name="item_total[]"], [name="length[]"]').forEach(input => input.addEventListener('input', calculateTotals));
        const remove = item.querySelector('.counter-remove-item');
        if (remove) remove.addEventListener('click', function () { item.remove(); refreshItemNumbers(); calculateTotals(); });
    };
    bindItem(container.querySelector('.stock-data'));

    const syncCustomerMode = function () {
        const mode = form.querySelector('[name="customer_mode"]:checked')?.value || 'regular';
        const isRegular = mode === 'regular';
        regularCustomerFields.hidden = !isRegular;
        randomCustomerFields.hidden = isRegular;
        customer.required = isRegular;
        randomCustomerName.required = !isRegular;
        if (isRegular) {
            const selected = customer.options[customer.selectedIndex];
            legacyCustomer.value = selected?.dataset.legacy || '';
        } else {
            legacyCustomer.value = '';
        }
    };
    customerModes.forEach(input => input.addEventListener('change', syncCustomerMode));
    customer.addEventListener('change', async function () {
        const selected = customer.options[customer.selectedIndex];
        legacyCustomer.value = selected?.dataset.legacy || '';
        const customerId = customer.value;
        if (!customerId) return;
        try { const response = await fetch(form.dataset.customerUrl + '?id=' + encodeURIComponent(customerId), {headers:{'Accept':'application/json'}}); if (!response.ok) throw new Error(); const payload = await response.json(); phone.value = payload.data?.phone_number1 || ''; } catch (error) { phone.value = ''; }
    });
    addButton.addEventListener('click', function () {
        const item = container.querySelector('.stock-data').cloneNode(true);
        item.querySelectorAll('input').forEach(input => { input.value = input.classList.contains('js-rate-per-meter') ? 'Rs. 0.00' : (input.name === 'per_meter[]' ? '0' : ''); });
        item.querySelectorAll('select').forEach(select => { select.selectedIndex = 0; });
        item.querySelector('.js-cloth-type').innerHTML = '<option value="" disabled selected>پہلے برانڈ منتخب کریں</option>';
        item.querySelector('.js-color').innerHTML = '<option value="" disabled selected>پہلے کپڑے کی قسم منتخب کریں</option>';
        item.querySelector('.counter-line-total').textContent = 'Rs. 0.00';
        const actionWrap = item.querySelector('.counter-item-head .d-flex');
        const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'counter-remove-item mr-2'; remove.setAttribute('aria-label','یہ آئٹم ہٹائیں'); remove.innerHTML = '<i class="fas fa-trash"></i>'; actionWrap.appendChild(remove);
        container.appendChild(item); bindItem(item); refreshItemNumbers(); item.querySelector('.js-brand').focus();
    });
    const syncReference = function () { const required = !['cash','other'].includes(method.value); reference.required = required; reference.setAttribute('aria-required', required ? 'true' : 'false'); referenceHint.textContent = required ? 'منتخب ادائیگی کے طریقے کے لیے حوالہ نمبر ضروری ہے۔' : 'نقد ادائیگی کے لیے اختیاری ہے۔'; };
    method.addEventListener('change', syncReference); payment.addEventListener('input', calculateTotals); syncCustomerMode(); syncReference(); calculateTotals();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/stock/sell.blade.php ENDPATH**/ ?>