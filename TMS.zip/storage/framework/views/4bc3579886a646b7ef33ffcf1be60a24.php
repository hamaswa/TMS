<?php $__env->startSection('title', __('storefront.marketplace.title')); ?>
<?php $__env->startSection('meta_description', __('storefront.marketplace.hero_text')); ?>
<?php $__env->startSection('canonical_url', route('storefront.index')); ?>
<?php $__env->startPush('structured_data'); ?>
    <script type="application/ld+json"><?php echo \App\Support\StorefrontSeo::json(\App\Support\StorefrontSeo::graph(
    \App\Support\StorefrontSeo::website(
        __('storefront.common.marketplace'),
        __('storefront.marketplace.hero_text'),
        route('storefront.index')
    )
)); ?></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
    .market-nav{background:#0b3d2e;color:#fff}.market-nav .nav-brand,.market-nav
    .nav-link{color:#fff}.market-hero{padding:68px 0;background:radial-gradient(circle at 15% 20%,#2ca679 0,transparent
    28%),linear-gradient(135deg,#0b3d2e,#126f50)}.market-filters{margin:-28px auto
    32px;position:relative}.market-filter-grid{display:grid;grid-template-columns:1.5fr .85fr 1.25fr 1.25fr
    auto;gap:12px;align-items:end}.filter-field
    label{display:block;font-size:.82rem;font-weight:800;margin-bottom:6px}.filter-actions{display:flex;gap:8px}.shop{padding:0;overflow:hidden;display:flex;flex-direction:column}.cover{height:170px;background:linear-gradient(135deg,#d9efe6,#9ed7c0);background-size:cover;background-position:center}.shop-body{padding:20px;display:flex;flex-direction:column;flex:1}.shop-body
    h2{margin:0}.tags{display:flex;flex-wrap:wrap;gap:7px;margin:12px 0}.shop
    .btn{margin-top:auto}@media(max-width:950px){.market-filter-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.filter-actions{grid-column:1/-1}}@media(max-width:600px){.market-filter-grid{grid-template-columns:1fr}}
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
    <nav class="nav market-nav">
        <div class="shell"><a class="nav-brand"
                href="<?php echo e(route('storefront.index')); ?>"><?php echo e(__('storefront.common.marketplace')); ?></a>
            <div class="nav-actions"><?php echo $__env->make('storefront.public.partials.language-switch', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><a class="nav-link"
                    href="<?php echo e(route('login')); ?>"><?php echo e(__('storefront.common.business_login')); ?></a></div>
        </div>
    </nav>
    <header class="hero market-hero">
        <div class="shell">
            <h1><?php echo e(__('storefront.marketplace.hero_title')); ?></h1>
            <p><?php echo e(__('storefront.marketplace.hero_text')); ?></p>
        </div>
    </header>
    <main class="section">
        <div class="shell">
            <form class="card market-filters" method="GET">
                <div class="market-filter-grid">
                    <div class="filter-field"><label
                            for="market_q"><?php echo e(__('storefront.marketplace.search_label')); ?></label><input id="market_q"
                            class="control" name="q" value="<?php echo e($filters['q'] ?? ''); ?>"
                            placeholder="<?php echo e(__('storefront.marketplace.search_placeholder')); ?>"></div>
                    <div class="filter-field"><label
                            for="market_city"><?php echo e(__('storefront.marketplace.city_label')); ?></label><select id="market_city"
                            class="control" name="city">
                            <option value=""><?php echo e(__('storefront.marketplace.all_cities')); ?></option>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city); ?>" <?php if(($filters['city'] ?? '') === $city): echo 'selected'; endif; ?>><?php echo e($city); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="filter-field"><label
                            for="market_category"><?php echo e(__('storefront.marketplace.category_label')); ?></label><select
                            id="market_category" class="control" name="category">
                            <option value=""><?php echo e(__('storefront.marketplace.all_categories')); ?></option>
                            <option value="clothing" <?php if(($filters['category'] ?? '') === 'clothing'): echo 'selected'; endif; ?>><?php echo e(__('storefront.common.clothing')); ?>

                            </option>
                            <option value="tailoring" <?php if(($filters['category'] ?? '') === 'tailoring'): echo 'selected'; endif; ?>><?php echo e(__('storefront.common.tailoring')); ?>

                            </option>
                            <option value="both" <?php if(($filters['category'] ?? '') === 'both'): echo 'selected'; endif; ?>>
                                <?php echo e(__('storefront.marketplace.both_categories')); ?></option>
                        </select></div>
                    <div class="filter-field"><label
                            for="market_delivery"><?php echo e(__('storefront.marketplace.delivery_label')); ?></label><select
                            id="market_delivery" class="control" name="delivery">
                            <option value=""><?php echo e(__('storefront.marketplace.any_delivery')); ?></option>
                            <option value="1" <?php if(($filters['delivery'] ?? '') === '1'): echo 'selected'; endif; ?>>
                                <?php echo e(__('storefront.marketplace.delivery_available')); ?></option>
                        </select></div>
                    <div class="filter-actions"><button
                            class="btn"><?php echo e(__('storefront.marketplace.apply_filters')); ?></button>
                        <?php if(collect($filters)->contains(fn($value) => $value !== null && $value !== '')): ?>
                            <a class="btn btn-secondary"
                                href="<?php echo e(route('storefront.index')); ?>"><?php echo e(__('storefront.marketplace.clear_filters')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
            <div class="row">
                <div>
                    <h2><?php echo e(__('storefront.marketplace.shops')); ?></h2>
                    <div class="muted"><?php echo e(__('storefront.marketplace.active_only')); ?></div>
                </div>
                <div class="muted"><?php echo e(__('storefront.marketplace.shop_count', ['count' => $storefronts->total()])); ?></div>
            </div>
            <?php if($storefronts->count()): ?>
                <div class="grid" style="margin-top:22px">
                    <?php $__currentLoopData = $storefronts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storefront): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="card shop">
                            <div class="cover"
                                <?php if($storefront->cover_url): ?> style="background-image:url('<?php echo e($storefront->cover_url); ?>')" <?php endif; ?>>
                            </div>
                            <div class="shop-body">
                                <h2><?php echo e($storefront->display_name); ?></h2>
                                <div class="muted"><?php echo e($storefront->city ?: __('storefront.common.pakistan')); ?></div>
                                <p><?php echo e($storefront->tagline ?: __('storefront.marketplace.default_tagline')); ?></p>
                                <div class="tags">
                                    <?php if($storefront->show_clothing && $storefront->business->clothing_enabled): ?>
                                        <span class="pill"><?php echo e(__('storefront.common.clothing')); ?></span>
                                        <?php endif; ?> <?php if($storefront->show_tailoring && $storefront->business->tailoring_enabled): ?>
                                            <span class="pill"><?php echo e(__('storefront.common.tailoring')); ?></span>
                                            <?php endif; ?> <?php if($storefront->offersDelivery()): ?>
                                                <span class="pill"><?php echo e(__('storefront.common.delivery')); ?></span>
                                            <?php endif; ?>
                                </div><a class="btn"
                                    href="<?php echo e(route('storefront.show', $storefront)); ?>"><?php echo e(__('storefront.marketplace.view_shop')); ?></a>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div style="margin-top:25px"><?php echo e($storefronts->links()); ?></div>
            <?php else: ?><div class="card empty" style="margin-top:22px">
                    <h2><?php echo e(__('storefront.marketplace.empty_title')); ?></h2>
                    <p class="muted"><?php echo e(__('storefront.marketplace.empty_text')); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </main>
    <footer class="footer">
        <div class="shell"><?php echo e(__('storefront.marketplace.footer')); ?></div>
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.public.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/storefront/public/index.blade.php ENDPATH**/ ?>