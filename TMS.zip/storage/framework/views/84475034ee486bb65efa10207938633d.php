<?php $__env->startSection('content'); ?>
    <?php
        $statusLabels = [
            ...\App\Models\Order::STATUS_LABELS,
            'pending' => 'زیرِ انتظار',
            'paid' => 'ادا شدہ',
            'partial' => 'کچھ ادائیگی',
            'unpaid' => 'ادائیگی باقی',
            'sent' => 'اطلاع درج',
            'failed' => 'ناکام',
            'skipped' => 'درج نہیں ہوئی',
        ];
        if (! $detailedWorkflow) {
            $statusLabels = [...$statusLabels, 'assigned' => 'کارخانے میں ہے', 'cutting' => 'کارخانے میں ہے', 'stitching' => 'کارخانے میں ہے', 'trial' => 'کارخانے میں ہے', 'ready' => 'تیار ہے'];
        }
        $hasMoreFilters =
            filled($filters['status'] ?? null) ||
            filled($filters['tailor_id'] ?? null) ||
            filled($filters['due'] ?? null) ||
            filled($filters['from_date'] ?? null) ||
            filled($filters['to_date'] ?? null) ||
            (int) ($filters['per_page'] ?? 25) !== 25;
    ?>

    <style>
        .tailor-jobs-page {
            --tj-blue: #1769e0;
            --tj-navy: #11365b;
            --tj-muted: #718198;
            --tj-line: #dfe7f1;
            background: #f4f7fa;
            min-height: calc(100vh - 70px)
        }

        .tj-shell {
            width: min(100% - 38px, 1460px);
            margin: 0 auto;
            padding: 28px 0 46px
        }

        .tj-head,
        .tj-panel-head,
        .tj-card-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px
        }

        .tj-head {
            margin-bottom: 18px
        }

        .tj-title h1 {
            margin: 0;
            color: var(--tj-navy);
            font-size: 1.55rem;
            font-weight: 900
        }

        .tj-title p {
            margin: 5px 0 0;
            color: var(--tj-muted);
            font-size: .78rem
        }

        .tj-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            min-height: 42px;
            padding: 8px 15px;
            border: 1px solid #bfd3ee;
            border-radius: 10px;
            color: var(--tj-blue);
            background: #fff;
            font-size: .75rem;
            font-weight: 800;
            text-decoration: none !important
        }

        .tj-stats {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: 12px;
            margin-bottom: 16px
        }

        .tj-stat {
            display: flex;
            align-items: center;
            gap: 11px;
            padding: 15px;
            border: 1px solid var(--tj-line);
            border-radius: 13px;
            background: #fff
        }

        .tj-stat-icon {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            border-radius: 11px;
            color: #1769e0;
            background: #eaf3ff
        }

        .tj-stat.is-due .tj-stat-icon {
            color: #a86f00;
            background: #fff4d8
        }

        .tj-stat.is-late .tj-stat-icon {
            color: #c33c4d;
            background: #fff0f2
        }

        .tj-stat.is-ready .tj-stat-icon {
            color: #168553;
            background: #e8f8ef
        }

        .tj-stat small {
            display: block;
            color: var(--tj-muted);
            font-size: .68rem
        }

        .tj-stat strong {
            display: block;
            color: var(--tj-navy);
            font-size: 1.2rem
        }

        .tj-panel {
            margin-bottom: 16px;
            border: 1px solid var(--tj-line);
            border-radius: 14px;
            background: #fff;
            box-shadow: 0 5px 16px rgba(25, 55, 88, .04)
        }

        .tj-search-form {
            padding: 15px
        }

        .tj-search-row {
            display: grid;
            grid-template-columns: minmax(240px, 1fr) auto;
            gap: 10px;
            align-items: end
        }

        .tj-field label {
            display: block;
            margin-bottom: 5px;
            color: #3c526d;
            font-size: .72rem;
            font-weight: 800
        }

        .tj-field .form-control {
            min-height: 42px;
            border-color: #d2deeb;
            border-radius: 9px;
            background: #fbfdff
            padding-top: 0px
        }

        .tj-filter-button {
            min-width: 100px;
            border-color: var(--tj-blue);
            color: #fff;
            background: var(--tj-blue)
        }

        .tj-more-filters {
            margin-top: 10px
        }

        .tj-more-filters summary {
            width: max-content;
            cursor: pointer;
            list-style: none
        }

        .tj-more-filters summary::-webkit-details-marker {
            display: none
        }

        .tj-filter-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
            padding-top: 14px;
            margin-top: 14px;
            border-top: 1px solid #e7edf5
        }

        .tj-filter-reset {
            display: inline-block;
            margin-top: 12px;
            color: #7a899b;
            font-size: .7rem
        }

        .tj-system-note {
            padding: 9px 14px;
            margin-bottom: 15px;
            border-radius: 10px;
            color: #64768c;
            background: #eef3f8;
            font-size: .68rem
        }

        .tj-system-note i {
            color: var(--tj-blue);
            margin-left: 5px
        }

        .tj-panel-head {
            padding: 14px 16px;
            border-bottom: 1px solid #e8eef5
        }

        .tj-panel-head h2 {
            margin: 0;
            color: var(--tj-navy);
            font-size: 1rem;
            font-weight: 900
        }

        .tj-panel-head span {
            color: var(--tj-muted);
            font-size: .68rem
        }

        .tj-list {
            display: grid;
            gap: 13px;
            padding: 15px
        }

        .tj-job-card {
            overflow: hidden;
            border: 1px solid #dce6f0;
            border-radius: 13px;
            background: #fff
        }

        .tj-job-card.is-overdue {
            border-color: #efbdc4
        }

        .tj-card-head {
            padding: 14px 16px;
            background: #f8fbff
        }

        .tj-job-card.is-overdue .tj-card-head {
            background: #fff5f6
        }

        .tj-order-main {
            display: flex;
            align-items: center;
            gap: 11px
        }

        .tj-order-number {
            display: grid;
            place-items: center;
            min-width: 52px;
            height: 44px;
            padding: 0 8px;
            border-radius: 10px;
            color: #fff;
            background: var(--tj-blue);
            font-weight: 900
        }

        .tj-order-main h3 {
            margin: 0;
            color: var(--tj-navy);
            font-size: .95rem;
            font-weight: 900
        }

        .tj-order-main small {
            color: var(--tj-muted);
            font-size: .68rem
        }

        .tj-status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 999px;
            color: #1769e0;
            background: #e9f2ff;
            font-size: .68rem;
            font-weight: 800
        }

        .tj-status.is-overdue {
            color: #b83243;
            background: #ffe8eb
        }

        .tj-info-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            border-top: 1px solid #e8eef5;
            border-bottom: 1px solid #e8eef5
        }

        .tj-info {
            padding: 12px 16px;
            border-left: 1px solid #edf1f6
        }

        .tj-info:last-child {
            border-left: 0
        }

        .tj-info small {
            display: block;
            color: var(--tj-muted);
            font-size: .65rem
        }

        .tj-info strong {
            display: block;
            margin-top: 3px;
            color: #334c68;
            font-size: .78rem
        }

        .tj-card-body {
            display: grid;
            grid-template-columns: minmax(0, 1.4fr) minmax(260px, .8fr);
            gap: 14px;
            padding: 15px
        }

        .tj-action-box {
            padding: 13px;
            border: 1px solid #e1e9f2;
            border-radius: 11px;
            background: #fbfdff
        }

        .tj-action-box h4 {
            margin: 0 0 10px;
            color: var(--tj-navy);
            font-size: .78rem;
            font-weight: 900
        }

        .tj-progress-form {
            display: grid;
            grid-template-columns: minmax(170px, 1fr) auto;
            gap: 8px
        }

        .tj-progress-form .form-control,
        .tj-payment-form .form-control {
            min-height: 40px;
            border-color: #d2deeb;
            border-radius: 8px
        }

        .tj-primary {
            border-color: var(--tj-blue);
            color: #fff;
            background: var(--tj-blue)
        }

        .tj-success {
            border-color: #15945c;
            color: #fff;
            background: linear-gradient(135deg, #1daa6a, #087747)
        }

        .tj-payment-summary {
            display: flex;
            justify-content: space-between;
            gap: 8px;
            margin-bottom: 9px;
            color: #52677f;
            font-size: .7rem
        }

        .tj-payment-summary strong {
            color: var(--tj-navy)
        }

        .tj-payment-form {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 8px
        }

        .tj-notifications {
            margin: 0 15px 15px;
            border-top: 1px dashed #dce5ef
        }

        .tj-notifications summary {
            padding: 11px 0 0;
            color: #718198;
            font-size: .68rem;
            cursor: pointer
        }

        .tj-notification-list {
            padding-top: 8px
        }

        .tj-notification-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding: 7px 9px;
            margin-top: 5px;
            border-radius: 8px;
            background: #f4f7fa;
            font-size: .67rem
        }

        .tj-empty {
            padding: 48px 20px;
            color: var(--tj-muted);
            text-align: center
        }

        .tj-empty i {
            display: block;
            margin-bottom: 10px;
            color: #9fb1c5;
            font-size: 2rem
        }

        .tj-pagination {
            padding: 12px 15px;
            border-top: 1px solid #e8eef5
        }

        @media(max-width:992px) {
            .tj-stats {
                grid-template-columns: repeat(2, minmax(0, 1fr))
            }

            .tj-card-body {
                grid-template-columns: 1fr
            }

            .tj-progress-form {
                grid-template-columns: 1fr 1fr
            }

            .tj-progress-form .tj-button {
                grid-column: 1/-1
            }
        }

        @media(max-width:767px) {
            .tj-shell {
                width: min(100% - 20px, 1460px);
                padding-top: 18px
            }

            .tj-head {
                align-items: flex-start;
                flex-direction: column
            }

            .tj-head>.tj-button {
                width: 100%
            }

            .tj-search-row {
                grid-template-columns: 1fr
            }

            .tj-filter-grid {
                grid-template-columns: 1fr
            }

            .tj-info-grid {
                grid-template-columns: repeat(2, 1fr)
            }

            .tj-info:nth-child(2) {
                border-left: 0
            }

            .tj-info:nth-child(-n+2) {
                border-bottom: 1px solid #edf1f6
            }

            .tj-card-head {
                align-items: flex-start
            }

            .tj-progress-form,
            .tj-payment-form {
                grid-template-columns: 1fr
            }

            .tj-progress-form .tj-button {
                grid-column: auto
            }

            .tj-more-filters summary {
                width: 100%
            }
        }
    </style>

    <section class="main-content tailor-jobs-page" dir="rtl">
        <div class="tj-shell">
            <header class="tj-head">
                <div class="tj-title">
                    <h1><i class="fas fa-tasks ml-2 text-primary"></i>سلائی کے کام</h1>
                    <p>ہر آرڈر کا درزی، تاریخ اور موجودہ مرحلہ ایک جگہ دیکھیں۔</p>
                </div>
                <?php if(!$isTailor): ?>
                    <a href="<?php echo e(route('admin.Tailor.index')); ?>" class="tj-button"><i class="fas fa-user-cog"></i> درزیوں کی
                        فہرست</a>
                <?php endif; ?>
            </header>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle ml-1"></i><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger"><strong>تبدیلی محفوظ نہیں ہو سکی۔</strong>
                    <ul class="mb-0 mt-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="tj-stats">
                <?php $__currentLoopData = [['درزی مقرر ہونا باقی', $stats['unassigned'], 'fa-user-clock', ''], ['جاری کام', $stats['active'], 'fa-cut', ''], ['آج دینے ہیں', $stats['due_today'], 'fa-calendar-day', 'is-due'], ['دیر ہو گئی', $stats['overdue'], 'fa-exclamation-triangle', 'is-late'], ['تیار ہیں', $stats['ready'], 'fa-check-circle', 'is-ready']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $icon, $class]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tj-stat <?php echo e($class); ?>"><span class="tj-stat-icon"><i
                                class="fas <?php echo e($icon); ?>"></i></span>
                        <div><small><?php echo e($label); ?></small><strong><?php echo e($value); ?></strong></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if(!$isTailor): ?>
                <form method="GET" action="<?php echo e(route('admin.tailor-jobs.index')); ?>" class="tj-panel tj-search-form">
                    <div class="tj-search-row">
                        <div class="tj-field"><label for="q">کام تلاش کریں</label><input id="q"
                                name="q" class="form-control" maxlength="100" value="<?php echo e($filters['q'] ?? ''); ?>"
                                placeholder="گاہک کا نام، فون یا آرڈر نمبر"></div>
                        <button class="tj-button tj-filter-button" type="submit"><i class="fas fa-search"></i> تلاش
                            کریں</button>
                    </div>
                    <details class="tj-more-filters" <?php if($hasMoreFilters): ?> open <?php endif; ?>>
                        <summary class="tj-button"><i class="fas fa-sliders-h"></i> مزید فلٹر</summary>
                        <div class="tj-filter-grid">
                            <div class="tj-field"><label for="status">کام کا مرحلہ</label><select id="status"
                                    name="status" class="form-control" style="padding-top: 0px">
                                    <?php if($detailedWorkflow): ?>
                                        <option value="">تمام مراحل</option>
                                        <?php $__currentLoopData = \App\Models\Order::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status); ?>" <?php if(($filters['status'] ?? '') === $status): echo 'selected'; endif; ?>><?php echo e($statusLabels[$status]); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="">تمام حالتیں</option>
                                        <option value="unassigned" <?php if(($filters['status'] ?? '') === 'unassigned'): echo 'selected'; endif; ?>>درزی مقرر ہونا باقی</option>
                                        <option value="workshop" <?php if(($filters['status'] ?? '') === 'workshop'): echo 'selected'; endif; ?>>کارخانے میں ہے</option>
                                        <option value="ready" <?php if(($filters['status'] ?? '') === 'ready'): echo 'selected'; endif; ?>>تیار ہے</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="tj-field"><label for="tailor_id">درزی</label><select id="tailor_id" name="tailor_id"
                                    class="form-control">
                                    <option value="">تمام درزی</option>
                                    <?php $__currentLoopData = $tailors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tailor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tailor->id); ?>" <?php if((int) ($filters['tailor_id'] ?? 0) === $tailor->id): echo 'selected'; endif; ?>>
                                            <?php echo e($tailor->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="tj-field"><label for="due">دینے کی تاریخ</label><select id="due"
                                    name="due" class="form-control">
                                    <option value="">تمام تاریخیں</option>
                                    <option value="today" <?php if(($filters['due'] ?? '') === 'today'): echo 'selected'; endif; ?>>آج دینے ہیں</option>
                                    <option value="overdue" <?php if(($filters['due'] ?? '') === 'overdue'): echo 'selected'; endif; ?>>دیر ہو گئی</option>
                                </select></div>
                            <div class="tj-field"><label for="from_date">شروع تاریخ</label><input id="from_date"
                                    type="date" name="from_date" value="<?php echo e($filters['from_date'] ?? ''); ?>"
                                    class="form-control"></div>
                            <div class="tj-field"><label for="to_date">آخری تاریخ</label><input id="to_date"
                                    type="date" name="to_date" value="<?php echo e($filters['to_date'] ?? ''); ?>"
                                    class="form-control"></div>
                            <div class="tj-field"><label for="per_page">ایک صفحے پر</label><select id="per_page"
                                    name="per_page" class="form-control">
                                    <?php $__currentLoopData = [15, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($size); ?>" <?php if((int) ($filters['per_page'] ?? 25) === $size): echo 'selected'; endif; ?>>
                                            <?php echo e($size); ?> کام</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <a class="tj-filter-reset" href="<?php echo e(route('admin.tailor-jobs.index')); ?>"><i
                                class="fas fa-times ml-1"></i>تمام فلٹر ختم کریں</a>
                    </details>
                </form>
            <?php endif; ?>

            <div class="tj-system-note"><i class="fas fa-info-circle"></i>گاہک کی اطلاع ابھی اندرونی ریکارڈ میں محفوظ ہوتی
                ہے۔ SMS یا واٹس ایپ فراہم کنندہ منسلک نہیں ہے۔</div>

            <section class="tj-panel">
                <div class="tj-panel-head">
                    <h2>کام کی فہرست</h2><span>کل <?php echo e($orders->total()); ?> کام</span>
                </div>
                <div class="tj-list">
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $deadline = $order->returnDate ? \Carbon\Carbon::parse($order->returnDate) : null;
                            $overdue = $deadline && $deadline->isBefore(today()) && $order->status !== 'delivered';
                            $isDelivered = $order->status === 'delivered';
                            $isReady = $order->status === 'ready';
                            $nextStatusOptions = $detailedWorkflow
                                ? collect($order->nextStatusOptions())->reject(fn($option) => $isTailor && $option['value'] === 'delivered')
                                : collect();
                            $earned = $order->tailorAmountDue();
                            $deliveries = $order->notificationDeliveries->keyBy('stage');
                            $paymentErrors = $errors->getBag('tailorPayment' . $order->id);
                        ?>
                        <article class="tj-job-card <?php echo e($overdue ? 'is-overdue' : ''); ?>">
                            <div class="tj-card-head">
                                <div class="tj-order-main"><span class="tj-order-number">#<?php echo e($order->id); ?></span>
                                    <div>
                                        <h3><?php echo e($order->customers->name ?? 'گاہک نمبر ' . $order->customerId); ?></h3>
                                        <small>آرڈر کی تاریخ: <?php echo e(optional($order->created_at)->format('d M Y')); ?></small>
                                    </div>
                                </div><span class="tj-status <?php echo e($overdue ? 'is-overdue' : ''); ?>"><i
                                        class="fas <?php echo e($overdue ? 'fa-exclamation-circle' : 'fa-circle'); ?>"></i><?php echo e($overdue ? 'دیر ہو گئی' : $statusLabels[$order->status] ?? $order->status); ?></span>
                            </div>
                            <div class="tj-info-grid">
                                <div class="tj-info"><small><i
                                            class="fas fa-user-cog ml-1"></i>درزی</small><strong><?php echo e($order->tailor->name ?? 'ابھی مقرر نہیں'); ?></strong>
                                </div>
                                <div class="tj-info"><small><i
                                            class="fas fa-tshirt ml-1"></i>سوٹ</small><strong><?php echo e($order->suitQuantity ?: 1); ?></strong>
                                </div>
                                <div class="tj-info"><small><i class="fas fa-calendar-alt ml-1"></i>دینے کی
                                        تاریخ</small><strong><?php echo e($deadline ? $deadline->format('d M Y') : 'مقرر نہیں'); ?></strong>
                                </div>
                                <div class="tj-info"><small><i class="fas fa-tasks ml-1"></i>موجودہ
                                        مرحلہ</small><strong><?php echo e($statusLabels[$order->status] ?? $order->status); ?></strong>
                                </div>
                            </div>
                            <?php if(!$isTailor && $order->status === 'unassigned'): ?>
                                <div class="tj-card-body" style="grid-template-columns:1fr">
                                    <div class="tj-action-box">
                                        <h4><i class="fas fa-user-check ml-1 text-primary"></i>دستیابی دیکھ کر درزی مقرر کریں</h4>
                                        <form method="POST" action="<?php echo e(route('admin.tailor-jobs.assign', $order)); ?>" class="tj-assignment-form">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <div class="tj-progress-form">
                                                <select name="tailor_id" class="form-control js-assignment-tailor" required aria-label="درزی منتخب کریں">
                                                    <option value="">درزی منتخب کریں</option>
                                                    <?php $__currentLoopData = $tailors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tailor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($tailor->id); ?>" <?php if($tailor->tailorsalary->isEmpty()): echo 'disabled'; endif; ?>><?php echo e($tailor->name); ?> — <?php echo e((int)($tailorWorkloads[$tailor->id] ?? 0)); ?> جاری کام<?php echo e($tailor->tailorsalary->isEmpty() ? ' — شرح موجود نہیں' : ''); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <select name="tailor_price" class="form-control js-assignment-rate" required aria-label="سلائی شرح منتخب کریں">
                                                    <option value="">پہلے درزی منتخب کریں</option>
                                                    <?php $__currentLoopData = $tailors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tailor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $tailor->tailorsalary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($rate->id); ?>-<?php echo e($rate->price); ?>" data-tailor="<?php echo e($tailor->id); ?>" hidden><?php echo e(number_format((float)$rate->price,2)); ?> — <?php echo e($rate->options?->Name ?: ($rate->type ?: 'عام سلائی')); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <button class="tj-button tj-primary" type="submit"><i class="fas fa-check"></i> درزی مقرر کریں</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                            <div class="tj-card-body">
                                <div class="tj-action-box">
                                    <h4><i class="fas fa-exchange-alt ml-1 text-primary"></i>کام کی حالت</h4>
                                    <?php if($detailedWorkflow && $nextStatusOptions->isNotEmpty()): ?>
                                        <form class="tj-progress-form" method="POST" action="<?php echo e($isTailor ? route('tailor.jobs.status', $order) : route('admin.tailor-jobs.status', $order)); ?>"
                                            data-offline-command="order.status.change" data-order-id="<?php echo e($order->id); ?>" data-base-status="<?php echo e($order->status); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <select name="status" class="form-control" required>
                                                <?php $__currentLoopData = $nextStatusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nextStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($nextStatus['value']); ?>"><?php echo e($nextStatus['label']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button class="tj-button tj-primary" type="submit"><i class="fas fa-check"></i> مرحلہ بدلیں</button>
                                        </form>
                                    <?php elseif(! $detailedWorkflow && ! $isDelivered): ?>
                                        <form class="tj-progress-form" method="POST"
                                            action="<?php echo e($isTailor ? route('tailor.order.status') : route('admin.order.status')); ?>"
                                            data-offline-command="order.status.change" data-order-id="<?php echo e($order->id); ?>" data-base-status="<?php echo e($order->status); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                                            <select name="order_status" class="form-control" required>
                                                <option value="start" <?php if(! $isReady): echo 'selected'; endif; ?>>کارخانے میں ہے</option>
                                                <option value="complete" <?php if($isReady): echo 'selected'; endif; ?>>تیار ہے</option>
                                            </select>
                                            <button class="tj-button tj-primary" type="submit"><i class="fas fa-check"></i> حالت بدلیں</button>
                                        </form>
                                        <?php if($isReady && ! $isTailor): ?>
                                            <form class="mt-2" method="POST" action="<?php echo e(route('admin.order.status')); ?>"
                                                data-offline-command="order.status.change" data-order-id="<?php echo e($order->id); ?>" data-base-status="<?php echo e($order->status); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                                                <button class="tj-button tj-success" type="submit" name="order_status" value="deliver"><i class="fas fa-handshake"></i> گاہک کے حوالے کریں</button>
                                            </form>
                                        <?php endif; ?>
                                    <?php else: ?><span class="text-muted small"><i
                                                class="fas fa-check-circle ml-1 text-success"></i>یہ کام مکمل ہو چکا
                                            ہے۔</span>
                                    <?php endif; ?>
                                    <?php if(!$isTailor): ?>
                                        <a class="tj-button mt-2"
                                            href="<?php echo e(route('admin.orders.workforce.index', $order)); ?>"><i
                                                class="fas fa-users-cog"></i> کاریگر اور کام</a>
                                    <?php endif; ?>
                                </div>
                                <?php if(!$isTailor): ?>
                                    <div class="tj-action-box">
                                        <h4><i class="fas fa-wallet ml-1 text-success"></i>درزی کی ادائیگی</h4>
                                        <div class="tj-payment-summary"><span>کل اجرت <strong>روپے
                                                    <?php echo e(number_format($earned, 2)); ?></strong></span><span><?php echo e($statusLabels[$order->tailor_payment_status] ?? $order->tailor_payment_status); ?></span>
                                        </div>
                                        <form class="tj-payment-form" method="POST"
                                            action="<?php echo e(route('admin.tailor-jobs.payment', $order)); ?>"><?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?><input type="number" name="paid_amount"
                                                class="form-control <?php echo e($paymentErrors->has('paid_amount') ? 'is-invalid' : ''); ?>"
                                                min="<?php echo e((float) $order->tailor_paid_amount); ?>" max="<?php echo e($earned); ?>"
                                                step="0.01" value="<?php echo e((float) $order->tailor_paid_amount); ?>"
                                                aria-label="کل ادا شدہ رقم"
                                                aria-describedby="tailor-payment-error-<?php echo e($order->id); ?>"><button
                                                class="tj-button" type="submit"><i class="fas fa-save"></i> رقم محفوظ
                                                کریں</button></form>
                                        <?php if($paymentErrors->has('paid_amount')): ?>
                                            <div id="tailor-payment-error-<?php echo e($order->id); ?>"
                                                class="text-danger small mt-1" role="alert">
                                                <?php echo e($paymentErrors->first('paid_amount')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <details class="tj-notifications">
                                <summary><i class="fas fa-bell ml-1"></i>گاہک کی اندرونی اطلاع دیکھیں</summary>
                                <div class="tj-notification-list">
                                    <?php $__currentLoopData = \App\Services\OrderLifecycleNotificationService::NOTIFIABLE_STAGES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php ($delivery = $deliveries->get($stage)); ?>
                                        <?php if($delivery): ?>
                                            <div class="tj-notification-item"><span><?php echo e($statusLabels[$stage] ?? $stage); ?>:
                                                    <?php echo e($statusLabels[$delivery->status] ?? $delivery->status); ?></span>
                                                <?php if(!$isTailor && in_array($delivery->status, ['failed', 'skipped'], true)): ?>
                                                    <form method="POST"
                                                        action="<?php echo e(route('admin.tailor-jobs.notifications.retry', [$order, $delivery])); ?>">
                                                        <?php echo csrf_field(); ?><button type="submit" class="btn btn-link btn-sm p-0">دوبارہ
                                                            کوشش</button></form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($deliveries->isEmpty()): ?>
                                        <div class="text-muted small">ابھی کوئی اندرونی اطلاع درج نہیں ہوئی۔</div>
                                    <?php endif; ?>
                                </div>
                            </details>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="tj-empty"><i class="fas fa-inbox"></i><strong>کوئی کام نہیں ملا</strong>
                            <div>تلاش یا فلٹر تبدیل کرکے دوبارہ دیکھیں۔</div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if($orders->hasPages()): ?>
                    <div class="tj-pagination"><?php echo e($orders->links()); ?></div>
                <?php endif; ?>
            </section>
        </div>
    </section>
    <script>
        document.addEventListener('change', function (event) {
            if (!event.target.matches('.js-assignment-tailor')) return;
            const form = event.target.closest('.tj-assignment-form');
            const rates = form.querySelector('.js-assignment-rate');
            const tailorId = event.target.value;
            rates.value = '';
            rates.querySelectorAll('option[data-tailor]').forEach(function (option) {
                option.hidden = option.dataset.tailor !== tailorId;
            });
            const firstRate = rates.querySelector('option[data-tailor="' + tailorId + '"]');
            if (firstRate) firstRate.selected = true;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/tailor-jobs/index.blade.php ENDPATH**/ ?>