<?php if($measurementFields->isNotEmpty()): ?>
<?php ($embedded = $embedded ?? false); ?>
<?php if (! ($embedded)): ?>
<div class="card border-primary mb-4" dir="rtl">
    <div class="card-header bg-light d-flex justify-content-between align-items-center">
        <div>
            <strong>اضافی پیمائش</strong>
        </div>
        <?php if(Auth::user()->hasBusinessPermission('tailoring.configuration')): ?>
            <a href="<?php echo e(route('admin.measurement-fields.index')); ?>" class="btn btn-sm btn-outline-primary">خانے ترتیب دیں</a>
        <?php endif; ?>
    </div>
    <div class="card-body"><div class="form-row">
<?php endif; ?>
        <?php $__currentLoopData = $measurementFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($value = old('custom_measurements.'.$field->id, $measurementValues->get($field->id))); ?>
            <div class="form-group <?php echo e($embedded ? 'edit-field mb-0' : 'col-md-6'); ?>" data-measurement-field="custom.<?php echo e($field->id); ?>">
                <label for="custom_measurement_<?php echo e($field->id); ?>"><?php echo e($field->label); ?> <?php if($field->unit && $field->unit !== 'none'): ?><small class="text-muted">(<?php echo e($field->unit === 'inch' ? 'انچ' : 'سینٹی میٹر'); ?>)</small><?php endif; ?> <?php if($field->is_required): ?><span class="text-danger">*</span><?php endif; ?></label>
                <?php if($field->field_type === 'select'): ?>
                    <select class="form-control" id="custom_measurement_<?php echo e($field->id); ?>" name="custom_measurements[<?php echo e($field->id); ?>]" <?php if($field->is_required): echo 'required'; endif; ?>>
                        <option value="">منتخب کریں</option>
                        <?php $__currentLoopData = $field->options ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($option); ?>" <?php if((string) $value === (string) $option): echo 'selected'; endif; ?>><?php echo e($option); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <input class="form-control" id="custom_measurement_<?php echo e($field->id); ?>" name="custom_measurements[<?php echo e($field->id); ?>]" value="<?php echo e($value); ?>" type="<?php echo e($field->field_type === 'number' ? 'number' : 'text'); ?>" <?php if($field->field_type === 'number'): ?> step="0.01" min="0" <?php endif; ?> <?php if($field->is_required): echo 'required'; endif; ?>>
                <?php endif; ?>
                <?php $__errorArgs = ['custom_measurements.'.$field->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if (! ($embedded)): ?>
    </div></div>
</div>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/customer/partials/custom-measurements.blade.php ENDPATH**/ ?>