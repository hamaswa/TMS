<?php $__env->startSection('content'); ?>
<section class="main-content team-page" dir="rtl"><div class="container-fluid py-4 px-lg-5">
    <?php echo $__env->make('team.partials.workspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="card team-card"><div class="card-body p-4 p-lg-5">
        <?php ($roleUsersCount = $role->users()->count()); ?>
        <div class="mb-4"><span class="badge badge-light text-primary mb-2">رول میں ترمیم</span><h1 class="h3 font-weight-bold mb-1"><?php echo e($role->name); ?></h1><p class="text-muted mb-0">محفوظ کرنے کے بعد اس رول کے <?php echo e($roleUsersCount); ?> <?php echo e($roleUsersCount === 1 ? 'ملازم' : 'ملازمین'); ?> کی رسائی فوراً تبدیل ہوگی۔</p></div>
        <?php if($errors->any()): ?><div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
        <form method="POST" action="<?php echo e(route('admin.team.roles.update', $role)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="form-group" style="max-width:520px"><label class="font-weight-bold" for="edit-role-name">رول کا نام</label><input id="edit-role-name" class="form-control form-control-lg" name="name" value="<?php echo e(old('name', $role->name)); ?>" required></div>
            <?php echo $__env->make('team.partials.permission-selector', ['selectorId' => 'edit-role-permissions', 'selectedPermissions' => old('permissions', $role->permissions), 'roleNameTarget' => '#edit-role-name'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="d-flex justify-content-end mt-3"><a class="btn btn-outline-secondary btn-lg ml-2" href="<?php echo e(route('admin.team.roles.index')); ?>">منسوخ کریں</a><button class="btn btn-primary btn-lg px-4">تبدیلی محفوظ کریں</button></div>
        </form>
    </div></div>
</div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/team/role-edit.blade.php ENDPATH**/ ?>