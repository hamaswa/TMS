<?php $__env->startSection('content'); ?>
<section class="main-content"><div class="container-fluid px-3 px-md-4 py-4" style="max-width:1100px">
    <div class="mb-4"><h1 class="h3 mb-1">سبسکرپشن اور ادائیگی</h1><p class="text-muted mb-0">اپنی موجودہ مدت، بقایا رقم اور سپر ایڈمن کے درج کردہ ادائیگی ریکارڈ دیکھیں۔</p></div>
    <?php if($currentSubscription): ?>
        <?php ($state=$currentSubscription->state()); ?>
        <div class="card mb-4 border-<?php echo e(['active'=>'success','expiring'=>'warning','expired'=>'danger'][$state] ?? 'secondary'); ?>"><div class="card-body">
            <div class="d-flex flex-wrap justify-content-between align-items-start">
                <div><span class="badge badge-<?php echo e(['active'=>'success','expiring'=>'warning','expired'=>'danger'][$state] ?? 'secondary'); ?> mb-2"><?php echo e(['active'=>'فعال','expiring'=>'جلد ختم ہوگی','expired'=>'میعاد ختم'][$state] ?? $state); ?></span><h2 class="h4"><?php echo e($currentSubscription->plan_name); ?></h2><p class="mb-0"><?php echo e($currentSubscription->starts_on->format('d-m-Y')); ?> تا <?php echo e($currentSubscription->ends_on->format('d-m-Y')); ?></p></div>
                <div class="text-left mt-3 mt-md-0"><div class="small text-muted">بقایا رقم</div><div class="h3 mb-0">روپے <?php echo e(number_format($currentSubscription->balanceDue(),2)); ?></div></div>
            </div>
            <?php if($state==='expiring'): ?><div class="alert alert-warning mt-3 mb-0">آپ کی سبسکرپشن <?php echo e($currentSubscription->daysRemaining()); ?> دن میں ختم ہوگی۔ تجدید کے لیے سپر ایڈمن سے رابطہ کریں۔</div><?php endif; ?>
            <?php if($state==='expired'): ?><div class="alert alert-danger mt-3 mb-0">آپ کی سبسکرپشن کی میعاد ختم ہو چکی ہے۔ آپ کا کاروباری ڈیٹا محفوظ ہے؛ تجدید کے لیے سپر ایڈمن سے رابطہ کریں۔</div><?php endif; ?>
        </div></div>
    <?php else: ?>
        <div class="alert alert-info">ابھی آپ کے اکاؤنٹ کے لیے سبسکرپشن مدت مقرر نہیں کی گئی۔ اکاؤنٹ اور کاروباری ڈیٹا معمول کے مطابق محفوظ ہیں۔</div>
    <?php endif; ?>
    <div class="card"><div class="card-header bg-white"><h2 class="h5 mb-0">سبسکرپشن اور ادائیگی کی تاریخ</h2></div><div class="table-responsive"><table class="table mb-0">
        <thead><tr><th>مدت</th><th>فیس</th><th>وصول شدہ</th><th>بقایا</th><th>حالت</th></tr></thead>
        <tbody><?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr>
            <td><?php echo e($subscription->starts_on->format('d-m-Y')); ?> تا <?php echo e($subscription->ends_on->format('d-m-Y')); ?><br><small><?php echo e($subscription->plan_name); ?></small></td>
            <td>روپے <?php echo e(number_format((float)$subscription->fee,2)); ?></td><td>روپے <?php echo e(number_format($subscription->amountPaid(),2)); ?></td><td>روپے <?php echo e(number_format($subscription->balanceDue(),2)); ?></td>
            <td><?php if($subscription->cancelled_at): ?><span class="badge badge-secondary">منسوخ</span><?php else: ?><span class="badge badge-<?php echo e(['active'=>'success','expiring'=>'warning','expired'=>'danger'][$subscription->state()] ?? 'secondary'); ?>"><?php echo e(['active'=>'فعال','expiring'=>'جلد ختم ہوگی','expired'=>'میعاد ختم'][$subscription->state()] ?? $subscription->state()); ?></span><?php endif; ?></td>
        </tr>
        <?php if($subscription->payments->isNotEmpty()): ?><tr><td colspan="5" class="bg-light"><strong>ادائیگیاں:</strong> <?php $__currentLoopData = $subscription->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="d-inline-block ml-3 <?php echo e($payment->reversed_at?'text-muted':''); ?>">روپے <?php echo e(number_format((float)$payment->amount,2)); ?> · <?php echo e($payment->paid_on->format('d-m-Y')); ?> · <?php echo e(\App\Models\SubscriptionPayment::URDU_METHODS[$payment->payment_method] ?? $payment->payment_method); ?> <?php if($payment->reversed_at): ?>(واپس/منسوخ)<?php endif; ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td></tr><?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5" class="text-center text-muted py-5">ابھی کوئی سبسکرپشن ریکارڈ نہیں۔</td></tr><?php endif; ?></tbody>
    </table></div></div>
</div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/subscriptions/client.blade.php ENDPATH**/ ?>