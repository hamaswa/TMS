<?php $__env->startPush('styles'); ?>
<style>
    @media (max-width: 767.98px) {
        .customer-account-table,
        .customer-account-table tbody,
        .customer-account-table tr,
        .customer-account-table td {
            display: block;
            width: 100%;
        }
        .customer-account-table thead {
            display: none;
        }
        .customer-account-table tr {
            border: 1px solid #e3e8ee;
            border-radius: .65rem;
            margin-bottom: 1rem;
            padding: .45rem .75rem;
            background: #fff;
        }
        .customer-account-table td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            border-top: 1px solid #eef1f4;
            padding: .7rem 0;
            text-align: left;
        }
        .customer-account-table td:first-child {
            border-top: 0;
        }
        .customer-account-table td::before {
            content: attr(data-label);
            flex: 0 0 38%;
            color: #6c757d;
            font-weight: 700;
            text-align: right;
        }
        .customer-account-table .customer-account-actions {
            display: grid;
            grid-template-columns: 1fr;
            gap: .5rem;
        }
        .customer-account-table .customer-account-actions::before {
            display: none;
        }
        .customer-account-table .customer-account-actions .btn {
            width: 100%;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="main-content">
    <div class="container py-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1">گاہکوں کے مشترکہ کھاتے</h1>
                <p class="text-muted mb-0">ٹیلرنگ اور کپڑے کی دکان کا مجموعی بقایا اور ادائیگی ایک جگہ دیکھیں۔</p>
            </div>
            <?php if(Auth::user()->hasBusinessPermission('finance.view')): ?>
                <a class="btn btn-outline-primary mt-2 mt-md-0" href="<?php echo e(route('admin.financial-reports.index')); ?>">
                    <i class="fas fa-chart-line ml-1" aria-hidden="true"></i> مالیاتی ڈیش بورڈ
                </a>
            <?php endif; ?>
        </div>

        <?php if(Session::has('insert')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(Session::get('insert')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('balanceError')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(Session::get('balanceError')); ?></div>
        <?php endif; ?>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 js-sortable-table customer-account-table">
                        <thead>
                            <tr>
                                <th scope="col">گاہک</th>
                                <th scope="col">فون نمبر</th>
                                <th scope="col">مجموعی بقایا</th>
                                <th scope="col" class="no-sort">عمل</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="font-weight-bold" data-label="گاہک"><?php echo e($customer->name); ?></td>
                                    <td dir="ltr" data-label="فون نمبر"><?php echo e($customer->phone_number1); ?></td>
                                    <td data-label="مجموعی بقایا">روپے <?php echo e(number_format((float) $customer->current_balance, 2)); ?></td>
                                    <td class="customer-account-actions" data-label="عمل">
                                        <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.customers.statement', $customer)); ?>">
                                            پروفائل / کھاتہ
                                        </a>
                                        <?php if((float) $customer->current_balance > 0): ?>
                                            <button
                                                type="button"
                                                class="btn btn-sm btn-primary"
                                                data-toggle="modal"
                                                data-target="#customerPaymentModal"
                                                data-customer-id="<?php echo e($customer->id); ?>"
                                                data-customer-name="<?php echo e($customer->name); ?>"
                                                data-customer-balance="<?php echo e((float) $customer->current_balance); ?>"
                                            >
                                                ادائیگی درج کریں
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="text-center text-muted py-5">ابھی کوئی گاہک موجود نہیں۔</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="customerPaymentModal" tabindex="-1" role="dialog" aria-labelledby="customerPaymentTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('admin.customer-payments.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="customer_id" id="account_customer_id">
                <input type="hidden" name="return_to_accounts" value="1">
                <div class="modal-header">
                    <h2 class="modal-title h5" id="customerPaymentTitle">گاہک کی ادائیگی درج کریں</h2>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="بند کریں"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3">
                        <strong id="account_customer_name"></strong>
                        <span class="text-muted"> — موجودہ بقایا: روپے <span id="account_customer_balance"></span></span>
                    </p>
                    <div class="form-group">
                        <label for="account_payment_amount">وصول شدہ رقم</label>
                        <input id="account_payment_amount" type="number" name="DirectPayment" min="0.01" step="0.01" class="form-control" required>
                    </div>
                    <?php echo $__env->make('components.payment-method-fields', ['prefix' => 'account_payment'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <div class="form-group">
                        <label for="account_payment_date">ادائیگی کی تاریخ</label>
                        <input id="account_payment_date" type="date" name="paid_on" value="<?php echo e(now()->toDateString()); ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="account_payment_comment">نوٹ <small class="text-muted">(اختیاری)</small></label>
                        <textarea id="account_payment_comment" name="comment" rows="3" maxlength="1000" class="form-control" placeholder="مثلاً نقد ادائیگی"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-dismiss="modal">منسوخ کریں</button>
                    <button type="submit" class="btn btn-primary">ادائیگی محفوظ کریں</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $('#customerPaymentModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var balance = Number(button.data('customer-balance') || 0);
        $('#account_customer_id').val(button.data('customer-id'));
        $('#account_customer_name').text(button.data('customer-name'));
        $('#account_customer_balance').text(balance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
        $('#account_payment_amount').attr('max', balance).val('');
        $('#account_payment_comment').val('');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/customer/accounts.blade.php ENDPATH**/ ?>