<?php echo $__env->make('inc/header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('components.subscription-alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if(session('error')): ?>
    <div class="main-content px-3 px-md-4 pt-3" role="alert" aria-live="polite">
        <div class="alert alert-danger mb-0"><?php echo e(session('error')); ?></div>
    </div>
<?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('inc/footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/main.blade.php ENDPATH**/ ?>