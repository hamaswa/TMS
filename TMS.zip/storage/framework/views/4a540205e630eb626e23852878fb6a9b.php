<div class="row">
    <div class="col-12 mb-3">
        <div class="field-group">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div><h3 class="h6 font-weight-bold mb-1">پیمائش کے خانے</h3><small class="text-muted">سسٹم اور اضافی پیمائش ایک ہی فہرست میں</small></div>
                <span class="badge badge-light"><?php echo e(count($systemFields) + $customFields->count()); ?></span>
            </div>
            <div class="field-options">
                <?php $__currentLoopData = $systemFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="field-choice" for="<?php echo e($prefix); ?>-system-<?php echo e($key); ?>"><input id="<?php echo e($prefix); ?>-system-<?php echo e($key); ?>" type="checkbox" name="system_fields[]" value="<?php echo e($key); ?>" <?php if(in_array($key, $selectedSystem, true)): echo 'checked'; endif; ?>><span><strong><?php echo e($meta['label']); ?></strong><small><?php echo e($meta['unit'] === 'inch' ? 'انچ' : $meta['unit']); ?></small></span></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $customFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="field-choice" for="<?php echo e($prefix); ?>-custom-<?php echo e($field->id); ?>"><input id="<?php echo e($prefix); ?>-custom-<?php echo e($field->id); ?>" type="checkbox" name="custom_field_ids[]" value="<?php echo e($field->id); ?>" <?php if(in_array($field->id, array_map('intval', $selectedCustom), true)): echo 'checked'; endif; ?>><span><strong><?php echo e($field->label); ?></strong><small><?php echo e($field->unit === 'inch' ? 'انچ' : ($field->unit === 'cm' ? 'سینٹی میٹر' : 'بغیر اکائی')); ?></small></span></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/measurement-templates/partials/fields.blade.php ENDPATH**/ ?>