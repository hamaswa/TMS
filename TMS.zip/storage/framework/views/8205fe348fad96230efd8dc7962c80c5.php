<label class="sr-only" for="measurement-profile-select">محفوظ ناپ منتخب کریں</label>
<select id="measurement-profile-select" class="form-control" style="height:50px" name="sub_id">
    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <option value="<?php echo e($profile->id); ?>" data-serial="<?php echo e($profile->id); ?>" data-name="<?php echo e($profile->name); ?>">
            #<?php echo e($profile->id); ?> — <?php echo e($profile->name); ?> — <?php echo e($profile->phone_number1); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <option value="">کوئی محفوظ ناپ نہیں ملا</option>
    <?php endif; ?>
</select>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/order/partials/measurement-profile-select.blade.php ENDPATH**/ ?>