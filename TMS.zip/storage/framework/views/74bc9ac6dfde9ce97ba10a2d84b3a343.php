<?php $__env->startSection('content'); ?>
    <style>
        span {
            font-size: 20px;
        }
    </style>
    <section class="main-content">
        <div class="container">

            <div class="card col-sm-10 mx-auto">
                <?php echo $__env->make('inc.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <h1 class="h4 mb-4 text-right">روزانہ اخراجات تبدیل کریں</h1>
                <form id="cc-form__addCustomerForm" class="add-customer-form" method="post"
                    action="<?php echo e(route('admin.dailyexpense.update',['id'=>$data->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">اخراجات کا عنوان</span>
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="name[]" value="<?php echo e($data->Expense_name); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">اخراجات کی رقم</span>
                                </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="rupee[]" value="<?php echo e($data->Expense_payment); ?>">
                                    <?php $__errorArgs = ['rupee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="clonedFields"></div>

                    <div class="form-group col-md-8 mx-auto row">
                        <div class="button-group">
                            <button type="submit" class="btn btn-blue mr-3">محفوظ کریں</button>
                        </div>
                        <div class="button-group">
                            <button type="button" class="btn btn-blue mr-3" onclick="cloneFields()">مزید شامل
                                کریں۔</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script>
    function cloneFields() {
        var originalFields = document.querySelectorAll('.form-group');
        var clonedFields = originalFields[0].cloneNode(true); // Cloning the first set of fields
        clearInputValues(clonedFields);
        var clonedFields2 = originalFields[1].cloneNode(true); // Cloning the second set of fields
        clearInputValues(clonedFields2);
        document.getElementById('clonedFields').appendChild(clonedFields);
        document.getElementById('clonedFields').appendChild(clonedFields2);
    }

    function clearInputValues(element) {
        // Select all input elements within the provided element
        var inputs = element.querySelectorAll('input');

        // Loop through each input element and clear its value
        inputs.forEach(function(input) {
            input.value = '';
        });
    }
</script>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/DailyExpenses/edit.blade.php ENDPATH**/ ?>