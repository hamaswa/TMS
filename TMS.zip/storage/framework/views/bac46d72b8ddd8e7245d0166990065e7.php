<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="container">
            <div class="card col-sm-10 mx-auto">
                <div class="row">
                    <div class="col-md-12">
                        <?php echo $__env->make('inc.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div class="bg-white px-3 py-4">
                            <p class="text-right"><a href="<?php echo e(route('admin.design.create')); ?>" class="btn btn-primary">
                                    نئے
                                    ڈیزائن شامل کریں۔ +</a>
                            </p>

                            <div class="table-title  mb-4 mt-2">
                                <h5 class="text-right"> ڈیزائن کی فہرست</h5>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <!-- First Table -->
                                        <table class="table js-sortable-table cc-table-data-options-history"
                                            id="cc-table-data-options-history1">
                                            <thead>
                                                <tr>
                                                    <th scope="col" class="no-sort"> ڈیزائن کا عنوان </th>
                                                    <th scope="col" class="no-sort">ڈیزائن کی رقم</th>
                                                    <th scope="col" class="no-sort" colspan="2"
                                                        style="text-align: center;">عمل</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($design->design_name); ?></td>
                                                    <td><?php echo e($design->design_price); ?></td>
                                                    <td><a href="<?php echo e(route('admin.design.edit', ['id' => $design->id])); ?>"
                                                        class="btn btn-primary btn-sm">تبدیلی</a></td>
                                                <td><form action="<?php echo e(route('admin.design.delete', ['id' => $design->id])); ?>" method="POST" data-confirm="کیا آپ واقعی یہ ڈیزائن حذف کرنا چاہتے ہیں؟">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm">حذف کریں</button>
                                                    </form></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/Design/index.blade.php ENDPATH**/ ?>