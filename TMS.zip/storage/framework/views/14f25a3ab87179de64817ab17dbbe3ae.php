<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="container">

            <div class="card col-sm-10 mx-auto">
                <h2 class="mb-4 text-right">کپڑا شامل کریں۔</h2>
                <form id="cc-form__addCustomerForm" action="<?php echo e(route('admin.cloth.store')); ?>" class="add-customer-form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">کپڑے کی قسم</span> </label>
                                <div class="col-sm-9">
                                    <select name="cloth_type_id" class="form-control" required>
                                        <option value="">کپڑے کی قسم منتخب کریں۔</option>
                                        <?php $__currentLoopData = $cloth_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cloth_type->id); ?>"><?php echo e($cloth_type->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">کپڑے کی کمپنی</span> </label>
                                <div class="col-sm-9">
                                    <select name="cloth_brand_id" class="form-control" required>
                                        <option value="">کپڑے کی کمپنی منتخب کریں۔</option>
                                        <?php $__currentLoopData = $cloth_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth_brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cloth_brand->id); ?>"><?php echo e($cloth_brand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">رنگ</span> </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="color" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">لمبائی (میٹر) میں</span> </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="length" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english">ریٹ فی میٹر</span> </label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="price" required>
                                </div>
                            </div>
                        </div>
                    </div>


                    
                    <div class="form-group row">
                        <div class="col-md-8">
                            <div class="form-row m-0">
                                <label class="col-sm-3 col-form-label f"><span class="english"> کپڑے کی تصویر</span> </label>
                                <div class="col-sm-9">
                                    <input type="file" class="form-control" name="image" required>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-md-8 mx-auto row">
                        <div class="button-group">
                            <button type="submit" class="btn btn-blue mr-3">محفوظ کریں</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <script>
        $(document).ready(function() {
            $("#c_name").on('change', function() {
                var selectedOption = $(this).val();
                console.log(selectedOption);
                $.ajax({
                    url : '/admin/getId/?name=' + selectedOption,
                    type : 'GET',
                    success:function(response){
                        const nmbr = response.data.id;
                        $("#cloth_id").val(nmbr);
                    },
                    error: function(xhr,status,error){
                        console.log("Error : " + error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/stock/create.blade.php ENDPATH**/ ?>