<div class="col-md-3">
    <h4 class="mb-4 text-right">آپشن کی قسم</h4>

    <ul class="options-list">
        <?php $__currentLoopData = $OptionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OptionType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="text-right">
            <a class="option-link" href="<?php echo e(url('admin/Options/add',$OptionType->id)); ?>"><span class="optiontype"><?php echo e($OptionType->Name); ?></span></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH E:\ITLinked\2026\TMS\resources\views/inc/OptionType.blade.php ENDPATH**/ ?>