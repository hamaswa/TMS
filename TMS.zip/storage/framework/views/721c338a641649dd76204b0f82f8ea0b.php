<?php $__env->startSection('content'); ?>
<section class="main-content team-page" dir="rtl"><div class="container-fluid py-4 px-lg-5">
    <?php echo $__env->make('team.partials.workspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php
        $roleLimit = $business->subscriptionLimit('max_business_roles');
        $roleLimitReached = $roleLimit !== null && $business->roles->count() >= $roleLimit;
    ?>

    <div class="card team-card mb-4"><div class="card-body p-4 p-lg-5">
        <div class="row align-items-center mb-4">
            <div class="col-lg-8"><h2 class="h4 font-weight-bold mb-1">نیا رول بنائیں</h2><p class="text-muted mb-0">تیار رول سے آغاز کریں یا ہر اجازت خود منتخب کریں۔ ملازم کو صرف اس کے کام کی ضروری رسائی دیں۔</p></div>
            <div class="col-lg-4 text-lg-left mt-3 mt-lg-0"><span class="badge badge-info px-3 py-2">کم از کم رسائی زیادہ محفوظ ہے</span></div>
        </div>
        <?php if($roleLimit !== null): ?><div class="alert alert-light border">پلان حد: <?php echo e($business->roles->count()); ?> / <?php echo e($roleLimit); ?> رولز</div><?php endif; ?>
        <?php if($roleLimitReached): ?>
            <div class="alert alert-warning mb-0">موجودہ پلان میں مزید رول نہیں بنایا جا سکتا۔ پلان اپ گریڈ کے لیے سپر ایڈمن سے رابطہ کریں۔</div>
        <?php else: ?>
        <form method="POST" action="<?php echo e(route('admin.team.roles.store')); ?>"><?php echo csrf_field(); ?>
            <div class="form-group" style="max-width:520px"><label class="font-weight-bold" for="new-role-name">رول کا نام</label><input id="new-role-name" class="form-control form-control-lg" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e($business->tailoring_enabled && ! $business->clothing_enabled ? 'مثلاً آرڈر منیجر' : ($business->clothing_enabled && ! $business->tailoring_enabled ? 'مثلاً سیلز پرسن' : 'مثلاً برانچ منیجر')); ?>" required></div>
            <?php echo $__env->make('team.partials.permission-selector', ['selectorId' => 'new-role-permissions', 'selectedPermissions' => old('permissions', []), 'roleNameTarget' => '#new-role-name'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="d-flex justify-content-end mt-3"><button class="btn btn-primary btn-lg px-5"><i class="fas fa-user-shield ml-1"></i> رول محفوظ کریں</button></div>
        </form>
        <?php endif; ?>
    </div></div>

    <div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="h4 font-weight-bold mb-1">کاروباری رولز</h2><p class="text-muted mb-0">ترمیم سے اس رول کے تمام ملازمین کی رسائی تبدیل ہوگی۔</p></div><span class="badge badge-secondary px-3 py-2"><?php echo e($business->roles->count()); ?> رولز</span></div>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $business->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-xl-6 mb-3"><div class="card team-card h-100"><div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start"><div><h3 class="h5 font-weight-bold mb-1"><?php echo e($role->name); ?></h3><span class="text-muted small"><?php echo e($role->users_count); ?> ملازم · <?php echo e(count($role->permissions ?? [])); ?> اجازتیں</span></div><div class="d-flex"><a class="btn btn-sm btn-outline-primary ml-2" href="<?php echo e(route('admin.team.roles.edit', $role)); ?>">ترمیم</a><form method="POST" action="<?php echo e(route('admin.team.roles.destroy', $role)); ?>" data-confirm="کیا آپ یہ رول حذف کرنا چاہتے ہیں؟"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger" <?php echo e($role->users_count ? 'disabled' : ''); ?>>حذف</button></form></div></div>
                <div class="mt-3"><?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-light border mb-1"><?php echo e(\App\Models\BusinessRole::PERMISSIONS[$permission] ?? $permission); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
            </div></div></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12"><div class="card team-card"><div class="card-body text-center text-muted py-5">ابھی کوئی رول نہیں بنایا گیا۔ اوپر تیار رول منتخب کرکے آغاز کریں۔</div></div></div>
        <?php endif; ?>
    </div>
</div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/team/roles.blade.php ENDPATH**/ ?>