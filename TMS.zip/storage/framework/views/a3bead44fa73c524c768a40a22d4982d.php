<?php $__env->startPush('styles'); ?>
<?php echo $__env->make('purchases._styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<style>
    .purchase-show-header{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px}.purchase-show-meta{display:flex;align-items:center;gap:14px;padding:18px 20px;min-width:360px}.purchase-show-meta h1{font:800 1.35rem/1.25 Arial,sans-serif}.purchase-status-check{display:inline-grid;place-items:center;width:22px;height:22px;margin-left:5px;border-radius:50%;background:#19a95b;color:#fff}.purchase-show-actions{display:flex;gap:10px;flex-wrap:wrap}.purchase-show-actions .btn{min-height:44px;border-radius:8px;padding:9px 16px;font-weight:700}.purchase-detail-summary .purchase-stat{min-height:108px}.purchase-detail-card{margin-bottom:18px;overflow:hidden}.purchase-detail-title{display:flex;align-items:center;justify-content:space-between;padding:18px 20px;border-bottom:1px solid var(--purchase-line)}.purchase-detail-title h2{margin:0;color:#1769ef;font-size:1.12rem;font-weight:800}.purchase-item-table{margin:0}.purchase-item-table thead th,.purchase-history-table thead th{border:0;background:#f8fafd;color:#52627b;font-weight:800;white-space:nowrap}.purchase-item-table td,.purchase-item-table th{padding:14px 16px;vertical-align:middle;border-color:#edf1f6}.purchase-item-name strong{display:block;color:var(--purchase-ink)}.purchase-item-name small{color:var(--purchase-muted)}.purchase-quantity{font-weight:800}.purchase-quantity.is-received{color:#18a866}.purchase-quantity.is-returned{color:#db3f4d}.purchase-return-form{display:flex;min-width:205px}.purchase-return-form .form-control{min-height:38px;border-radius:7px 0 0 7px}.purchase-return-form .btn{white-space:nowrap;border-radius:0 7px 7px 0}.purchase-totals-strip{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:15px;margin:16px;padding:15px 18px;border:1px solid var(--purchase-line);border-radius:10px;background:#fbfcff}.purchase-totals-strip span{color:#52627b;font-weight:700}.purchase-totals-strip strong{margin-right:5px;color:var(--purchase-ink)}.purchase-totals-strip .total-primary strong{color:#1769ef}.purchase-totals-strip .total-success strong{color:#18a866}.purchase-totals-strip .total-danger strong{color:#db3f4d}.purchase-lower-grid{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(360px,.8fr);gap:18px}.purchase-form-panel,.purchase-history-card{padding:20px}.purchase-form-panel h2,.purchase-history-card h2{margin:0 0 18px;color:#1769ef;font-size:1.12rem;font-weight:800}.purchase-history-stack{display:grid;gap:18px}.purchase-history-card{padding:0;overflow:hidden}.purchase-history-card h2{padding:16px 18px;margin:0;border-bottom:1px solid var(--purchase-line)}.purchase-history-table{margin:0}.purchase-history-table td,.purchase-history-table th{padding:11px 14px;border-color:#edf1f6}.purchase-empty{padding:26px!important;color:#9ba8ba;text-align:center}.purchase-empty i{display:block;margin-bottom:8px;font-size:25px}.purchase-draft-notice{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:18px;padding:15px 18px}.purchase-draft-notice p{margin:0;color:#52627b}.purchase-draft-actions{display:flex;gap:8px;flex-shrink:0}
    @media print{.tms-sidebar,.tms-nav,.purchase-show-actions,.purchase-return-action,.purchase-draft-notice,.purchase-form-panel{display:none!important}body{padding:0!important}.purchase-page{padding:0;background:#fff}.purchase-shell{max-width:none}.purchase-panel,.purchase-stat{box-shadow:none!important}}
    @media(max-width:991.98px){.purchase-show-header{flex-direction:column}.purchase-show-meta{width:100%;min-width:0}.purchase-lower-grid{grid-template-columns:1fr}.purchase-totals-strip{grid-template-columns:repeat(2,1fr)}}
    @media(max-width:767.98px){.purchase-show-actions{width:100%}.purchase-show-actions .btn{flex:1}.purchase-item-table,.purchase-item-table tbody,.purchase-item-table tr,.purchase-item-table td{display:block;width:100%}.purchase-item-table thead{display:none}.purchase-item-table tr{width:calc(100% - 20px);margin:10px;border:1px solid var(--purchase-line);border-radius:10px;padding:7px}.purchase-item-table td{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:10px;border-top:1px solid #edf1f6}.purchase-item-table td:first-child{border-top:0}.purchase-item-table td::before{content:attr(data-label);color:var(--purchase-muted);font-weight:800}.purchase-item-table .purchase-return-action{display:block}.purchase-item-table .purchase-return-action::before{display:none}.purchase-return-form{width:100%}.purchase-totals-strip{grid-template-columns:1fr}.purchase-draft-notice{align-items:stretch;flex-direction:column}.purchase-draft-actions{flex-direction:column}}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $statusLabels = ['draft' => 'زیرِ تیاری', 'received' => 'وصول شدہ', 'cancelled' => 'منسوخ'];
    $statusLabel = $statusLabels[$purchase->status] ?? $purchase->status;
    $orderedQuantity = $purchase->items->sum('quantity');
    $receivedQuantity = $purchase->items->sum('received_quantity');
    $returnedQuantity = $purchase->items->sum('returned_quantity');
?>
<section class="main-content purchase-page" dir="rtl">
<div class="purchase-shell">
    <div class="purchase-breadcrumb mb-3"><a href="<?php echo e(route('admin.purchases.index')); ?>">خریداری</a><span class="mx-2">‹</span>خریداری کی فہرست<span class="mx-2">‹</span>خریداری کی تفصیل</div>

    <header class="purchase-show-header">
        <div class="purchase-panel purchase-show-meta">
            <div class="flex-grow-1"><h1 class="h3 mb-1"><?php echo e($purchase->purchase_number); ?></h1><div class="purchase-breadcrumb"><?php echo e($purchase->supplier->name); ?> <span class="mx-2">•</span> <?php echo e($purchase->purchase_date->format('d M Y')); ?></div></div>
            <span class="purchase-status purchase-status-<?php echo e($purchase->status); ?>"><?php if($purchase->status === 'received'): ?><span class="purchase-status-check"><i class="fas fa-check"></i></span><?php endif; ?><?php echo e($statusLabel); ?></span>
        </div>
        <div class="purchase-show-actions">
            <a href="<?php echo e(route('admin.purchases.create')); ?>" class="purchase-primary-btn"><i class="fas fa-plus"></i> نئی خریداری</a>
            <button type="button" class="btn btn-outline-secondary" onclick="window.print()"><i class="fas fa-print ml-1"></i> پرنٹ</button>
            <a href="<?php echo e(route('admin.purchases.index')); ?>" class="btn btn-outline-secondary"><i class="fas fa-arrow-right ml-1"></i> فہرست</a>
        </div>
    </header>

    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>

    <div class="purchase-stats purchase-detail-summary">
        <article class="purchase-stat"><div class="purchase-stat-copy"><small>حالت</small><strong><?php echo e($statusLabel); ?></strong></div><span class="purchase-stat-icon"><i class="fas fa-box-open"></i></span></article>
        <article class="purchase-stat"><div class="purchase-stat-copy"><small>کل رقم</small><strong>Rs. <?php echo e(number_format($purchase->total_amount, 2)); ?></strong></div><span class="purchase-stat-icon"><i class="fas fa-file-invoice-dollar"></i></span></article>
        <article class="purchase-stat"><div class="purchase-stat-copy"><small>ادائیگی</small><strong>Rs. <?php echo e(number_format($purchase->paid_amount, 2)); ?></strong></div><span class="purchase-stat-icon"><i class="fas fa-arrow-down"></i></span></article>
        <article class="purchase-stat"><div class="purchase-stat-copy"><small>بقایا ادائیگی</small><strong>Rs. <?php echo e(number_format($purchase->balance_amount, 2)); ?></strong></div><span class="purchase-stat-icon"><i class="fas fa-wallet"></i></span></article>
    </div>

    <?php if($purchase->status === 'draft'): ?>
        <div class="purchase-panel purchase-draft-notice"><p><i class="fas fa-info-circle text-primary ml-1"></i> مال وصول کرنے پر تمام آئٹمز اسٹاک میں شامل ہو جائیں گے۔</p><div class="purchase-draft-actions"><form method="POST" action="<?php echo e(route('admin.purchases.receive', $purchase)); ?>" data-confirm="کیا تمام مال وصول کر کے اسٹاک اپ ڈیٹ کرنا ہے؟" data-confirm-variant="success"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="btn btn-success">مال وصول کریں</button></form><form method="POST" action="<?php echo e(route('admin.purchases.cancel', $purchase)); ?>" data-confirm="کیا یہ خریداری منسوخ کرنا ہے؟"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="btn btn-outline-danger">منسوخ کریں</button></form></div></div>
    <?php endif; ?>

    <section class="purchase-panel purchase-detail-card">
        <div class="purchase-detail-title"><h2>آئٹمز کی تفصیل</h2><span class="purchase-breadcrumb">کل <?php echo e($purchase->items->count()); ?> آئٹمز</span></div>
        <div class="table-responsive"><table class="table purchase-item-table"><thead><tr><th>#</th><th>آئٹم</th><th>آرڈر شدہ</th><th>وصول شدہ</th><th>واپس شدہ</th><th>فی یونٹ قیمت</th><th>واپسی کے بعد رقم</th><?php if($purchase->status === 'received'): ?><th>عمل</th><?php endif; ?></tr></thead><tbody>
            <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-label="#"><?php echo e($loop->iteration); ?></td>
                    <td data-label="آئٹم" class="purchase-item-name"><strong><?php echo e($item->cloth->brand->name ?? 'برانڈ'); ?></strong><small><?php echo e($item->cloth->type->name ?? 'قسم'); ?> / <?php echo e($item->color); ?></small></td>
                    <td data-label="آرڈر شدہ"><span class="purchase-quantity"><?php echo e(number_format($item->quantity, 2)); ?> میٹر</span></td>
                    <td data-label="وصول شدہ"><span class="purchase-quantity is-received"><?php echo e(number_format($item->received_quantity, 2)); ?> میٹر</span></td>
                    <td data-label="واپس شدہ"><span class="purchase-quantity is-returned"><?php echo e(number_format($item->returned_quantity, 2)); ?> میٹر</span></td>
                    <td data-label="فی اکائی لاگت">روپے <?php echo e(number_format($item->unit_cost, 2)); ?></td>
                    <td data-label="واپسی کے بعد رقم">روپے <?php echo e(number_format((float) $item->line_total - ((float) $item->returned_quantity * (float) $item->unit_cost), 2)); ?></td>
                    <?php if($purchase->status === 'received'): ?>
                        <td class="purchase-return-action" data-label="مال واپس کریں">
                            <?php if((float) $item->received_quantity > (float) $item->returned_quantity): ?>
                                <form class="purchase-return-form" method="POST" action="<?php echo e(route('admin.purchases.return', $purchase)); ?>" data-confirm="کیا منتخب مقدار سپلائر کو واپس کر کے اسٹاک اور بقایا کم کرنا ہے؟"><?php echo csrf_field(); ?><input type="hidden" name="purchase_item_id" value="<?php echo e($item->id); ?>"><input type="hidden" name="return_date" value="<?php echo e(now()->toDateString()); ?>"><input type="number" name="quantity" step="0.01" min="0.01" max="<?php echo e((float) $item->received_quantity - (float) $item->returned_quantity); ?>" class="form-control" aria-label="واپسی کی مقدار میٹر میں" placeholder="میٹر" required><button class="btn btn-outline-danger">واپس کریں</button></form>
                            <?php else: ?><span class="text-muted">مکمل واپس شدہ</span><?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody></table></div>
        <div class="purchase-totals-strip"><span>کل آئٹمز:<strong><?php echo e($purchase->items->count()); ?></strong></span><span class="total-primary">آرڈر شدہ:<strong><?php echo e(number_format($orderedQuantity, 2)); ?> میٹر</strong></span><span class="total-success">وصول شدہ:<strong><?php echo e(number_format($receivedQuantity, 2)); ?> میٹر</strong></span><span class="total-danger">واپس شدہ:<strong><?php echo e(number_format($returnedQuantity, 2)); ?> میٹر</strong></span></div>
    </section>

    <div class="purchase-lower-grid">
        <div>
            <?php if($purchase->status === 'received' && (float) $purchase->balance_amount > 0): ?>
                <section class="purchase-panel purchase-form-panel">
                    <h2>سپلائر ادائیگی درج کریں</h2>
                    <form method="POST" action="<?php echo e(route('admin.purchases.payment', $purchase)); ?>"><?php echo csrf_field(); ?>
                        <div class="form-row"><div class="form-group col-md-6"><label>رقم</label><input type="number" name="amount" step="0.01" min="0.01" max="<?php echo e(max(0, (float) $purchase->balance_amount)); ?>" class="form-control" required></div><div class="form-group col-md-6"><label>تاریخ</label><input type="date" name="payment_date" value="<?php echo e(now()->toDateString()); ?>" class="form-control" required></div><div class="form-group col-md-6"><label>ادائیگی کا طریقہ</label><select name="payment_method" class="form-control" required><?php $__currentLoopData = \App\Support\PaymentMethods::LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>"><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div><div class="form-group col-md-6"><label>حوالہ / ٹرانزیکشن نمبر</label><input name="reference" maxlength="255" class="form-control" placeholder="حوالہ نمبر درج کریں"></div></div>
                        <button class="btn btn-success px-4"><i class="fas fa-check ml-1"></i> ادائیگی جمع کریں</button>
                    </form>
                </section>
            <?php else: ?>
                <section class="purchase-panel purchase-form-panel"><h2>خریداری کی معلومات</h2><div class="row"><div class="col-md-6 mb-3"><small class="text-muted d-block">سپلائر</small><strong><?php echo e($purchase->supplier->name); ?></strong></div><div class="col-md-6 mb-3"><small class="text-muted d-block">خریداری کی تاریخ</small><strong><?php echo e($purchase->purchase_date->format('d-m-Y')); ?></strong></div><div class="col-12"><small class="text-muted d-block">حوالہ</small><strong><?php echo e($purchase->reference ?: '—'); ?></strong></div></div></section>
            <?php endif; ?>
        </div>

        <div class="purchase-history-stack">
            <section class="purchase-panel purchase-history-card"><h2>واپسی کی تاریخ</h2><div class="table-responsive"><table class="table table-sm purchase-history-table"><thead><tr><th>#</th><th>تاریخ</th><th>واپس شدہ رقم</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $purchase->returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($return->return_number); ?></td><td><?php echo e($return->return_date->format('d-m-Y')); ?></td><td>روپے <?php echo e(number_format($return->total_amount, 2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3" class="purchase-empty"><i class="fas fa-inbox"></i>کوئی واپسی ریکارڈ موجود نہیں</td></tr><?php endif; ?></tbody></table></div></section>
            <section class="purchase-panel purchase-history-card"><h2>ادائیگیوں کی تاریخ</h2><div class="table-responsive"><table class="table table-sm purchase-history-table"><thead><tr><th>تاریخ</th><th>طریقہ</th><th>رقم</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $purchase->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($payment->payment_date->format('d-m-Y')); ?></td><td><?php echo e(\App\Support\PaymentMethods::LABELS[$payment->payment_method] ?? 'درج نہیں'); ?></td><td>روپے <?php echo e(number_format($payment->amount, 2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3" class="purchase-empty"><i class="fas fa-inbox"></i>کوئی ادائیگی ریکارڈ موجود نہیں</td></tr><?php endif; ?></tbody></table></div></section>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/purchases/show.blade.php ENDPATH**/ ?>