<?php $__env->startSection('content'); ?>
<section class="main-content">
    <div class="container">
         <div class="card">
        <h1 class="h4 mb-4 text-right">درزی کی معلومات تبدیل کریں</h1>
        <div class="row">


            <div class="col-md-12">
                <?php if(Session::has('insert')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('insert')); ?></div>
                <?php endif; ?>

                <?php if(Session::has('del')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('del')); ?></div>
                <?php endif; ?>

                <div class="bg-white px-3 py-4">
                    <div class="tab-content" id="v-pills-tabContent">
                        <div class="tab-pane fade show active" id="v-pills-sewing" role="tabpanel"
                            aria-labelledby="v-pills-sewing-tab">
                            <form id="cc-form__optionsForm" action="<?php echo e(url('admin/Tailor',$tailorData->id)); ?>"
                                method="post" class="cc-form__box">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <label>نام</label>
                                        <input type="text" class="form-control" name="name"
                                            value="<?php echo e($tailorData->name); ?>">
                                    </div>

                                    <div class="col-sm-6">
                                        <label>پاس ورڈ</label>
                                        <input type="password" class="form-control" name="password"
                                            autocomplete="new-password" minlength="6"
                                            placeholder="موجودہ پاس ورڈ برقرار رکھنے کے لیے خالی چھوڑ دیں">
                                    </div>


                                    <div class="col-sm-6">
                                        <label>نمبر</label>
                                        <input type="text" class="form-control" name="contact"
                                            value="<?php echo e($tailorData->phone_number1); ?>">
                                    </div>

                                    
                                    <div class="col-sm-6 mt-3">
                                        <button class="btn btn-warning mt-md-0">محفوظ کریں</button>
                                    </div>


                                </div>


                            </form>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/tailor/edit.blade.php ENDPATH**/ ?>