<div id="message">
<?php if(Session::has('insert')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('insert')); ?></div>
<?php endif; ?>

<?php if(Session::has('update')): ?>
    <div class="alert alert-warning"><?php echo e(Session::get('update')); ?></div>
<?php endif; ?>

<?php if(Session::has('delete')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('delete')); ?></div>
<?php endif; ?>
<?php if(Session::has('balanceError')): ?>
    <div class="alert alert-danger">
        <?php echo e(Session::get('balanceError')); ?>

    </div>
<?php endif; ?>
</div>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/inc/message.blade.php ENDPATH**/ ?>