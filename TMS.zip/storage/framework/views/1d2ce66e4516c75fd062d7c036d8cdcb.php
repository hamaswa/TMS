<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="container">
            <div class="card col-sm-10 mx-auto">
                <div class="row">
                    <div class="col-md-12">
                        <?php if(Session::has('insert')): ?>
                            <div class="alert alert-success"><?php echo e(Session::get('insert')); ?></div>
                        <?php endif; ?>

                        <?php if(Session::has('update')): ?>
                            <div class="alert alert-warning"><?php echo e(Session::get('update')); ?></div>
                        <?php endif; ?>

                        <?php if(Session::has('delete')): ?>
                            <div class="alert alert-danger"><?php echo e(Session::get('delete')); ?></div>
                        <?php endif; ?>

                        <div class="bg-white px-3 py-4">
                            <p class="text-right"><a href="<?php echo e(route('admin.clothtype.create')); ?>"
                                    class="btn btn-primary">کپڑے کی قسم شامل کریں +</a>
                            </p>
                            <div class="table-title  mb-4 mt-2">
                                <h5 class="text-right">کپڑے کی قسم کی فہرست</h5>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table js-sortable-table cc-table-data-options-history"
                                            id="cc-table-data-options-history">
                                            <thead>
                                                <tr>
                                                    <th scope="col" class="no-sort">#</th>
                                                    <th scope="col" class="no-sort">نام</th>
                                                    <th scope="col" class="no-sort">عمل</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $cloth_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td style="font-size: 18px;font-weight:600;"><?php echo e($loop->iteration); ?></td>
                                                        <td style="font-size: 18px;font-weight:600;"><?php echo e($cloth_type->name); ?></td>
                                                        <td class="d-flex justify-content-end">
                                                            <a href="<?php echo e(route('admin.clothtype.edit', $cloth_type->id)); ?>"
                                                                class=""><i class="fa fa-edit"
                                                                    aria-hidden="true"></i></a>
                                                            <form
                                                                action="<?php echo e(route('admin.clothtype.destroy', $cloth_type->id)); ?>"
                                                                method="POST" data-confirm="کیا آپ واقعی یہ کپڑے کی قسم حذف کرنا چاہتے ہیں؟">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('delete'); ?>
                                                                <button class="delete-tr btn btn-sm" type="submit"><i
                                                                        class="fa fa-trash-alt"
                                                                        aria-hidden="true"></i></button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/clothtype/index.blade.php ENDPATH**/ ?>