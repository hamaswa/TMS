<?php $__env->startSection('content'); ?>
<?php ($statusLabels=['assigned'=>'تفویض شدہ','in_progress'=>'جاری','completed'=>'مکمل','cancelled'=>'منسوخ']); ?>
<section class="main-content"><div class="container-fluid px-3 px-md-4 py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3"><div><a href="<?php echo e(route('admin.tailor-jobs.index')); ?>">← کام کی فہرست</a><h3 class="mt-2 mb-1">آرڈر #<?php echo e($order->id); ?> — کاریگر اور کام</h3><div class="text-muted">گاہک: <?php echo e($order->customers->name ?? 'نام موجود نہیں'); ?> · سوٹ: <?php echo e($order->suitQuantity ?: 1); ?></div></div><a class="btn btn-outline-primary" href="<?php echo e(route('admin.production-workers.index')); ?>">پروڈکشن ورکرز</a></div>
    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><strong>کام محفوظ نہیں ہو سکا۔</strong><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>

    <div class="row"><div class="col-lg-8 mb-4"><div class="card"><div class="card-header"><strong>تفویض شدہ کام</strong></div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>کام</th><th>ورکر</th><th>مقدار × شرح</th><th>کل اجرت</th><th>حالت</th><th>عمل</th></tr></thead><tbody>
        <?php $__empty_1 = true; $__currentLoopData = $order->workAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr>
            <td><?php echo e($assignment->workType->name ?? 'کام'); ?><?php if($assignment->legacy_key): ?><br><span class="badge badge-info">موجودہ ٹیلرنگ آرڈر</span><?php endif; ?></td>
            <td><a href="<?php echo e(route('admin.production-workers.show',$assignment->worker)); ?>"><?php echo e($assignment->worker->name ?? 'ورکر'); ?></a></td>
            <td><?php echo e(number_format((float)$assignment->quantity,2)); ?> × روپے <?php echo e(number_format((float)$assignment->rate,2)); ?></td>
            <td>روپے <?php echo e(number_format((float)$assignment->amount,2)); ?></td>
            <td><span class="badge badge-<?php echo e($assignment->status==='completed'?'success':($assignment->status==='cancelled'?'secondary':'warning')); ?>"><?php echo e($statusLabels[$assignment->status] ?? $assignment->status); ?></span></td>
            <td><?php if(!$assignment->legacy_key && in_array($assignment->status,['assigned','in_progress'])): ?><form method="POST" action="<?php echo e(route('admin.orders.workforce.status',[$order,$assignment])); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><div class="input-group input-group-sm"><select name="status" class="form-control"><?php if($assignment->status==='assigned'): ?><option value="in_progress">کام شروع</option><?php endif; ?><option value="completed">مکمل</option><option value="cancelled">منسوخ</option></select><div class="input-group-append"><button class="btn btn-outline-primary">محفوظ</button></div></div></form><?php elseif($assignment->legacy_key): ?><small class="text-muted">مرکزی آرڈر مراحل سے منسلک</small><?php else: ?>—<?php endif; ?></td>
        </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="text-center text-muted py-4">کوئی کام تفویض نہیں۔</td></tr><?php endif; ?>
    </tbody></table></div></div></div>
    <div class="col-lg-4 mb-4"><div class="card"><div class="card-header"><strong>اضافی کام تفویض کریں</strong></div><div class="card-body">
        <?php if($order->status==='delivered'): ?><div class="alert alert-info mb-0">یہ آرڈر حوالہ کیا جا چکا ہے، اس لیے نیا کام تفویض نہیں کیا جا سکتا۔</div><?php elseif($workers->isEmpty()): ?><div class="alert alert-warning">پہلے پروڈکشن ورکر اور اس کی اجرت بنائیں۔</div><a class="btn btn-primary" href="<?php echo e(route('admin.production-workers.create')); ?>">نیا ورکر</a><?php else: ?>
        <form method="POST" action="<?php echo e(route('admin.orders.workforce.store',$order)); ?>"><?php echo csrf_field(); ?>
            <div class="form-group"><label for="worker_id">ورکر</label><select id="worker_id" name="production_worker_id" class="form-control" required><option value="">منتخب کریں</option><?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($worker->id); ?>"><?php echo e($worker->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="form-group"><label for="work_type_id">کام اور فی عدد اجرت</label><select id="work_type_id" name="work_type_id" class="form-control" required disabled><option value="">پہلے ورکر منتخب کریں</option><?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php $__currentLoopData = $worker->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php ($plan=$worker->compensationPlans->firstWhere('work_type_id',$skill->id)); ?><?php if($plan && in_array($plan->method,['per_piece','hybrid']) && (float)$plan->rate>0): ?><option value="<?php echo e($skill->id); ?>" data-worker="<?php echo e($worker->id); ?>" hidden><?php echo e($skill->name); ?> — روپے <?php echo e(number_format((float)$plan->rate,2)); ?></option><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><small class="form-text text-muted">شرح اجرت کے اصول سے خود لی جائے گی اور بعد میں نہیں بدلے گی۔</small></div>
            <div class="form-group"><label for="quantity">مقدار</label><input id="quantity" type="number" name="quantity" min="0.001" step="0.001" class="form-control" value="<?php echo e(old('quantity',$order->suitQuantity ?: 1)); ?>" required></div>
            <div class="form-group"><label for="notes">کام کی ہدایت</label><textarea id="notes" name="notes" class="form-control" rows="3" maxlength="1000"></textarea></div>
            <button class="btn btn-primary" type="submit">کام تفویض کریں</button>
        </form><?php endif; ?>
    </div></div></div></div>
</div></section>
<script>
$(function(){
    $('#worker_id').on('change',function(){
        var worker=$(this).val(), select=$('#work_type_id');
        select.prop('disabled',!worker).val('');
        select.find('option[data-worker]').prop('hidden',true).prop('disabled',true);
        select.find('option[data-worker="'+worker+'"]').prop('hidden',false).prop('disabled',false);
        select.find('option:first').text(worker?'کام منتخب کریں':'پہلے ورکر منتخب کریں');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/order/workforce.blade.php ENDPATH**/ ?>