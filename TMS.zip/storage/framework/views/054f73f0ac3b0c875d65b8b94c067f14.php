<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="container-fluid px-3 px-md-4 py-4">
            <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
                <div>
                    <h1 class="h3 mb-1">پروڈکشن ورکرز</h1>
                    <p class="text-muted mb-0">درزی، کٹنگ ماسٹر اور دوسرے کاریگروں کا کام اور اجرت—ملازم اجازتوں سے الگ۔</p>
                </div>
                <a class="btn btn-primary" href="<?php echo e(route('admin.production-workers.create')); ?>"><i
                        class="fas fa-plus ml-1"></i>نیا ورکر</a>
            </div>
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <form class="card card-body mb-3" method="GET">
                <div class="form-row align-items-end">
                    <div class="form-group col-md-5 mb-md-0"><label for="q">نام یا فون</label><input id="q"
                            name="q" class="form-control" value="<?php echo e($filters['q'] ?? ''); ?>"
                            placeholder="ورکر تلاش کریں"></div>
                    <div class="form-group col-md-3 mb-md-0"><label for="relationship">تعلق</label><select id="relationship"
                            name="relationship" class="form-control" style="padding-top: 0px;">
                            <option value="">تمام</option>
                            <option value="contractor" <?php if(($filters['relationship'] ?? '') === 'contractor'): echo 'selected'; endif; ?>>آزاد کاریگر</option>
                            <option value="employee" <?php if(($filters['relationship'] ?? '') === 'employee'): echo 'selected'; endif; ?>>تنخواہ دار ملازم</option>
                        </select></div>
                    <div class="form-group col-md-2 mb-md-0"><label for="status">حالت</label><select id="status"
                            name="status" class="form-control" style="padding-top: 0px;">
                            <option value="">تمام</option>
                            <option value="active" <?php if(($filters['status'] ?? '') === 'active'): echo 'selected'; endif; ?>>فعال</option>
                            <option value="inactive" <?php if(($filters['status'] ?? '') === 'inactive'): echo 'selected'; endif; ?>>غیر فعال</option>
                        </select></div>
                    <div class="col-md-2"><button class="btn btn-outline-primary" type="submit">فلٹر</button> <a
                            class="btn btn-light" href="<?php echo e(route('admin.production-workers.index')); ?>">صاف</a></div>
                </div>
            </form>
            <div class="card">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>ورکر</th>
                                <th>کام</th>
                                <th>تعلق</th>
                                <th>موجودہ واجب الادا</th>
                                <th>حالت</th>
                                <th>عمل</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><strong><?php echo e($worker->name); ?></strong><br><small
                                            class="text-muted"><?php echo e($worker->phone ?: 'فون درج نہیں'); ?></small>
                                        <?php if($worker->legacy_tailor_id): ?>
                                            <br><span class="badge badge-info">موجودہ درزی سے منسلک</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php $__empty_2 = true; $__currentLoopData = $worker->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                            <span
                                            class="badge badge-light border ml-1"><?php echo e($skill->name); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><span
                                                class="text-muted">مقرر نہیں</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($worker->relationship_type === 'employee' ? 'تنخواہ دار ملازم' : 'آزاد کاریگر'); ?>

                                    </td>
                                    <td class="<?php echo e((float) $worker->ledger_balance > 0 ? 'text-danger' : 'text-success'); ?>">
                                        روپے <?php echo e(number_format((float) $worker->ledger_balance, 2)); ?></td>
                                    <td><span
                                            class="badge badge-<?php echo e($worker->active ? 'success' : 'secondary'); ?>"><?php echo e($worker->active ? 'فعال' : 'غیر فعال'); ?></span>
                                    </td>
                                    <td><a class="btn btn-sm btn-outline-primary"
                                            href="<?php echo e(route('admin.production-workers.show', $worker)); ?>">کھاتہ اور اجرت</a>
                                    </td>
                            </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr>
                                    <td colspan="6" class="text-center text-muted py-5">ابھی کوئی پروڈکشن ورکر موجود
                                        نہیں۔</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if($workers->hasPages()): ?>
                    <div class="card-footer"><?php echo e($workers->links()); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/production-workers/index.blade.php ENDPATH**/ ?>