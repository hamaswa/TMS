<!-- <div class="language">    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarLanguage" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Language
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarLanguage">
                <a class="dropdown-item" href="<?php echo e(url('admin/Lang-change?lang=eng')); ?>" id="english">English</a>
                <a class="dropdown-item" href="<?php echo e(url('admin/Lang-change?lang=ur')); ?>" id="urdu">urdu</a>
            </div>
        </li>
    </ul>
</div> -->


<!-- JavaScript
================================================== -->
<?php ($isSuperAdminFooter = request()->is('administrator') || request()->is('administrator/*') || (Auth::check() && Auth::user()->hasRole('administrative'))); ?>
<?php echo $__env->make('components.confirmation-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/owlcarousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>?v=20260924d"></script>
<script src="<?php echo e(asset('assets/js/form-accessibility.js')); ?>?v=20260728"></script>
<script src="<?php echo e(asset('assets/js/confirm-modal.js')); ?>?v=20260923b"></script>
<script>if('serviceWorker' in navigator){navigator.serviceWorker.register('/service-worker.js?v=20260924m',{scope:'/',updateViaCache:'none'});}</script>
<script src="<?php echo e(asset('assets/js/offline-workspace.js')); ?>?v=20260924m"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.js"></script>
<script>
(function () {
    'use strict';

    const isUrdu = document.documentElement.lang === 'ur';
    <?php if (! ($isSuperAdminFooter)): ?>
    const urduLocale = {
        weekdays: {
            shorthand: ['اتوار', 'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ'],
            longhand: ['اتوار', 'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ']
        },
        months: {
            shorthand: ['جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون', 'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'],
            longhand: ['جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون', 'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر']
        },
        firstDayOfWeek: 0,
        rangeSeparator: ' سے ',
        weekAbbreviation: 'ہفتہ',
        scrollTitle: 'تبدیل کرنے کے لیے اسکرول کریں',
        toggleTitle: 'کیلنڈر تبدیل کریں',
        time_24hr: false
    };
    <?php endif; ?>

    const datePickerSelector = 'input[type="date"], input#myflatpickr, input[data-flatpickr]';

    const initializeDatePicker = function (input) {
        if (!window.flatpickr || input._flatpickr || input.hasAttribute('data-no-flatpickr') || input.disabled) {
            return;
        }

        window.flatpickr(input, {
            altInput: true,
            altFormat: isUrdu ? 'j F Y' : 'F j, Y',
            dateFormat: 'Y-m-d',
            allowInput: true,
            disableMobile: true,
            locale: isUrdu ? urduLocale : 'default',
            minDate: input.getAttribute('min') || null,
            maxDate: input.getAttribute('max') || null,
            ariaDateFormat: isUrdu ? 'j F Y' : 'F j, Y'
        });
    };

    const initializeWithin = function (root) {
        if (root.matches && root.matches(datePickerSelector)) {
            initializeDatePicker(root);
        }
        if (root.querySelectorAll) {
            root.querySelectorAll(datePickerSelector).forEach(initializeDatePicker);
        }
    };

    document.addEventListener('DOMContentLoaded', function () {
        initializeWithin(document);
        new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1) initializeWithin(node);
                });
            });
        }).observe(document.body, { childList: true, subtree: true });
    });
}());
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<!--<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>-->
<!--<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>-->
<!--<script src="<?php echo e(asset('assets/owlcarousel/owl.carousel.min.js')); ?>"></script>-->
<!--<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>-->
<!--<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>-->
<!---->
<!-- <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script> -->

</body>
<!---->
<!--    -->

</html>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/inc/footer.blade.php ENDPATH**/ ?>