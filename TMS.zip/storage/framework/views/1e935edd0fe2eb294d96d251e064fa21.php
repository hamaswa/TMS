<?php
    $selectedTemplateId = old('measurement_template_id', $selectedTemplateId ?? null);
    $systemInputNames = ['length' => 'length', 'arms' => 'arms', 'teraa' => 'teraa', 'senaChorai' => 'senaChorai', 'damanchorai' => 'damanchorai', 'shalwar' => 'shalwar', 'pancha' => 'pancha', 'shalwarGheer' => 'shalwarGheer', 'shoulder' => 'monda', 'chuta' => 'chuta'];
?>
<div class="measurement-template-picker mb-4" dir="rtl">
    <?php if($measurementTemplates->isNotEmpty()): ?>
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-2"><div><label for="measurement-template-select" class="font-weight-bold mb-1">لباس کا پیمائش ٹیمپلیٹ</label><p class="text-muted small mb-0">ٹیمپلیٹ منتخب کرنے سے صرف متعلقہ پیمائش خانے دکھائی دیں گے۔</p></div><?php if(Auth::user()->hasBusinessPermission('tailoring.configuration')): ?><a href="<?php echo e(route('admin.measurement-templates.index')); ?>" class="btn btn-sm btn-outline-primary">ٹیمپلیٹس ترتیب دیں</a><?php endif; ?></div>
        <select id="measurement-template-select" class="form-control form-control-lg" name="measurement_template_id">
            <option value="" data-system='<?php echo json_encode(array_keys(\App\Services\MeasurementService::SYSTEM_FIELDS), 15, 512) ?>' data-custom='<?php echo json_encode($measurementFields->pluck('id')->values(), 15, 512) ?>'>تمام پیمائش خانے</option>
            <?php $__currentLoopData = $measurementTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($template->id); ?>" data-system='<?php echo json_encode($template->system_fields ?? [], 15, 512) ?>' data-custom='<?php echo json_encode(array_map('intval', $template->custom_field_ids ?? []), 512) ?>' <?php if((string) $selectedTemplateId === (string) $template->id): echo 'selected'; endif; ?>><?php echo e($template->name); ?><?php echo e($template->is_default ? ' — ڈیفالٹ' : ''); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php else: ?>
        <div class="alert alert-info mb-0"><strong>تمام پیمائش خانے دکھائے جا رہے ہیں۔</strong> <?php if(Auth::user()->hasBusinessPermission('tailoring.configuration')): ?><a href="<?php echo e(route('admin.measurement-templates.index')); ?>">لباس کے حساب سے ٹیمپلیٹ بنائیں</a><?php endif; ?></div>
    <?php endif; ?>
</div>

<?php if($measurementTemplates->isNotEmpty()): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var select = document.getElementById('measurement-template-select');
    if (!select) return;
    var systemInputs = <?php echo json_encode($systemInputNames, 15, 512) ?>;

    function toggleControl(input, visible) {
        if (!input) return;
        var container = input.closest('.form-group');
        if (!container) return;
        if (input.dataset.templateRequired === undefined) input.dataset.templateRequired = input.required ? '1' : '0';
        container.style.display = visible ? '' : 'none';
        input.required = visible && input.dataset.templateRequired === '1';
    }

    function applyTemplate() {
        var option = select.options[select.selectedIndex];
        var selectedSystem = JSON.parse(option.dataset.system || '[]');
        var selectedCustom = JSON.parse(option.dataset.custom || '[]').map(Number);
        Object.keys(systemInputs).forEach(function (key) {
            toggleControl(document.querySelector('[name="' + systemInputs[key] + '"]'), selectedSystem.indexOf(key) !== -1);
        });
        document.querySelectorAll('[name^="custom_measurements["]').forEach(function (input) {
            var match = input.name.match(/\[(\d+)\]/);
            toggleControl(input, match && selectedCustom.indexOf(Number(match[1])) !== -1);
        });
    }

    select.addEventListener('change', applyTemplate);
    applyTemplate();
});
</script>
<?php endif; ?>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/customer/partials/measurement-template-selector.blade.php ENDPATH**/ ?>