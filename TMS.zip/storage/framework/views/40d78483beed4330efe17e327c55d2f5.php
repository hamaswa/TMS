<?php $__env->startSection('content'); ?>
<style>
    .storefront-orders-head{display:flex;justify-content:space-between;align-items:center;gap:18px}
    .storefront-orders-head h1{line-height:1.8}
    @media(max-width:575px){
        .storefront-orders-head{display:block}
        .storefront-orders-head .btn{display:inline-block;margin-top:10px}
    }
</style>
<section class="main-content" dir="rtl">
    <div class="container">
        <div class="card">
            <div class="card-body">
                <div class="storefront-orders-head mb-3">
                    <div><div class="text-muted small">آن لائن دکان</div><h1 class="h3 mb-0">کپڑے کے آن لائن آرڈرز</h1></div>
                    <?php if(Auth::user()->hasBusinessPermission('storefront.manage')): ?><a class="btn btn-outline-secondary" href="<?php echo e(route('admin.storefront.edit')); ?>">دکان کی ترتیب</a><?php endif; ?>
                </div>
                <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
                <?php if($errors->any()): ?><div class="alert alert-danger"><?php echo e($errors->first()); ?></div><?php endif; ?>
                <form method="GET" class="form-row mb-4">
                    <div class="col-md-6 mb-2"><label for="order_search">حوالہ، نام یا فون</label><input id="order_search" class="form-control" name="search" value="<?php echo e(request('search')); ?>"></div>
                    <div class="col-md-4 mb-2"><label for="order_status">حالت</label><select id="order_status" class="form-control" name="status"><option value="">تمام</option><option value="pending" <?php if(request('status')==='pending'): echo 'selected'; endif; ?>>زیرِ انتظار</option><option value="confirmed" <?php if(request('status')==='confirmed'): echo 'selected'; endif; ?>>تصدیق شدہ</option><option value="complete" <?php if(request('status')==='complete'): echo 'selected'; endif; ?>>مکمل</option><option value="cancelled" <?php if(request('status')==='cancelled'): echo 'selected'; endif; ?>>منسوخ</option></select></div>
                    <div class="col-md-2 mb-2 d-flex align-items-end"><button class="btn btn-primary btn-block">تلاش کریں</button></div>
                </form>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $statusLabels=['pending'=>'زیرِ انتظار','confirmed'=>'تصدیق شدہ','complete'=>'مکمل','cancelled'=>'منسوخ'];
                        $statusClasses=['pending'=>'warning','confirmed'=>'primary','complete'=>'success','cancelled'=>'secondary'];
                    ?>
                    <article class="border rounded p-3 mb-3">
                        <div class="d-flex flex-wrap justify-content-between">
                            <div><strong dir="ltr"><?php echo e($order->reference); ?></strong><div><?php echo e($order->customer->name); ?> · <span dir="ltr"><?php echo e($order->customer->phone_number1); ?></span></div><small class="text-muted"><?php echo e($order->placed_at->format('d-m-Y h:i A')); ?></small></div>
                            <div class="text-left"><span class="badge badge-<?php echo e($statusClasses[$order->status] ?? 'secondary'); ?>"><?php echo e($statusLabels[$order->status] ?? $order->status); ?></span><div class="h5 mt-2">Rs <?php echo e(number_format($order->subtotal,2)); ?></div></div>
                        </div>
                        <div class="border rounded bg-light p-3 mt-3">
                            <div><strong>وصولی:</strong> <?php echo e($order->fulfillment_method === 'delivery' ? 'ڈیلیوری' : 'دکان سے وصولی'); ?></div>
                            <?php if($order->delivery_address): ?><div class="mt-1"><strong>ڈیلیوری پتہ:</strong> <?php echo e($order->delivery_address); ?></div><?php endif; ?>
                            <?php if($order->customer_note): ?><div class="mt-1"><strong>گاہک کا نوٹ:</strong> <?php echo e($order->customer_note); ?></div><?php endif; ?>
                            <?php if($order->confirmed_at): ?>
                                <small class="text-muted d-block mt-2">تصدیق: <?php echo e($order->confirmed_at->format('d-m-Y h:i A')); ?><?php if($order->confirmedBy): ?> · <?php echo e($order->confirmedBy->name ?: $order->confirmedBy->username); ?><?php endif; ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="mt-2"><strong>ادائیگی:</strong> <?php echo e(\App\Models\StorefrontOrder::paymentMethods()[$order->payment_method] ?? $order->payment_method); ?>

                            <?php if(\App\Models\StorefrontOrder::requiresManualVerification($order->payment_method)): ?>
                                <?php if($order->payment_sender_phone): ?> · <span dir="ltr"><?php echo e($order->payment_sender_phone); ?></span><?php endif; ?>
                                · <code><?php echo e($order->payment_reference); ?></code>
                                <span class="badge badge-<?php echo e($order->payment_verification_status === \App\Models\StorefrontOrder::VERIFICATION_VERIFIED ? 'success' : ($order->payment_verification_status === \App\Models\StorefrontOrder::VERIFICATION_REJECTED ? 'danger' : 'info')); ?>"><?php echo e(\App\Models\StorefrontOrder::verificationStatuses()[$order->payment_verification_status] ?? 'دستی تصدیق درکار'); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if(\App\Models\StorefrontOrder::requiresManualVerification($order->payment_method)): ?>
                            <?php
                                $verificationLabels = \App\Models\StorefrontOrder::verificationStatuses();
                                $verificationClass = match($order->payment_verification_status) {
                                    \App\Models\StorefrontOrder::VERIFICATION_VERIFIED => 'success',
                                    \App\Models\StorefrontOrder::VERIFICATION_REJECTED => 'danger',
                                    default => 'warning',
                                };
                            ?>
                            <div class="border rounded bg-light p-3 mt-3">
                                <div class="d-flex flex-wrap justify-content-between align-items-center">
                                    <strong><?php echo e(\App\Models\StorefrontOrder::paymentMethods()[$order->payment_method] ?? $order->payment_method); ?> تصدیق</strong>
                                    <span class="badge badge-<?php echo e($verificationClass); ?>"><?php echo e($verificationLabels[$order->payment_verification_status] ?? $order->payment_verification_status); ?></span>
                                </div>
                                <?php if($order->paymentVerifier): ?>
                                    <small class="text-muted d-block mt-2">
                                        کارروائی: <?php echo e($order->paymentVerifier->name ?: $order->paymentVerifier->username); ?>

                                        · <?php echo e(($order->payment_verified_at ?: $order->payment_rejected_at)?->format('d-m-Y h:i A')); ?>

                                    </small>
                                <?php endif; ?>
                                <?php if($order->payment_verification_notes): ?>
                                    <div class="small mt-2"><?php echo e($order->payment_verification_notes); ?></div>
                                <?php endif; ?>
                                <?php if($order->payment_evidence_path): ?>
                                    <div class="mt-2">
                                        <a class="btn btn-sm btn-outline-primary" target="_blank" rel="noopener" href="<?php echo e(route('admin.storefront.orders.payment-evidence', $order)); ?>">
                                            <i class="fas fa-paperclip ml-1"></i> ادائیگی کا ثبوت دیکھیں
                                        </a>
                                        <small class="text-muted mr-2"><?php echo e($order->payment_evidence_original_name); ?> · <?php echo e(number_format(($order->payment_evidence_size ?? 0) / 1024, 1)); ?> KB</small>
                                    </div>
                                <?php else: ?>
                                    <div class="small text-muted mt-2">گاہک نے ادائیگی کا ثبوت منسلک نہیں کیا۔</div>
                                <?php endif; ?>
                                <?php if($order->payment_verification_status !== \App\Models\StorefrontOrder::VERIFICATION_VERIFIED): ?>
                                    <form method="POST" action="<?php echo e(route('admin.storefront.orders.payment-verification', $order)); ?>" class="mt-3">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <label for="order_payment_notes_<?php echo e($order->id); ?>">تصدیقی نوٹ <small class="text-muted">(مسترد کرنے پر ضروری)</small></label>
                                        <textarea id="order_payment_notes_<?php echo e($order->id); ?>" name="payment_verification_notes" class="form-control mb-2" rows="2" maxlength="1000"></textarea>
                                        <button name="decision" value="verified" class="btn btn-success">ادائیگی تصدیق کریں</button>
                                        <button name="decision" value="rejected" class="btn btn-outline-danger">دعویٰ مسترد کریں</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <ul class="mt-2 mb-3"><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($item->item_name); ?> — <?php echo e($item->color); ?>، <?php echo e(number_format($item->quantity,2)); ?> میٹر</li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                        <?php if($order->returns->isNotEmpty()): ?>
                            <div class="border rounded bg-light p-3 mt-3">
                                <strong>جزوی واپسی اور تبدیلی کی تاریخ</strong>
                                <?php $__currentLoopData = $order->returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $returnItem = $return->items->first(); ?>
                                    <div class="small border-top pt-2 mt-2">
                                        <span dir="ltr"><?php echo e($return->reference); ?></span>
                                        · <?php echo e(\App\Models\StorefrontOrderReturn::types()[$return->type] ?? $return->type); ?>

                                        · <?php echo e($returnItem?->orderItem?->item_name); ?>

                                        · <?php echo e(number_format((float) $returnItem?->quantity, 2)); ?> میٹر
                                        <?php if((float) $return->refund_amount > 0): ?> · <?php echo e(\App\Support\PakistanCurrency::format($return->refund_amount)); ?><?php endif; ?>
                                        <?php if($returnItem?->replacementColor): ?> · متبادل رنگ: <?php echo e($returnItem->replacementColor->color); ?><?php endif; ?>
                                        · <?php echo e($returnItem?->restocked ? 'اسٹاک میں واپس' : 'خراب / اسٹاک میں واپس نہیں'); ?>

                                        <span class="d-block text-muted"><?php echo e($return->processed_at->format('d-m-Y h:i A')); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <?php if($order->status !== \App\Models\StorefrontOrder::STATUS_CANCELLED && $order->refunds->isEmpty()): ?>
                            <div class="mt-3">
                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $processedQuantity = (float) $item->returnItems->sum('quantity');
                                        $returnableQuantity = max(0, (float) $item->quantity - $processedQuantity);
                                    ?>
                                    <?php if($returnableQuantity > 0): ?>
                                        <details class="border rounded p-2 mb-2">
                                            <summary class="font-weight-bold" style="cursor:pointer"><?php echo e($item->item_name); ?> — جزوی واپسی یا رنگ تبدیل کریں <small class="text-muted">(دستیاب <?php echo e(number_format($returnableQuantity, 2)); ?> میٹر)</small></summary>
                                            <form method="POST" action="<?php echo e(route('admin.storefront.orders.returns.store', $order)); ?>" class="mt-3"
                                                data-confirm="مقدار، رقم اور اسٹاک کی تفصیل دوبارہ دیکھ لی ہے؟" data-confirm-variant="warning">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="order_item_id" value="<?php echo e($item->id); ?>">
                                                <div class="form-row">
                                                    <div class="col-md-3 mb-2"><label for="return_type_<?php echo e($item->id); ?>">کارروائی</label><select id="return_type_<?php echo e($item->id); ?>" name="return_type" class="form-control" required><?php $__currentLoopData = \App\Models\StorefrontOrderReturn::types(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>"><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                                                    <div class="col-md-2 mb-2"><label for="return_quantity_<?php echo e($item->id); ?>">مقدار (میٹر)</label><input id="return_quantity_<?php echo e($item->id); ?>" name="quantity" type="number" class="form-control" min="0.01" max="<?php echo e($returnableQuantity); ?>" step="0.01" required></div>
                                                    <div class="col-md-3 mb-2"><label for="replacement_color_<?php echo e($item->id); ?>">متبادل رنگ <small class="text-muted">(صرف تبدیلی)</small></label><select id="replacement_color_<?php echo e($item->id); ?>" name="replacement_cloth_color_id" class="form-control"><option value="">منتخب کریں</option><?php $__currentLoopData = $item->cloth?->colors ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if($color->id !== $item->cloth_color_id): ?><option value="<?php echo e($color->id); ?>"><?php echo e($color->color); ?> — <?php echo e(number_format((float)$color->length,2)); ?> میٹر</option><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                                                    <?php if((float) $order->paid_amount > 0): ?>
                                                        <div class="col-md-2 mb-2"><label for="partial_refund_method_<?php echo e($item->id); ?>">رقم واپسی <small class="text-muted">(صرف واپسی)</small></label><select id="partial_refund_method_<?php echo e($item->id); ?>" name="refund_method" class="form-control"><option value="">منتخب کریں</option><?php $__currentLoopData = \App\Models\StorefrontOrderRefund::methods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>"><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                                                        <div class="col-md-2 mb-2"><label for="partial_refund_reference_<?php echo e($item->id); ?>">ادائیگی حوالہ</label><input id="partial_refund_reference_<?php echo e($item->id); ?>" name="refund_reference" class="form-control" maxlength="100" dir="ltr"></div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-row align-items-end">
                                                    <div class="col-md-7 mb-2"><label for="return_notes_<?php echo e($item->id); ?>">اندرونی نوٹ <small class="text-muted">(اختیاری)</small></label><input id="return_notes_<?php echo e($item->id); ?>" name="return_notes" class="form-control" maxlength="1000"></div>
                                                    <div class="col-md-3 mb-2"><div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="restock_<?php echo e($item->id); ?>" name="restock" value="1" checked><label class="custom-control-label" for="restock_<?php echo e($item->id); ?>">کپڑا قابلِ فروخت ہے، اسٹاک میں واپس کریں</label></div></div>
                                                    <div class="col-md-2 mb-2"><button class="btn btn-warning btn-block">درج کریں</button></div>
                                                </div>
                                            </form>
                                        </details>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <?php if($order->refunds->isNotEmpty()): ?>
                            <?php $__currentLoopData = $order->refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-info mt-3 mb-0">
                                    <strong>رقم واپس کی گئی:</strong> <?php echo e(\App\Support\PakistanCurrency::format($refund->amount)); ?>

                                    · <?php echo e(\App\Models\StorefrontOrderRefund::methods()[$refund->method] ?? $refund->method); ?>

                                    · <span dir="ltr"><?php echo e($refund->reference); ?></span>
                                    <?php if($refund->external_reference): ?> · بیرونی حوالہ: <span dir="ltr"><?php echo e($refund->external_reference); ?></span><?php endif; ?>
                                    <small class="d-block mt-1"><?php echo e($refund->refunded_at->format('d-m-Y h:i A')); ?></small>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(in_array($order->status, [\App\Models\StorefrontOrder::STATUS_PENDING, \App\Models\StorefrontOrder::STATUS_CONFIRMED], true)): ?>
                            <div class="mt-3">
                                <?php if($order->status === \App\Models\StorefrontOrder::STATUS_PENDING): ?>
                                    <form method="POST" action="<?php echo e(route('admin.storefront.orders.update',$order)); ?>" class="d-inline-block ml-2"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><input type="hidden" name="status" value="confirmed"><button class="btn btn-primary" <?php if(\App\Models\StorefrontOrder::requiresManualVerification($order->payment_method) && $order->payment_verification_status !== \App\Models\StorefrontOrder::VERIFICATION_VERIFIED): echo 'disabled'; endif; ?>>آرڈر کی تصدیق کریں</button></form>
                                <?php else: ?>
                                    <a class="btn btn-dark ml-2" target="_blank" rel="noopener" href="<?php echo e(route('admin.storefront.orders.dispatch-print', $order)); ?>"><i class="fas fa-print ml-1"></i> ڈسپیچ شیٹ پرنٹ کریں</a>
                                    <form method="POST" action="<?php echo e(route('admin.storefront.orders.update',$order)); ?>" class="d-inline-block ml-2"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><input type="hidden" name="status" value="complete"><button class="btn btn-success">مکمل کریں</button></form>
                                <?php endif; ?>
                                <?php if($order->returns->isNotEmpty()): ?>
                                    <div class="alert alert-light mt-2 mb-0">اس آرڈر پر جزوی واپسی یا تبدیلی موجود ہے، اس لیے مکمل منسوخی دستیاب نہیں۔ باقی مقدار الگ واپسی یا تبدیلی سے درج کریں۔</div>
                                <?php elseif((float) $order->paid_amount <= 0): ?>
                                    <form method="POST" action="<?php echo e(route('admin.storefront.orders.update',$order)); ?>" class="d-inline-block" data-confirm="آرڈر منسوخ کرنے سے اسٹاک اور گاہک کا بقایا واپس ہوگا۔ جاری رکھیں؟"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><input type="hidden" name="status" value="cancelled"><button class="btn btn-outline-danger">منسوخ کریں</button></form>
                                <?php else: ?>
                                    <div class="border border-danger rounded p-3 mt-3">
                                        <h2 class="h5">مکمل رقم واپس کر کے آرڈر منسوخ کریں</h2>
                                        <p class="mb-3">واپس کی جانے والی رقم: <strong><?php echo e(\App\Support\PakistanCurrency::format($order->paid_amount)); ?></strong>۔ یہ کارروائی اسٹاک واپس کرے گی اور ایک قابلِ جانچ مالی اندراج بنائے گی۔</p>
                                        <form method="POST" action="<?php echo e(route('admin.storefront.orders.update',$order)); ?>" data-confirm="کیا رقم واقعی گاہک کو واپس کر دی گئی ہے؟ یہ کارروائی دوبارہ نہیں کی جا سکے گی۔">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <input type="hidden" name="status" value="cancelled">
                                            <div class="form-row">
                                                <div class="col-md-4 mb-2"><label for="refund_method_<?php echo e($order->id); ?>">رقم واپسی کا طریقہ</label><select id="refund_method_<?php echo e($order->id); ?>" name="refund_method" class="form-control" required><?php $__currentLoopData = \App\Models\StorefrontOrderRefund::methods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>"><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                                                <div class="col-md-4 mb-2"><label for="refund_reference_<?php echo e($order->id); ?>">واپسی کا بیرونی حوالہ <small class="text-muted">(نقد کے علاوہ ضروری)</small></label><input id="refund_reference_<?php echo e($order->id); ?>" name="refund_reference" class="form-control" maxlength="100" dir="ltr"></div>
                                                <div class="col-md-4 mb-2"><label for="refund_notes_<?php echo e($order->id); ?>">اندرونی نوٹ <small class="text-muted">(اختیاری)</small></label><input id="refund_notes_<?php echo e($order->id); ?>" name="refund_notes" class="form-control" maxlength="1000"></div>
                                            </div>
                                            <button class="btn btn-danger">رقم واپس اور آرڈر منسوخ کریں</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-light text-center">کوئی آن لائن آرڈر موجود نہیں۔</div>
                <?php endif; ?>
                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/storefront/admin/orders.blade.php ENDPATH**/ ?>