<?php ($isSuperAdminConfirmation = Auth::check() && Auth::user()->hasRole('administrative')); ?>
<div class="modal fade" id="tmsConfirmModal" tabindex="-1" role="dialog"
    aria-labelledby="tmsConfirmModalTitle" aria-describedby="tmsConfirmModalMessage" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content border-0 shadow">
            <div class="modal-header align-items-center">
                <h2 class="modal-title h5 mb-0" id="tmsConfirmModalTitle"><?php echo e($isSuperAdminConfirmation ? 'Confirmation required' : 'تصدیق درکار'); ?></h2>
                <button type="button" class="close mx-0" data-dismiss="modal" aria-label="<?php echo e($isSuperAdminConfirmation ? 'Close' : 'بند کریں'); ?>">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p id="tmsConfirmModalMessage" class="mb-0"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light border" data-dismiss="modal" data-tms-confirm-cancel>
                    <?php echo e($isSuperAdminConfirmation ? 'Cancel' : 'واپس جائیں'); ?>

                </button>
                <button type="button" class="btn btn-danger" data-tms-confirm-accept>
                    <?php echo e($isSuperAdminConfirmation ? 'Continue' : 'جاری رکھیں'); ?>

                </button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/components/confirmation-modal.blade.php ENDPATH**/ ?>