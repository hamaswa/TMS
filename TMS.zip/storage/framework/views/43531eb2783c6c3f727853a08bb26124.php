<?php
    $paymentFieldPrefix = $prefix ?? 'payment';
    $paymentMethodName = $methodName ?? 'payment_method';
    $paymentReferenceName = $referenceName ?? 'payment_reference';
    $paymentReferenceHintId = $paymentFieldPrefix.'_reference_hint';
    $selectedPaymentMethod = old($paymentMethodName, $currentMethod ?? 'cash');
    $paymentReferenceValue = old($paymentReferenceName, $currentReference ?? null);
?>
<div class="<?php echo e($methodGroupClass ?? 'form-group'); ?>">
    <label for="<?php echo e($paymentFieldPrefix); ?>_method">ادائیگی کا طریقہ</label>
    <select id="<?php echo e($paymentFieldPrefix); ?>_method" name="<?php echo e($paymentMethodName); ?>" class="form-control" required>
        <?php $__currentLoopData = \App\Support\PaymentMethods::LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $methodValue => $methodLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($methodValue); ?>" <?php if($selectedPaymentMethod === $methodValue): echo 'selected'; endif; ?>><?php echo e($methodLabel); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="<?php echo e($referenceGroupClass ?? 'form-group'); ?>">
    <label for="<?php echo e($paymentFieldPrefix); ?>_reference">حوالہ / ٹرانزیکشن نمبر</label>
    <input
        id="<?php echo e($paymentFieldPrefix); ?>_reference"
        type="text"
        name="<?php echo e($paymentReferenceName); ?>"
        value="<?php echo e($paymentReferenceValue); ?>"
        maxlength="255"
        class="form-control"
        placeholder="بینک، والٹ، راست یا چیک نمبر"
        aria-describedby="<?php echo e($paymentReferenceHintId); ?>"
    >
    <small id="<?php echo e($paymentReferenceHintId); ?>" class="form-text text-muted">نقد اور دیگر ادائیگی کے لیے اختیاری ہے۔</small>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const method = document.getElementById(<?php echo json_encode($paymentFieldPrefix.'_method', 15, 512) ?>);
    const reference = document.getElementById(<?php echo json_encode($paymentFieldPrefix.'_reference', 15, 512) ?>);
    const hint = document.getElementById(<?php echo json_encode($paymentReferenceHintId, 15, 512) ?>);

    if (!method || !reference || !hint) {
        return;
    }

    const syncReferenceRequirement = function () {
        const required = !['cash', 'other'].includes(method.value);
        reference.required = required;
        reference.setAttribute('aria-required', required ? 'true' : 'false');
        hint.textContent = required
            ? 'منتخب ادائیگی کے طریقے کے لیے حوالہ نمبر ضروری ہے۔'
            : 'نقد اور دیگر ادائیگی کے لیے اختیاری ہے۔';
    };

    method.addEventListener('change', syncReferenceRequirement);
    syncReferenceRequirement();
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/components/payment-method-fields.blade.php ENDPATH**/ ?>