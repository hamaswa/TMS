<?php $__env->startSection('content'); ?>
<?php
    $statusLabels = \App\Models\Order::STATUS_LABELS;
    $historySourceLabels = ['customer_created' => 'ابتدائی پیمائش', 'baseline' => 'پچھلی محفوظ پیمائش', 'customer_update' => 'تبدیل شدہ پیمائش', 'order_update' => 'آرڈر سے تبدیل شدہ پیمائش'];
    $customerScopeLabel = $canViewTailoring && $canViewShop
        ? 'ٹیلرنگ اور کپڑے کی دکان کا ایک ریکارڈ'
        : ($canViewTailoring ? 'ٹیلرنگ کا مشترکہ گاہک ریکارڈ' : ($canViewShop ? 'کپڑے کی دکان کا گاہک ریکارڈ' : 'گاہک کا ریکارڈ'));
    $balanceScopeLabel = $canViewTailoring && $canViewShop
        ? 'دکان اور ٹیلرنگ کا مجموعہ'
        : ($canViewTailoring ? 'ٹیلرنگ کا مجموعہ' : ($canViewShop ? 'دکان کا مجموعہ' : 'تمام مجاز اندراجات کا مجموعہ'));
?>
<section class="main-content customer-workspace" dir="rtl">
    <div class="container-fluid px-3 px-lg-5 py-4">
        <div class="customer-hero mb-4">
            <div class="row align-items-center">
                <div class="col-lg-8 d-flex align-items-center">
                    <div class="customer-avatar"><?php echo e(\Illuminate\Support\Str::substr($customer->name, 0, 1)); ?></div>
                    <div><span class="badge badge-light text-primary mb-2">مشترکہ گاہک پروفائل</span><h1 class="h3 font-weight-bold mb-1"><?php echo e($customer->name); ?></h1><p class="mb-0"><?php echo e($customer->phone_number1); ?> · <?php echo e($customerScopeLabel); ?></p></div>
                </div>
                <div class="col-lg-4 text-lg-left mt-3 mt-lg-0">
                    <?php if($canManageMeasurements): ?><a href="<?php echo e(route('admin.Customers.edit', $customer)); ?>" class="btn btn-light ml-2"><i class="fas fa-edit ml-1"></i> معلومات تبدیل کریں</a><?php endif; ?>
                    <?php if($canManageMeasurements): ?><a href="<?php echo e(route('admin.Customers.create', ['parent' => $customer->id])); ?>" class="btn btn-success ml-2"><i class="fas fa-user-plus ml-1"></i> خاندان کا نیا ناپ</a><?php endif; ?>
                    <a href="<?php echo e(route('admin.workspace.current')); ?>" class="btn btn-outline-light">ڈیش بورڈ</a>
                </div>
            </div>
        </div>

        <?php if(session('insert')): ?><div class="alert alert-success"><?php echo e(session('insert')); ?></div><?php endif; ?>
        <?php if(session('balanceError')): ?><div class="alert alert-danger"><?php echo e(session('balanceError')); ?></div><?php endif; ?>
        <?php if($errors->any()): ?><div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>

        <nav class="customer-tabs mb-4" aria-label="گاہک پروفائل">
            <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="customer-tab <?php echo e($activeTab === $key ? 'active' : ''); ?>" href="<?php echo e(route('admin.customers.statement', ['id' => $customer->id, 'tab' => $key])); ?>"><i class="fas <?php echo e($tab['icon']); ?>"></i><span><?php echo e($tab['label']); ?></span></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <?php if($activeTab === 'overview'): ?>
            <div class="row mb-2">
                <?php if($canViewBalances): ?>
                    <div class="col-md-6 col-xl-3 mb-3"><div class="profile-stat balance"><span class="stat-icon"><i class="fas fa-wallet"></i></span><small>کل مشترکہ بقایا</small><strong>Rs <?php echo e(number_format($totalBalance, 2)); ?></strong><span><?php echo e($balanceScopeLabel); ?></span></div></div>
                    <div class="col-md-6 col-xl-3 mb-3"><div class="profile-stat paid"><span class="stat-icon"><i class="fas fa-hand-holding-usd"></i></span><small>کل وصول شدہ رقم</small><strong>Rs <?php echo e(number_format($totalReceived, 2)); ?></strong><span>ابتدائی اور بعد کی ادائیگیاں</span></div></div>
                <?php endif; ?>
                <?php if($canViewTailoring): ?><div class="col-md-6 col-xl-3 mb-3"><div class="profile-stat"><span class="stat-icon"><i class="fas fa-cut"></i></span><small>ٹیلرنگ آرڈرز</small><strong><?php echo e($orders->count()); ?></strong><a href="<?php echo e(route('admin.customers.statement', ['id' => $customer->id, 'tab' => 'tailoring'])); ?>">تمام آرڈرز دیکھیں</a></div></div><?php endif; ?>
                <?php if($canViewShop): ?><div class="col-md-6 col-xl-3 mb-3"><div class="profile-stat"><span class="stat-icon"><i class="fas fa-shopping-bag"></i></span><small>حالیہ دکان خریداری</small><strong><?php echo e($sales->count()); ?></strong><a href="<?php echo e(route('admin.customers.statement', ['id' => $customer->id, 'tab' => 'shop'])); ?>">خریداری دیکھیں</a></div></div><?php endif; ?>
            </div>

            <?php if (! ($canViewBalances)): ?><div class="alert alert-secondary"><i class="fas fa-lock ml-1"></i> آپ کے رول کو گاہک کا بقایا اور ادائیگیاں دیکھنے کی اجازت نہیں ہے۔ دیگر اجازت یافتہ ریکارڈ نیچے دستیاب ہیں۔</div><?php endif; ?>

            <div class="row">
                <?php if($canViewTailoring): ?>
                    <div class="col-lg-6 mb-4"><div class="card workspace-card h-100"><div class="card-body p-4"><div class="section-heading"><div><h2 class="h5 font-weight-bold">حالیہ ٹیلرنگ آرڈرز</h2><p>سلائی کے تازہ ترین کام اور موجودہ حالت</p></div><a href="<?php echo e(route('admin.customers.statement', ['id' => $customer->id, 'tab' => 'tailoring'])); ?>">تمام دیکھیں</a></div>
                        <?php $__empty_1 = true; $__currentLoopData = $orders->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="activity-row"><span class="activity-icon tailoring"><i class="fas fa-cut"></i></span><div class="flex-grow-1"><strong>آرڈر #<?php echo e($order->id); ?> · <?php echo e($order->suitQuantity ?: 1); ?> سوٹ</strong><small><?php echo e($order->created_at?->format('d-m-Y')); ?> · <?php echo e($statusLabels[$order->status] ?? $order->status); ?></small></div><strong>Rs <?php echo e(number_format((float) $order->totalPayment, 0)); ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state">ابھی کوئی ٹیلرنگ آرڈر موجود نہیں۔</div><?php endif; ?>
                    </div></div></div>
                <?php endif; ?>
                <?php if($canViewShop): ?>
                    <div class="col-lg-6 mb-4"><div class="card workspace-card h-100"><div class="card-body p-4"><div class="section-heading"><div><h2 class="h5 font-weight-bold">حالیہ کپڑے کی خریداری</h2><p>فروخت، اشیاء اور واجب الادا رقم</p></div><a href="<?php echo e(route('admin.customers.statement', ['id' => $customer->id, 'tab' => 'shop'])); ?>">تمام دیکھیں</a></div>
                        <?php $__empty_1 = true; $__currentLoopData = $sales->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="activity-row"><span class="activity-icon shop"><i class="fas fa-shopping-bag"></i></span><div class="flex-grow-1"><strong>رسید #<?php echo e($sale->id); ?> · <?php echo e($sale->items_count); ?> اشیاء <?php if($sale->status === 'cancelled'): ?><span class="badge badge-danger">منسوخ</span><?php endif; ?></strong><small><?php echo e($sale->created_at?->format('d-m-Y')); ?> · <?php echo e($sale->summary ?: 'کپڑے کی فروخت'); ?></small></div><strong class="<?php echo e($sale->status === 'cancelled' ? 'text-muted' : ''); ?>">Rs <?php echo e(number_format($sale->amount, 0)); ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state">ابھی کوئی دکان خریداری موجود نہیں۔</div><?php endif; ?>
                    </div></div></div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if($activeTab === 'transactions' && $canViewBalances): ?>
            <div class="row">
                <div class="col-xl-8 mb-4"><div class="card workspace-card"><div class="card-body p-0"><div class="section-heading p-4 mb-0"><div><h2 class="h5 font-weight-bold">مشترکہ کھاتہ</h2><p>ہر اندراج پر شعبہ درج ہے، لیکن بقایا ایک مجموعی رقم ہے۔</p></div><span class="balance-pill">بقایا: Rs <?php echo e(number_format($totalBalance, 2)); ?></span></div><div class="table-responsive"><table class="table table-hover mb-0 text-right"><thead><tr><th>تاریخ</th><th>شعبہ</th><th>حوالہ</th><th>وصول شدہ</th><th>بقایا تبدیلی</th><th>تفصیل</th></tr></thead><tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e(($transaction->paid_on ?: $transaction->created_at)?->format('d-m-Y')); ?></td><td><span class="type-badge type-<?php echo e(strtolower(str_replace(' ', '-', $transaction->Order_type))); ?>"><?php echo e($transaction->Order_type === 'Tailor' ? 'ٹیلرنگ' : ($transaction->Order_type === 'Sale' ? 'دکان' : ($transaction->Order_type === 'Sale Cancellation' ? 'فروخت منسوخی' : ($transaction->Order_type === 'Payment' ? 'مشترکہ ادائیگی' : 'دیگر')))); ?></span></td><td><?php echo e($transaction->orderId ? 'آرڈر #'.$transaction->orderId : ($transaction->sale_id ? 'فروخت #'.$transaction->sale_id : 'ادائیگی')); ?></td><td>Rs <?php echo e(number_format((float) $transaction->recivedPayment, 2)); ?></td><td class="<?php echo e((float) $transaction->remainingBalance < 0 ? 'text-success' : 'text-danger'); ?>">Rs <?php echo e(number_format((float) $transaction->remainingBalance, 2)); ?></td><td><?php if($transaction->payment_method): ?><strong><?php echo e(\App\Support\PaymentMethods::LABELS[$transaction->payment_method] ?? $transaction->payment_method); ?></strong><?php if($transaction->payment_reference): ?><br><small><?php echo e($transaction->payment_reference); ?></small><?php endif; ?> <?php if($transaction->comment): ?><br><?php endif; ?> <?php endif; ?><?php echo e($transaction->comment ?: ($transaction->payment_method ? '' : '—')); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="empty-state">ابھی کوئی لین دین موجود نہیں۔</td></tr><?php endif; ?>
                    </tbody></table></div><?php if($transactions->hasPages()): ?><div class="card-footer"><?php echo e($transactions->links()); ?></div><?php endif; ?></div></div></div>
                <div class="col-xl-4 mb-4">
                    <div class="card workspace-card mb-3"><div class="card-body p-4"><small class="text-muted">موجودہ مشترکہ بقایا</small><div class="display-4 font-weight-bold text-primary">Rs <?php echo e(number_format($totalBalance, 2)); ?></div><p class="text-muted mb-0">یہ <?php echo e($balanceScopeLabel); ?> واجب الادا رقم ہے۔</p></div></div>
                    <?php if($paymentRoute && $totalBalance > 0): ?>
                        <div class="card workspace-card">
                            <div class="card-body p-4">
                                <h2 class="h5 font-weight-bold">نئی ادائیگی درج کریں</h2>
                                <p class="text-muted small">ادائیگی مشترکہ بقایا میں جمع ہوگی اور اس کا طریقہ و حوالہ محفوظ رہے گا۔</p>
                                <form method="POST" action="<?php echo e($paymentRoute); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                                    <input type="hidden" name="return_to_statement" value="1">
                                    <div class="form-group">
                                        <label for="statement_payment_amount">وصول شدہ رقم</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend"><span class="input-group-text">Rs</span></div>
                                            <input id="statement_payment_amount" type="number" class="form-control" name="DirectPayment" min="0.01" max="<?php echo e($totalBalance); ?>" step="0.01" required>
                                        </div>
                                    </div>
                                    <?php echo $__env->make('components.payment-method-fields', ['prefix' => 'statement_payment'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    <div class="form-group">
                                        <label for="statement_payment_date">ادائیگی کی تاریخ</label>
                                        <input id="statement_payment_date" type="date" name="paid_on" value="<?php echo e(now()->toDateString()); ?>" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="statement_payment_note">نوٹ <small class="text-muted">(اختیاری)</small></label>
                                        <textarea id="statement_payment_note" class="form-control" name="comment" rows="3" placeholder="مثلاً نقد ادائیگی"></textarea>
                                    </div>
                                    <button class="btn btn-primary btn-block">ادائیگی محفوظ کریں</button>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if($activeTab === 'tailoring' && $canViewTailoring): ?>
            <div class="card workspace-card"><div class="card-body p-0"><div class="section-heading p-4 mb-0"><div><h2 class="h5 font-weight-bold">ٹیلرنگ آرڈرز</h2><p>گاہک کے تمام حالیہ سلائی آرڈرز اور کام کی حالت</p></div><span class="badge badge-primary px-3 py-2"><?php echo e($orders->count()); ?> آرڈرز</span></div><div class="table-responsive"><table class="table table-hover mb-0 text-right"><thead><tr><th>آرڈر</th><th>فرد / سیریل</th><th>لباس</th><th>آرڈر تاریخ</th><th>واپسی</th><th>سوٹ</th><th>کل رقم</th><th>بقایا</th><th>درزی</th><th>حالت</th><th></th></tr></thead><tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td>#<?php echo e($order->id); ?></td><td><strong><?php echo e($order->customers?->name ?: $customer->name); ?></strong><br><small class="text-muted">سیریل <?php echo e($order->sub_customer ?: $order->suitNum); ?></small></td><td><?php echo e($order->measurementTemplate?->name ?: 'تمام پیمائش'); ?></td><td><?php echo e($order->created_at?->format('d-m-Y')); ?></td><td><?php echo e($order->returnDate ? \Illuminate\Support\Carbon::parse($order->returnDate)->format('d-m-Y') : '—'); ?></td><td><?php echo e($order->suitQuantity ?: 1); ?></td><td>Rs <?php echo e(number_format((float) $order->totalPayment, 2)); ?></td><td>Rs <?php echo e(number_format((float) ($order->outstanding_amount ?? 0), 2)); ?></td><td><?php echo e($order->tailor?->name ?: 'مقرر نہیں'); ?></td><td><span class="status-badge"><?php echo e($statusLabels[$order->status] ?? 'نامعلوم حالت'); ?></span></td><td><a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.order-print', $order)); ?>">رسید</a></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="11" class="empty-state">ابھی کوئی ٹیلرنگ آرڈر موجود نہیں۔</td></tr><?php endif; ?>
                </tbody></table></div></div></div>
        <?php endif; ?>

        <?php if($activeTab === 'shop' && $canViewShop): ?>
            <div class="card workspace-card"><div class="card-body p-0"><div class="section-heading p-4 mb-0"><div><h2 class="h5 font-weight-bold">کپڑے کی خریداری</h2><p>دکان سے خریدی گئی اشیاء، رقم اور بقایا</p></div><span class="badge badge-primary px-3 py-2"><?php echo e($sales->count()); ?> رسیدیں</span></div><div class="table-responsive"><table class="table table-hover mb-0 text-right"><thead><tr><th>رسید</th><th>تاریخ</th><th>تفصیل</th><th>اشیاء</th><th>کل رقم</th><th>وصول شدہ</th><th>بقایا</th><th></th></tr></thead><tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr class="<?php echo e($sale->status === 'cancelled' ? 'text-muted' : ''); ?>"><td>#<?php echo e($sale->id); ?> <?php if($sale->status === 'cancelled'): ?><span class="badge badge-danger">منسوخ</span><?php endif; ?></td><td><?php echo e($sale->created_at?->format('d-m-Y')); ?></td><td><?php echo e($sale->summary ?: 'کپڑے کی فروخت'); ?><?php if($sale->cancellation_reason): ?><br><small>وجہ: <?php echo e($sale->cancellation_reason); ?></small><?php endif; ?></td><td><?php echo e($sale->items_count); ?></td><td>Rs <?php echo e(number_format($sale->amount, 2)); ?></td><td>Rs <?php echo e(number_format($sale->status === 'cancelled' ? 0 : $sale->received, 2)); ?></td><td>Rs <?php echo e(number_format($sale->status === 'cancelled' ? 0 : $sale->balance, 2)); ?></td><td><?php if($sale->source === 'stock'): ?><a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.printStock', ['id' => $sale->id, 'customerId' => $customer->id])); ?>">رسید</a><?php elseif($sale->source === 'legacy'): ?><a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.sale.show', $sale->id)); ?>">تفصیل</a><?php else: ?><span class="text-muted">—</span><?php endif; ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="8" class="empty-state">ابھی کوئی کپڑے کی خریداری موجود نہیں۔</td></tr><?php endif; ?>
                </tbody></table></div></div></div>
        <?php endif; ?>

        <?php if($activeTab === 'measurements' && $canManageMeasurements): ?>
            <div class="card workspace-card mb-4"><div class="card-body p-4 p-lg-5">
                <div class="section-heading"><div><h2 class="h4 font-weight-bold">خاندان کے محفوظ ناپ</h2><p>ایک فون نمبر اور مشترکہ کھاتے کے تحت ہر فرد کا نام اور پیمائش الگ رکھیں۔</p></div><a class="btn btn-success" href="<?php echo e(route('admin.Customers.create', ['parent' => $customer->id])); ?>"><i class="fas fa-user-plus ml-1"></i> نیا خاندانی ناپ شامل کریں</a></div>
                <form class="family-profile-selector" method="GET" action="<?php echo e(route('admin.customers.statement', $customer->id)); ?>">
                    <input type="hidden" name="tab" value="measurements">
                    <div class="family-profile-field">
                        <label for="family-profile-select">جس فرد کے ناپ دیکھنے ہیں اسے منتخب کریں</label>
                        <select id="family-profile-select" name="profile" class="form-control" onchange="this.form.submit()">
                            <?php $__currentLoopData = $measurementProfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($profile->id); ?>" <?php if($measurementProfile->id === $profile->id): echo 'selected'; endif; ?>>
                                    <?php echo e($profile->name); ?> — <?php echo e($profile->id === $customer->id ? 'مرکزی گاہک' : 'خاندانی فرد'); ?> — <?php echo e($profile->measurementTemplate?->name ?: 'تمام پیمائش'); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button class="btn btn-primary family-profile-submit" type="submit"><i class="fas fa-ruler ml-1"></i> ناپ دکھائیں</button>
                    <div class="family-profile-current" aria-live="polite">
                        <span class="family-profile-avatar"><?php echo e(\Illuminate\Support\Str::substr($measurementProfile->name, 0, 1)); ?></span>
                        <span><small>اس وقت منتخب</small><strong><?php echo e($measurementProfile->name); ?></strong></span>
                        <span class="family-profile-count"><?php echo e($measurementProfile->measurement_values_count); ?> اضافی پیمائش</span>
                    </div>
                </form>
            </div></div>
            <div class="card workspace-card"><div class="card-body p-4 p-lg-5"><div class="section-heading"><div><h2 class="h4 font-weight-bold"><?php echo e($measurementProfile->name); ?> کی محفوظ شدہ پیمائش</h2><p>سسٹم اور کاروبار کے اپنے اضافی پیمائشی خانے <?php if($measurementProfile->measurementTemplate): ?>· ٹیمپلیٹ: <strong><?php echo e($measurementProfile->measurementTemplate->name); ?></strong><?php endif; ?></p></div><a class="btn btn-outline-primary" href="<?php echo e(route('admin.Customers.edit', $measurementProfile)); ?>"><i class="fas fa-edit ml-1"></i> پیمائش تبدیل کریں</a></div>
                <h3 class="h6 font-weight-bold text-muted mt-4 mb-3">بنیادی پیمائش</h3><div class="measurement-grid"><?php $__empty_1 = true; $__currentLoopData = $systemMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="measurement-item"><small><?php echo e($measurement['label']); ?></small><strong><?php echo e($measurement['value']); ?> <span><?php echo e($measurement['unit'] === 'inch' ? 'انچ' : $measurement['unit']); ?></span></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state grid-full">بنیادی پیمائش درج نہیں کی گئی۔</div><?php endif; ?></div>
                <h3 class="h6 font-weight-bold text-muted mt-5 mb-3">اضافی پیمائش</h3><div class="measurement-grid"><?php $__empty_1 = true; $__currentLoopData = $customMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="measurement-item custom"><small><?php echo e($measurement->field->label); ?></small><strong><?php echo e($measurement->value); ?> <?php if($measurement->field->unit !== 'none'): ?><span><?php echo e($measurement->field->unit === 'inch' ? 'انچ' : $measurement->field->unit); ?></span><?php endif; ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state grid-full">اس گاہک کے لیے اضافی پیمائش درج نہیں کی گئی۔</div><?php endif; ?></div>
            </div></div>
            <div class="card workspace-card mt-4"><div class="card-body p-4 p-lg-5"><div class="section-heading"><div><h2 class="h4 font-weight-bold">پیمائش کی تاریخ</h2><p>ہر حقیقی تبدیلی کا پرانا اور نیا ریکارڈ محفوظ رہتا ہے۔</p></div><span class="badge badge-secondary px-3 py-2"><?php echo e($measurementHistories->count()); ?> ورژن</span></div>
                <div class="measurement-history-list">
                    <?php $__empty_1 = true; $__currentLoopData = $measurementHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <details class="measurement-history-item" <?php if($loop->first): ?> open <?php endif; ?>><summary><div><strong><?php echo e($historySourceLabels[$history->source] ?? 'محفوظ پیمائش'); ?></strong><small><?php echo e($history->created_at?->format('d-m-Y h:i A')); ?> · <?php echo e($history->recorder?->name ?: 'سسٹم'); ?> <?php if($history->template): ?>· <?php echo e($history->template->name); ?><?php endif; ?></small></div><span><?php echo e($history->values->count()); ?> خانے <i class="fas fa-chevron-down mr-1"></i></span></summary><div class="measurement-grid history-values"><?php $__currentLoopData = $history->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="measurement-item"><small><?php echo e($value->label); ?></small><strong><?php echo e($value->value); ?> <?php if(!in_array($value->unit, [null, '', 'none'], true)): ?><span><?php echo e($value->unit === 'inch' ? 'انچ' : ($value->unit === 'cm' ? 'سینٹی میٹر' : $value->unit)); ?></span><?php endif; ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></details>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state">اگلی پیمائش تبدیلی کے بعد تاریخ یہاں دکھائی جائے گی۔ موجودہ پیمائش محفوظ ہے۔</div><?php endif; ?>
                </div>
            </div></div>
        <?php endif; ?>

        <?php if($activeTab === 'profile'): ?>
            <div class="row"><div class="col-xl-8"><div class="card workspace-card"><div class="card-body p-4 p-lg-5"><div class="section-heading"><div><h2 class="h4 font-weight-bold">ذاتی معلومات</h2><p>تمام نظاموں میں استعمال ہونے والی مشترکہ شناخت</p></div><?php if($canManageMeasurements): ?><a class="btn btn-outline-primary" href="<?php echo e(route('admin.Customers.edit', $customer)); ?>">تبدیل کریں</a><?php endif; ?></div><div class="profile-details"><div><small>نام</small><strong><?php echo e($customer->name); ?></strong></div><div><small>فون نمبر</small><strong dir="ltr"><?php echo e($customer->phone_number1); ?></strong></div><div><small>گاہک نمبر</small><strong>#<?php echo e($customer->id); ?></strong></div><div><small>شامل ہونے کی تاریخ</small><strong><?php echo e($customer->created_at?->format('d-m-Y')); ?></strong></div><div class="wide"><small>نوٹ</small><strong><?php echo e($customer->note ?: 'کوئی نوٹ درج نہیں۔'); ?></strong></div></div></div></div></div></div>
        <?php endif; ?>
    </div>
</section>

<style>
    .customer-workspace{background:#f4f7fa;min-height:calc(100vh - 70px);color:#243b53}.customer-hero{background:linear-gradient(135deg,#102a43,#1769aa);color:#fff;border-radius:22px;padding:1.7rem 2rem;box-shadow:0 15px 35px rgba(16,42,67,.16)}
    .customer-hero h1{color:#fff!important}.customer-hero p{color:rgba(255,255,255,.78)}.customer-avatar{width:65px;height:65px;border-radius:19px;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:1.8rem;font-weight:800;margin-left:1rem;flex:0 0 auto}
    .customer-tabs{display:flex;gap:.55rem;overflow-x:auto;padding:.15rem}.customer-tab{display:flex;align-items:center;gap:.45rem;white-space:nowrap;padding:.7rem 1rem;border-radius:999px;border:1px solid #d7e2eb;background:#fff;color:#52667a;font-weight:700}.customer-tab:hover{text-decoration:none;border-color:#1769aa;color:#1769aa}.customer-tab.active{background:#1769aa;border-color:#1769aa;color:#fff;box-shadow:0 6px 16px rgba(23,105,170,.22)}
    .workspace-card{border:0;border-radius:18px;box-shadow:0 9px 26px rgba(31,45,61,.07);overflow:hidden}.profile-stat{height:100%;border:0;border-radius:17px;background:#fff;padding:1.25rem;box-shadow:0 8px 22px rgba(31,45,61,.07);display:flex;flex-direction:column;position:relative}.profile-stat small{display:block;color:#718096;line-height:1.9}.profile-stat strong{display:block;font-size:1.65rem;line-height:1.4;margin:.45rem 0}.profile-stat>span:last-child,.profile-stat a{font-size:.82rem;line-height:1.9;color:#718096}.profile-stat .stat-icon{position:absolute;left:1.1rem;top:1.1rem;width:39px;height:39px;border-radius:11px;background:#edf5fb;color:#1769aa;display:flex;align-items:center;justify-content:center}.profile-stat.balance{border-right:4px solid #1769aa}.profile-stat.paid{border-right:4px solid #20a06b}
    .section-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;margin-bottom:1.35rem}.section-heading h2,.section-heading p{margin-bottom:0}.section-heading h2{line-height:1.65}.section-heading p{color:#718096;font-size:.9rem;line-height:1.95;margin-top:.3rem}.activity-row{display:flex;align-items:center;gap:.75rem;padding:.85rem 0;border-bottom:1px solid #edf2f7}.activity-row:last-child{border-bottom:0}.activity-row small{display:block;color:#718096;line-height:1.9;margin-top:.15rem}.activity-icon{width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex:0 0 auto}.activity-icon.tailoring{background:#f0eafd;color:#7048b5}.activity-icon.shop{background:#e7f7ef;color:#198754}
    .empty-state{text-align:center;color:#718096;padding:2rem!important}.balance-pill{background:#e8f3fb;color:#1769aa;border-radius:999px;padding:.55rem .9rem;font-weight:800}.type-badge,.status-badge{display:inline-block;border-radius:999px;padding:.25rem .6rem;background:#edf2f7;font-size:.78rem;font-weight:700}.type-tailor{background:#f0eafd;color:#7048b5}.type-sale{background:#e7f7ef;color:#198754}.type-payment{background:#e8f3fb;color:#1769aa}
    .measurement-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:.8rem}.measurement-item{border:1px solid #dfe7f0;border-radius:14px;padding:1rem;background:#fbfdff}.measurement-item.custom{border-color:#cfe7d9;background:#f5fbf8}.measurement-item small,.measurement-item strong{display:block}.measurement-item small{color:#718096;line-height:1.9;margin-bottom:.35rem}.measurement-item strong{font-size:1.2rem;line-height:1.55}.measurement-item strong span{font-size:.75rem;color:#718096}.grid-full{grid-column:1/-1}
    .family-profile-selector{display:grid;grid-template-columns:minmax(260px,1fr) auto minmax(230px,auto);align-items:end;gap:1rem;padding:1rem;border:1px solid #dfe7f0;border-radius:14px;background:#fbfdff}.family-profile-field label{display:block;margin-bottom:.45rem;color:#52667a;font-weight:700}.family-profile-field .form-control{min-height:52px;border-color:#cdd9e5;border-radius:10px;background:#fff}.family-profile-submit{min-height:52px;white-space:nowrap}.family-profile-current{display:flex;align-items:center;gap:.7rem;min-height:52px;padding:.45rem .7rem;border-right:1px solid #dfe7f0}.family-profile-current small,.family-profile-current strong{display:block;line-height:1.7}.family-profile-current small{color:#718096}.family-profile-avatar{display:flex;align-items:center;justify-content:center;flex:0 0 42px;height:42px;border-radius:12px;background:#1769aa;color:#fff;font-size:1.15rem;font-weight:800}.family-profile-count{margin-right:auto;white-space:nowrap;color:#52667a;font-size:.76rem;font-weight:700}
    .measurement-history-item{border:1px solid #dfe7f0;border-radius:14px;background:#fff;margin-bottom:.75rem;overflow:hidden}.measurement-history-item summary{display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:1rem 1.1rem;cursor:pointer;list-style:none;background:#f8fafc}.measurement-history-item summary::-webkit-details-marker{display:none}.measurement-history-item summary small{display:block;color:#718096;margin-top:.2rem}.measurement-history-item summary>span{color:#52667a;font-size:.85rem;white-space:nowrap}.measurement-history-item[open] summary{border-bottom:1px solid #e4ebf1;background:#eef7fd}.history-values{padding:1rem}.history-values .measurement-item{background:#fff}
    .profile-details{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}.profile-details>div{border:1px solid #e1e8ef;border-radius:14px;padding:1rem}.profile-details small,.profile-details strong{display:block}.profile-details small{color:#718096;margin-bottom:.35rem}.profile-details .wide{grid-column:1/-1}
    .table thead th{border-top:0;background:#f7fafc;color:#627487;font-size:.8rem;white-space:nowrap}.table td{vertical-align:middle}.display-4{font-size:2.15rem}
    @media(max-width:991px){.family-profile-selector{grid-template-columns:1fr auto}.family-profile-current{grid-column:1/-1;border-right:0;border-top:1px solid #dfe7f0;padding-top:.8rem}}
    @media(max-width:767px){.customer-hero{padding:1.3rem}.customer-avatar{width:50px;height:50px}.profile-details{grid-template-columns:1fr}.profile-details .wide{grid-column:auto}.section-heading{align-items:flex-start;flex-direction:column}.family-profile-selector{grid-template-columns:1fr}.family-profile-submit{width:100%}.family-profile-current{grid-column:auto}.family-profile-count{white-space:normal}}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/customer/statement.blade.php ENDPATH**/ ?>