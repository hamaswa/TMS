<nav class="tms-print-toolbar" aria-label="پرنٹ سائز">
    <button type="button" class="tms-print-now" onclick="window.print()">ابھی پرنٹ کریں</button>
    <?php $__currentLoopData = $printConfig['paper_options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paperValue => $paperLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a
            href="<?php echo e(request()->fullUrlWithQuery(['paper' => $paperValue])); ?>"
            class="<?php echo e($printConfig['paper'] === $paperValue ? 'is-active' : ''); ?>"
            <?php if($printConfig['paper'] === $paperValue): ?> aria-current="page" <?php endif; ?>
        ><?php echo e($paperLabel); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button type="button" onclick="window.history.back()">واپس جائیں</button>
</nav>
<?php /**PATH E:\ITLinked\2026\TMS\resources\views/print/partials/toolbar.blade.php ENDPATH**/ ?>