<?php $__env->startSection('content'); ?>
<section class="main-content"><div class="container-fluid px-3 px-md-4" dir="rtl">
    <style>
        .reconciliation-hero{background:linear-gradient(135deg,#123a58,#176b65);border-radius:18px;color:#fff;padding:1.5rem}
        .reconciliation-card{border:0;border-radius:14px;box-shadow:0 8px 22px rgba(15,42,59,.07)}
        .status-dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-left:5px}
        .status-pending{background:#d39e00}.status-matched{background:#198754}.status-variance{background:#dc3545}
        .amount-ltr{direction:ltr;display:inline-block}
        @media(max-width:767px){.reconciliation-hero{padding:1.15rem}.reconciliation-actions .btn{display:block;width:100%;margin:.25rem 0!important}}
    </style>
    <div class="reconciliation-hero mb-3 d-flex flex-wrap align-items-center justify-content-between">
        <div><div class="small text-white-50 mb-1">آن لائن ادائیگیاں</div><h1 class="h3 mb-2">روزانہ ادائیگی مصالحت</h1><p class="mb-0 text-white-50">تصدیق شدہ رقم کو والٹ یا بینک کی روزانہ رپورٹ سے ملائیں۔ یہ عمل گاہک کے کھاتے میں دوبارہ رقم درج نہیں کرتا۔</p></div>
        <div class="reconciliation-actions mt-3 mt-md-0">
            <a class="btn btn-light ml-2" href="<?php echo e(route('admin.financial-reports.index')); ?>"><i class="fas fa-chart-line ml-1"></i> مالیاتی ڈیش بورڈ</a>
            <a class="btn btn-outline-light" href="<?php echo e(route('admin.payment-reconciliation.export', ['start_date'=>$report['period']['start'],'end_date'=>$report['period']['end'],'payment_method'=>$selectedMethod])); ?>"><i class="fas fa-file-csv ml-1"></i> CSV</a>
        </div>
    </div>

    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>

    <form class="card reconciliation-card card-body mb-3" method="GET" action="<?php echo e(route('admin.payment-reconciliation.index')); ?>">
        <div class="form-row align-items-end">
            <div class="form-group col-md-3 mb-md-0"><label for="start_date">شروع تاریخ</label><input id="start_date" type="date" name="start_date" value="<?php echo e($report['period']['start']); ?>" class="form-control" required></div>
            <div class="form-group col-md-3 mb-md-0"><label for="end_date">آخری تاریخ</label><input id="end_date" type="date" name="end_date" value="<?php echo e($report['period']['end']); ?>" class="form-control" required></div>
            <div class="form-group col-md-3 mb-md-0"><label for="payment_method_filter">ادائیگی کا طریقہ</label><select id="payment_method_filter" name="payment_method" class="form-control"><option value="">تمام دستی طریقے</option><?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>" <?php if($selectedMethod===$value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-3"><button class="btn btn-primary">رپورٹ دکھائیں</button> <a class="btn btn-light" href="<?php echo e(route('admin.payment-reconciliation.index')); ?>">موجودہ مہینہ</a></div>
        </div>
    </form>

    <div class="row mb-3">
        <?php $__currentLoopData = [
            ['تصدیق شدہ متوقع رقم',$report['summary']['expected_amount'],'primary'],
            ['فراہم کنندہ کی درج رقم',$report['summary']['actual_amount'],'info'],
            ['ابھی ملانے والی رقم',$report['summary']['outstanding_amount'],$report['summary']['outstanding_amount']==0?'success':'warning'],
            ['درست دن',$report['summary']['matched_days'],'success'],
            ['زیرِ انتظار دن',$report['summary']['pending_days'],'warning'],
            ['فرق والے دن',$report['summary']['variance_days'],'danger'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label,$amount,$color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-2 mb-2"><div class="card reconciliation-card h-100"><div class="card-body py-3"><small class="text-muted"><?php echo e($label); ?></small><div class="h5 text-<?php echo e($color); ?> mb-0"><?php if(str_contains($label,'رقم')): ?> روپے <?php echo e(number_format($amount,2)); ?> <?php else: ?> <?php echo e(number_format($amount)); ?> <?php endif; ?></div></div></div></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="alert alert-info">
        <strong>طریقہ:</strong> ہر تاریخ اور ادائیگی طریقے کے لیے TMS کی تصدیق شدہ رقم دیکھیں، پھر والٹ/بینک رپورٹ کی اصل رقم اور حوالہ درج کریں۔ صفر رقم درج کرنے پر وضاحتی نوٹ ضروری ہے۔ فرق درست ہونے تک ریکارڈ دوبارہ محفوظ کیا جا سکتا ہے؛ ہر تبدیلی کی تاریخ محفوظ رہتی ہے۔
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $report['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            $record = $row['reconciliation'];
            $statusLabel = ['pending'=>'زیرِ انتظار','matched'=>'مکمل درست','variance'=>'فرق موجود'][$row['status']];
            $statusClass = ['pending'=>'warning','matched'=>'success','variance'=>'danger'][$row['status']];
        ?>
        <article class="card reconciliation-card mb-3">
            <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center">
                <div><strong><?php echo e(\Carbon\Carbon::parse($row['date'])->format('d-m-Y')); ?> · <?php echo e($row['method_label']); ?></strong><div class="small text-muted"><?php echo e($row['expected_count']); ?> تصدیق شدہ ادائیگیاں</div></div>
                <span class="badge badge-<?php echo e($statusClass); ?>"><span class="status-dot status-<?php echo e($row['status']); ?>"></span><?php echo e($statusLabel); ?></span>
            </div>
            <div class="card-body">
                <?php if($row['snapshot_changed']): ?><div class="alert alert-warning">اس تاریخ کی تصدیق شدہ ادائیگیاں پچھلی مصالحت کے بعد تبدیل ہوئی ہیں۔ موجودہ رقم دوبارہ ملائیں۔</div><?php endif; ?>
                <div class="row mb-3">
                    <div class="col-md-3 mb-2"><small class="text-muted d-block">TMS متوقع رقم</small><strong class="amount-ltr">PKR <?php echo e(number_format($row['expected_amount'],2)); ?></strong></div>
                    <div class="col-md-3 mb-2"><small class="text-muted d-block">فراہم کنندہ رقم</small><strong class="amount-ltr">PKR <?php echo e(number_format($row['actual_amount'],2)); ?></strong></div>
                    <div class="col-md-3 mb-2"><small class="text-muted d-block">فرق</small><strong class="amount-ltr text-<?php echo e($row['variance_amount']==0?'success':'danger'); ?>">PKR <?php echo e(number_format($row['variance_amount'],2)); ?></strong></div>
                    <div class="col-md-3 mb-2"><small class="text-muted d-block">آخری مصالحت</small><strong><?php echo e($record?->reconciled_at?->format('d-m-Y h:i A') ?: '—'); ?></strong><?php if($record): ?><div class="small text-muted"><?php echo e($record->reconciler->name ?? $record->reconciler->username ?? 'سابق صارف'); ?> · <?php echo e($record->events_count); ?> اندراج</div><?php endif; ?></div>
                </div>
                <?php if($record?->external_reference): ?><div class="small mb-1"><strong>فراہم کنندہ حوالہ:</strong> <code><?php echo e($record->external_reference); ?></code></div><?php endif; ?>
                <?php if($record?->notes): ?><div class="small mb-3"><strong>نوٹ:</strong> <?php echo e($record->notes); ?></div><?php endif; ?>
                <?php if($record?->events->isNotEmpty()): ?>
                    <details class="mb-3">
                        <summary class="text-primary" style="cursor:pointer">تبدیلی کی مکمل تاریخ (<?php echo e($record->events_count); ?>)</summary>
                        <div class="table-responsive mt-2"><table class="table table-sm table-bordered bg-white mb-0">
                            <thead><tr><th>وقت / صارف</th><th>اس وقت متوقع</th><th>درج رقم</th><th>فرق</th><th>حوالہ / نوٹ</th></tr></thead>
                            <tbody><?php $__currentLoopData = $record->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr>
                                <td><?php echo e($event->reconciled_at->format('d-m-Y h:i A')); ?><br><small><?php echo e($event->reconciler->name ?? $event->reconciler->username ?? 'سابق صارف'); ?></small></td>
                                <td><span dir="ltr">PKR <?php echo e(number_format($event->expected_amount,2)); ?></span><br><small><?php echo e($event->expected_count); ?> ادائیگیاں</small></td>
                                <td dir="ltr">PKR <?php echo e(number_format($event->actual_amount,2)); ?></td>
                                <td dir="ltr">PKR <?php echo e(number_format($event->variance_amount,2)); ?></td>
                                <td><?php if($event->external_reference): ?><code><?php echo e($event->external_reference); ?></code><?php endif; ?> <?php if($event->notes): ?><div class="small"><?php echo e($event->notes); ?></div><?php endif; ?></td>
                            </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody>
                        </table></div>
                    </details>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('admin.payment-reconciliation.store')); ?>" class="border rounded p-3 bg-light">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="settlement_date" value="<?php echo e($row['date']); ?>">
                    <input type="hidden" name="payment_method" value="<?php echo e($row['method']); ?>">
                    <div class="form-row align-items-end">
                        <div class="form-group col-md-3 mb-md-0"><label>والٹ/بینک کی اصل رقم</label><input type="number" name="actual_amount" min="0" max="999999999999.99" step="0.01" class="form-control" value="<?php echo e(old('actual_amount', $record?->actual_amount ?? number_format($row['expected_amount'],2,'.',''))); ?>" required></div>
                        <div class="form-group col-md-3 mb-md-0"><label>سیٹلمنٹ / اسٹیٹمنٹ حوالہ</label><input type="text" name="external_reference" maxlength="100" class="form-control" dir="ltr" value="<?php echo e(old('external_reference',$record?->external_reference)); ?>"></div>
                        <div class="form-group col-md-4 mb-md-0"><label>وضاحتی نوٹ</label><input type="text" name="notes" maxlength="1000" class="form-control" value="<?php echo e(old('notes',$record?->notes)); ?>"></div>
                        <div class="col-md-2"><button class="btn btn-<?php echo e($record?'outline-primary':'primary'); ?> btn-block"><?php echo e($record ? 'دوبارہ ملائیں' : 'مصالحت محفوظ کریں'); ?></button></div>
                    </div>
                </form>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card reconciliation-card"><div class="card-body text-center py-5"><i class="fas fa-balance-scale fa-3x text-muted mb-3"></i><h2 class="h5">اس مدت میں تصدیق شدہ دستی ادائیگی موجود نہیں</h2><p class="text-muted mb-0">گاہک کی EasyPaisa، JazzCash، بینک یا Raast ادائیگی تصدیق ہونے کے بعد یہاں روزانہ مصالحت کے لیے نظر آئے گی۔</p></div></div>
    <?php endif; ?>
</div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ITLinked\2026\TMS\resources\views/storefront/admin/payment-reconciliation.blade.php ENDPATH**/ ?>